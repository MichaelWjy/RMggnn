### subroutines

def get_direc(pt0, pt1)
  dx = pt1[0] - pt0[0]
  dy = pt1[1] - pt0[1]

  return 0 if dx > 0
  return 1 if dy > 0
  return 2 if dx < 0
  return 3
end

def rot_n(pt, n)
  x, y = pt

  return [-y,  x] if n == 1
  return [-x, -y] if n == 2
  return [ y, -x] if n == 3
  [x, y]
end

def is_same?(pol0, pol1)
  return false if pol0.length != pol1.length

  d0 = get_direc(pol0[0], pol0[1])
  d1 = get_direc(pol1[0], pol1[1])
  rn = (d0 - d1 + 4) % 4

  pol2 = pol1.map{|pt| rot_n(pt, rn)}

  dx = pol0[0][0] - pol2[0][0] 
  dy = pol0[0][1] - pol2[0][1] 

  pol3 = pol2.map{|x, y| [x + dx, y + dy]}

  #p [pol0, pol3]
  pol0 == pol3
end

### main

loop do
  n = gets.to_i
  break if n == 0

  polys = []

  (n + 1).times do
    m = gets.to_i
    pol = m.times.map{gets.split.map(&:to_i)}
    polys << pol
  end

  tmpl = polys.shift
  #p tmpl
  #p polys

  for i in (0...n)
    poli = polys[i]
    if is_same?(tmpl, poli) || is_same?(tmpl, poli.reverse)
      puts (i + 1)
    end
  end
  puts '+++++'
end