def func arr
    new_arr = []
    prev = arr[0]
    arr[1..-1].each{|v|
        distance = (prev[0] - v[0]) ** 2 + (prev[1] - v[1]) ** 2
        direction = nil
        if prev[0] == v[0]
            direction = prev[1] < v[1] ? "y+" : "y-"
        else
            direction = prev[0] < v[0] ? "x+" : "x-"
        end
        new_arr << [distance, direction]
        prev = v
    }
    new_arr2 = [new_arr[0][0]]
    prev = new_arr[0]
    new_arr[1..-1].each{|v|
        direction = nil
        case prev[1]
        when "y+" then direction = v[1] == "x+" ? "r" : "l"
        when "y-" then direction = v[1] == "x-" ? "r" : "l"
        when "x+" then direction = v[1] == "y-" ? "r" : "l"
        when "x-" then direction = v[1] == "y+" ? "r" : "l"
        end
        new_arr2 << direction
        new_arr2 << v[0]
        prev = v
    }
    new_arr2
end

while true
    n = gets.to_i
    break if n == 0

    lines = Array.new(n + 1){[]}
    (n + 1).times{|i|
        m = gets.to_i
        m.times{lines[i] << gets.chomp.split.map(&:to_i)}
    }
    lines2 = lines.map{|arr| func(arr)}
    templates = [lines2[0]]
    templates << lines2[0].reverse.map{|x| x == "r" ? "l" : x == "l" ? "r" : x}
    match = []
    1.upto(n + 1){|i| match << i if templates.any?{|arr| arr == lines2[i]}}
    puts match
    puts "+" * 5
end

