def round(points)
  3.times.each_with_object([points]){ |_, obj| obj << obj[-1].map{ |p| [-p[1], p[0]] } }
end

def same(a, b)
  a.size == b.size && a.zip(b).map { |(xa, ya), (xb, yb)| [xb - xa, yb - ya] }.uniq.size == 1
end

while (n = gets.to_i) != 0
  target = gets.to_i.times.map{ gets.split.map(&:to_i) }
  cand = n.times.map{ gets.to_i.times.map{ gets.split.map(&:to_i) } }
  (1..n).each do |i|
    [target, target.reverse].flat_map{ |t| round(t) }.each do |t|
      if same(t, cand[i - 1])
        puts i
        break
      end
    end
  end
  puts '+++++'
end