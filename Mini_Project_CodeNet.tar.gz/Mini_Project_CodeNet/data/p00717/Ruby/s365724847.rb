include Math

def memo(m, xy)
    x1, y1 = xy[0]
    x2, y2 = xy[1]

    re = [[hypot(x2 - x1, y2 - y1)]]

    (m-2).times do |i|
        xn, yn = xy[i+2]

        case x2 <=> x1
        when -1
            j = yn > y2
        when 0
            j = !(y2 > y1) ^ (xn > x2)
        when 1
            j = yn < y2
        end
        
        re << [hypot(xn - x2, yn - y2), j]

        x1, y1 = x2, y2
        x2, y2 = xn, yn
    end
    re
end

loop do
    n = gets.to_i
    break if n == 0

    g1 = []
    g2 = []
    (n+1).times do |i|
        m = gets.to_i

        xy = []
        m.times {xy << gets.split.map(&:to_i)}

        if i == 0
            g1 << memo(m, xy)
            g1 << memo(m, xy.reverse)
        else
            g2 << memo(m, xy)
        end
    end

    ans = []
    g2.each_with_index {|g, i| ans << i + 1 if g == g1[0] || g == g1[1]}
    puts ans, "+++++"
end

