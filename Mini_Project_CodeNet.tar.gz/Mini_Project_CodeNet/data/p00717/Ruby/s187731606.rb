require 'matrix'

rot = Matrix[[0, -1], [1, 0]]

loop {
	n = gets.to_i
	break if n == 0

	polylines = []
	(n+1).times {
		m = gets.to_i
		polylines << (1..m).map { Vector[*gets.split.map(&:to_i)] }
	}
	
	polylines.map!{|points|
		origin = points[0]
		points.map!{|point|
			point - origin
		}
	}
	
	target = polylines[0]
	(1..n).each{|i|
		points = polylines[i]
		ok = false
		4.times {
			ok = true if target == points
			points.map!{|v| rot * v}
		}
		origin = points[-1]
		points.map!{|point|
			point - origin
		}
		points.reverse!
		4.times {
			ok = true if target == points
			points.map!{|v| rot * v}
		}
		puts i if ok
	}

	puts "+++++"
}