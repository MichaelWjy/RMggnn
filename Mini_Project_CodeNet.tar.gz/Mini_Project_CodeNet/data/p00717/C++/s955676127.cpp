#include <bits/stdc++.h>
using namespace std;
#define int long long
#define REP(i,n) for (int i = 0; i < (int)(n); ++i)
#define DEBUG(x) cerr << #x << " = " << x << endl

struct P {
  int x, y;
  bool operator <(const P& other) const {
    return tie(x, y) < tie(other.x, other.y);
  }
  bool operator ==(const P& other) const {
    return x == other.x && y == other.y;
  }
};

typedef vector<P> Poly;

void slide(Poly &poly) {
  int minX = poly[0].x;
  int minY = poly[0].y;
  REP(i,poly.size()) {
    minX = min(minX, poly[i].x);
    minY = min(minY, poly[i].y);
  }
  REP(i,poly.size()) {
    poly[i].x -= minX;
    poly[i].y -= minY;
  }
}

signed main() {
  while(true) {
    int N; cin >> N;
    if(N == 0) break;
    vector<Poly> VP(N + 1);
    REP(i,N + 1) {
      int M; cin >> M;
      REP(j,M) {
        int x, y; cin >> x >> y;
        P p;
        p.x = x;
        p.y = y;
        VP[i].push_back(p);
      }
    }
    slide(VP[0]);
    for(int n = 1; n <= N; ++n) {
      bool same = false;
      Poly poly = VP[n];
      REP(r,4) {
        slide(poly);
        if(poly == VP[0]) same = true;
        reverse(poly.begin(), poly.end());
        if(poly == VP[0]) same = true;
        reverse(poly.begin(), poly.end());
        REP(i,poly.size()) {
          int x = poly[i].x;
          int y = poly[i].y;
          poly[i].x = -y;
          poly[i].y = x;
        }
      }
      if(same) cout << n << endl;
    }
    cout << "*****" << endl;
  }
}