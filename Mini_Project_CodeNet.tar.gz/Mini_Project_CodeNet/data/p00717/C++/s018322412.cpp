#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <string>
#include <vector>
#include <queue>
#include <map>
#include <set>
#include <algorithm>

#define FOR(i,k,n) for (int i=(k); i<(int)(n); ++i)
#define REP(i,n) FOR(i,0,n)
#define FORIT(i,c) for(__typeof((c).begin())i=(c).begin();i!=(c).end();++i)
#define sz size()
#define pb push_back
#define mp make_pair
#define ALL(X) (X).begin(),(X).end()

using namespace std;

const int INF = 1000000000;
const double eps = 1e-8;

int main(void) {
  for(;;) {
    int n;
    cin>>n;
    if(n == 0)
      break;
    int m;
    cin>>m;
    vector<vector<pair<int,int>>> line(4,vector<pair<int,int>>(m));
    REP(i,m) {
      int x,y;
      cin>>x>>y;
      line[0][i] = make_pair(x,y);
      line[1][i] = make_pair(-y,x);
      line[2][i] = make_pair(-x,-y);
      line[3][i] = make_pair(y,-x);
    }
    REP(i,4) {
      int xm = INF;
      int ym = INF;
      REP(j,m) {
        xm=min(xm,line[i][j].first);
        ym=min(ym,line[i][j].second);
      }
      REP(j,m) {
        line[i][j].first -= xm;
        line[i][j].second -= ym;
      }
    }
    REP(i,n) {
      int m;
      cin>>m;
      vector<pair<int,int>> rhs(m);
      int xm = INF;
      int ym = INF;
      REP(j,m) {
        int x,y;
        cin>>x>>y;
        xm=min(xm,x);
        ym=min(ym,y);
        rhs[j] = make_pair(x,y);
      }
      REP(j,m) {
        rhs[j].first -= xm;
        rhs[j].second -= ym;
      }
      REP(j,4) {
        bool f1 = true;
        bool f2 = true;
        REP(k,m) {
          if(line[j][k] != rhs[k]) {
            f1 = false;
          }
          if(line[j][k] != rhs[m-k-1]) {
            f2 = false;
          }
        }
        if(f1 || f2) {
          cout<<(i+1)<<endl;
          break;
        }
      }
    }
    cout<<"+++++"<<endl;
  }
  return 0;
}