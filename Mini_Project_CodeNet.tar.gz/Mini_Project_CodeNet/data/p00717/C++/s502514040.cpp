#include<iostream>
#include<algorithm>
#include<vector>
#define X first
#define Y second
using namespace std;
int n,m;
vector<pair<int,int> > v,s;

bool IsSame(){
	bool ok=true;
	int sx=v[0].X-s[0].X,sy=v[0].Y-s[0].Y;
	for(int i=1;i<m;i++){
		if(v[i].X-s[i].X==sx&&v[i].Y-s[i].Y==sy){}
		else ok=false;
	}
	if(ok)return true;
	
	ok=true;
	sx=v[0].X-s[m-1].X,sy=v[0].Y-s[m-1].Y;
	for(int i=1;i<m;i++){
		if(v[i].X-s[m-1-i].X==sx&&v[i].Y-s[m-1-i].Y==sy){}
		else ok=false;
	}
	if(ok)return true;
	
	return false;
}

bool Solve(){
	cin>>m;
	if(m!=v.size())return false;
	s.clear();
	for(int i=0;i<m;i++){
		int x,y;cin>>x>>y;
		s.push_back(make_pair(x,y));
	}
	if(IsSame())return true;
	for(int i=0;i<m;i++)s[i].X=-s[i].X,s[i].Y=-s[i].Y;
	if(IsSame())return true;
	for(int i=0;i<m;i++){
		int t=s[i].X;
		s[i].X=s[i].Y;
		s[i].Y=-t;
	}
	if(IsSame())return true;
	for(int i=0;i<m;i++)s[i].X=-s[i].X,s[i].Y=-s[i].Y;
	if(IsSame())return true;
	
	return false;
}

int main(){
	while(cin>>n&&n){
	cin>>m;
	while(m--){
		int x,y;cin>>x>>y;
		v.clear();
		v.push_back(make_pair(x,y));
	}
	for(int i=1;i<=n;i++){
		if(Solve())cout<<i<<endl;
	}
	cout<<"+++++"<<endl;
}
	return 0;
}