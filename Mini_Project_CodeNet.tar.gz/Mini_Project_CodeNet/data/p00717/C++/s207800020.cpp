#include <bits/stdc++.h>
using namespace std;

#define INF_LL (int64)1e18
#define INF (int32)1e9
#define REP(i, n) for(int i = 0;i < (n);i++)
#define FOR(i, a, b) for(int i = (a);i < (b);i++)
#define all(x) x.begin(),x.end()
#define fs first
#define sc second

using int32 = int_fast32_t;
using uint32 = uint_fast32_t;
using int64 = int_fast64_t;
using uint64 = uint_fast64_t;
using PII = pair<int32, int32>;
using PLL = pair<int64, int64>;

const double eps = 1e-6;

template<typename A, typename B>inline void chmin(A &a, B b){if(a > b) a = b;}
template<typename A, typename B>inline void chmax(A &a, B b){if(a < b) a = b;}

const int64 mod = 1e9+7;

PLL rot(PLL x){
	PLL ret;
	ret.fs = x.fs*0+x.sc*(-1);
	ret.sc = x.fs*1+x.sc*0;
	return ret;
}

int main(void){
	int32 N;
	while(cin >> N && N){
		int32 m;
		cin >> m;
		vector<PLL> base(m), b1(m), b2(m);
		REP(i, m) cin >> base[i].fs >> base[i].sc;
		for(int32 i = m-1;i >= 0;i--){
			b1[i].fs = base[i].fs-base[0].fs; b1[i].sc = base[i].sc-base[0].sc;
			b2[i].fs = base[m-i-1].fs-base[m-1].fs; b2[i].sc = base[m-i-1].sc-base[m-1].sc;
		}
		REP(i, N){
			cin >> m;
			vector<PLL> a(m);
			REP(j, m) cin >> a[j].fs >> a[j].sc;
			if(m != base.size()) continue;
			for(int32 j = m-1;j >= 0;j--){ a[j].fs -= a[0].fs; a[j].sc -= a[0].sc; }
			REP(k, 4){
				bool ok = 1, ok2 = 1;
				REP(j, m) a[j] = rot(a[j]);
				REP(j, m){
					ok = ok&(a[j] == b1[j]);
					ok2 = ok2&(a[j] == b2[j]);
				}
				if(ok || ok2){
					cout << i+1 << endl;
					break;
				}
			}
		}
		cout << "+++++" << endl;
	}
}
