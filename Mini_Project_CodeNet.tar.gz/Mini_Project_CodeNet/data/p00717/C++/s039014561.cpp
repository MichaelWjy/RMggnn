#include <bits/stdc++.h>
using namespace std;
#define int long long   // <-----!!!!!!!!!!!!!!!!!!!

#define rep(i,n) for (int i=0;i<(n);i++)
#define rep2(i,a,b) for (int i=(a);i<(b);i++)
#define rrep(i,n) for (int i=(n)-1;i>=0;i--)
#define rrep2(i,a,b) for (int i=(a)-1;i>=b;i--)
#define chmin(a,b) (a)=min((a),(b));
#define chmax(a,b) (a)=max((a),(b));
#define all(a) (a).begin(),(a).end()
#define rall(a) (a).rbegin(),(a).rend()
#define printV(v) cerr<<(#v)<<":";for(auto(x):(v)){cerr<<" "<<(x);}cerr<<endl;
#define printVS(vs) cerr<<(#vs)<<":"<<endl;for(auto(s):(vs)){cerr<<(s)<< endl;}
#define printVV(vv) cerr<<(#vv)<<":"<<endl;for(auto(v):(vv)){for(auto(x):(v)){cerr<<" "<<(x);}cerr<<endl;}
#define printP(p) cerr<<(#p)<<(p).first<<" "<<(p).second<<endl;
#define printVP(vp) cerr<<(#vp)<<":"<<endl;for(auto(p):(vp)){cerr<<(p).first<<" "<<(p).second<<endl;}

inline void output(){ cerr << endl; }
template<typename First, typename... Rest>
inline void output(const First& first, const Rest&... rest) {
    cerr << first << " "; output(rest...);
}

using ll = long long;
using Pii = pair<int, int>;
using TUPLE = tuple<int, int, int>;
using vi = vector<int>;
using vvi = vector<vi>;
using vvvi = vector<vvi>;
const int inf = 1ll << 60;
const int mod = 1e9 + 7;
using Graph = vector<vector<int>>;

int n, m0, m;
vector<Pii> vp0, vp;

void trans() {
    int dx = vp[0].first - vp0[0].first;
    int dy = vp[0].second - vp0[0].second;
    for (auto& p : vp0) {
        p = Pii(p.first + dx, p.second + dy);
    }
}


void rot() {
    for (auto& p : vp0) {
        p = Pii(p.second, -p.first);
    }
}

bool check() {
    rep(k, 4) {
        trans();
        if (vp0 == vp) return true;
        reverse(all(vp0));
        trans();
        if (vp0 == vp) return true;
        rot();
    }
    return false;
}

signed main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(0);

    int n;
    while (cin >> n, n) {
        cin >> m0;
        vp0.clear();
        vp0.resize(m0);
        rep(i, m0) cin >> vp0[i].first >> vp0[i].second;

        rep(i, n) {
            cin >> m;
            vp.clear();
            vp.resize(m);
            rep(i, m0) cin >> vp[i].first >> vp[i].second;
            if (check()) cout << i + 1 << endl;
        }
        cout << "+++++" << endl;
    }
}