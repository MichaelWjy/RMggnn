#include <bits/stdc++.h>
using namespace std;

#define fi first
#define se second
#define repl(i,a,b) for(int i=(int)(a);i<(int)(b);i++)
#define rep(i,n) repl(i,0,n)
#define each(itr,v) for(auto itr:v)
#define pb(s) push_back(s)
#define mp(a,b) make_pair(a,b)
#define all(x) (x).begin(),(x).end()
#define dbg(x) cout<<#x"="<<x<<endl
#define maxch(x,y) x=max(x,y)
#define minch(x,y) x=min(x,y)
#define uni(x) x.erase(unique(all(x)),x.end())
#define exist(x,y) (find(all(x),y)!=x.end())
#define bcnt(x) bitset<32>(x).count()

typedef long long ll;
typedef unsigned long long ull;


#define INF INT_MAX/3

#define MAX_N 1000

//// definition of point
double EPS=1e-10;
double add(double a,double b){
	if(abs(a+b)<EPS*(abs(a)+abs(b)))return 0;
	return a+b;
}
struct P
{
	double x,y;
	P(){}
	P(double x, double y):x(x),y(y){}
	P operator + (P p){
		return P(add(x,p.x),add(y,p.y));
	}
	P operator - (P p){
		return P(add(x,-p.x),add(y,-p.y));
	}
	P operator * (double d){
		return P(x*d,y*d);
	}
	double dot(P p){
		return add(p.x*x,p.y*y);
	}
	double cross(P p){
		return add(x*p.y,-y*p.x);
	}
	double norm(){
		return x*x+y*y;
	}
	double abs(){
		return sqrt(norm());
	}
};

//// counter-clockwise
int ccw(P a, P b, P c) {
  b =b-a; c =c-a;
  if (b.cross(c) > 0)   return +1;       // counter clockwise
  if (b.cross(c) < 0)   return -1;       // clockwise
  if (b.dot(c) < 0)     return +2;       // c--a--b on line
  if (b.norm() < c.norm()) return -2;       // a--b--c on line
  return 0;
}

//// distance of two points
double dist(P a,P b){
	return (a-b).abs();
}

int n;

int main(){
	cin.sync_with_stdio(false);
	while(1){
		cin>>n;
		if(n==0)break;
		vector<int> res;
		vector<pair<int,int> > dat[55],rdat[55];
		vector<P> ps[55];
		rep(i,n+1){
			int m;
			cin>>m;
			rep(j,m){
				double x,y;
				cin>>x>>y;
				ps[i].pb(P(x,y));
			}
			dat[i].pb(mp(dist(ps[i][0],ps[i][1]),-INF));
			rep(j,m-2){
				dat[i].pb(mp(dist(ps[i][j+1],ps[i][j+2]),ccw(ps[i][j],ps[i][j+1],ps[i][j+2])));
			}
			reverse(all(ps[i]));
			rdat[i].pb(mp(dist(ps[i][0],ps[i][1]),-INF));
			rep(j,m-2){
				rdat[i].pb(mp(dist(ps[i][j+1],ps[i][j+2]),ccw(ps[i][j],ps[i][j+1],ps[i][j+2])));
			}
		}
		repl(i,1,n+1){
			if(dat[i]==dat[0]||rdat[i]==dat[0])res.pb(i);
		}
		rep(i,res.size())cout<<res[i]<<endl;
		cout<<"+++++"<<endl;
	}
	return 0;
}