#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef pair<int,int> P;
typedef vector<int> VI;
 
template<class T> bool chmax(T &a, const T &b) { if (a<b) { a=b; return 1; } return 0; }
template<class T> bool chmin(T &a, const T &b) { if (a>b) { a=b; return 1; } return 0; }
#define _overload3(_1,_2,_3,name,...) name
#define _rep(i,n) repi(i,0,n)
#define repi(i,a,b) for(int i=int(a);i<int(b);++i)
#define rep(...) _overload3(__VA_ARGS__,repi,_rep,)(__VA_ARGS__)
#define all(x) (x).begin(),(x).end()
const int mod=1e9+7;

bool isSame(vector<P> a,vector<P> b){
    int sz=a.size();
    rep(i,4){
        rep(j,sz){
            if((a[j].first!=b[j].first)||(a[j].second!=b[j].second))break;
            if(j==(sz-1))return true;
        }
        if(i==3) return false;
        rep(j,sz){
            int x=b[j].first;
            int y=b[j].second;
            b[j].first=-y;
            b[j].second=x;
        }
    }
}

int main(){
    while(true){
        int n;cin>>n;
        if(n==0)break;
        int m;cin>>m;
        vector<P> ori(m);
        rep(i,m)cin>>ori[i].first>>ori[i].second;
        vector<P> inv(m);
        rep(i,m){
            inv[i].first=ori[i].first;
            inv[i].second=ori[i].second;
        }
        rep(i,m){
            ori[m-1-i].first-=ori[0].first;
            ori[m-1-i].second-=ori[0].second;
            inv[i].first-=inv[m-1].first;
            inv[i].second-=inv[m-1].second;
        }
        reverse(all(inv));
        rep(i,n){
            int l;cin>>l;
            vector<P> q(l);
            rep(i,l)cin>>q[i].first>>q[i].second;
            if(l!=m)continue;
            rep(i,l){
                q[l-1-i].first-=q[0].first;
                q[l-1-i].second-=q[0].second;
            }
            if(isSame(q,ori)||isSame(q,inv))cout<<i+1<<endl;
        }
        cout<<"+++++"<<endl;
    }
}            


