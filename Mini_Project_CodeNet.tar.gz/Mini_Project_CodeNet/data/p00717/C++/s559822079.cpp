#include<iostream>
#include<cstring>
using namespace std;

#define MAX_N 1355

int x[MAX_N][4], y[MAX_N][4];
int X[MAX_N][MAX_N], Y[MAX_N][MAX_N];
int n, m, M ,cnt;

int main() {
	while (true) {
		if (cnt >= 1) { cout << "+++++" << endl; }
		cnt++;
		memset(x, 0, sizeof(x));
		memset(y, 0, sizeof(y));
		memset(X, 0, sizeof(X));
		memset(Y, 0, sizeof(Y));
		cin >> n;
		if (n == 0) { break; }
		cin >> M;
		for (int i = 0; i < M; i++) {
			cin >> x[i][0] >> y[i][0];
		}
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < M; j++) {
				x[j][i + 1] = -y[j][i];
				y[j][i + 1] = x[j][i];
			}
		}
		for (int i = 1; i <= n; i++) {
			cin >> m;
			for (int j = 0; j < m; j++) {
				cin >> X[i][j] >> Y[i][j];
			}
			int same = 8;
			if (M != m) { same = 0; }
			else {
				for (int j = 0; j < 4; j++) {
					int X1 = x[0][j] - X[i][0], Y1 = y[0][j] - Y[i][0];
					for (int k = 1; k < M; k++) {
						if ((x[k][j] - X[i][k] != X1 || y[k][j] - Y[i][k] != Y1) && same == 8 - j) {
							same--;
						}
					}
				}
				for (int j = 0; j < 4; j++) {
					int X1 = x[0][j] - X[i][M - 1], Y1 = y[0][j] - Y[i][M - 1];
					for (int k = 1; k < M; k++) {
						if ((x[k][j] - X[i][M - 1 - k] != X1 || y[k][j] - Y[i][M - 1 - k] != Y1) && same == 4 - j) {
							same--;
						}
					}
				}
			}
			if (same >= 1) { cout << i << endl; }
		}
	}
	return 0;
}