#include <iostream>
#include <string>
#include <map>
#include <vector>
#include <set>
#include <iomanip>
#include <stack>
#include <fstream>
#include <cstdint>
#include <cmath>
#include <algorithm>
#include <utility>
#include <numeric>
#include <functional>

using namespace std;
typedef int64_t ll;

pair<int, int> rot0(pair<int, int> xy){
    return xy;
};

pair<int,int> rot90(pair<int, int> xy){
    return {-xy.second, xy.first};
};

pair<int,int> rot180(pair<int, int> xy){
    return {-xy.first, -xy.second};
};
pair<int,int> rot270(pair<int, int> xy){
    return {xy.second, -xy.first};
};

void input(vector<pair<int, int>>& sn){
    int m;
    cin >> m;
    int cx, cy;
    cin >> cx >> cy;
    sn.push_back({0, 0});
    int x, y;
    cin >> x >> y;
    auto rt = rot0;
    if(x - cx != 0){
        if(x - cx < 0) rt = rot180;
    }
    else{
        if(y - cy > 0) rt = rot270;
        else rt = rot90;
    }
    sn.push_back(rt({x-cx, y-cy}));
    for (int i = 2; i < m; ++i) {
        cin >> x >> y;
        sn.push_back(rt({x-cx, y-cy}));
    }
}

template<class T>
ostream& operator<<(ostream& os, const vector<T>& x){
    for(auto&& t: x)
        os << t << ' ';
    return os;
}

ostream& operator<<(ostream& os, const pair<int, int>& px){
    return os << '(' << px.first << ", " << px.second << ')';
}

void rev(const vector<pair<int, int>>& sn, vector<pair<int, int>>& rn){
    auto st = sn.back();
    int cx, cy, x, y;
    cx = st.first;
    cy = st.second;
    rn.push_back({0,0});
    st = sn[sn.size()-2];
    x = st.first;
    y = st.second;
    auto rt = rot0;
    if(x - cx != 0){
        if(x - cx < 0) rt = rot180;
    }
    else{
        if(y - cy > 0) rt = rot270;
        else rt = rot90;
    }
    rn.push_back(rt({x-cx, y-cy}));
    for (int i = sn.size() - 3; i >= 0; --i) {
        st = sn[i];
        x = st.first;
        y = st.second;

        rn.push_back(rt({x-cx, y-cy}));
    }
}


int main() {
    cin.tie(0);
    ios::sync_with_stdio(false);

    int n;
    while(true){
        cin >> n;
        if(n == 0) break;
        vector<int> ans;
        vector<pair<int, int>> sn, snr;
        input(sn);
        rev(sn, snr);
//        cout << "sn :: " << sn << endl;
//        cout << "snr :: " << snr << endl;

        for (int i = 0; i < n; ++i) {
            vector<pair<int, int>> inn;
            input(inn);
//            cout << "inn :: " << inn << endl;
            if(inn.size() == sn.size()){
                bool can = true;
                bool rcan = true;
                for (int j = 0; j < sn.size(); ++j) {
                    if(can && inn[j] != sn[j]){
                        can = false;
                    }
                    if(rcan && inn[j] != snr[j]){
                        rcan = false;
                    }
                    if(!can && !rcan) break;
                }
                if(can || rcan) ans.push_back(i+1);
            }
        }

        for (auto &&a  : ans) {
            cout << a << '\n';
        }
        cout << "+++++" << endl;
    }
}

