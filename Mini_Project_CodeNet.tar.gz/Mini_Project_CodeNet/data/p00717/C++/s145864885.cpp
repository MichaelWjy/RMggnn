#include <bits/stdc++.h>
using namespace std;
const int MAX_N=55,MAX_M=11;

int n,ok;
int m[MAX_N];
vector<vector<int>> x(MAX_N,vector<int>(MAX_M))
                    ,y(MAX_N,vector<int>(MAX_M));

void translate(int p){
    for (int i=1;i<m[p];++i)
        x[p][i]-=x[p][0],y[p][i]-=y[p][0];
    x[p][0]=y[p][0]=0;
}

void rotate(int p){
    if (x[p][1]>0) return;
    else if (x[p][1]<0){
        for (int i=0;i<m[p];++i)
            x[p][i]*=-1,y[p][i]*=-1;
    } else if (y[p][1]>0){
        for (int i=0;i<m[p];++i){
            swap(x[p][i],y[p][i]);
            y[p][i]*=-1;
        }
    } else {
        for (int i=0;i<m[p];++i){
            swap(x[p][i],y[p][i]);
            x[p][i]*=-1;
        }
    }
}

void solve(){
    translate(0); rotate(0);
    for (int i=1;i<=n;++i){
        if (m[i]!=m[0]) continue;
        translate(i); rotate(i);
        ok=0;
        for (int j=0;j<m[0];++j){
            if (x[i][j]!=x[0][j]||y[i][j]!=y[0][j]) break;
            if (j==m[0]-1){cout << i << '\n'; ok=1;}
        }
        if (ok) continue;
        reverse(x[i].begin(),x[i].begin()+m[i]);
        reverse(y[i].begin(),y[i].begin()+m[i]);
        translate(i); rotate(i);
        for (int j=0;j<m[0];++j){
            if (x[i][j]!=x[0][j]||y[i][j]!=y[0][j]) break;
            if (j==m[0]-1){cout << i << '\n';}
        }
    }
}

int main(){
    cin.tie(0);
    ios::sync_with_stdio(false);
    while(cin >> n,n){
        for (int i=0;i<=n;++i){
            cin >> m[i];
            for (int j=0;j<m[i];++j)
                cin >> x[i][j] >> y[i][j];
        }
        solve();
        cout << "+++++" << '\n';
    }
}
