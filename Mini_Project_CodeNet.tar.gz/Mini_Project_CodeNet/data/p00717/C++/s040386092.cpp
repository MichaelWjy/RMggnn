#include <stdio.h>
#include <string.h>
#define MV 0x7FFFFFFF

int main(void){
	int i, j, k, l, m[51], n, p, x[4][51][10], y[4][51][10], sum, minx, miny, tmpx, tmpy, flag[51];
	while(1){
		scanf("%d",&n);
		if(n == 0)
			break;
		for(i = 0;i <= n;i++){
			scanf("%d",&m[i]);
			minx = MV, miny = MV;
			for(j = 0;j < m[i];j++){
				scanf("%d%d",&x[0][i][j],&y[0][i][j]);
				if(x[0][i][j] < minx)
					minx = x[0][i][j];
				if(y[0][i][j] < miny)
					miny = y[0][i][j];
			}
			for(j = 0;j < m[i];j++){
				x[0][i][j] = x[0][i][j] - minx;
				y[0][i][j] = y[0][i][j] - miny;
			}
			for(j = 0;j < 3;j++){
				for(k = 0;k < m[i];k++){
					x[j + 1][i][k] = -y[j][i][k];
					y[j + 1][i][k] = x[j][i][k];
				}
			}
		}
		memset(flag,0,sizeof(flag));
		for(i = 1;i <= n;i++){
			if(m[0] == m[i]){
				for(k = 0;k < 4;k++){
					for(l = 0;l < 4;l++){
						tmpx = x[k][0][0] - x[l][i][0];
						tmpy = y[k][0][0] - y[l][i][0];
						for(p = 1;p < m[0];p++){
							if(tmpx != x[k][0][p] - x[l][i][p] || tmpy != y[k][0][p] - y[l][i][p])
								break;
						}
						if(p == m[0]){
							flag[0] = flag[i] = 1;
							break;
						}
						tmpx = x[k][0][0] - x[l][i][m[i] - 1];
						tmpy = y[k][0][0] - y[l][i][m[i] - 1];
						for(p = 1;p < m[i];p++){
							if(tmpx != x[k][0][p] - x[l][i][m[0] - 1 - p] || tmpy != y[k][0][p] - y[l][i][m[0] - 1 - p])
								break;
						}
						if(p == m[0]){
							flag[i] = 1;
							break;
						}
					}						
					if(l != 4)
						break;
				}
			}
		}
		sum = 0;
		for(i = 1;i <= n;i++)
			if(flag[i]) printf("%d\n",i);
		printf("+++++\n");
	}
	return 0;
}