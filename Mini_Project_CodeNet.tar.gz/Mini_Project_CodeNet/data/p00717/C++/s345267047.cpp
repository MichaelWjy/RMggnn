#include <bits/stdc++.h>

using namespace std;
#define ll long long

#define rep(i, a) for (int (i) = 0; (i) < (int) (a); (i)++)
#define reps(i, a, b) for (int (i) = (int) (a); (i) < (int) (b); (i)++)
#define rrep(i, a) for (int (i) = (int) a-1; (i) >= 0; (i)--)
#define rreps(i, a, b) for (int (i) = (int) (a)-1; (i) >= (int) (b); (i)--)
#define MP(a, b) make_pair((a), (b))
#define PB(a) push_back((a))
#define all(v) (v).begin(), (v).end()
#define PERM(v) next_permutation(all(v))
#define UNIQUE(v) sort(all(v));(v).erase(unique(all(v)), v.end())
#define CIN(type, x) type x;cin >> x
#define TRUE__ "Yes"
#define FALSE__ "No"
#define PRINT(f) if((f)){cout << (TRUE__) << endl;}else{cout << FALSE__ << endl;}

#ifdef LOCAL
#define lcout(a) cout << a;
#define lcoutln(a) cout << a << endl;
#define lcerr(a) cerr << a;
#define lcerrln(a) cerr << a << endl;
#else
#define lcout(a) 
#define lcoutln(a) 
#define lcerr(a) 
#define lcerrln(a) 
#endif

int N;
vector<vector<pair<int, int> > > ans(8);

void rot(vector<pair<int, int> >& ori, vector<pair<int, int> >& to)
{
	rep(i, ori.size()) {
		auto p = ori[i];
		int x = p.first;
		int y = p.second;
		to.PB(MP(y, -x));
	}
}

signed main()
{
	cin >> N;
	while (N) {
		int M;
		cin >> M;
		auto& vt1 = ans[0];
		auto& vt2 = ans[4];
		rep(i, M) {
			CIN(int, x);
			CIN(int, y);
			vt1.PB(MP(x, y));
			vt2.PB(MP(x, y));
		}
		reverse(all(vt2));
		rrep(i,M) {
			vt1[i].first -= vt1[0].first;
			vt1[i].second -= vt1[0].second;
			vt2[i].first -= vt2[0].first;
			vt2[i].second -= vt2[0].second;
		}
		reps(i, 1, 4) {
			rot(ans[i-1], ans[i]);
			rot(ans[i+3], ans[i+4]);
		}
		rep(i, N) {
			cin >> M;
			int ox, oy;
			cin >> ox >> oy;
			vector<pair<int, int> > vv;
			vv.PB(MP(0, 0));
			rep(j, M-1) {
				CIN(int, x);
				CIN(int, y);
				vv.PB(MP(x-ox, y-oy));
			}
			rep(j, 8) {
				int  k = 0;
				int en = (int) ans[j].size();
				if ((int) vv.size() != en) break;
				for (; k < en; k++) {
					if (ans[j][k].first != vv[k].first || ans[j][k].second != vv[k].second) {
						break;
					}
				}
				if (k == en) {
					cout << i+1 << endl;
					break;
				}
			}
		}
		cout << "+++++" << endl;
		rep(i, 8) ans[i].clear();
		cin >> N;
	}
}

