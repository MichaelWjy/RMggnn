#include <iostream>
#include <cstdio>
#include <cassert>
#include <algorithm>
#include <complex>
#include <vector>
#include <cmath>
using namespace std;

#define EPS 1e-7
#define INF 360
#define PI M_PI


int N, M;

typedef complex<double> Point;

namespace std{
	bool operator < (const Point &a, const Point &b){
		return real(a) != real(b) ? real(a) < real(b) : imag(a) < imag(b);
	}
	Point operator / (const Point &p, const double &a){
		return Point(real(p)/a, imag(p)/a);
	}
	Point operator * (const Point &p, const double &a){
		return Point(real(p) * a, imag(p)*a);
	}
	bool operator == (const Point &a, const Point &b){
		return real(a) == real(b) && imag(a) == imag(b);
	}
}
struct Line : public vector<Point>{
	Line(){}
	Line (const Point &a, const Point &b){
		push_back(a); push_back(b);
	}
};

double distancePP(const Point &a, const Point &b){
	return abs(a-b);
}

double cross(const Point &a, const Point &b){
	return imag(conj(a)*b);
}

double dot(const Point &a, const Point &b){
 return real(conj(a) * b);
}



int main(void){
	int n,m;
	int x, y, px, py;
	double d, pd;
	while(cin >> n , n){
		vector<vector<double> > lines(n+1);
		vector<vector<int> > dists(n+1);
		for(int i = 0; i <= n; i++){
			cin >> m;
			for(int j = 0; j < m; j++){
				cin >> x >> y;
        if (j == 0){
        }else{
          d = (x == px ? y-py : x-px);
          lines[i].push_back(distancePP(Point(px,py), Point(x,y)));
          if (j != 1) {
          	int f;
            if (x == px) {
              f = ( pd * d > 0 ?  1 : -1 );
            } else {
              f = ( pd * d > 0 ? -1 :  1 );
            }
            dists[i].push_back(f);
          }
        }
        px = x; py = y; pd = d;
      }
		}
		for(int i = 1; i < lines.size(); i++){
//printf("line [%d %d] dists[%d %d]\n", lines[i].size(), lines[n].size(), dists[i].size(), dists[n].size());
			if(lines[i].size() != lines[0].size() || dists[i].size() != dists[0].size()) continue;
			int f = 1;
			for(int j = 0; j < lines[i].size(); j++){
//				cout << "lines : " << lines[i][j] << ":" << lines[0][j] << endl;
				if(lines[i][j] != lines[0][j]) f = 0;
			}
			for(int j = 0; j < dists[i].size(); j++){
//				cout << "dists : " << dists[i][j] << ":" << dists[0][j] << endl;
				if(dists[i][j] != dists[0][j]) f = 0;
			}
			if(f){ cout << i << endl; continue;}
			f = 1;
			for(int j = 0; j < lines[i].size(); j++){
				if(lines[i][j] != lines[0][lines[i].size()-1-j]) f = 0;
			}
			for(int j = 0; j < dists[i].size(); j++){
				if(dists[i][j] != dists[0][dists[i].size()-1-j] * -1) f = 0;
			}
			if(f){ cout << i << endl; continue;}
		}
		cout << "++++++" << endl;
	}
	return 0;
}