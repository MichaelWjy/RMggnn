#include<complex>
#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#define REP(i,s,n) for(int i=s;i<n;i++)
#define rep(i,n) REP(i,0,n)
#define EPS 1e-10
using namespace std;




typedef complex<double> P;
const double rad[4] ={0.0,M_PI/2,M_PI,-M_PI/2};
int main(){
  int n,m[110],x,y;
  double st,ed;
  P p[60][15];
  while(cin >> n && n){
    rep(i,n+1){
      cin >> m[i];
      rep(j,m[i]){
	cin >> x >> y; 
	p[i][j] = P((double)x,(double)y);

	if(j == 1){
	  st = abs(p[i][j]-p[i][j-1]);//要潤
	}
	else if(j == m[i]-1)ed = abs(p[i][j]-p[i][j-1]);
      }

      if(st > ed){
	P sub = p[i][0];
	rep(j,m[i])p[i][j] -= sub;
      }
      else {
	P sub = p[i][m[i]-1];
	rep(j,m[i])p[i][j] -= sub;
	P h;
	rep(j,m[i]/2){
	  h = p[i][j];
	  p[i][j] = p[i][(m[i]-1)-j];
	  p[i][(m[i]-1)-j] = h;
	}
      }
      /*
      if(i == 3){cout << "3晩M " << endl;
	rep(j,m[i])cout << p[i][j] << endl;
	}*/

    }

    bool iso;

    //cout << "基準" << endl;
    //rep(i,m[0])cout << p[0][i] << endl;
    //cout << "基準" << endl;


    REP(i,1,n+1){
      if(m[i] != m[0])continue;
      //cout << i << "-------------------------" << endl;
      rep(j,4){
	iso = true;
	rep(k,m[0]){
	  P cp = p[i][k]*polar(1.0,rad[j]);
	  //要潤
	  
	  //cout <<"pre cp = " << cp;
	  if(cp.real() > 0.0){
	    if(1.0-EPS>cp.real()-(int)cp.real()&&cp.real()-(int)cp.real() > 0.0){
	      cp.real() = (int)cp.real();
	    }
	  }
	  if(cp.imag() > 0.0){
	    if(1.0-EPS>cp.imag()-(int)cp.imag()&&cp.imag()-(int)cp.imag() > 0.0){
	      cp.imag() = (int)cp.imag();
	    }
	  }
	  if(cp.real() <0.0){
	    if(-1.0+EPS<cp.real()+(int)cp.real() && cp.real()+(int)cp.real() < 0.0){
	      cp.real() = (int)cp.real();
	    }
	  }
	  if(cp.imag() < 0.0){
	    if(-1.0+EPS< cp.imag()+(int)cp.imag() &&cp.imag()+(int)cp.imag() < 0.0){
	      cp.imag() = (int)cp.imag();
	    }
	  }
	  // cout << endl;
	  
	  //要潤
	  //cout << j<< "th - p[i][k]*pol = " << cp  << "　基準 is " << p[0][k]<< endl;


	  if(!(1.0-EPS>cp.real()-p[0][k].real()&&cp.real()-p[0][k].real()>=0.0-EPS&&1.0-EPS>cp.imag()-p[0][k].imag()&&cp.imag()-p[0][k].imag()>=0.0-EPS)){
	    iso = false;
	    break;
	  } 


	  //if(cp != p[0][k]){iso = false; break;}
	}
	
	if(iso)break;
      }
      if(iso)cout << i << endl;
    }
    cout <<"+++++" << endl;
  }
  return 0;
}