//23
#include<iostream>
#include<vector>
#include<complex>

using namespace std;

typedef complex<double> P;

vector<P> ip(){
  int m;
  cin>>m;
  vector<P> v(m);
  for(int i=0;i<m;i++){
    int x,y;
    cin>>x>>y;
    v[i]=P(x,y);
  }
  return v;
}

bool cmp(vector<P> a,vector<P> b){
  if(a.size()!=b.size())return false;
  P d=a[0]-b[0];
  for(int i=0;i<4;i++){
    int j;
    for(j=0;j<a.size();j++){
      if(a[j]-a[0]!=(b[j]-b[0])*pow(P(0,1),i))break;
    }
    if(!(j<a.size()))return true;
  }
  return false;
}

int main(){
  for(int n;cin>>n,n;){
    vector<P> o=ip();
    for(int i=1;i<=n;i++){
      vector<P> l=ip();
      if(cmp(o,l)||cmp(o,vector<P>(l.rbegin(),l.rend()))){
	cout<<i<<endl;
      }
    }
    cout<<"+++++"<<endl;
  }
  return 0;
}