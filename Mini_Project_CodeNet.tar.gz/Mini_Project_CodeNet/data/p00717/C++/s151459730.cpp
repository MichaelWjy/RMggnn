#define _USE_MATH_DEFINES
#include<iostream>
#include<string>
#include<cmath>
#include<queue>
#include<map>
#include<set>
#include<list>
#include<iomanip>
#include<vector>
#include<random>
#include<functional>
#include<algorithm>
#include<cstdio>
#include<unordered_map>
using namespace std;
//---------------------------------------------------
//ライブラリゾーン！！！！
typedef long long ll;
typedef long double ld;
#define str string
#define rep(i,j) for(ll i=0;i<(long long)(j);i++)
const ll Mod = 1000000007;
const ll gosenchou = 5000000000000000;
short gh[2][4] = { { 0,0,-1,1 },{ -1,1,0,0 } };
struct P {
	ll pos, cost;
};
bool operator<(P a, P b) { return a.cost < b.cost; }
bool operator>(P a, P b) { return a.cost > b.cost; }
struct B {//隣接リスト表現
	ll to;
	ld cost;
};
struct E {//辺の情報を入れる変数
	ll from, to, cost;
};
bool operator<(E a, E b) {
	return a.cost < b.cost;
}
struct H {
	ll x, y;
};
bool operator<(H a, H b) {
	/*if (a.x != b.x) return a.x < b.x;
	return a.y < b.y;*/
	return ((a.x + 1)*(a.y + 1)) < ((b.x + 1)*(b.y + 1));
}
bool operator>(H a, H b) {
	if (a.x != b.x) return a.x > b.x;
	return a.y > b.y;
}
bool operator==(H a, H b) {
	return a.x == b.x&&a.y == b.y;
}
bool operator!=(H a, H b) {
	return a.x != b.x || a.y != b.y;
}
ll gcm(ll i, ll j) {//最大公約数
	if (i > j) swap(i, j);
	if (i == 0) return j;
	return gcm(j%i, i);
}
ld rad(H a, H b) {
	return sqrt(pow(a.x - b.x, 2.0) + pow(a.y - b.y, 2.0));
}//rad＝座標上の2点間の距離
ll ari(ll a, ll b, ll c) {
	return (a + b)*c / 2;
}//等差数列の和
bool suf(ld a, ld b, ld c, ld d) {
	if (b <= c || d <= a) return 0;
	return 1;
}//[a,b),[c,d)
ll fact(ll x, ll k, ll p) {//最大値、個数
	ll sum = 1;
	for (int i = 0; i < k; i++) {
		sum *= (x--);
		sum %= p;
	}
	return sum;
}//階乗(正）
ll mod_pow(ll x, ll n, ll p) {
	ll res = 1;
	while (n > 0) {
		if (n & 1) res = res*x%p;
		x = x*x%p;
		n >>= 1;
	}
	return res;
}//x^n%p
 //#define int long long
const long long inf = 4523372036854775807;
const int iinf = 1500000000;
//----------------------------------------------------
//++++++++++++++++++++++++++++++++++++++++++++++++++++
struct A {
	string s;
	int id;
};
bool operator<(A a, A b) {
	if (a.s != b.s) return a.s < b.s;
	return a.id < b.id;
}
vector<A>v;
vector<string>o;
signed main() {
	int n, m;
	while (cin >> n&&n) {
		string r = "";
		for (int i = 0; i <= n; i++) {
			cin >> m;
			H pre, prev = H{ 0,0 }, now;//２前、前、いま
			string s = "", h = "";
			vector<string>q;
			for (int j = 0; j < m; j++) {
				cin >> now.x >> now.y;
				if (j > 0) {
					if (j == 1)
						q.push_back(to_string(max(abs(now.x - prev.x), abs(now.y - prev.y))));
					if (j > 1) {
						if (now.x == prev.x) {
							if (pre.x < prev.x&&prev.y > now.y)
								q.push_back("a");//左
							if (pre.x < prev.x&&prev.y < now.y)
								q.push_back("b");
							if (pre.x > prev.x&&prev.y < now.y)
								q.push_back("a");
							if (pre.x > prev.x&&prev.y > now.y)
								q.push_back("b");
						}
						if (now.y == prev.y) {
							if (pre.y < prev.y&&prev.x < now.x)
								q.push_back("a");
							if (pre.y < prev.y&&prev.x > now.x)
								q.push_back("b");
							if (pre.y > prev.y&&prev.x < now.x)
								q.push_back("b");
							if (pre.y > prev.y&&prev.x > now.x)
								q.push_back("a");
						}
						q.push_back(to_string(max(abs(now.x - prev.x), abs(now.y - prev.y))));
					}
				}
				pre = prev;
				prev = now;
			}
			if (i == 0) {
				for (int i = 0; i < q.size(); i++)
					s += q[i];
				r = s;
			}
			else {
				for (int i = 0; i < q.size(); i++) 
					s += q[i];
				v.push_back(A{ s,i });
				o.push_back(s);
				for (int i = q.size() - 1; i >= 0; i--) {
					if (q[i] == "a") h += 'b';
					else if (q[i] == "b") h += 'a';
					else h += q[i];
				}
				v.push_back(A{ h,i });
				o.push_back(h);
			}
		}
		sort(v.begin(), v.end());
		sort(o.begin(), o.end());
		for (int i = lower_bound(o.begin(), o.end(), r) - o.begin(); i < upper_bound(o.begin(), o.end(), r) - o.begin(); i++) {
			cout << v[i].id << endl;
		}
		cout << "+++++\n";
	}
	getchar(); getchar();
}
