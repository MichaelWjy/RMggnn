#include <iostream>
#include <vector>
#include <cmath>
#include <complex>
#include <algorithm>

using namespace std;

typedef complex<int> P;

struct l {
	int n;
	vector<P> p;
};

P rotate(P p, int n) {
	int x = p.real(), y = p.imag();

	return
		  n == 0 ? P(x,  y)
		: n == 1 ? P(-y, x)
		: n == 2 ? P(y,  -x)
		:          P(-x, -y)
		;
}

int main() {
	int n;
	while (cin >> n, n) {
		vector<l> lines(++n);

		for (int i = 0; i < n; ++i) {
			cin >> lines[i].n;
			for (int j = 0; j < lines[i].n; ++j) {
				int x, y;
				cin >> x >> y;
				lines[i].p.push_back( P(x, y) );
			}
		}

		vector<l> pattern(8);
		for (int i = 0; i < 4; ++i) {
			l new_line;
			for (int j = 0; j < lines[0].n; ++j)
				new_line.p.push_back( rotate(lines[0].p[j], i) );

			pattern[i+4] = pattern[i] = new_line;
			reverse( pattern[i+4].p.begin(), pattern[i+4].p.end() );
		}

		for (int i = 1; i < n; ++i) {
			if (lines[i].n != lines[0].n) continue;
			for (int j = 0; j < 8; ++j) {
				P d = pattern[j].p[0] - lines[i].p[0];
				bool same = true;
				for (int k = 1; k < lines[i].n; ++k)
					same &= lines[i].p[k] + d == pattern[j].p[k];

				if (same) {
					cout << i << endl;
					break;
				}
			}
		}

		cout << "+++++" << endl;
	}
}