#include<cstdio>
#include<iostream>
#include<algorithm>
#include<vector>
#include<string>
#include<sstream>
#include<queue>
#include<cstdlib>
#include<cmath>

using namespace std;

#define reps(i,f,n) for(int i=f;i<int(n);i++)
#define rep(i,n) reps(i,0,n)


class Line{
	public:
	double x,y;
	Line(double x,double y):x(x),y(y){}
	bool operator!=(const Line& line)const{
		if(fabs(line.x-x)>0.001)return true;
		if(fabs(line.y-y)>0.001)return true;
		return false;
	}
};

double getarg(Line line){
	double par = M_PI/2;
	if(line.x>0)return par*0;
	if(line.x<0)return par*2;
	if(line.y>0)return par*1;
	if(line.y<0)return par*3;
	return 0;
}

void henkan(vector<Line>& lines, double arg){
	rep(i,lines.size()){
		double x = lines[i].x*cos(arg) + lines[i].y*sin(arg);
		double y = -lines[i].x*sin(arg) + lines[i].y*cos(arg);
		
		lines[i] = Line(x,y);
	}
}

int main(){
	while(1){
		int n;
		cin>>n;
		if(n==0)break;
		
		vector<Line> moto;
		
		rep(i,n+1){
			int m;
			cin>>m;
			
			int a,b;
			cin>>a>>b;
			
			vector<Line> lines;
			rep(j,m-1){
				int c,d;
				cin>>c>>d;
				lines.push_back(Line(c-a,d-b));
				a=c; b=d;
			}
			
			vector<Line> lines2;
			for(int i=lines.size()-1;i>=0;i--){
				lines2.push_back(lines[i]);
			}
			double arg2 = getarg(lines2[0]);
			henkan(lines2,arg2);
			
			double arg = getarg(lines[0]);
			henkan(lines, arg);
			
			if(i==0){
				moto = lines;
			}else{
				bool same = true;
				bool same2 = true;
				rep(i,lines.size()){
					if(lines[i] != moto[i])same = false;
					if(lines2[i] != moto[i])same2 = false;
				}
				if(same || same2)printf("%d\n",i);
			}
		}
		
		printf("+++++\n");
	}
}