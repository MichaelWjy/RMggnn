#include <bits/stdc++.h>
using namespace std;

#define rep(i,j) for (int (i)=0;(i)<(int)(j);++(i))

pair<int, int> rotate(pair<int, int> p) {
    return { -p.second, p.first };
}

int main() {
    int n;
    while (cin >> n && n) {
        set<int> ans;
        vector<pair<int, int>> v[n+1];
        rep(i, n+1) {
            int m; cin >> m;
            rep(j, m) {
                pair<int, int> p;
                cin >> p.first >> p.second;
                v[i].push_back(p);
            }
        }

        for (int i = 1; i < n+1; ++i) {
            bool ok = false;
            for (int r = 0; r < 4; ++r) {
                bool f = true;
                double dx = -1, dy = -1;
                for (int j = 0; j < v[i].size(); ++j) {

                    double x = abs(v[0][j].first - v[i][j].first);
                    double y = abs(v[0][j].second - v[i][j].second);

                    if (dx == -1 && dy == -1) { dx = x; dy = y; }

                    if (v[0][j] != v[i][j]) {
                        if (dx != x || dy != y) {
                            f = false;
                        }
                    }

                    v[i][j] = rotate(v[i][j]);
                }
                if (f) {
                    ok = true;
                    cout << i << endl;
                    break;
                }
            }

            if (!ok) {
                for (int r = 0; r < 4; ++r) {
                    bool f = true;
                    int dx = -1, dy = -1;
                    for (int j = v[i].size()-1; j >= 0; --j) {

                        double x = abs(v[0][v[i].size()-j-1].first - v[i][j].first);
                        double y = abs(v[0][v[i].size()-j-1].second - v[i][j].second);

                        if (dx == -1 && dy == -1) { dx = x; dy = y; }

                        if (v[0][v[i].size()-j-1] != v[i][j]) {
                            if (dx != x || dy != y){
                                f = false;
                            }
                        }

                        v[i][j] = rotate(v[i][j]);
                    }
                    if (f) {
                        ok = true;
                        cout << i << endl;
                        break;
                    }
                }
            }
        }

        cout << "+++++" << endl;
    }
}