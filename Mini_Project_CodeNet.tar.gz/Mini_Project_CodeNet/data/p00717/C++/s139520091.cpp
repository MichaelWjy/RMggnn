#include <algorithm>
#include <iostream>
#include <limits.h>
#include <math.h>
#include <set>
#include <stack>
#include <stdlib.h>
#include <string>
#include <vector>

#define el endl
#define fd fixed
#define INF INT_MAX/2-1
#define pb push_back

using namespace std;

class Point
{
public:
  int x;
  int y;
  Point(int ax, int ay) {
    x = ax, y = ay;
  }
};

vector<Point> l_rotate(vector<Point> line) {
  vector<Point> res;
  for (int i = 0; i < line.size(); i++) {
    res.pb(Point(-line[i].y, line[i].x));
  }
  return res;
}

vector<Point> r_rotate(vector<Point> line) {
  vector<Point> res;
  for (int i = 0; i < line.size(); i++) {
    res.pb(Point(line[i].y, -line[i].x));
  }
  return res;
}

vector<Point> ll_rotate(vector<Point> line) {
  vector<Point> res;
  res = l_rotate(line);
  res = l_rotate(res);
  return res;
}

int main () {
  int n, m, x0, y0, x, y;
  bool flag;
  while (cin >> n, n) {
    vector<Point> line0;
    cin >> m >> x0 >> y0;
    line0.pb(Point(0, 0));
    while (--m) {
      cin >> x >> y;
      line0.pb(Point(x-x0, y-y0));
    }
    if (line0[1].x > 0) line0 = l_rotate(line0);
    else if (line0[1].x < 0) line0 = r_rotate(line0);
    else if (line0[1].y < 0) line0 = ll_rotate(line0);
    for (int i = 1; i <= n; i++) {
      flag = true;
      cin >> m >> x0 >> y0;
      vector<Point> line1, line2;
      line1.pb(Point(0, 0));
      while(--m) {
        cin >> x >> y;
        line1.pb(Point(x-x0, y-y0));
      }
      for (int j = line1.size()-1; j >= 0; j--) {
        line2.pb(Point(line1[j].x-x, line1[j].y-y));
      }
      if (line1[1].x > 0) line1 = l_rotate(line1);
      else if (line1[1].x < 0) line1 = r_rotate(line1);
      else if (line1[1].y < 0) line1 = ll_rotate(line1);
      if (line2[1].x > 0) line2 = l_rotate(line2);
      else if (line2[1].x < 0) line2 = r_rotate(line2);
      else if (line2[1].y < 0) line2 = ll_rotate(line2);
      for (int j = 0; j < line1.size(); j++) {
        if (line0[j].x != line1[j].x || line0[j].y != line1[j].y) {
          flag = false;
          break;
        }
      }
      if (!flag) {
        flag = true;
        for (int j = 0; j < line2.size(); j++) {
          if (line0[j].x != line2[j].x || line0[j].y != line2[j].y) {
            flag = false;
            break;
          }
        }
      }
      if (flag) cout << i << el;
    }
    cout << "+++++" << el;
  }
}