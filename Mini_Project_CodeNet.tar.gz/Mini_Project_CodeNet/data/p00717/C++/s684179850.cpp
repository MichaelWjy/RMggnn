#include<cstdio>
#include<cstdlib>
#include<math.h>
#include<iostream>
using namespace std;

int cmpsub(int d[],int pd[],int m){
	int i;
	if(d[0]==pd[0]){
		for(i=1;i<m;i++) if(d[i]!=pd[i]) break;
		if(i==m) return 1;
		for(i=1;i<m;i++) if(d[i]!=-pd[m-i]) break;
		if(i==m) return 1;
	}
	else if(m%2==1){
		for(i=1;i<m;i++) if(d[i]!=-pd[m-i]) break;
		if(i==m) return 1;
	}
	return 0;
}

int cmp(int d[],int pd[],int m){
	int i;
	if(cmpsub(d,pd,m)) return 1;
	for(i=0;i<m;i++) if(i%2==0) pd[i]=-pd[i];
	if(cmpsub(d,pd,m)) return 1;
	pd[0]=-pd[0];
	for(i=0;i<m;i++) if(i%2==1) pd[i]=-pd[i];
	if(cmpsub(d,pd,m)) return 1;
	for(i=0;i<m;i++) if(i%2==0) pd[i]=-pd[i];
	if(cmpsub(d,pd,m)) return 1;
	return 0;
}

int main(){
	int i,j;
	int n;
	int m;
	int x0,y0,x1,y1;
	int *d;
	int pm;
	int *pd;
	while(true){
		cin>>n;
		//cout<<"  "<<n<<endl;
		if(n==0) break;
		cin>>m;
		d=new int[m];
		cin>>x0>>y0;
		cin>>x1>>y1;
		if(x1-x0!=0) d[0]=1;
		else d[0]=-1;
		d[1]=x1-x0+y1-y0;
		x0=x1;
		y0=y1;
		for(i=2;i<m;i++){
			cin>>x1>>y1;
			d[i]=x1-x0+y1-y0;
			x0=x1;
			y0=y1;
		}
		for(i=1;i<=n;i++){
			cin>>pm;
			pd=new int[pm];
			cin>>x0>>y0;
			cin>>x1>>y1;
			if(x1-x0!=0) pd[0]=1;
			else pd[0]=-1;
			pd[1]=x1-x0+y1-y0;
			x0=x1;
			y0=y1;
			for(j=2;j<pm;j++){
				cin>>x1>>y1;
				pd[j]=x1-x0+y1-y0;
				x0=x1;
				y0=y1;
			}
			if(m!=pm){
				delete []pd;
				continue;
			}
			if(cmp(d,pd,m)){
				cout<<i<<endl;
				delete []pd;
				continue;
			}
			delete []pd;
		}
		cout<<"+++++"<<endl;
		delete []d;
	}
	return 0;
}