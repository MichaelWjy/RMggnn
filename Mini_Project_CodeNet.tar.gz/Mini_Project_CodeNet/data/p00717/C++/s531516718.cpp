#include <cstdio>
#include <iostream>
#include <vector>
#include <algorithm>


using namespace std;

#define foreach(it, c) for (__typeof__((c).begin()) it=(c).begin(); it != (c).end(); ++it)
#define all(c) (c).begin(), (c).end()
#define rall(c) (c).rbegin(), (c).rend()
#define clear(arr, val) memset(arr, val, sizeof(arr))


struct P
{
	int x, y;
	P(int x, int y)
		: x(x), y(y) { }
	P operator-(const P& a) const { return P(x - a.x, y - a.y); }
	bool operator==(const P& a) const { return x == a.x && y == a.y; }
};
vector<P> ori(const vector<P>& v)
{
	vector<P> res;
	P rela = v[0];
	for (int i = 0; i < v.size(); ++i)
		res.push_back(v[i] - rela);
	return res;
}
vector<P> rotate(const vector<P>& v)
{
	vector<P> res;
	for (int i = 0; i < v.size(); ++i)
		res.push_back(P(-v[i].y, v[i].x));
	return res;
}
vector<P> input()
{
	int m;
	cin >> m;
	vector<P> res;
	while (m--)
	{
		int x, y;
		cin >> x >> y;
		res.push_back(P(x, y));
	}
	return res;
}
int main()
{
	int n;
	while (cin >> n, n)
	{
		vector<vector<P> > ok;
		ok.push_back(ori(input()));
		for (int i = 0; i < 3; ++i)
			ok.push_back(rotate(ok.back()));
		for (int i = 0; i < 4; ++i)
		{
			vector<P> a = ok[i];
			reverse(all(a));
			ok.push_back(ori(a));
		}

		for (int T = 1; T <= n; ++T)
		{
			vector<P> t = ori(input());
			bool s = false;
			for (int i = 0; i < ok.size(); ++i)
				s |= t == ok[i];
			if (s)
				cout << T << endl;
		}
		cout << "+++++" << endl;
	}
}