#include <bits/stdc++.h>
using namespace std;

vector<int> V[4];

int T[4][4];
void init(){
	T[0][1]=-2;
	T[0][3]=-1;
	T[1][0]=-1;
	T[1][2]=-2;
	T[2][1]=-1;
	T[2][3]=-2;
	T[3][0]=-2;
	T[3][2]=-1;
}

int houkou(int X,int Y,int x,int y){
	if(x>X)return 0;
	if(y>Y)return 1;
	if(X>x)return 2;
	if(Y>y)return 3;
}

void in(int num){
	V[num].clear();
	int m;cin>>m;
	int X,Y,Z,x,y,z;
	cin>>X>>Y;
	cin>>x>>y;
	Z=houkou(X,Y,x,y);
	V[num].push_back((X-x>0?X-x:x-X)+(Y-y>0?Y-y:y-Y));
	X=x;
	Y=y;
	for(int i=0;i<m-2;i++){
		cin>>x>>y;
		z=houkou(X,Y,x,y);
		V[num].push_back(T[Z][z]);
		V[num].push_back((X-x>0?X-x:x-X)+(Y-y>0?Y-y:y-Y));
		X=x;
		Y=y;
		Z=z;
	}
	V[num+1].clear();
	for(int i=V[num].size()-1,j=0;i>=0;i--,j++){
		if(j%2){
			V[num+1].push_back((V[num][i]==-1?-2:-1));
		}
		else{
			V[num+1].push_back(V[num][i]);
		}
	}
}

void draw(int num){
	for(int i=0;i<V[num].size();i++){
		if(i%2){
			if(V[num][i]==-1)cout<<"R";
			else cout<<"L";
		}
		else{
			cout<<V[num][i];
		}
	}
	cout<<endl;
}

int chk(int a,int b){
	if(V[a].size() != V[b].size())return 0;
	for(int i=0;i<V[a].size();i++){
		if(V[a][i]!=V[b][i]){
			return 0;
		}
	}
	return 1;
}

int main(){
	init();
	for(int n;cin>>n,n;cout<<"+++++\n"){
		in(0);
		for(int i=1;i<=n;i++){
			in(2);
			if(chk(0,2)+chk(1,2)){
				cout<<i<<endl;
			}
		}
	}
	
	return 0;
}
