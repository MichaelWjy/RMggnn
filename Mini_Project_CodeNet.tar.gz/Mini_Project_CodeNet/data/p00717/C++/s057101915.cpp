#define _USE_MATH_DEFINES
#include <bits/stdc++.h>
#define int long long
#define rep(i,n) for(int i=0;i<n;i++)
#define Rep(i,a,b) for(int i=a;i<b;i++)
#define REP(i,a,b) for(int i=a;i<=b;i++)
#define rev(i,n) for(int i=(n)-1;i>=0;i--)
#define vi vector<int>
#define vvi vector<vi>
#define pb push_back
#define pi pair<int,int>
#define vp vector<pair<int,int>>
#define mp make_pair
#define all(v) (v).begin(),(v).end()
#define fi first
#define se second
#define MEMSET(a) memset(a,0,sizeof(a))
#define inf (1ll<<60)
#define Yes(f) cout<<(f?"Yes":"No")<<endl
#define yes(f) cout<<(f?"yes":"no")<<endl
#define YES(f) cout<<(f?"YES":"NO")<<endl
#define SORT(v) sort(all(v))
#define RSORT(v) sort(all(v), greater<int>())

using namespace std;

const int mod=1e9+7;
const string sp=" ";

void run();

void init() {
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout<<fixed<<setprecision(12);
}

signed main(){
    init();
    run();
    return 0;
}

bool judge(int m,vp &l0,vp &l){
    complex<double> c0(l0[1].fi-l0[0].fi,l0[1].se-l0[0].se);
    complex<double> t(1,0);
    complex<double> r(0,1);
    complex<double> c(l[1].fi-l[0].fi,l[1].se-l[0].se);
    bool found=false;
    rep(i,4){
        if(c0*t==c){
            found=true;
            break;
        }
        t*=r;
    }
    Rep(i,1,m-1){
        c0=complex<double>(l0[i+1].fi-l0[i].fi,l0[i+1].se-l0[i].se);
        c=complex<double>(l[i+1].fi-l[i].fi,l[i+1].se-l[i].se);
        found&=c0*t==c;
    }
    return found;
}

void run(){
    int n;
    cin>>n;
    if(!n)return;
    int m0;
    cin>>m0;
    vp l0(m0);
    rep(i,m0){
        int x,y;
        cin>>x>>y;
        l0[i]={x,y};
    }
    vi ans;
    rep(i,n){
        int m;
        cin>>m;
        vp l(m);
        rep(j,m){
            int x,y;
            cin>>x>>y;
            l[j]={x,y};
        }
        if(m!=m0)continue;
        bool found=judge(m,l0,l);
        reverse(all(l));
        found|=judge(m,l0,l);
        if(found)ans.pb(i+1);
    }
    rep(i,ans.size())cout<<ans[i]<<endl;
    cout<<"+++++"<<endl;
    run();
}
