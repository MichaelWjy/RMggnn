
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <climits>
#include <cfloat>
#include <cstring>
#include <map>
#include <utility>
#include <set>
#include <iostream>
#include <memory>
#include <string>
#include <vector>
#include <algorithm>
#include <functional>
#include <sstream>
#include <complex>
#include <stack>
#include <queue>
#include <unordered_set>
#include <unordered_map>
using namespace std;

using LL = unsigned long long;

const LL P = 1e9 + 7;

int main(void)
{
	int n;
	while (cin >> n, n)
	{
		vector<LL>hash;
		for (int i = 0; i <= n; ++i)
		{
			int m;
			cin >> m;
			vector<pair<int, int>>shape;
			int x, y;
			cin >> x >> y;
			int tx = 0, ty = 0;
			bool swap = false;
			for (int j = 1; j < m; ++j)
			{
				int xx, yy;
				cin >> xx >> yy;
				if (j == 1)
				{
					if (yy - y > 0)
					{
						tx = 1, ty = 1;
					}
					else if (yy - y < 0)
					{
						tx = -1, ty = -1;
					}
					else if (xx - x > 0)
					{
						tx = 1, ty = -1;
						swap = true;
					}
					else
					{
						tx = -1, ty = 1;
						swap = true;
					}
					if (swap)
					{
						shape.push_back({ y*ty,x*tx });
					}
					else
					{
						shape.push_back({ x*tx,y*ty });
					}
				}
				if (swap)
				{
					shape.push_back({ yy*ty,xx*tx });
				}
				else
				{
					shape.push_back({ xx*tx,yy*ty });
				}
			}
			LL hs1 = 0, hs2 = 0;
			for (auto s : shape)
			{
				hs1 *= P;
				hs1 += s.first - shape[0].first;
				hs1 *= P;
				hs1 += s.second - shape[0].second;
			}
			reverse(shape.begin(), shape.end());
			for (auto s : shape)
			{
				hs2 *= P;
				hs2 += s.first - shape[0].first;
				hs2 *= P;
				hs2 += s.second - shape[0].second;
			}
			hash.push_back(min(hs1, hs2));
		}
		for (int i = 1; i <= n; ++i)
		{
			if (hash[0] == hash[i])
			{
				cout << i << endl;
			}
		}
		cout << "+++++\n";
	}
	return 0;
}