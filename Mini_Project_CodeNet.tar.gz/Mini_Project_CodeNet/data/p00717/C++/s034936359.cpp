#include<cstdio>
#include<complex>

using namespace std;
typedef complex<double> xy;

const double eps=0.01;
bool eq(double a, double b) {
    return abs(a-b) < eps;
}
double dot(xy a, xy b) {
    return (a*conj(b)).real();
}
double cross(xy a, xy b) {
    return (a*conj(b)).imag();
}

int main(void) {
    while(true) {
        int n;
        scanf("%d",&n);
        if(!n) break;

        int tm;
        scanf("%d",&tm);
        xy txy[100];
        for(int j=0; j<tm; j++) {
            double x,y;
            scanf("%lf%lf",&x,&y);
            txy[j] = xy(x,y);
        }
        for(int i=1; i<=n; i++) {
            int m;
            scanf("%d",&m);
            xy nxy[100];
            for(int j=0; j<tm; j++) {
                double x,y;
                scanf("%lf%lf",&x,&y);
                nxy[j] = xy(x,y);
            }

            bool flag1,flag2;
            flag1=flag2=(tm==m);

            for(int j=0; j+1<m; j++) {
                if(!eq(norm(txy[j+1]-txy[j]), norm(nxy[j+1]-nxy[j])))
                    flag1 = false;
            }
            for(int j=0; j+2<m; j++) {
                if(!eq(cross(txy[j+2]-txy[j+1], txy[j+1]-txy[j]), cross(nxy[j+2]-nxy[j+1], nxy[j+1]-nxy[j])))
                    flag1 = false;
            }
            for(int j=0; j+1<m; j++) {
                if(!eq(norm(txy[j+1]-txy[j]), norm(nxy[m-1 - (j+1)]-nxy[m-1 - j])))
                    flag2 = false;
            }
            for(int j=0; j+2<m; j++) {
                if(!eq(cross(txy[j+2]-txy[j+1], txy[j+1]-txy[j]), cross(nxy[m-1 - (j+2)]-nxy[m-1 - (j+1)], nxy[m-1 - (j+1)]-nxy[m-1 - j])))
                    flag2 = false;
            }
            if(flag1 || flag2) printf("%d\n",i);
        }
        printf("+++++\n");
    }
    return 0;
}