#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef pair<ll, ll> l_l;
typedef pair<int, int> i_i;

#define EPS (1e-7)
#define INF (1e9)
#define PI (acos(-1))
//const ll mod = 1000000007;
int xzero[11];
int yzero[11];
int x[11];
int y[11];

void f(int *a, int *b, int m) {
    for(int i = 1; i <= m; i++) {
        swap(a[i], b[i]);
        b[i] = -b[i];
    }
}

void g(int *a, int *b, int m) {
    for(int i = 2; i <= m; i++) {
        a[i] -= a[1];
        b[i] -= b[1];
    }
    a[1] = 0;
    b[1] = 0;
    while(a[2] <= 0) f(a, b, m);
}

int main() {
    //cout.precision(10);
    cin.tie(0);
    ios::sync_with_stdio(false);
    while(true) {
        int n;
        cin >> n;
        if(n == 0) break;
        int m0;
        cin >> m0;
        for(int i = 1; i <= m0; i++) {
            cin >> xzero[i] >> yzero[i];
        }
        for(int i = 2; i <= m0; i++) {
            xzero[i] -= xzero[1];
            yzero[i] -= yzero[1];
        }
        xzero[1] = 0;
        yzero[1] = 0;
        while(xzero[2] <= 0) f(xzero, yzero, m0);
        for(int index = 1; index <= n; index++) {
            int m;
            cin >> m;
            for(int i = 1; i <= m; i++) {
                cin >> x[i] >> y[i];
            }
            if(m != m0) continue;
            bool ok = true;
            g(x, y, m);
            for(int i = 1; i <= m; i++) {
                if(x[i] != xzero[i] || y[i] != yzero[i]) ok = false;
            }
            if(ok) {
                cout << index << endl;
                continue;
            }
            ok = true;
            for(int i = 1; i <= m - i + 1; i++) {
                swap(x[i], x[m - i + 1]);
                swap(y[i], y[m - i + 1]);
            }
            g(x, y, m);
            for(int i = 1; i <= m; i++) {
                if(x[i] != xzero[i] || y[i] != yzero[i]) ok = false;
            }
            if(ok) {
                cout << index << endl;
                continue;
            }
        }
        cout << "+++++" << endl;
    }
    return 0;
}
