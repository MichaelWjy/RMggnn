#define  _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <algorithm>
#include <utility>
#include <functional>
#include <cstring>
#include <queue>
#include <stack>
#include <math.h>
#include <iterator>
#include <vector>
#include <string>
#include <set>
#include <math.h>
#include <iostream> 
#include <random>
#include<map>
#include <iomanip>
#include <time.h>
#include <stdlib.h>
#include <list>
#include <typeinfo>
#include <list>
#include <set>
#include <cassert>
#include<fstream>
#include <unordered_map>  
using namespace std;
#define Ma_PI 3.141592653589793
#define eps 0.00000000000000000000000001
#define LONG_INF 10000000000000000
#define GOLD 1.61803398874989484820458
#define MAX_MOD 1000000007
#define MOD  998244353
#define REP(i,n) for(long long i = 0;i < n;++i)
int main(){
	while (true) {
		long long n;
		cin >> n;
		if (n == 0) return 0;
		vector<pair<int, int>> gogo;
		int m;
		cin >> m;
		int base_x = 0;
		int base_y = 0;
		cin >> base_x >> base_y;
		REP(i, m-1) {
			int a, b;
			cin >> a >> b;
			if (a != base_x) {
				gogo.push_back(make_pair(a - base_x, 0));
			}
			else {
				gogo.push_back(make_pair(b - base_y, 1));
			}
			base_x = a;
			base_y = b;
		}
		if (gogo[0].second == 1) {
			//moving y
			//spin it!
			for (int q = 0; q < gogo.size(); ++q) {
				if (gogo[q].second == 0) {
					gogo[q].second = 1;
				}
				else {
					gogo[q].second = 0;
					gogo[q].first *= -1;
				}
			}
		}
		if (gogo[0].first < 0) {
			for (int q = 0; q < gogo.size(); ++q) {
				gogo[q].first *= -1;
			}
		}
		REP(tea, n) {
			vector<pair<int,int>> compared;
			int m;
			cin >> m;
			int base_x, base_y;
			cin >> base_x >> base_y;
			REP(i, m-1) {
				int a, b;
				cin >> a >> b;
				if (a != base_x) {
					compared.push_back(make_pair(a - base_x, 0));
				}
				else {
					compared.push_back(make_pair(b - base_y, 1));
				}
				base_x = a;
				base_y = b;
			}
			if (compared[0].second == 1) {
				//moving y
				//spin it!
				for (int q = 0; q < compared.size(); ++q) {
					if (compared[q].second == 0) {
						compared[q].second = 1;
					}
					else {
						compared[q].second = 0;
						compared[q].first *= -1;
					}
				}
			}
			if (compared[0].first < 0) {
				for (int q = 0; q < compared.size(); ++q) {
					compared[q].first *= -1;
				}
			}
			if (compared == gogo) {
				cout << tea + 1 << endl;
				continue;
			}
			REP(q, compared.size()) {
				compared[q].first *= -1;
			}
			reverse(compared.begin(), compared.end());
			if (compared[0].second == 1) {
				//moving y
				//spin it!
				for (int q = 0; q < compared.size(); ++q) {
					if (compared[q].second == 0) {
						compared[q].second = 1;
					}
					else {
						compared[q].second = 0;
						compared[q].first *= -1;
					}
				}
			}
			if (compared[0].first < 0) {
				for (int q = 0; q < compared.size(); ++q) {
					compared[q].first *= -1;
				}
			}
			if (compared == gogo) {
				cout << tea + 1 << endl;
				continue;
			}
		}
		cout << "+++++" << endl;
	}
}
