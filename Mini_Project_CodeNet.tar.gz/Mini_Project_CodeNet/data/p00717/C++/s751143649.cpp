#include<bits/stdc++.h>
using namespace std;
#define rep(i,n) for(long long int i=0;i<n;++i)
typedef long long int ll;

int main(){

    while(1){
        int n;
        cin >> n;
        if(n==0){
            break;
        }
        int c;
        cin >> c;
        vector<pair<int,int>> p(c);
        for(int i=0;i<c;i++){
            cin >> p[i].first >> p[i].second;
        }
        string ss="D",sr="D";
        ss+=to_string(max(abs(p[0].first-p[1].first),abs(p[0].second-p[1].second)));
        for(int i=1;i<c-1;i++){
            if(p[i-1].first<p[i].first){
                if(p[i].second<p[i+1].second){
                    ss+="L";
                }else{
                    ss+="R";
                }
            }else if(p[i-1].second<p[i].second){
                if(p[i].first<p[i+1].first){
                    ss+="R";
                }else{
                    ss+="L";
                }
            }else if(p[i-1].first>p[i].first){
                if(p[i].second<p[i+1].second){
                    ss+="R";
                }else{
                    ss+="L";
                }
            }else{
                if(p[i].first<p[i+1].first){
                    ss+="L";
                }else{
                    ss+="R";
                }
            }
            ss+=to_string(max(abs(p[i].first-p[i+1].first),abs(p[i].second-p[i+1].second)));
        }
        sr+=to_string(max(abs(p[c-1].first-p[c-2].first),abs(p[c-1].second-p[c-2].second)));
        for(int i=c-2;i>0;i--){
            if(p[i+1].first<p[i].first){
                if(p[i].second<p[i-1].second){
                    sr+="L";
                }else{
                    sr+="R";
                }
            }else if(p[i+1].second<p[i].second){
                if(p[i].first<p[i-1].first){
                    sr+="R";
                }else{
                    sr+="L";
                }
            }else if(p[i+1].first>p[i].first){
                if(p[i].second<p[i-1].second){
                    sr+="R";
                }else{
                    sr+="L";
                }
            }else{
                if(p[i].first<p[i-1].first){
                    sr+="L";
                }else{
                    sr+="R";
                }
            }
            sr+=to_string(max(abs(p[i].first-p[i-1].first),abs(p[i].second-p[i-1].second)));
        }
        vector<string> cand(n,"D");
        for(int i=0;i<n;i++){
            int m;
            cin >> m;
            vector<pair<int,int>> a(m);
            for(int j=0;j<m;j++){
                cin >> a[j].first >> a[j].second;
            }
            cand[i]+=to_string(max(abs(a[0].first-a[1].first),abs(a[0].second-a[1].second)));
            for(int k=1;k<m-1;k++){
                if(a[k-1].first<a[k].first){
                    if(a[k].second<a[k+1].second){
                        cand[i]+="L";
                    }else{
                        cand[i]+="R";
                    }
                }else if(a[k-1].second<a[k].second){
                    if(a[k].first<a[k+1].first){
                        cand[i]+="R";
                    }else{
                        cand[i]+="L";
                    }
                }else if(a[k-1].first>a[k].first){
                    if(a[k].second<a[k+1].second){
                        cand[i]+="R";
                    }else{
                        cand[i]+="L";
                    }
                }else{
                    if(a[k].first<a[k+1].first){
                        cand[i]+="L";
                    }else{
                        cand[i]+="R";
                    }
                }
                cand[i]+=to_string(max(abs(a[k].first-a[k+1].first),abs(a[k].second-a[k+1].second)));
            }
        }
        for(int i=0;i<n;i++){
            if(ss==cand[i]||sr==cand[i]){
                cout << i+1 << endl;
            }
        }
        cout << "+++++" << endl;
    }

    return 0;
}
