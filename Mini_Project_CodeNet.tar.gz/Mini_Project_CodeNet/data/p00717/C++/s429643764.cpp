#include<iostream>
#include<complex>
#include<vector>
using namespace std;

struct Point {
  int x;
  int y;
};

typedef struct Point Point;

vector<Point> rotate(vector<Point> p) {

  for(int i=0; i<p.size(); i++) {

  }

}

bool compare(vector<Point> r,vector<Point> l) {
  vector<Point> p = vector<Point>(l.rbegin(), l.rend());

  if( r.size() != l.size() ) return false;

  bool f1=true,f2=true,f3=true,f4=true,f5=true,f6=true,f7=true,f8=true;
  for(int i=0; i<r.size(); i++) {

    //cout<<i<<endl;
    //cout<<"r"<<r[i].x<<" "<<r[i].y<<"l"<<l[i].x<<" "<<l[i].y<<"p"<<p[i].x<<" "<<p[i].y<<endl;
    if( !(r[i].x == l[i].x && r[i].y == l[i].y) ) f1 = false;
    if( !(r[i].x == -1*l[i].y && r[i].y == l[i].x) ) f2 = false;
    if( !(r[i].x == -1*l[i].x && r[i].y == -1*l[i].y ) ) f3 = false;
    if( !(r[i].x == l[i].y && r[i].y == -1*l[i].x) ) f4 = false;
    if( !(r[i].x == p[i].x && r[i].y == p[i].y) ) f5 = false;
    if( !(r[i].x == -1*p[i].y && r[i].y == p[i].x) ) f6 = false;
    if( !(r[i].x == -1*p[i].x && r[i].y == -1*p[i].y ) ) f7 = false;
    if( !(r[i].x == p[i].y && r[i].y == -1*p[i].x) ) f8 = false;
  }


  if( f1 || f2 || f3 || f4 || f5 || f6 || f7 || f8 ) return true;
  return false;
}

int main() {

  int n;
  while(true) {
    cin>>n;
    if( n==0 ) break;

    n++;
    vector< vector<Point> > polys;
    while(n--) {

      int m;
      cin>>m;
      vector<Point> poly,tmp;


      while(m--) {
	int x,y;
	cin>>x>>y;
	Point p;
	p.x = x;
	p.y = y;
	tmp.push_back(p);
      }

      //cout<<"!!!"<<endl;
      for(int i=1; i<tmp.size(); i++) {
	Point p;
	p.x = tmp[i].x - tmp[i-1].x;
	p.y = tmp[i].y - tmp[i-1].y;
	//pcout<<p.x<<" "<<p.y<<endl;
	poly.push_back(p);
      }

      polys.push_back(poly);

    }

    //cout<<"output"<<endl;
    for(int i=1; i<polys.size(); i++) {
      if( compare( polys[0], polys[i] ) ) {
	cout<<i<<endl;
      }
    }

    cout<<"+++++"<<endl;
  }
}