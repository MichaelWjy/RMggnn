#include <bits/stdc++.h>
#define rep(i, a, n) for(int i = a; i < n; i++)
#define repb(i, a, b) for(int i = a; i >= b; i--)
#define all(a) a.begin(), a.end()
#define int long long
using namespace std;

signed main(){
    int n;
    while(cin >> n, n){
        int m;
        cin >> m;
        int dx[8][11] = {0}, dy[8][11] = {0};
        int ax[11] = {0}, ay[11] = {0};
        rep(i, 0, m){
            cin >> ax[i] >> ay[i];
        }
        rep(i, 0, m){
            dx[0][i] = ax[i] - ax[0];
            dy[0][i] = ay[i] - ay[0];
            dx[1][i] = -dy[0][i];
            dy[1][i] = dx[0][i];
            dx[2][i] = -dx[0][i];
            dy[2][i] = -dy[0][i];
            dx[3][i] = dy[0][i];
            dy[3][i] = -dx[0][i];
        }
        vector<int> ans;
        rep(t, 1, n + 1){
            int am;
            cin >> am;
            int bx[11] = {0}, by[11] = {0};
            rep(i, 0, am){
                cin >> bx[i] >> by[i];
            }
            if(am != m) continue;
            rep(i, 0 ,am){
                int tx[11], ty[11];
                rep(j ,0, am){
                    tx[j] = bx[j] - bx[i];
                    ty[j] = by[j] - by[i];
                }
                rep(j, 0, 4){
                    rep(k, 0, m){
                        if(!(tx[k] == dx[j][k] && ty[k] == dy[j][k])) break;
                        if(k == m - 1){
                            ans. push_back(t);
                            j = 4; i = m; break;
                        }
                    }
                    rep(k, 0, m){
                        if(!(tx[k] == dx[j][m - 1 - k] && ty[k] == dy[j][m - 1 - k])) break;
                        if(k == m - 1){
                            ans. push_back(t);
                            j = 4; i = m; break;
                        }
                    }
                }
            }
        }
        rep(i, 0, ans.size()){
            cout << ans[i] << endl;
        }
        cout << "+++++" << endl;
    }
}