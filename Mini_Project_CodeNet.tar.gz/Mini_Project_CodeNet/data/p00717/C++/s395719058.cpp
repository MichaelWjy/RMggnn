
#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <stack>
#include <queue>
#include <cctype>
#include <complex>
#include <vector>
#include <set>
#include <map>
#include <algorithm>
#include <functional>
#include <cassert>
#include <iomanip>

using namespace std;

#define pb push_back
#define dump(x)  cout << " "<< #x << " = " << (x) << endl;
typedef long long ll;
typedef complex<int> P;
const double EPS = 1e-10;
const double PI  = acos(-1.0);



struct st{
	vector<P> vp;
	vector<P> rvp;
};


P d[] = { P(1,0), P(0,1), P(-1,0), P(0,-1) };

void f(vector<P> &vp){
	P p0 = vp[0];
	for(int i=0;i<vp.size();i++) vp[i] -= p0;
	P a = vp[0], b = vp[1];
	int num = 0;
	if(a.real() == b.real()){
		if(a.imag() < b.imag()) num = 3;
		else num = 1;
	}else if(a.imag() == b.imag()){
		if(a.real() < b.real()) num = 0;
		else num = 2;
	}else{
		cout<< "err"<< endl;
	}
	for(int i=0;i<vp.size();i++){
		vp[i] *= d[num];
	}
	return;
}

bool solve(int n){
	vector<st> vst(n+1);
	
	int m; cin>> m;
	vector<P> tmp, rtmp;
	for(int i=0;i<m;i++){
		P in;
		cin>> in.real()>> in.imag();
		tmp.pb(in);
	}
	rtmp = tmp;
	reverse(rtmp.begin(), rtmp.end());
	f(tmp);
	f(rtmp);
	vst[0].vp = tmp;
	vst[0].rvp = rtmp;
	
	for(int i=1;i<n+1;i++){
		int m2; cin>> m2;
		vector<P> tmp;
		for(int j=0;j<m2;j++){
			P in;
			cin>> in.real()>> in.imag();
			tmp.pb(in);
		}
		f(tmp);
		vst[i].vp = tmp;
	}
	
/*	for(int i=0;i<n+1;i++){
		cout<< " "<< i<< endl;
		for(int j=0;j<m;j++) cout<< " "<< vst[i].vp[j].real()<< " "<< vst[i].vp[j].imag()<< endl;
		if(i==0){
			cout<< " "<< i<< endl;
			for(int j=0;j<m;j++) cout<< " "<< vst[i].rvp[j].real()<< " "<< vst[i].rvp[j].imag()<< endl;
		}
	}
*/	
	
	for(int i=1;i<n+1;i++){
		if(vst[0].vp.size() != vst[i].vp.size()) continue;
		for(int k=0;k<2;k++){
			int flg = true;
			for(int j=0;j<m;j++){
				if(vst[i].vp[j] != vst[0].vp[j]){
					flg = false;
					break;
				}
			}
			if(flg) cout<< i<< endl;
			swap(vst[0].vp, vst[0].rvp);
		}
	}
	cout<< "+++++"<< endl;
	return true;
}

int main(){
	cout.setf(ios::fixed);
	cout.precision(10);
	int n;
	while(cin>>n, n) solve(n);
	return 0;
}

 