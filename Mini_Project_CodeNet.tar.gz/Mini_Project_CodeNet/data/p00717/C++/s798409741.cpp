#include <iostream>
#include <complex>
using namespace std;
typedef complex<int> C;

int n;

C l[51][11];
int ml[51];

void solve() {
  for (int i = 0; i <= n; i += 1) {
    cin>>ml[i];
    int bx, by; cin>>bx>>by;
    for (int j = 0; j < ml[i]-1; j += 1) {
      int nx, ny; cin>>nx>>ny;
      l[i][j].real() = nx - bx;
      l[i][j].imag() = ny - by;
      bx = nx;
      by = ny;
    }
  }
  
  for (int i = 1; i <= n; i += 1) {
    if (ml[0] != ml[i]) continue;
    bool is_printed = false;
    for (int j = 0; j < 4; j += 1) {
      bool flag = true;
      for (int k = 0; k < ml[0]-1; k += 1) {
        l[i][k] *= C(0,1);
      }
      for (int k = 0; k < ml[0]-1; k += 1) {
        /*
        cout<<i<<"|"<<j<<"|";
        cout<<l[0][k].real()<<","<<l[0][k].imag();
        cout<<l[i][k].real()<<","<<l[i][k].imag()<<endl;
        */
        if (l[0][k] != l[i][k]) {flag = false;break;}
      }
      if (flag) {
        cout<<i<<endl;
        is_printed = true;
        break;
      }
    }
    if (!is_printed) {
      for (int j = 0; j < 4; j += 1) {
        bool flag = true;
        for (int k = 0; k < ml[0]-1; k += 1) {
          l[i][k] *= C(0,1);
        }
        for (int k = 0; k < ml[0]-1; k += 1) {
          /*
          cout<<i<<"|"<<j<<"|";
          cout<<l[0][k].real()<<","<<l[0][k].imag();
          cout<<l[i][ml[0]-2-k].real()<<","<<l[i][ml[0]-2-k].imag()<<endl;
          */
          if (l[0][k] != l[i][ml[0]-2-k]) {flag = false;break;}
        }
        if (flag) {
          cout<<i<<endl;
          break;
        }
      }
    }
  }
  
  cout<<"++++"<<endl;
}

int main (int argc, char const* argv[]) {
  while (cin>>n, n) {
    solve();
  }
  return 0;
}