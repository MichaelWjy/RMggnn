#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#include<ctime>

using namespace std;
using ll = long long;

int main(){
  cin.tie(0);
  ios::sync_with_stdio(false);
  int ti = clock();
  // start-----------------------------------------------
  int n;
  while(cin >> n && n){
    vector<vector<int>> items(n+1);
    vector<vector<int>> rev_items(n+1);
    int x, y;
    for(int i = 0; i <= n; i++){
      int m; cin >> m;
      vector<pair<int, int>> nodes(m);
      for(int j = 0; j < m; j++){
        cin >> x >> y;
        nodes[j] = {x, y};
        if(j == 0) continue;
        else if(j == 1){
          items[i].push_back(max(abs(nodes[0].first - x), abs(nodes[0].second - y)));
        }
        else{
          if(nodes[j-1].first == x){
            if((x - nodes[j-2].first) * (y - nodes[j-1].second) > 0) items[i].push_back(abs(y - nodes[j-1].second));
            else items[i].push_back(-1 * abs(y - nodes[j-1].second));
          }
          else{
            if((y - nodes[j-2].second) * (x - nodes[j-1].first) < 0) items[i].push_back(abs(x - nodes[j-1].first));
            else items[i].push_back(-1 * abs(x - nodes[j-1].first));
          }
        }
      }
      for(int j = m-1; j >= 0; j--){
        x = nodes[j].first, y = nodes[j].second;
        if(j == m-1) continue;
        else if(j == m-2){
          rev_items[i].push_back(max(abs(nodes[m-1].first - x), abs(nodes[m-1].second - y)));
        }
        else{
          if(nodes[j+1].first == x){
            if((x - nodes[j+2].first) * (y - nodes[j+1].second) > 0) rev_items[i].push_back(abs(y - nodes[j+1].second));
            else rev_items[i].push_back(-1 * abs(y - nodes[j+1].second));
          }
          else{
            if((y - nodes[j+2].second) * (x - nodes[j+1].first) < 0) rev_items[i].push_back(abs(x - nodes[j+1].first));
            else rev_items[i].push_back(-1 * abs(x - nodes[j+1].first));
          }
        }
      }
      if(i > 0 && items[i].size() == items[0].size()){
        bool f = true;
        for(int j = 0; j < items[0].size(); j++){
          if(items[0][j] != items[i][j]){
            f = false;
            break;
          }
        }
        if(f){
          cout << i << endl;
          continue;
        }
        f = true;
        for(int j = 0; j < items[0].size(); j++){
          if(items[0][j] != rev_items[i][j]){
            f = false;
            break;
          }
        }
        if(f){
          cout << i << endl;
        }
      }
    }
    cout << "+++++" << endl;
  }

  // end-----------------------------------------------
  // cerr << 1.0 * (clock() - ti) / CLOCKS_PER_SEC << endl;
}

