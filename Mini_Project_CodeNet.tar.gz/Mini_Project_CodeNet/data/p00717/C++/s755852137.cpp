#include <bits/stdc++.h>
using namespace std;

using ll = long long int;
using ull = unsigned long long int;
using P = pair<int, int>;
using P3 = pair<P,ll>;
using PP = pair<P, P>;
constexpr int INF = 1 << 30;
constexpr ll MOD = ll(1e9)+7;
constexpr int di[] = {0, 1, 0, -1};
constexpr int dj[] = {1, 0, -1, 0};
constexpr double EPS = 1e-9;

int gcd(int p, int q){
    if(q==0) return p;
    return gcd(q,p%q);
}

void compress(vector<P> &v){
    int g = 0;
    for(auto &p : v){
        g = gcd(abs(p.first), g);
        g = gcd(abs(p.second), g);
    }
    for(auto &p : v){
        p.first /= g;
        p.second /= g;
    }
}

void rotate90(vector<P> &v){
    for(auto &p : v){
        int x = p.first, y = p.second;
        p.first = y;
        p.second = -x;
    }
}

void rev(vector<P> &v){
    reverse(v.begin(), v.end());
    for(auto &p : v){
        p.first *= -1;
        p.second *= -1;
    }
}

int solve(){
    int n;
    cin >> n;
    if(n == 0) return 1;
    vector<vector<P> > lines(n+1);
    for(int i=0;i<n+1;i++){
        int m, px, py;
        cin >> m;
        for(int j=0;j<m;j++){
            int x, y;
            cin >> x >> y;
            if(j>0) lines[i].push_back(P(x-px,y-py));
            px = x;
            py = y;
        }
        compress(lines[i]);
    }
    for(int i=1;i<=n;i++){
        bool same = false;
        if(lines[0].size() != lines[i].size()) continue;
        for(int j=0;j<2;j++){
            for(int k=0;k<4;k++){
                same |= lines[0] == lines[i];
                rotate90(lines[i]);
            }
            rev(lines[i]);
        }
        if(same) cout << i << endl;
    }
    cout << "+++++" << endl;
    return 0;
}

int main(){
    while(solve()==0);
    return 0;
}

