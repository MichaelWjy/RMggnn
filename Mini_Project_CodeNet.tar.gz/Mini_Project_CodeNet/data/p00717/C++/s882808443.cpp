#include <sstream>
#include <string>
#include <vector>
#include <map>
#include <algorithm>
#include <iostream>
#include <utility>
#include <set>
#include <cctype>
#include <queue>
#include <stack>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <climits>
using namespace std;
#define INF 100000000
#define MAXN 64
#define MAXM 10

typedef long long ll;
typedef pair<int, int> P;
const int dx[] = {1, 0, -1, 0};
const int dy[] = {0, 1, 0, -1};

int main(void) {
    int n;
    while (1) {
        cin >> n;
        if (n == 0) break;
        int x[MAXN][MAXM], y[MAXN][MAXM];
        int m;
        for (int i = 0; i <= n; i++) {
            cin >> m;
            for (int j = 0; j < m; j++) {
                cin >> x[i][j] >> y[i][j];
            }
        }
        P sample[4][MAXM];
        for (int i = 1; i < m; i++) {
            int X = x[0][i] - x[0][0];
            int Y = y[0][i] - y[0][0];
            // 元の形
            sample[0][i] = make_pair(X, Y);
            // 回転
            sample[1][i] = make_pair(-Y, X);
            sample[2][i] = make_pair(-X, -Y);
            sample[3][i] = make_pair(Y, -X);
        }
        for (int i = 1; i <= n; i++) {
            // 先頭からベクトルを作る
            P model[MAXM];
            for (int j = 1; j < m; j++) {
                model[j] = make_pair(x[i][j]-x[i][0], y[i][j]-y[i][0]);
            }
            bool ok = true;
            bool cout_flag = false;
            for (int j = 0; j < 4; j++) {
                for (int k = 1; k < m; k++) {
                    if (model[k] != sample[j][k]) {
                        ok = false;
                        break;
                    }
                }
                if (ok) {
                    cout << i << endl;
                    cout_flag = true;
                    break;
                }
                ok = true;
            }
            // 末尾からベクトルを作る
            if (cout_flag) continue;
            for (int j = m-2; j >= 0; j--) {
                model[j] = make_pair(x[i][j]-x[i][m-1], y[i][j]-y[i][m-1]);
            }
            ok = true;
            for (int j = 0; j < 4; j++) {
                for (int k = 1; k < m; k++) {
                    if (model[m-1-k] != sample[j][k]) {
                        ok = false;
                        break;
                    }
                }
                if (ok) {
                    cout << i << endl;
                    break;
                }
                ok = true;
            }
        }
        cout << "+++++" << endl;
    }
    return 0;
}