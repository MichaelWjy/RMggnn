#include <iostream>
#include <complex>
#include <vector>
using namespace std;

typedef complex<int> point;
typedef vector<point> polygon;

polygon read_polygon() {
	int m;
	cin >> m;
	polygon res(m);
	for (auto& p : res) {
		int x, y;
		cin >> x >> y;
		p = point(x, y);
	}
	point offset = res[0];
	for (auto& p : res) p -= offset;
	return res;
}

bool same(const polygon& target, polygon pol) {
	for (int j = 0; j < 2; j++) {
		for (int i = 0; i < 4; i++) {
			if (target == pol) return true;
			for (auto& p : pol) {
				p *= point(0, -1);
			}
		}
		pol = polygon(pol.rbegin(), pol.rend());
		point offset = pol[0];
		for (auto& p : pol) p -= offset;
	}
	return false;
}

int main() {
	int n;
	while (cin >> n, n) {
		polygon target = read_polygon();
		vector<polygon> pols(n);
		for (auto& p : pols) p = read_polygon();
		for (int i = 0; i < n; i++) {
			if (same(target, pols[i])) {
				cout << i + 1 << endl;
			}
		}
		cout << "+++++" << endl;
	}
	return 0;
}