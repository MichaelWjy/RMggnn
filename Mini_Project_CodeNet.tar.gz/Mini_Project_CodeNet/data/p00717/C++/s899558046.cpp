#include <iostream>
#include <vector>
#include <algorithm>
#include <utility>
using namespace std;

void turn(vector<pair<int,int> >& a){
	for(int i=0; i<(int)a.size(); i++){
		int x=a[i].first;
		int y=a[i].second;
		a[i].first = -y;
		a[i].second = x;
	}
}

int main(){
	while(1){
		int n;
		cin >> n;
		if(n==0) break;
		
		//input
		vector<vector<pair<int, int> > > lines(n+1);
		for(int i=0; i<=n; i++){
			int m, sx, sy;
			cin >> m;
			cin >> sx >> sy;
			lines[i].push_back(make_pair(0,0));
			for(int j=1; j<m; j++){
				int x,y;
				cin >> x >> y;
				lines[i].push_back(make_pair(x-sx,y-sy));
			}
		}
		
		vector<pair<int,int> > a,b;
		a = b = lines[0];
		for(int i=0; i<(int)b.size(); i++){
			b[i].first -= b[b.size()-1].first;
			b[i].second -= b[b.size()-1].second;
		}
		reverse(b.begin(), b.end());
		
		//check
		for(int i=1; i<=n; i++){
			if(a.size() != lines[i].size()) continue;
			for(int s=0; s<4; s++){
				bool same_a = true, same_b = true;
				for(int j=0; j<(int)a.size(); j++){
					if(a[j] != lines[i][j]){
						same_a = false;
						break;
					}
				}
				for(int j=0; j<(int)b.size(); j++){
					if(b[j] != lines[i][j]){
						same_b = false;
						break;
					}
				}
				if(same_a || same_b){
					cout << i << endl;
					s = 4;
					break;
				}
				turn(a);
				turn(b);
			}
		}
		cout << "+++++" << endl;
	}
	return 0;	
}