#include <iostream>
#include <vector>
#include <algorithm>
#include <map>
#include <queue>
#include <cstdio>
#include <ctime>
#include <assert.h>
#include <chrono>
#include <random>
#include <numeric>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
using namespace std;
typedef long long int ll;
typedef unsigned long long ull;

mt19937_64 rng(chrono::steady_clock::now().time_since_epoch().count());
ll myRand(ll B) {
    return (ull)rng() % B;
}

int n,M;
int x[11],y[11];

bool solve(){
	int m;cin >> m;
	vector<pair<int,int>> v(m);
	for(int i=0;i<m;i++){
		cin >> v[i].first >> v[i].second;
	}
	if(m!=M)return 0;
	bool ok=true;
	for(int i=1;i<m;i++){
		ok&=(abs(v[i].first-v[i-1].first)+abs(v[i].second-v[i-1].second)==abs(x[i]-x[i-1])+abs(y[i]-y[i-1]));
	}
	for(int i=1;i<m-1;i++){
		ok&=((v[i-1].first-v[i].first)*(v[i+1].second-v[i].second)-(v[i-1].second-v[i].second)*(v[i+1].first-v[i].first)>0)==((x[i-1]-x[i])*(y[i+1]-y[i])-(y[i-1]-y[i])*(x[i+1]-x[i])>0);
	}
	if(ok)return 1;
	ok=1;
	reverse(v.begin(), v.end());
	for(int i=1;i<m;i++){
		ok&=(abs(v[i].first-v[i-1].first)+abs(v[i].second-v[i-1].second)==abs(x[i]-x[i-1])+abs(y[i]-y[i-1]));
	}
	for(int i=1;i<m-1;i++){
		ok&=((v[i-1].first-v[i].first)*(v[i+1].second-v[i].second)-(v[i-1].second-v[i].second)*(v[i+1].first-v[i].first)>0)==((x[i-1]-x[i])*(y[i+1]-y[i])-(y[i-1]-y[i])*(x[i+1]-x[i])>0);
	}
	if(ok)return 1;
	return 0;
}

int main(){
	cin.tie(nullptr);
	ios::sync_with_stdio(false);
	while(cin >> n,n){
		cin >> M;
		for(int i=0;i<M;i++){
			cin >> x[i] >> y[i];
		}
		for(int i=0;i<n;i++){
			if(solve())printf("%d\n",i+1);
		}
		printf("+++++\n");
	}
}

