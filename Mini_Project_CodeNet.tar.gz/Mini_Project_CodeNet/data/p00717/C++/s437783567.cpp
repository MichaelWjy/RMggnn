#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <functional>
#include <numeric>
#include <stack>
#include <queue>
#include <map>
#include <set>
#include <utility>
#include <sstream>
#include <complex>
#include <fstream>
#include <bitset>
#include <time.h>
#include <tuple>
#include <iomanip>

using namespace std;

typedef long long ll;
typedef unsigned long long ull;
typedef pair<ll, ll> P;
typedef vector<ll> V;
typedef complex<double> Point;

#define PI acos(-1.0)
#define EPS 1e-10
const ll INF = 1e12;
const ll MOD = 1e9 + 7;

#define FOR(i,a,b) for(int i=(a);i<(b);i++)
#define rep(i,N) for(int i=0;i<(N);i++)
#define ALL(s) (s).begin(),(s).end()
#define EQ(a,b) (abs((a)-(b))<EPS)
#define EQV(a,b) ( EQ((a).real(), (b).real()) && EQ((a).imag(), (b).imag()) )
#define fi first
#define se second
#define N_SIZE (1LL << 20)
#define NIL -1

ll sq(ll num) { return num*num; }
ll mod_pow(ll x, ll n) {
	if (n == 0)return 1;
	if (n == 1)return x%MOD;
	ll res = sq(mod_pow(x, n / 2));
	res %= MOD;
	if (n % 2 == 1) {
		res *= x;
		res %= MOD;
	}
	return res;
}
ll mod_add(ll a, ll b) { return (a + b) % MOD; }
ll mod_sub(ll a, ll b) { return (a - b + MOD) % MOD; }
ll mod_mul(ll a, ll b) { return a*b % MOD; }

int n;
vector<vector<P>> vvp;

int main() {
	while (cin >> n&&n) {
		vvp.clear();
		rep(i, n + 1) {
			int m;
			cin >> m;
			ll x, y;
			ll px = 10000, py = 10000;
			vector<P> vp;
			rep(j, m) {
				cin >> x >> y;
				if (j != 0) {
					if (px == x) {
						if (py < y)vp.push_back(P(0, y - py));
						else vp.push_back(P(2, py - y));
					}
					else {
						if (px < x)vp.push_back(P(1, x - px));
						else vp.push_back(P(3, px - x));
					}
				}
				px = x, py = y;
			}
			vvp.push_back(vp);
			if (i == 0) {
				rep(j, vp.size()) {
					vp[j].first = (vp[j].first + 2) % 4;
				}
				reverse(ALL(vp));
				vvp.push_back(vp);
			}
		}
		//rep(i, vvp.size()) {
		//	cout << "!" << i << endl;
		//	rep(j, vvp[i].size()) {
		//		cout << vvp[i][j].first << " " << vvp[i][j].second << endl;
		//	}
		//	cout << endl;
		//}
		FOR(i, 2, vvp.size()) {
			if (vvp[i].size() != vvp[i].size())continue;
			bool f = 0;
			rep(k, 4) {
				bool f1 = 1, f2 = 1;
				rep(j, vvp[i].size()) {
					if ((vvp[0][j].first + k) % 4 != vvp[i][j].first
						|| vvp[0][j].second != vvp[i][j].second)f1 = 0;
				}
				rep(j, vvp[i].size()) {
					if ((vvp[1][j].first + k) % 4 != vvp[i][j].first
						|| vvp[1][j].second != vvp[i][j].second)f2 = 0;
				}
				if (f1 || f2)f = 1;
			}
			if (f)cout /*<< "!!!!!"*/ << i - 1 << endl;
		}
		cout << "+++++" << endl;
	}
}
