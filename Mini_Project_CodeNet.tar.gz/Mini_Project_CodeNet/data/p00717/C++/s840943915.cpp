#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

typedef pair <int, int> P;
vector <P> target;

void rotate(vector <P> &line)
{
	for (int i = 0; i < line.size(); i++){
		int x = line[i].first, y = line[i].second;
		line[i].first = y * -1;
		line[i].second = x;
	}
	return;
}

bool issame(vector <P> line)
{
	bool flag = true;
	for (int i = 0; i < min(target.size(), line.size()); i++){
		if (target[i].first != line[i].first) flag = false;
		if (target[i].second != line[i].second) flag = false;
	}

	return flag;
}

int main(void)
{
	int n;
	while (cin >> n, n){
		int m;
		vector < vector < P > > data;

		for (int i = 0; i <= n; i++){
			cin >> m;
			vector <P> line;
			int x, y, px, py;
			cin >> px >> py;
			for (int j = 1; j < m; j++){
				cin >> x >> y;
				line.push_back(make_pair(x - px, y - py));
				px = x;
				py = y;
			}
			data.push_back(line);
		}
		target = data[0];

		for (int i = 1; i <= n; i++){
			bool pf = false;
			for (int cnt = 0; cnt < 4; cnt++){
				rotate(data[i]);
				if (issame(data[i])){
					cout << i << endl;
					pf = true;
					break;
				}
			}
			reverse(data[i].begin(), data[i].end());
			if (!pf && issame(data[i])){
				cout << i << endl;
			}
		}
		cout << "+++++" << endl;
	}

	return 0;
}