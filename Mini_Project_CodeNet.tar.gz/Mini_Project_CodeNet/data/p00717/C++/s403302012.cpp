#include<iostream>
#include<vector>
#include<cmath>
#include<algorithm>
using namespace std;

int main(){
	while(true){
		int n,nn;
		cin >> n;
		if(n == 0){
			exit(0);
		}
		cin >> nn;
		
		int bx,by,x,y,nx,ny;
		cin >> x >> y;
		vector<int> nvmove;
		vector<int> nvnext;
		for(int i=1;i<nn;i++){
			cin >> nx >> ny;
			int move = max(abs(x-nx),abs(y-ny));
			nvmove.push_back(move);
			if(i==1){
				bx = x;
				by = y;
				x = nx;
				y = ny;
				continue;
			}
			int flag;
			if(bx < x){
				flag = 1;
			}
			if(bx > x){
				flag = -1;
			}
			if(by < y){
				flag = 1;
			}
			if(by > y){
				flag = -1;
			}
			if(x < nx){
				;
			}
			if(x > nx){
				flag = flag * (-1);
			}
			if(y < ny){
				flag = flag * (-1);
			}
			if(y > ny){
				;
			}
			nvnext.push_back(flag);

			bx = x;
			by = y;
			x = nx;
			y = ny;
		}
		for(int l=0;l<n;l++){
			int m;
			cin >> m;
			cin >> x >> y;
			vector<int> mvmove;
			vector<int> mvnext;
			for(int i=1;i<nn;i++){
				cin >> nx >> ny;
				int move = max(abs(x-nx),abs(y-ny));
				mvmove.push_back(move);
				if(i==1){
					bx = x;
					by = y;
					x = nx;
					y = ny;
					continue;
				}
				int flag;
				if(bx < x){
					flag = 1;
				}
				if(bx > x){
					flag = -1;
				}
				if(by < y){
					flag = 1;
				}
				if(by > y){
					flag = -1;
				}
				if(x < nx){
					;
				}
				if(x > nx){
					flag = flag * (-1);
				}
				if(y < ny){
					flag = flag * (-1);
				}
				if(y > ny){
					;
				}
				mvnext.push_back(flag);

				bx = x;
				by = y;
				x = nx;
				y = ny;
			}

			if(nn != m){
				continue;
			}
			bool ansflag = true;
			bool ansflag2 = true;
			for(int i=0;i<mvmove.size();i++){
				if(nvmove[i] != mvmove[i]){
					ansflag = false;
				}
			}
			for(int i=0;i<mvnext.size();i++){
				if(nvnext[i] != mvnext[i]){
					ansflag = false;
				}
			}
			reverse(mvmove.begin(),mvmove.end());
			reverse(mvnext.begin(),mvnext.end());
			for(int i=0;i<mvmove.size();i++){
				if(nvmove[i] != mvmove[i]){
					ansflag2 = false;
				}
			}
			for(int i=0;i<mvnext.size();i++){
				if(nvnext[i] == mvnext[i]){
					ansflag2 = false;
				}
			}


			if(ansflag || ansflag2){
				cout << l+1 << endl;
			}
		}
		cout << "+++++" << endl;
	}
}