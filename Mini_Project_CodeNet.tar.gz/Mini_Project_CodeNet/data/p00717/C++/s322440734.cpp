#include <bits/stdc++.h>
using namespace std;
typedef complex<double> xy_t;

int n;
int m[55];
xy_t P[55][15];
xy_t Q[55][15];
xy_t A[55][15];
xy_t B[55][15];
int c = 0;
int d = 0;
int main()
{
    while(cin >> n && n != 0)
    {
        for(int i = 0; i < n+1; i++)
        {
            cin >> m[i];
            for(int j = 0; j < m[i]; j++)
            {
                int x, y;
                cin >> x >> y;
                P[i][j] = xy_t(x, y);
                Q[i][m[i]-1-j] = P[i][j];
            }
        }
        
        for(int i = 1; i < n+1; i++)
        {
            A[i][0] = P[i][0];
            A[i][1] = P[i][1];
            B[i][0] = P[i][0];
            B[i][1] = P[i][1];
            for(int j = 2; j < m[i]; j++)
            {
                A[i][j] = (P[0][j] - P[0][0]) * (P[i][1] - P[i][0]) / (P[0][1] - P[0][0]) + P[i][0];
                B[i][j] = (Q[0][j] - Q[0][0]) * (P[i][1] - P[i][0]) / (Q[0][1] - Q[0][0]) + P[i][0];
            }
        }
        
        for(int i = 1; i < n+1; i++)
        {
            c = 0;
            d = 0;
            if(m[i] != m[0])
            {
                c = 1;
                d = 1;
            }
            if(abs(P[0][1] - P[0][0]) != abs(P[i][1] - P[i][0]))
            {
                c = 1;
            }
            for(int j = 0; j < m[i]; j++)
            {
                if(P[i][j] != A[i][j])
                {
                    c = 1;
                }
            }
            if(c == 0)
            {
                cout << i << endl;
            }
            else
            {
                if(abs(Q[0][1] - Q[0][0]) != abs(P[i][1] - P[i][0]))
                {
                    d = 1;
                }
                for(int j = 0; j < m[i]; j++)
                {
                    if(P[i][j] != B[i][j])
                    {
                        d = 1;
                    }
                }
                if(d == 0)
                {
                    cout << i << endl;
                }
            }
        }
        
        cout << "+++++" << endl;
    }
}