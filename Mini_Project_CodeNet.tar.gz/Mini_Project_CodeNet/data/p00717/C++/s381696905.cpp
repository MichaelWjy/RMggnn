#include<complex>
#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#define REP(i,s,n) for(int i=s;i<n;i++)
#define rep(i,n) REP(i,0,n)
#define EPS 1e-10
using namespace std;

typedef complex<int> P;
const double rad[4] ={0.0,M_PI/2,M_PI,-M_PI/2};
const int Sin[4] = {0,1,0,-1};
const int Cos[4] = {1,0,-1,0};

int main(){
  int n,m[110],x,y;
  double st,ed;
  P p[60][15];
  while(cin >> n && n){
    rep(i,n+1){
      cin >> m[i];
      rep(j,m[i]){
	cin >> x >> y; 
	p[i][j] = P(x,y);

	if(j == 1){
	  st = abs((double)(p[i][j]-p[i][j-1]));//要潤
	}
	else if(j == m[i]-1)ed = abs((double)(p[i][j]-p[i][j-1]));
      }

      if(st > ed){
	P sub = p[i][0];
	rep(j,m[i])p[i][j] -= sub;
      }
      else {
	P sub = p[i][m[i]-1];
	rep(j,m[i])p[i][j] -= sub;
	P h;
	rep(j,m[i]/2){
	  h = p[i][j];
	  p[i][j] = p[i][(m[i]-1)-j];
	  p[i][(m[i]-1)-j] = h;
	}
      } 
    }
    bool iso;
    REP(i,1,n+1){
      if(m[i] != m[0])continue;
  
      rep(j,4){
	iso = true;
	rep(k,m[0]){
	  P cp;

	  cp = P((int)(p[i][k].real()*Cos[j]-p[i][k].imag()*Sin[j]),(int)(p[i][k].real()*Sin[j]+p[i][k].imag()*Cos[j]));
		

	  if(cp != p[0][k]){iso = false; break;}
	}
	
	if(iso)break;
      }
      if(iso)cout << i << endl;
    }
    cout <<"+++++" << endl;
  }
  return 0;
}