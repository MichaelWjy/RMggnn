#include <iostream>
#include <cstdio>
#include <vector>
#include <algorithm>
#include <iterator>

using namespace std;

struct Vector2{
	double x;
	double y;
};

Vector2 rotate(Vector2 v){
	Vector2 vec;
	vec.x = -v.y;
	vec.y = v.x;
	return vec;
}

Vector2 shape[100][20];

Vector2 shape_origin[10][20];

int main(){
	
	int m_copy, n, m_origin;
	
	while(true){
		
		cin >> n;
		
		if(n == 0){
			break;
		}
		
		for(int loop = 0; loop <= n; loop++){
			int x1_, y1_, x2_, y2_;
			if(loop == 0){
				cin >> m_origin;
				cin >> x1_ >> y1_;
				for(int i = 0; i < m_origin - 1; i++){
					cin >> x2_ >> y2_;
					shape_origin[0][i].x = x2_ - x1_;
					shape_origin[0][i].y = y2_ - y1_;
					x1_ = x2_;
					y1_ = y2_;
				}
				for(int num = 1; num <= 3; num++){
					for(int i = 0; i < m_origin - 1; i++){
						shape_origin[num][i] = rotate(shape_origin[num - 1][i]);
					}
				}
				for(int num = 4; num <= 7; num++){
					for(int i = 0; i < m_origin - 1; i++){
						shape_origin[num][i].x = -shape_origin[num - 4][m_origin - 2 - i].x;
						shape_origin[num][i].y = -shape_origin[num - 4][m_origin - 2 - i].y;
					}
				}
				/*
				for(int num = 0; num <= 7; num++){
					printf("%d\n", num);
					for(int i = 0; i < m_origin - 1; i++){
						printf("%f %f\n", shape_origin[num][i].x, shape_origin[num][i].y);
					}
				}
				*/
			}else{
				cin >> m_copy;
				cin >> x1_ >> y1_;
				for(int i = 0; i < m_copy - 1; i++){
					cin >> x2_ >> y2_;
					shape[loop][i].x = x2_ - x1_;
					shape[loop][i].y = y2_ - y1_;
					x1_ = x2_;
					y1_ = y2_;
				}
				if(m_copy != m_origin){
					continue;
				}
				bool checker = false;
				for(int num = 0; num <= 7; num++){
					for(int i = 0; i < m_copy - 1; i++){
						if(shape[loop][i].x != shape_origin[num][i].x || shape[loop][i].y != shape_origin[num][i].y){
							break;
						}
						if(i == m_copy - 2){
							checker = true;
						}
					}
				}
				if(checker){
					printf("%d\n", loop);
				}
			}
		}
		printf("+++++\n");
	}
	
	return 0;
}