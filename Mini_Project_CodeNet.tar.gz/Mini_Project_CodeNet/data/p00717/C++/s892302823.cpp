#include <vector>
#include <map>
#include <set>
#include <stack>
#include <queue>
#include <deque>
#include <algorithm>
#include <utility>
#include <functional>
#include <sstream>
#include <iostream>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <cctype>
#include <string>
#include <cstring>
#include <ctime>
#include <climits>
using namespace std;
inline int toInt(string s) { int v; istringstream sin(s); sin >> v; return v;}
template<class T> inline string toString(T x) { ostringstream sout; sout << x; return sout.str();}
typedef vector<int> vi;
typedef vector<vi>  vvi;
typedef vector<string> vs;
typedef pair<int, int> pii;
typedef long long ll;
#define ALL(a) (a).begin(),(a).end()
#define RALL(a) (a).rbegin(),(a).rend()
#define EACH(t,i,c) for(t::iretator i=(c).begin(); i!=(c).end(); ++i)
#define EXIST(s,e) ((s).find(e)!=(s).end())
#define FOR(i,a,b) for(int i=(a);i<=(b);++i)
#define REP(i,n) FOR(i,0,(n)-1)
const double EPS = 1e-10;
const double PI = acos(-1.0);

int c[] = {1, 0, -1, 0};
int s[] = {0, 1, 0, -1};

bool same(vvi a, vvi b, int m) {
	REP(i, m) {
		if(a[i][0] != b[i][0] || a[i][1] != b[i][1]) {
			return false;
		}
	}
	return true;
}

int main() {
	int n;
	while(cin >> n, n) {
		int m;
		cin >> m;
		vvi line(m, vi(2));
		vvi diff(m-1, vi(2));

		REP(i, m) {
			cin >> line[i][0] >> line[i][1];
		}

		REP(i, m-1) {
			diff[i][0] = line[i+1][0] - line[i][0];
			diff[i][1] = line[i+1][1] - line[i][1];
		}

		REP(no, n) {
			int mi;
			cin >> mi;
			vvi linei(mi, vi(2));
			vvi diffi(mi-1, vi(2));

			REP(i, mi) {
				cin >> linei[i][0] >> linei[i][1];
			}

			if(m != mi) {
				continue;
			}

			REP(d, 4) {
				REP(i, m-1) {
					int dx = linei[i+1][0] - linei[i][0];
					int dy = linei[i+1][1] - linei[i][1];

					diffi[i][0] = c[d]*dx - s[d]*dy;
					diffi[i][1] = s[d]*dx + c[d]*dy;
				}

				if(same(diff, diffi, m-1)) {
					cout << no+1 << endl;
					goto next;
				}
			}
			
			REP(d, 4) {
				REP(i, m-1) {
					int dx = linei[m-i-1][0] - linei[m-i-2][0];
					int dy = linei[m-i-1][1] - linei[m-i-2][1];

					diffi[i][0] = c[d]*dx - s[d]*dy;
					diffi[i][1] = s[d]*dx + c[d]*dy;
				}

				if(same(diff, diffi, m-1)) {
					cout << no+1 << endl;
					goto next;
				}
			}

			next:;
		}
		cout << "+++++" << endl;
	}

	cout << "+++++" << endl;
	return 0;
}