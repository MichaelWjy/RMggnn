#include <bits/stdc++.h>
using namespace std;
#define int long long
#define rep(i, a, b) for (int i = (a); i < ((int)b); ++i)
#define rrep(i, a, b) for (int i = (int)(b) - 1; i >= ((int)a); --i)
#define sz(c) ((int)c.size())
#define all(c) c.begin(),c.end()

using pii = pair<int, int>;
using vi = vector<int>;
using vvi = vector<vi>;

void dump_impl(string str) {}
template <class H, class... T>
void dump_impl(string s, const H &head, const T&... tail) {
    int par = 0;
    rep(i, 0, sz(s)) {
        char ch = s[i];
        if (ch == ',' && par == 0) {
            cerr << " = " << head << ", ";
            dump_impl(s.substr(i + 1), tail...);
            return;
        } else {
            cerr << ch;
            if (ch == '(') par++;
            if (ch == ')') par--;
        }
    }
}
#define dump(...) do { cerr << "\x1b[33;1m"; dump_impl(#__VA_ARGS__ ",", __VA_ARGS__); cerr << "\x1b[0m" << endl; } while (0)

int DX[] = {0, 1, 0, -1, 1, 1, -1, -1};
int DY[] = {-1, 0, 1, 0, -1, 1, 1, -1};

vector<pii> rotate(const vector<pii> &L) {
    vector<pii> ret;
    if (L[0].first == 0 && L[0].second > 0) {
        return L;
    }
    if (L[0].first == 0 && L[0].second < 0) {
        // 180度回転
        rep(i, 0, sz(L)) {
            ret.push_back({L[i].first, -L[i].second});
        }
    }
    if (L[0].first == 1 && L[0].second > 0) {
        // 時計回りに90度
        rep(i, 0, sz(L)) {
            if (L[i].first == 0) {
                ret.push_back({1, -L[i].second});
            } else {
                ret.push_back({0, L[i].second});
            }
        }
    }
    if (L[0].first == 1 && L[0].second < 0) {
        // 反時計回りに90度
        rep(i, 0, sz(L)) {
            if (L[i].first == 1) {
                ret.push_back({0, -L[i].second});
            } else {
                ret.push_back({1, L[i].second});
            }
        }
    }
    return ret;
}

vector<pii> input_line() {
    vector<pii> ret;
    int last_x, last_y;
    int M;
    cin >> M;
    cin >> last_x >> last_y;
    rep(i, 0, M - 1) {
        int X, Y;
        cin >> X >> Y;

        int dx = X - last_x;
        int dy = Y - last_y;
        if (dx == 0) {
            ret.push_back({0, dy});
        } else if (dy == 0) {
            ret.push_back({1, dx});
        } else {
            assert(false);
        }

        last_x = X;
        last_y = Y;
    }
    return ret;
}

bool same(const vector<pii> &L, const vector<pii> &R) {
    return L == R;
}

vector<pii> rev(vector<pii> &L) {
    vector<pii> ret;
    rrep(i, 0, sz(L)) {
        ret.push_back({L[i].first, -L[i].second});
    }
    return ret;
}

signed main() {
    while (1) {
        int N;
        cin >> N;
        if (N == 0) break;
        vector<vector<pii>> lines;
        rep(i, 0, N + 1) {
            lines.push_back(input_line());
        }
        lines.front() = rotate(lines.front());
        rep(i, 1, N + 1) {
            if (same(lines[0], rotate(lines[i])) || same(lines[0], rotate(rev(lines[i])))) {
                cout << i << endl;
            }
        }
        cout << "+++++" << endl;
    }
}

