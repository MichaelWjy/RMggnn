#include <bits/stdc++.h>
#define chmin(a, b) ((a)=min((a), (b)))
#define chmax(a, b) ((a)=max((a), (b)))
#define fs first
#define sc second
#define eb emplace_back
using namespace std;
 
typedef long long ll;
typedef pair<int, int> P;
typedef tuple<int, int, int> T;
 
const ll MOD=1e9+7;
const ll INF=1e18;
 
int dx[]={1, -1, 0, 0};
int dy[]={0, 0, 1, -1};

int moto[10][12][2];

int main(){
    int n,moto_m;
    while(true){
        cin >> n;
        if(n == 0)break;
        cin >> moto_m;
        for(int i = 0;i < moto_m;i++){ // 0
            cin >> moto[0][i][0] >> moto[0][i][1];
        }
        for(int i = 1;i < moto_m;i++){
            moto[0][i][0] -= moto[0][0][0];
            moto[0][i][1] -= moto[0][0][1];
        }
        moto[0][0][0] = 0; moto[0][0][1] = 0;
        for(int i = 0;i < moto_m;i++){ // 1
            moto[1][i][0] = moto[0][i][1];
            moto[1][i][1] = -moto[0][i][0];
        }
        for(int i = 0;i < moto_m;i++){ // 2
            moto[2][i][0] = -moto[0][i][0];
            moto[2][i][1] = -moto[0][i][1];
        }
        for(int i = 0;i < moto_m;i++){ // 3
            moto[3][i][0] = -moto[0][i][1];
            moto[3][i][1] = moto[0][i][0];
        }
        for(int i = 0;i < moto_m;i++){ // 4
            moto[4][i][0] = moto[0][moto_m-i-1][0] - moto[0][moto_m-1][0];
            moto[4][i][1] = moto[0][moto_m-i-1][1] - moto[0][moto_m-1][1];
        }
        for(int i = 0;i < moto_m;i++){ // 5
            moto[5][i][0] = moto[4][i][1];
            moto[5][i][1] = -moto[4][i][0];
        }
        for(int i = 0;i < moto_m;i++){ // 6
            moto[6][i][0] = -moto[4][i][0];
            moto[6][i][1] = -moto[4][i][1];
        }
        for(int i = 0;i < moto_m;i++){ // 7
            moto[7][i][0] = -moto[4][i][1];
            moto[7][i][1] = moto[4][i][0];
        }
        for(int ii = 1;ii <= n;ii++){
            int m,line[12][2];
            cin >> m;
            for(int i = 0;i < m;i++) cin >> line[i][0] >> line[i][1];
            for(int i = 1;i < m;i++){
                line[i][0] -= line[0][0];
                line[i][1] -= line[0][1];
            }
            line[0][0] = 0; line[0][1] = 0;
            if(moto_m != m) continue;
            for(int k = 0;k < 8;k++){
                if(line[m-1][0] != moto[k][m-1][0] || line[m-1][1] != moto[k][m-1][1]) continue;
                int flag = 0;
                for(int i = 0;i < m;i++){
                    if(line[i][0] != moto[k][i][0] || line[i][1] != moto[k][i][1]){
                        flag = 1;
                        break;
                    }
                }
                if(flag == 0){
                    cout << ii << endl;
                    break;
                }
            }
        }
        cout << "+++++" << endl;

    }
}
