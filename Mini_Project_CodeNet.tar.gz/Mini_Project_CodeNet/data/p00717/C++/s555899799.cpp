#include <iostream>
#include <vector>

using namespace std;
typedef pair<int, int> P;

void solve()
{
	int n;
	while(cin >> n, n)
	{
		vector<P> input;
		int m;
		cin >> m;
		for(int i = 0; i < m; ++i)
		{
			int x, y;
			cin >> x >> y;
			input.push_back(P(x, y));
		}
		vector< vector<P> > target(4);
		for(int i = 1; i < m; ++i)
		{
			target[0].push_back(P(input[i].first - input[i - 1].first, input[i].second - input[i - 1].second));
		}
		vector< vector<P> > target_reverse(4);
		for(int i = m - 2; i >= 0; --i)
		{
			target_reverse[0].push_back(P(input[i].first - input[i + 1].first, input[i].second - input[i + 1].second));
		}
		for(int i = 1; i < 4; ++i)
		{
			for(int j = 0; j < target[0].size(); ++j)
			{
				target[i].push_back(P(-target[i - 1][j].second, target[i - 1][j].first));
				target_reverse[i].push_back(P(-target_reverse[i - 1][j].second, target_reverse[i - 1][j].first));
			}
		}
		
		for(int i = 0; i < n; ++i)
		{
			cin >> m;
			vector<P> temp;
			for(int j = 0; j < m; ++j)
			{
				int x, y;
				cin >> x >> y;
				temp.push_back(P(x, y));
			}
			vector<P> line;
			for(int j = 1; j < m; ++j)
			{
				line.push_back(P(temp[j].first - temp[j - 1].first, temp[j].second - temp[j - 1].second));
			}
			bool flag1 = false;
			bool flag2 = false;
			for(int j = 0; j < 4; ++j)
			{
				if(target[0].size() != line.size())
				{
					break;
				}
				bool flag = true;
				for(int k = 0; k < line.size(); ++k)
				{
					if(line[k].first != target[j][k].first || line[k].second != target[j][k].second)
					{
						flag = false;
						break;
					}
				}
				if(flag)
				{
					flag1 = true;
					break;
				}

				flag = true;
				for(int k = 0; k < line.size(); ++k)
				{
					if(line[k].first != target_reverse[j][k].first || line[k].second != target_reverse[j][k].second)
					{
						flag = false;
						break;
					}
				}
				if(flag)
				{
					flag2 = true;
					break;
				}
			}
			if(flag1 || flag2)
			{
				cout << i + 1 <<  endl;
			}
		}
		cout << "+++++" << endl;
	}
}

int main()
{
	solve();
	return(0);
}