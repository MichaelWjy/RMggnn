#include <iostream>
#include <vector>
#include <utility>
using namespace std;

typedef pair<int,int> pos;

void rotate(vector<pos> &v){
	for(int i=0;i<v.size();i++){
		int nx = -v[i].second;
		int ny = v[i].first;
		v[i].first=nx;
		v[i].second=ny;
	}
}

void fix(vector<pos> v1,vector<pos>& v2){
	pos p1=v1[0],p2=v2[0];
	int dx = p1.first - p2.first;
	int dy = p1.second - p2.second;
	for(int i=0;i<v2.size();i++){
		v2[i].first += dx;
		v2[i].second += dy;
	}
}

void rev(vector<pos>& v){
	vector<pos> t;
	for(int i=v.size()-1;i>=0;i--){
		t.push_back(v[i]);
	}
	v=t;
}

bool check(vector<pos> v1,vector<pos> v2 ){
	if(v1.size()!=v2.size())return false;
	
	for(int k=0;k<5;k++){
		fix(v1,v2);
		bool b=true;
		for(int i=0;i<v1.size();i++){
			if(v1[i]!=v2[i]){
				b=false;
				break;
			}
		}
		if(b)return true;
		rotate(v2);
	}
	rev(v2);
	
	for(int k=0;k<5;k++){
		bool b = true;
		fix(v1,v2);
		for(int i=0;i<v1.size();i++){
			if(v1[i]!=v2[i]){
				b=false;
				break;
			}
		}
		if(b)return true;
		rotate(v2);
		
	}
	return false;
}

int main(){
	while(true){
		int n;
		cin >> n;
		if(n==0)return 0;
		int m;
		cin >> m;
		vector<pos> v1;
		for(int i=0;i<m;i++){
			int x,y;
			cin>>x>>y;
			v1.push_back(make_pair(x,y));
		}
		for(int i=0;i<n;i++){
			int m;
			cin >> m;
			vector<pos> v2;
			for(int k=0;k<m;k++){
				int x,y;
				cin>>x>>y;
				v2.push_back(make_pair(x,y));
			}
			//cout << "121" << endl;
			if(check(v1,v2))cout << i+1 << endl;
			//cout << "12" << endl;
		}
		cout << "+++++"<<endl;
	}
}