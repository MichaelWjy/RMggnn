#include <algorithm>
#include <iostream>
#include <limits.h>
#include <math.h>
#include <set>
#include <stack>
#include <stdlib.h>
#include <string>
#include <vector>

#define el endl
#define fd fixed
#define INF INT_MAX/2-1
#define pb push_back

using namespace std;

class Point
{
public:
  int x;
  int y;
  Point(int ax, int ay) {
    x = ax, y = ay;
  }
};

vector<Point> l_rotate(vector<Point> line) {
  vector<Point> res;
  for (int i = 0; i < line.size(); i++) {
    res.pb(Point(-line[i].y, line[i].x));
  }
  return res;
}

vector<Point> r_rotate(vector<Point> line) {
  vector<Point> res;
  for (int i = 0; i < line.size(); i++) {
    res.pb(Point(line[i].y, -line[i].x));
  }
  return res;
}

int main () {
  int n, m, x0, y0, x, y;
  bool flag;
  while (cin >> n, n) {
    vector<Point> line0;
    cin >> m >> x0 >> y0;
    while (--m) {
      cin >> x >> y;
      line0.pb(Point(x-x0, y-y0));
    }
    if (line0[0].x > 0) line0 = l_rotate(line0);
    else if (line0[0].x < 0) line0 = r_rotate(line0);
    else if (line0[0].y < 0) line0 = l_rotate(line0), line0 = l_rotate(line0);
    for (int i = 1; i <= n; i++) {
      flag = true;
      cin >> m >> x0 >> y0;
      vector<Point> line1, line2;
      while(--m) {
        cin >> x >> y;
        line1.pb(Point(x-x0, y-y0));
      }
      for (int i = line1.size()-2; i >= 0; i--) {
        line2.pb(Point(line1[i].x-x, line1[i].y-y));
      }
      if (line1[0].x > 0) line1 = l_rotate(line1);
      else if (line1[0].x < 0) line1 = r_rotate(line1);
      else if (line1[0].y < 0) line1 = l_rotate(line1), line1 = l_rotate(line1);
      if (line2[0].x > 0) line2 = l_rotate(line2);
      else if (line2[0].x < 0) line2 = r_rotate(line2);
      else if (line2[0].y < 0) line2 = l_rotate(line2), line2 = l_rotate(line2);
      for (int i = 0; i < line1.size(); i++) {
        if (line0[i].x != line1[i].x || line0[i].y != line1[i].y) {
          flag = false;
          break;
        }
      }
      if (!flag) {
        flag = true;
        for (int i = 0; i < line2.size(); i++) {
          if (line0[i].x != line2[i].x || line0[i].y != line2[i].y) {
            flag = false;
            break;
          }
        }
      }
      if (flag) cout << i << el;
    }
    cout << "+++++" << el;
  }
}