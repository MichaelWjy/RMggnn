#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
#include<cstdlib>

#define EPS (1e-10)

using namespace std;

static const int COUNTER_CLOCKWISE = 1;
static const int CLOCKWISE = -1;
static const int ONLINE_BACK = 2;
static const int ONLINE_FRONT = -2;
static const int ON_SEGMENT = 0;



class Point{
public:
  double x,y;
  
  Point(double x = 0, double y = 0): x(x),y(y){};
  
  Point operator + (Point p) {return Point(x+p.x,y+p.y);}
  Point operator - (Point p) {return Point(x-p.x,y-p.y);}
  Point operator * (double a) {return Point(a*x,a*y);}

  double own_dot(){return x*x+y*y;};
  double abs(){return sqrt(own_dot());}

  bool operator < (const Point &p) const {
    return x != p.x ? x < p.x : y < p.y;
  }
  bool operator == (const Point &p) const{
    return fabs(x-p.x) < EPS && fabs(y-p.y) < EPS;
  }
};

double dot(Point a, Point b){
  return a.x*b.x+a.y*b.y;
}

double cross(Point a, Point b){
  return a.x*b.y-a.y*b.x; 
}


int ccw(Point p0, Point p1, Point p2){
  Point a = p1-p0;
  Point b = p2-p0;
  if(cross(a,b) > EPS) return COUNTER_CLOCKWISE;
  if(cross(a,b) < -EPS) return CLOCKWISE;
  if(dot(a,b) < -EPS) return ONLINE_BACK;
  if(a.own_dot() < b.own_dot()) return ONLINE_FRONT;
  return ON_SEGMENT;
}

const int MAX = 51;
int n;
vector<Point> V[MAX];

void init(){
  for(int i = 0; i < MAX; i++) V[i].clear();
}

void input(){


  for(int i = 0; i <= n; i++){
    int m;
    cin >> m;

    V[i].resize(m);
    for(int j = 0; j < m; j++) cin >> V[i][j].x >> V[i][j].y;
  }
}

bool isSame(const vector<Point>& P1, vector<Point> P2, const bool option){
  
  if(P1.size() != P2.size()) return false;

  if(option) reverse(P2.begin(),P2.end());

  for(int i = 1; i < P1.size(); i++){
    double diff1 = (P1[i].x-P1[i-1].x)*(P1[i].x-P1[i-1].x) + (P1[i].y-P1[i-1].y)*(P1[i].y-P1[i-1].y);
    double diff2 = (P2[i].x-P2[i-1].x)*(P2[i].x-P2[i-1].x) + (P2[i].y-P2[i-1].y)*(P2[i].y-P2[i-1].y);
    if(diff1 != diff2) return false;
  }
  
  
  for(int i = 2; i < P1.size(); i++){
    int rev1 = ccw(P1[i-2],P1[i-1],P1[i]);
    int rev2 = ccw(P2[i-2],P2[i-1],P2[i]);
    if(rev1 != rev2) return false;
  }
  return true;
}


void solve(){

  for(int i = 1; i <= n; i++){
    
    if(isSame(V[0],V[i],false) || isSame(V[0],V[i],true)) cout << i << endl; 
    
  }

  cout << "+++++" << endl;
}

int main(){
  while(cin >> n && n){
    init();
    input();
    solve();
  }
  return 0;
}