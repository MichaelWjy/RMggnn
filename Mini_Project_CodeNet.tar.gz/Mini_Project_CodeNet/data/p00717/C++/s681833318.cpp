#include <bits/stdc++.h>

#define REP(i, n) for(int i = 0; i < (int) (n); i++)
#define ALL(v) (v).begin(), (v).end()
#define INF (1e9+7)

using namespace std;

typedef pair<int, int> pii;

struct edge{
  int l;
  bool xaxis;
  edge(const pii &fr,const pii &to){
    if(fr.first == to.first){
      l = to.second - fr.second;
      xaxis = false;
    } else {
      l = to.first - fr.first;
      xaxis = true;
    }
  }
  edge() : l(0), xaxis(false) {}
};

vector<pii> vs(50);
vector<pii> revvs(50);
vector<pii> tvs(50);
vector<edge> forw(10);
vector<edge> rev(10);
vector<edge> tmpl(10);
vector<edge> target(10);

int main(){
  int n;
  while(cin >> n and n){
    int m;
    cin >> m;
    REP(i, m) {
      int tmpx, tmpy; cin >> tmpx >> tmpy;
      vs[i] = make_pair(tmpx, tmpy);
      revvs[m-1-i] = make_pair(tmpx, tmpy);
    }
    REP(i, m-1){
      forw[i] = edge(vs[i], vs[i+1]);
      rev[i] = edge(revvs[i], revvs[i+1]);
    }
    for(int count = 1; count < n+1; count++){
      int mm; cin >> mm;
      REP(i, mm) {
        int tmpx, tmpy; cin >> tmpx >> tmpy;
        tvs[i] = make_pair(tmpx, tmpy);
      }
      if(m != mm) continue;
      REP(i, m-1) target[i] = edge(tvs[i], tvs[i+1]);
      for(int kind = 0; kind < 2; kind++){
        bool match = true;
        if(kind) tmpl = rev;
        else tmpl = forw;
        if(abs(tmpl[0].l) != abs(target[0].l)) continue;
        if(tmpl[0].xaxis == target[0].xaxis){
          bool flag = (tmpl[0].l == target[0].l);
          for(int i=1; i<m-1; i++)
            if(tmpl[i].l != ((flag ? 1 : -1) * target[i].l)) match = false;
          if(match) { cout << count << endl; break;}
        } else {
          bool flag = (tmpl[0].l == target[0].l);
          for(int i=1; i<m-1; i++){
            if(i%2) {
              if(tmpl[i].l != ((flag ? -1 : 1) * target[i].l)) match = false;
            } else if(tmpl[i].l != ((flag ? 1 : -1) * target[i].l)) match = false;
          }
          if(match) { cout << count << endl; break; }
        }
      }
    }
    cout << "+++++" << endl;
  }
  return 0;
}