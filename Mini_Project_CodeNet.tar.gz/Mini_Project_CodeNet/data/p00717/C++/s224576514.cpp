#include <algorithm>
#include <iostream>
#include <vector>
#include <math.h>
#include <set>
#include <map>
#include <string>
#include <stack>
#include <queue>
#include <iomanip>
#include <numeric>
#include <tuple>
#include <bitset>
#include <complex>
#include <unistd.h>
#include <cassert>
#include <cctype>
#include <random>
#define _USE_MATH_DEFINES
#define _GLIBCXX_DEBUG
using namespace std;
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> plglg;
typedef tuple<int, int, int> tiii;
typedef tuple<ll, ll, ll> tlglglg;
typedef complex<double> xy_t;
int dx[4] = {1, 0, -1, 0};
int dy[4] = {0, 1, 0, -1};
double pi = 3.141592653589793;
ll mod = 1000000007;
int intmax = 2147483647;
int intmin = -2147483648;
ll llmax = 9223372036854775807;
ll llmin = -9223372036854775807;
ll inf = llmax / 2;
double eps = 1e-11;

xy_t base[2][11];

xy_t diff[11];

int main() {
    while (1) {
        int N;
        cin >> N;
        if (N == 0) {
            break;
        }
        int M;
        cin >> M;
        int pos[M][2];
        for (int i = 0; i < M; i++) {
            cin >> pos[i][0] >> pos[i][1];
        }
        xy_t rot[2];
        int x = pos[0][0];
        int y = pos[0][1];
        int xx = pos[1][0];
        int yy = pos[1][1];
        if (y == yy) {
            if (xx > x) {
                rot[0] = xy_t(cos(0), sin(0));
            } else {
                rot[0] = xy_t(cos(pi), sin(pi));
            }
        } else {
            if (yy > y) {
                rot[0] = xy_t(cos(-pi / 2.0), sin(- pi / 2.0));
            } else {
                rot[0] = xy_t(cos(pi / 2.0), sin(pi / 2.0));
            }
        }
        x = pos[M - 1][0];
        y = pos[M - 1][1];
        xx = pos[M - 2][0];
        yy = pos[M - 2][1];
        if (y == yy) {
            if (xx > x) {
                rot[1] = xy_t(cos(0), sin(0));
            } else {
                rot[1] = xy_t(cos(pi), sin(pi));
            }
        } else {
            if (yy > y) {
                rot[1] = xy_t(cos(-pi / 2.0), sin(- pi / 2.0));
            } else {
                rot[1] = xy_t(cos(pi / 2.0), sin(pi / 2.0));
            }
        }
        for (int j = 0; j < M - 1; j++) {
            base[0][j] = rot[0] * xy_t(pos[j + 1][0] - pos[0][0], pos[j + 1][1] - pos[0][1]);
            base[1][j] = rot[1] * xy_t(pos[M - 1 - j - 1][0] - pos[M - 1][0],
                                       pos[M - 1 - j - 1][1] - pos[M - 1][1]);
        }
        // for (int i = 0; i < 2; i++) {
        //     for (int j = 0; j < M - 1; j++) {
        //         cout << base[i][j].real() << " " << base[i][j].imag() << endl;
        //     }
        // }
        for (int i = 0; i < N; i++) {
            int mm;
            cin >> mm;
            if (mm != M) {
                int xp, yp;
                for (int i = 0; i < mm; i++) {
                    cin >> xp >> yp;
                }
                continue;
            }
            int difpos[M][2];
            for (int j = 0; j < M; j++) {
                cin >> difpos[j][0] >> difpos[j][1];
            }
            xy_t difrot;
            x = difpos[0][0];
            y = difpos[0][1];
            xx = difpos[1][0];
            yy = difpos[1][1];
            if (y == yy) {
                if (xx > x) {
                    difrot = xy_t(cos(0), sin(0));
                } else {
                    difrot = xy_t(cos(pi), sin(pi));
                }
            } else {
                if (yy > y) {
                    difrot = xy_t(cos(-pi / 2.0), sin(- pi / 2.0));
                } else {
                    difrot = xy_t(cos(pi / 2.0), sin(pi / 2.0));
                }
            }
            for (int j = 0; j < M - 1; j++) {
                diff[j] = difrot * xy_t(difpos[j + 1][0] - difpos[0][0], difpos[j + 1][1] - difpos[0][1]);
            }
            bool pre = true;
            for (int j = 0; j < M - 1; j++) {
                if (abs(base[0][j] - diff[j]) > 1e-7) {
                    pre = false;
                    break;
                }
            }
            if (pre) {
                cout << i + 1 << endl;
            } else {
                bool post = true;
                for (int j = 0; j < M - 1; j++) {
                    if (abs(base[1][j] - diff[j]) > 1e-7) {
                        post = false;
                        break;
                    }
                }
                if (post) {
                    cout << i + 1 << endl;
                }
            }
        }
        cout << "+++++" << endl;
    }
}

