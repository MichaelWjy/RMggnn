#include <iostream>
#include <algorithm>
#include <string>
#include <vector>
#include <queue>
#include <complex>
using namespace std;

typedef complex<int> Point;

int m;
Point line_ori[10];
Point lines[50][10];
Point lines2[50][10];

void normalize(Point *line) {
  Point p = line[0];
  for(int i = 0;i < m;i++) line[i] -= p;
  int ct = 0;
  for(int i = 0;i < 3;i++) {
    if(line[1].real() > 0) break;
    line[1] *= Point(0,-1);
    ct++;
  }
  for(int i = 2;i < m;i++) {
    for(int j = 0;j < ct;j++) line[i] *= Point(0,-1);
  }
}

int main() {

	int n;
	while(cin >> n && n != 0) {
	  int x,y,m2;
		cin >> m;
		for(int i = 0;i < m;i++) {
			cin >> x >> y;
			line_ori[i] = Point(x,y);
		}
		normalize(line_ori);
		m2 = m;

		for(int i = 0;i < n;i++) {
			cin >> m;
			for(int j = 0;j < m;j++) {
				cin >> x >> y;
				lines[i][j] = Point(x,y);
				lines2[i][m - j - 1] = Point(x,y);
			}

			if(m != m2) continue;
			
		        normalize(lines[i]);
			normalize(lines2[i]);

			bool f1 = true,f2 = true;
			for(int j = 0;j < m;j++) {
				f1 = f1 && (lines[i][j] == line_ori[j]);
				f2 = f2 && (lines2[i][j] == line_ori[j]);
			}
		      
			if(f1 || f2) cout << i + 1 << endl;
		} 
		cout << "+++++" << endl;

	}

}