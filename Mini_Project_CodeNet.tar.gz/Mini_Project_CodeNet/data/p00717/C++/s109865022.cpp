#include <iostream>
#include <vector>
#include <complex>
#include <utility>
#include <algorithm>
using namespace std;

typedef pair<int, int> Point;

int dis(Point a, Point b){
  return abs((a.first - b.first) + (a.second - b.second));
}
int compass(Point a, Point b, Point c){
  if(a.first < b.first && c.second < b.second){ return 1; }
  if(a.second < b.second && c.first > b.first){ return 1; }
  if(a.first > b.first && c.second > b.second){ return 1; }
  if(a.second > b.second && c.first < b.first){ return 1; }
  return -1;
}

int main(void){
  while(true){
    int n;
    cin >> n;
    if(n == 0){ break; }
    ++n;
    
    // ??\??????????????????
    vector<vector<Point> > input(n);
    for(int i = 0; i < n; i++){
      int m;
      cin >> m;
      for(int j = 0; j < m; j++){
        int x, y;
        cin >> x >> y;
        input[i].push_back(Point(x, y));
      }
    }

    // ?????¢??¨???????????????????????????????????????
    vector<vector<int> > poly(n);
    for(int i = 0; i < n; i++){
      for(int j = 1; j < (int)input[i].size(); j++){
        poly[i].push_back(dis(input[i][j - 1], input[i][j]));
        if(j + 1 < (int)input[i].size()){
          poly[i].push_back(compass(input[i][j - 1], input[i][j], input[i][j + 1]));
        }
      }
    }

    // ?????´??????
    for(int i = 1; i < n; i++){
      if(poly[i].size() != poly[0].size()){ continue; }
      if(poly[i] == poly[0]){ cout << i << endl; }
      else{
        reverse(poly[i].begin(), poly[i].end());
        for(int j = 1; j < (int)poly[i].size(); j += 2){ poly[i][j] *= -1; }
        if(poly[i] == poly[0]){ cout << i << endl; }
      }
    }

    cout << "+++++" << endl;
  }
  
  return 0;
}