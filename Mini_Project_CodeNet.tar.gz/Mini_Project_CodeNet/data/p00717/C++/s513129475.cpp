#include<iostream>
#include<iomanip>
#include<math.h>
#include<algorithm>
#include<string>
#include<vector>
#include<queue>
#include<stack>
#include<set>
#include<map>
#define REP(i, N) for(ll i = 0; i < N; ++i)
#define FOR(i, a, b) for(ll i = a; i < b; ++i)
#define ALL(a) (a).begin(),(a).end()
#define pb push_back
#define INF (long long)1000000000
#define MOD 1000000007
using namespace std;
typedef long long ll;
typedef pair<ll, ll> P;
int dx[4] = {1, 0, -1, 0};
int dy[4] = {0, 1, 0, -1};

int main(void) {
	while(true) {
		int n;
		cin>>n;
		if(n == 0) break;
		int m;
		cin>>m;
		vector<P> z(m);
		string sr = "";
		string sl = "";
		vector<int> ans;
		REP(i, m) {
			int x, y;
			cin>>x>>y;
			z[i].first = x;
			z[i].second = y;
		}
		FOR(i, 1, m) {
			sr += to_string(abs(z[i].first - z[i - 1].first) + abs(z[i].second - z[i - 1].second));
			sl = to_string(abs(z[i].first - z[i - 1].first) + abs(z[i].second - z[i - 1].second)) + sl;
			if(i != m - 1) {
				P l1, l2;
				l1.first = z[i].first - z[i - 1].first;
				l1.second = z[i].second - z[i - 1].second;
				l2.first = z[i + 1].first - z[i].first;
				l2.second = z[i + 1].second - z[i].second;
				ll gs = l1.first * l2.second - l1.second * l2.first;
				if(gs > 0) {
					sr += "r";
					sl = "l" + sl;
				}
				else {
					sr += "l";
					sl = "r" + sl;
				}
			}
		}
		REP(i, n) {
			cin>>m;
			string t;
			vector<P> Z(m);
			REP(j, m) {
				int x, y;
				cin>>x>>y;
				Z[j].first = x;
				Z[j].second = y;
			}
			FOR(j, 1, m) {
				t += to_string(abs(Z[j].first - Z[j - 1].first) + abs(Z[j].second - Z[j - 1].second));
				if(j != m - 1) {
					P l1, l2;
					l1.first = Z[j].first - Z[j - 1].first;
					l1.second = Z[j].second - Z[j - 1].second;
					l2.first = Z[j + 1].first - Z[j].first;
					l2.second = Z[j + 1].second - Z[j].second;
					ll gs = l1.first * l2.second - l1.second * l2.first;
					if(gs > 0) t += "r";
					else t += "l";
				}
			}
			if(sr == t || sl == t) ans.pb(i + 1);
		}
		REP(i, ans.size()) {
			cout<<ans[i]<<endl;
		}
		cout<<"+++++"<<endl;
	}
}