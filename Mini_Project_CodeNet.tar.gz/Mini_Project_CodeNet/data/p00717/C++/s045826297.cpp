#include<iostream>
#include<string>
#include<vector>
using namespace std;
#define int long long
#define rep(i,n) for(int i = 0; i < n; i++)
#define INF (long long)(1e18)
#define MOD (int)(1e9+7)
#define MAX_N 103
#define MAX_V 10
#define MAX_M 101
#define yn(f) (f?"Yes":"No")
#define YN(f) (f?"YES":"NO")
#define pro "はいプロ　世界一○○が上手　○○界のtourist　○○時代の終焉を告げる者　実質○○　○○するために生まれてきた男"

vector<pair<int,int>> rotation(vector<pair<int,int>> a){
	vector<pair<int,int>> b;
	for(pair<int,int> z: a)
		b.push_back(make_pair(z.second,z.first*-1));
	return b;
}

vector<pair<int,int>> huga(vector<pair<int,int>> a){
	vector<pair<int,int>> b;
	int size = a.size(), x = a[size-1].first , y = a[size-1].second;
	for(int i = size-1; i >= 0; i--)
		b.push_back(make_pair(a[i].first-x,a[i].second-y));
	
	return b;
}

bool foo(vector<pair<int,int>> a, vector<pair<int,int>> b){
	if(a.size() != b.size()) return false;
	for(int i = 0; i < 4; i++){
		if(a==b)      return true;
		if(huga(a)==b)return true;
		a = rotation(a);
	}
	return false;
}

signed main(){
	while(true){
		int n, m, x, y, x0, y0;
		cin>>n;
		vector<pair<int,int>> ve[n+4];
		if(!n)break;
		for(int i = 0; i <= n; i++){
			cin>>m;
			for(int j = 1; j <= m; j++){
				cin>>x>>y;
				if(j==1)x0 = x, y0 = y;
				ve[i].push_back(make_pair(x-x0,y-y0));
			}
			if(i&&foo(ve[0], ve[i]))cout<<i<<endl;
		}
		cout<<"+++++"<<endl;
	}
	return 0;
}
