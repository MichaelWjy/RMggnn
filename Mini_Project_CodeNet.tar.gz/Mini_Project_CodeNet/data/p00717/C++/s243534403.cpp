#include<bits/stdc++.h>
using namespace std;

typedef long long int ll;
typedef pair<int, int> pii;
typedef vector<int> vi;
typedef vector<pair<int, int> > vii;
#define rrep(i, m, n) for(int (i)=(m); (i)<(n);  (i)++)
#define erep(i, m, n) for(int (i)=(m); (i)<=(n); (i)++)
#define  rep(i, n)    for(int (i)=0; (i)<(n);  (i)++)
#define rrev(i, m, n) for(int (i)=(n)-1; (i)>=(m); (i)--)
#define erev(i, m, n) for(int (i)=(n); (i)>=(m); (i)--)
#define  rev(i, n)    for(int (i)=(n)-1; (i)>=0; (i)--)
#define vrep(i, c)    for(__typeof((c).begin())i=(c).begin(); i!=(c).end(); i++)
#define  ALL(v)       (v).begin(), (v).end()
#define pb            push_back
#define mp            make_pair
template<class T, class S> inline bool minup(T& m, const S x){ return m>(T)x ? (m=(T)x, true) : false; }
template<class T, class S> inline bool maxup(T& m, const S x){ return m<(T)x ? (m=(T)x, true) : false; }

static const int    INF = 1000000000;
static const ll     MOD = 1000000007LL;
static const double EPS = 1E-10;

const int dx[] = {1, 0, -1, 0};
const int dy[] = {0, 1, 0, -1};
int n;
int m[55];
int x[55][22], y[55][22];

inline bool rotate(int k, int i, int j)
{
  if(k == 0){
    if(x[0][j + 1] - x[0][j] != x[i][j + 1] - x[i][j]) return false;
    if(y[0][j + 1] - y[0][j] != y[i][j + 1] - y[i][j]) return false;
    return true;
  }
  if(k == 1){
    if(x[0][j + 1] - x[0][j] != - y[i][j + 1] + y[i][j]) return false;
    if(y[0][j + 1] - y[0][j] !=   x[i][j + 1] - x[i][j]) return false;
    return true;
  }
  if(k == 2){
    if(x[0][j + 1] - x[0][j] != - x[i][j + 1] + x[i][j]) return false;
    if(y[0][j + 1] - y[0][j] != - y[i][j + 1] + y[i][j]) return false;
    return true;
  }
  if(k == 3){
    if(x[0][j + 1] - x[0][j] !=   y[i][j + 1] - y[i][j]) return false;
    if(y[0][j + 1] - y[0][j] != - x[i][j + 1] + x[i][j]) return false;
    return true;
  }
}

int main(int argc, char *argv[])
{
  while(cin >> n, n){
    rep(i, n + 1){
      cin >> m[i];
      rep(j, m[i]){
        cin >> x[i][j] >> y[i][j];
      }
    }

    erep(i, 1, n){
      bool ok = false;
      if(m[0] == m[i]) rep(_, 2){
        int p = INF;
        rep(k, 4) if(rotate(k, i, 0)){
          p = k;
          break;
        }
        if(p < INF){
          ok = true;
          rep(j, m[i] - 1) if(!rotate(p, i, j)){
            ok = false;
            break;
          }
          if(ok) break;
        }
        rep(j, m[i] / 2){
          swap(x[i][j], x[i][m[i] - j - 1]);
          swap(y[i][j], y[i][m[i] - j - 1]);
        }
      }
      if(ok) cout << i << endl;
    }

    cout << "+++++" << endl;
  }
  
  return 0;
}