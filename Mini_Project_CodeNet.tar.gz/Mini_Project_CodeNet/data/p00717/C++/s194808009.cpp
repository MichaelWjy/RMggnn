#include<bits/stdc++.h>
#define INF 2000000000
#define MOD 1000000007
#define EPS (1e-10)

using namespace std;


vector<int>  dx = {1,-1,0,0};
vector<int>  dy = {0,0,1,-1};

pair<int,int> rot(pair<int,int> p) {
	int _x = - p.second;
	int _y = p.first;
	return make_pair(_x,_y);	
}

bool check(vector<pair<int,int>> v1,vector<pair<int,int>> v2) {
	for (int i = 0; i < v1.size(); i++) {
		if (v1[i] != v2[i]) {
			return false;
		}
	}
	return true;
}



int main() {

	while(1) {
		int n; cin >> n;
		if (n == 0) break;

		int m; cin >> m;
		vector<pair<int,int>> vo(m);
		for (int i = 0; i < m; i++) {
			int x,y; cin >> x >> y;
			vo[i] = make_pair(x,y);
		}
		int sx = vo[0].first;
		int sy = vo[0].second;
		for (int j = 0; j < m; j++) {
			vo[j].first -= sx;
			vo[j].second -= sy;
		}

		for (int i = 1; i <= n; i++) {
			int m; cin >> m;
			bool flg = false;
			vector<pair<int,int>> v(m);
			for (int j = 0; j < m; j++) {
				int x,y; cin >> x >> y;
				v[j] = make_pair(x,y);
			}
			//ido
			int sx = v[0].first;
			int sy = v[0].second;
			for (int j = 0; j < m; j++) {
				v[j].first -= sx;
				v[j].second -= sy;
			}
			for (int j = 0; j < 4; j++) {
				for (int k = 0; k < m; k++) {
					v[k] = rot(v[k]);
				}
				if (check(v,vo)) {
					flg = true;
				}
			}


			int ex = v[m-1].first;
			int ey = v[m-1].second;
			for (int j = 0; j < m; j++) {
				v[j].first -= ex;
				v[j].second -= ey;
			}
			reverse(v.begin(),v.end());
			for (int j = 0; j < 4; j++) {
				for (int k = 0; k < m; k++) {
					v[k] = rot(v[k]);
				}
				if (check(v,vo)) {
					flg = true;
				}
			}
			if (flg) {
				cout << i << endl;
			}
		}	
		cout << "+++++" << endl;
	}    	
	return 0;
}        	

