#include<iostream>
#include<vector>
#include<algorithm>
#include<utility>
#include<string>
#include<cmath>
#include<cstring>
#include<queue>
#include<map>
#include<climits>
#include<set>
#include<complex>

#define llong long long;
using namespace std;
typedef pair<int, int> pii;
typedef long long int ll;
typedef pair<ll, ll> pll;
int dx[4] = { 1,0,0,-1 };
int dy[4] = { 0,1,-1,0 };
#define MOD 1000000007
#define ARRAY_MAX 55

//const int INF = 1e9 + 7;


typedef complex<int> cpi;
int n;
int m[ARRAY_MAX];


int main() {


	cpi mp[55][15];
	while (cin >> n, n)
	{
		for (int i = 0; i <= n; i++) {
			cin >> m[i];
			for (int j = 0; j < m[i]; j++) {
				int a, b;
				cin >> a >> b;
				mp[i][j] = cpi(a, b);
			}
		}

		//入力終了

		for (int i = 1; i <= n; i++) {

			if (m[0] != m[i]) {
				//座標の数が違う
				continue;
			}


			for (int tm = 0; tm < 4; tm++) {
				//4回回転させる
				for (int j = 0; j < m[0]; j++) {
					mp[0][j] *= cpi(0, 1);//元の折れ線を回転させる
				}

				bool flag = true;

				//そのまま比較
				for (int index = 1; index < m[0]; index++)
				{
					flag &= (((mp[i][index].real() - mp[i][index - 1].real()) == (mp[0][index].real() - mp[0][index - 1].real()))
						&& ((mp[i][index].imag() - mp[i][index - 1].imag()) == (mp[0][index].imag() - mp[0][index - 1].imag())));

				}

				if (flag == true) {
					cout << i << endl;
					break;
				}
				//逆順比較
				flag = true;
				for (int index = 1; index < m[0]; index++)
				{
					flag &= (((mp[i][index].real() - mp[i][index - 1].real()) == (mp[0][m[0] - 1 - index].real() - mp[0][m[0] - index].real()))
						&& ((mp[i][index].imag() - mp[i][index - 1].imag()) == (mp[0][m[0] - 1 - index].imag() - mp[0][m[0] - index].imag())));

				}

				if (flag == true) {
					cout << i << endl;
					break;
				}
			}
		}
		cout << "+++++" << endl;
	}

	return 0;
}
