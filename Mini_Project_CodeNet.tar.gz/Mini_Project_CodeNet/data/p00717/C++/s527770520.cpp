#include <bits/stdc++.h>
using namespace std;
#define int long long
#define REP(i,n) for(int i = 0; i < (int)(n); ++i)
#define DEBUG(x) cerr << #x << " = " << x << endl
struct P {
  int x, y;
  P(int x_, int y_) : x(x_), y(y_) {}
  P() {}
  bool operator ==(const P &other) const {
    return x == other.x && y == other.y;
  }
  bool operator !=(const P &other) const {
    return !(*this == other);
  }
};
ostream &operator <<(ostream &os, const P &p) {
  os << "(" << p.x << "," << p.y << ")";
  return os;
}
int direction(const P &p) {
  if (p.y == 0 && p.x > 0) return 0;
  if (p.y > 0 && p.x == 0) return 3;
  if (p.y == 0 && p.x < 0) return 2;
  return 1;
}
P rot(const P &p, int direction) {
  if (direction == 0) return p;
  if (direction == 1) return P(-p.y, p.x);
  if (direction == 2) return P(-p.x, -p.y);
  return P(p.y, -p.x);
}
bool same(const vector<P> &a, const vector<P> &b) {
  if (a.size() != b.size()) return false;
  int N = a.size();
  vector<P> l(N), r(N);
  REP(i,N) {
    l[i] = P(a[i].x - a[0].x, a[i].y - a[0].y);
    r[i] = P(b[i].x - b[0].x, b[i].y - b[0].y);
  }
  bool ok = true;
  for(int i = 1; i < N; i++) {
    if(rot(l[i], direction(l[1])) != rot(r[i], direction(r[1]))) ok = false;
  }
  // if(ok) {
  //   cerr << "[";
  //   REP(i,N) cerr << l[i];
  //   cerr << "] = [";
  //   REP(i,N) cerr << r[i];
  //   cerr << "]" << endl;
  // }
  if(ok) return true;
  REP(i,N) {
    l[i] = P(a[i].x - a[0].x, a[i].y - a[0].y);
    r[i] = P(b[N - 1 - i].x - b[N - 1].x, b[N - 1 - i].y - b[N - 1].y);
  }
  ok = true;
  for(int i = 1; i < N; i++) {
    if(rot(l[i], direction(l[1])) != rot(r[i], direction(r[1]))) ok = false;
  }
  // if(ok) {
  //   cerr << "[";
  //   REP(i,N) cerr << l[i];
  //   cerr << "] = [";
  //   REP(i,N) cerr << r[i];
  //   cerr << "]" << endl;
  // }
  if(ok) return true;
  return false;
}
signed main() {
  ios::sync_with_stdio(false);
  while(true) {
    int N; cin >> N;
    if(N == 0) break;
    vector<vector<P>> DS(N + 1);
    REP(i,N + 1) {
      int M; cin >> M;
      vector<P> D(M);
      REP(j,M) {
        int x, y; cin >> x >> y;
        D[j] = P(x, y);
      }
      DS[i] = D;
    }
    for(int i = 1; i <= N; i++) {
      if(same(DS[0], DS[i])) {
        cout << i << endl;
      }
    }
    cout << "+++++" << endl;
  }
}