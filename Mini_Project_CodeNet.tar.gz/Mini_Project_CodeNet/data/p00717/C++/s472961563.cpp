#include <bits/stdc++.h>
using namespace std;
using Pi = pair<int, int>;
bool solve() {
    int N;
    cin >> N;
    if (N == 0) return (false);
    int bm;
    int X[15], Y[15];
    vector<Pi> base[8];
    
    auto rotate = [](int &x, int &y) {
        swap(y = -y, x);
    };
    
    cin >> bm;
    for (int i = 0; i < bm; i++) cin >> X[i] >> Y[i];

    for (int i = 1; i < bm; i++) {
        int x = X[i] - X[0], y = Y[i] - Y[0];
        for (int j = 0; j < 4; j++) {
            base[j].emplace_back(x, y);
            rotate(x, y);
        }
    }

    for (int i = bm - 2; i >= 0; i--) {
        int x = X[i] - X[bm - 1], y = Y[i] - Y[bm - 1];
        for (int j = 4; j < 8; j++) {
            base[j].emplace_back(x, y);
            rotate(x, y);
        }
    }

    for (int i = 0; i < N; i++) {
        int m, bx, by;
        cin >> m;
        cin >> bx >> by;
        vector<Pi> comp;
        bool flag = false;
        for (int i = 0; i < m - 1; i++) {
            int x, y;
            cin >> x >> y;
            x -= bx, y -= by;
            comp.emplace_back(x, y);
        }
        if (m != bm) continue;
        for (int i = 0; i < 8; i++) {
            if (comp == base[i]) flag = true;
        }
        if (flag) cout << i + 1 << endl;
    }
    cout << "+++++" << endl;
    return (true);
}

int main() {
    while (solve());
    return (0);
}
