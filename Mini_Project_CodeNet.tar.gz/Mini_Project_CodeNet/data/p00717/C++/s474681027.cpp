#include <bits/stdc++.h>
#define range(i, a, b) for(int i = (a); i < (b); i++)
#define rep(i, a) range(i, 0, a)
using namespace std;

const double PI  = acos(-1);
const double EPS = 1e-10;
typedef complex <double> P;
/*
 * 実数         : p.real() or real(p)
 * 虚数         : p.imag() or imag(p)
 * 偏角         : arg(p)
 * 長さ         : abs(p)
 * ノルム       : norm(p)
 * 共役な複素数 : conj(p)
 */

int main() {
    int n;
    while (cin >> n, n) {
        vector <vector <P>> line, gen(4);
        rep (i, n + 1) {
            int m;
            cin >> m;
            vector <P> tmp;
            int x0, y0;
            rep (j, m) {
                int x, y;
                cin >> x >> y;
                if (j == 0) {
                    x0 = x, y0 = y;
                    x = y = 0;
                }
                else {
                    x -= x0, y -= y0;
                }
                if (i == 0) {
                    gen[0].emplace_back(x * -1, y * -1);
                    gen[1].emplace_back(x, y);
                    swap(x, y);
                    gen[2].emplace_back(x, y * -1);
                    gen[3].emplace_back(x * -1, y);
                }
                else {
                    tmp.emplace_back(x, y);
                }
            }
            if (i == 0) {
                int sz = gen.size();
                rep (j, sz) {
                    vector <P> rev = gen[j];
                    int x0 = rev.back().real(), y0 = rev.back().imag();
                    rep (k, gen[j].size()) {
                        rev[k].real(rev[k].real() - x0);
                        rev[k].imag(rev[k].imag() - y0);
                    }
                    reverse(rev.begin(), rev.end());
                    gen.push_back(rev);
                }
            }

            if (i != 0) line.push_back(tmp);
        }

        rep (i, line.size()) {
            rep (j, gen.size()) {
                bool flag = true;
                rep (k, gen[j].size()) {
                    flag &= gen[j][k] == line[i][k];
                }
                if (flag) {
                    cout << i + 1 << endl;
                    break;
                }
            }
        }
        cout << "+++++" << endl;
    }
    return 0;
}
