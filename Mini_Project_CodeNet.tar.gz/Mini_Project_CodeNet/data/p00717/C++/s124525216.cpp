#include <stdio.h>
#include <cmath>
#include <algorithm>
#include <cfloat>
#include <stack>
#include <queue>
#include <vector>
typedef long long int ll;
#define BIG_NUM 2000000000
#define MOD 1000000007
#define EPS 0.000001
using namespace std;

int N;

struct Point{
	int x,y;
};

struct Info{
	int num_point;
	Point point[10];
};

void func(){

	Info base;
	int DIFF_X,DIFF_Y;

	int M;
	scanf("%d",&M);

	base.num_point = M;

	for(int i = 0; i < M; i++){
		scanf("%d %d",&base.point[i].x,&base.point[i].y);
	}

	DIFF_X = -base.point[0].x;
	DIFF_Y = -base.point[0].y;

	for(int i = 0; i < base.num_point; i++){
		base.point[i].x += DIFF_X;
		base.point[i].y += DIFF_Y;
	}

	Info tmp;

	int new_x,new_y;

	for(int id = 1; id <= N; id++){
		scanf("%d",&M);

		tmp.num_point = M;

		for(int i = 0; i < M; i++){
			scanf("%d %d",&tmp.point[i].x,&tmp.point[i].y);
		}

		if(base.num_point != tmp.num_point){
			continue;
		}

		DIFF_X = -tmp.point[0].x;
		DIFF_Y = -tmp.point[0].y;

		for(int i = 0; i < tmp.num_point; i++){
			tmp.point[i].x += DIFF_X;
			tmp.point[i].y += DIFF_Y;
		}

		bool FLG;
		int base_x_diff,base_y_diff,tmp_x_diff,tmp_y_diff;

		for(int loop = 0; loop < 4; loop++){

			for(int k = 0; k < tmp.num_point; k++){
				new_x = tmp.point[k].y;
				new_y = -tmp.point[k].x;
				tmp.point[k].x = new_x;
				tmp.point[k].y = new_y;
			}

			FLG = true;

			for(int i = 1; i < tmp.num_point; i++){
				base_x_diff = base.point[i].x - base.point[i-1].x;
				base_y_diff = base.point[i].y - base.point[i-1].y;
				tmp_x_diff = tmp.point[i].x - tmp.point[i-1].x;
				tmp_y_diff = tmp.point[i].y - tmp.point[i-1].y;

				if(base_x_diff != tmp_x_diff || base_y_diff != tmp_y_diff){
					FLG = false;
					break;
				}
			}

			if(FLG){
				printf("%d\n",id);
				break;
			}

			FLG = true;

			for(int i = 1; i < tmp.num_point; i++){
				base_x_diff = base.point[i].x - base.point[i-1].x;
				base_y_diff = base.point[i].y - base.point[i-1].y;
				tmp_x_diff = tmp.point[(tmp.num_point-1)-i].x - tmp.point[(tmp.num_point-1)-(i-1)].x;
				tmp_y_diff = tmp.point[(tmp.num_point-1)-i].y - tmp.point[(tmp.num_point-1)-(i-1)].y;

				if(base_x_diff != tmp_x_diff || base_y_diff != tmp_y_diff){
					FLG = false;
					break;
				}
			}

			if(FLG){
				printf("%d\n",id);
				break;
			}
		}
	}

	printf("+++++\n");
}

int main(){

	while(true){
		scanf("%d",&N);
		if(N == 0)break;

		func();
	}

	return 0;
}