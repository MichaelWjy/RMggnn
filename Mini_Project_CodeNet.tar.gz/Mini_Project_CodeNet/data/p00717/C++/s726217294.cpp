
#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <stack>
#include <queue>
#include <cctype>
#include <complex>
#include <vector>
#include <set>
#include <map>
#include <algorithm>
#include <functional>
#include <cassert>
#include <iomanip>

using namespace std;

#define pb push_back
#define dump(x)  cout << " "<< #x << " = " << (x) << endl;
typedef long long ll;
typedef complex<int> P;
const double EPS = 1e-10;
const double PI  = acos(-1.0);



struct st{
	vector<P> vp;
	vector<P> rvp;
};


P d[] = { P(1,0), P(0,1), P(-1,0), P(0,-1) };

void f(vector<P> &vp){
	P a = vp[0], b = vp[1];
	int num = 0;
	if(a.real() == b.real()){
		if(a.imag() < b.imag()) num = 3;
		else num = 1;
	}else if(a.imag() == b.imag()){
		if(a.real() < b.real()) num = 0;
		else num = 2;
	}
	for(int i=0;i<vp.size();i++){
		vp[i] -= a;
		vp[i] *= d[num];
	}
	return;
}

bool eq(vector<P> &a, vector<P> &b){
	for(int i=0;i<a.size();i++){
		if(a[i] != b[i]) return false;
	}
	return true;
}

bool solve(int n){
	vector<st> vst(n+1);
	
	int m; cin>> m;
	vector<P> tmp;
	for(int i=0;i<m;i++){
		P in; cin>> in.real()>> in.imag();
		tmp.pb(in);
	}
	f(tmp);
	vst[0].vp = tmp;
	reverse(tmp.begin(), tmp.end());
	f(tmp);
	vst[0].rvp = tmp;
	
	for(int i=1;i<n+1;i++){
		int m2; cin>> m2;
		vector<P> tmp;
		for(int j=0;j<m2;j++){
			P in; cin>> in.real()>> in.imag();
			tmp.pb(in);
		}
		f(tmp);
		vst[i].vp = tmp;
	}
	
	for(int i=1;i<n+1;i++){
		if(vst[0].vp.size() != vst[i].vp.size()) continue;	//
		if(eq(vst[i].vp, vst[0].vp) || eq(vst[i].vp, vst[0].rvp)) cout<< i<< endl;
	}
	cout<< "+++++"<< endl;
	return true;
}

int main(){
	cout.setf(ios::fixed);
	cout.precision(10);
	int n;
	while(cin>>n, n) solve(n);
	return 0;
}

 