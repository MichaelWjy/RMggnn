#include <bits/stdc++.h>
#define r(i,n) for(int i=0;i<n;i++)
#define EPS (1e-10)
using namespace std;
class Point{
  public:
  double x,y;
  Point(double x=0,double y=0):x(x),y(y){}
  Point operator + (Point p){return Point(x+p.x,y+p.y);}
  Point operator - (Point p){return Point(x-p.x,y-p.y);}
  Point operator * (double a){return Point(a*x,a*y);}
  Point operator / (double a){return Point(x/a,y/a);}

  bool operator < (const Point &p) const{
    return x!=p.x?x<p.x:y<p.y;
  }
  bool operator == (const Point &p) const{
    return fabs(x-p.x)<EPS&&fabs(y-p.y)<EPS;
  }
};
double norm(Point p){return p.x*p.x+p.y*p.y;}
double abs(Point p){return sqrt(norm(p));}
double cross(Point a,Point b){return a.x*b.y-a.y*b.x;}
double dot(Point a,Point b){return a.x*b.x+a.y*b.y;}
double getDistancePP(Point a,Point b){return abs(a-b);}
int CCW(Point p0,Point p1,Point p2){
  Point a=p1-p0;
  Point b=p2-p0;
  if(cross(a,b)>EPS)return 1;
  if(cross(a,b)<-EPS)return -1;
  if(dot(a,b)<-EPS)return 2;
  if(norm(a)<norm(b))return -2;
  return 0;
}
int main(){
  int n,m;
  Point p;
  while(cin>>n,n){
    vector<Point>a[50];
    r(i,n){cin>>m;
    while(m--){
      cin>>p.x>>p.y;
      a[i].push_back(p);
    }}
    int cc[10],c=0,cp[10];
    r(i,a[n-1].size()-2)cc[i]=CCW(a[n-1][i],a[n-1][i+1],a[n-1][i+2]);
    r(i,a[n-1].size()-1)cp[i]=getDistancePP(a[n-1][i],a[n-1][i+1]);
    r(j,n-2){
      if(a[n-1].size()!=a[j].size())continue;
      int dd[10],d=0,dp[10];
    r(i,a[j].size()-2)dd[i]=CCW(a[j][i],a[j][i+1],a[j][i+2]);
    r(i,a[j].size()-2)if(dd[i]!=cc[i])d++;
    r(i,a[j].size()-1)dp[i]=getDistancePP(a[j][i],a[j][i+1]);
    r(i,a[j].size()-2)if(dp[i]!=cp[i])d++;
    if(!d)cout<<j+1<<endl;
    }
    cout<<"+++++"<<endl;
  }
}