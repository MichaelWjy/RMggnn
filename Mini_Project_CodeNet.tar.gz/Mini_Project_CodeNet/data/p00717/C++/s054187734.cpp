#include <bits/stdc++.h>

using namespace std;

typedef unsigned long long ull;
#define loop(i,a,b) for(int i=(a);i<ull(b);++i)
#define rep(i,n) loop(i,0,n)
#define all(a) (a).begin(), (a).end()

const double eps = 1e-10;
const double pi  = acos(-1.0);
const double inf = (int)1e8;

int main(){

	int p;
	while(cin >> p, p){
		int n, m;
		cin >> n;
		vector<pair<int, int> > v(n);
		rep(i, n) cin >> v[i].first >> v[i].second;
		vector<pair<int, int> > s(n-1);
		rep(i, n-1){ s[i].first = v[i+1].first - v[i].first; s[i].second = v[i+1].second - v[i].second;}
		rep(q, p){
			bool possible = false;
			cin >> m;
			vector<pair<int, int> > vv(m);
			rep(i, m) cin >> vv[i].first >> vv[i].second;
			vector<pair<int, int> > ss(m-1);
			rep(i, m-1){ ss[i].first = vv[i+1].first - vv[i].first; ss[i].second = vv[i+1].second - vv[i].second;}

			if(n != m) continue;

			rep(j, 2){
				bool p = true;
				rep(i, s.size()) if(s[i].first != ss[i].first || s[i].second != ss[i].second){p = false; break;}
				if(p) possible = true;

				p = true;
				rep(i, s.size()) if(s[i].first != ss[i].first*-1 || s[i].second != ss[i].second*-1){p = false; break;}
				if(p) possible = true;

				p = true;
				rep(i, s.size()) if(s[i].first != ss[i].second || s[i].second*-1 != ss[i].first){p = false; break;}
				if(p) possible = true;

				p = true;
				rep(i, s.size()) if(s[i].first != ss[i].second*-1 || s[i].second != ss[i].first){p = false; break;}
				if(p) possible = true;

				rep(i, s.size()/2) swap(s[i], s[s.size()-i-1]);
				rep(i, s.size()){s[i].first *= -1; s[i].second *= -1;}
			}
			if(possible) cout << q+1 << endl;
		}
		cout << "+++++" << endl;
	}
}