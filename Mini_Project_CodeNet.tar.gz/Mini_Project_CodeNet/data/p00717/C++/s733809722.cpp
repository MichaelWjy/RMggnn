#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <queue>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <cctype>
#include <string>
#include <cstring>
#include <ctime>
#include <climits>
#include <complex>
using namespace std;

#define REP(i,a,n) for(int i=(a); i<(int)(n); i++)
#define rep(i,n) REP(i,0,n)
#define all(x) (x).begin(),(x).end()
#define mp make_pair
#define pb push_back
#define EPS 1e-8
#define DEB 0

typedef complex<double> P;

int main(){
	int n,m,x,y;
	vector<vector<P> > vp;
	P rot[] = {P(1,0), P(0,1), P(0,1)*P(0,1), P(0,1)*P(0,1)*P(0,1)};
	
	while(scanf("%d",&n),n){
		vp.clear();
		rep(i,n+1){
			vector<P> v;
			int px,py;
			scanf("%d",&m);
			rep(j,m){
				scanf("%d %d",&x,&y);
				if( j>0 ){
					v.push_back(P((double)(x-px), (double)(y-py)));
				}
				px = x;
				py = y;
			}
			vp.push_back(v);
		}
#if DEB
		printf("n:%d\n",n);
		rep(i,vp.size()){
			printf("sz:%d  i:%d\n",vp.size(),i);
			rep(j,vp[i].size()){
				cout << vp[i][j] << "  180: " << vp[i][j]*P(1,0) << endl;
			}
			puts("");
		}
#endif		

		REP(i,1,vp.size()){
			if( vp[0].size() != vp[i].size() )continue;
			rep(k,4){
				bool f = true;
				rep(j,vp[0].size()){
					if( vp[0][j]!=vp[i][j]*rot[k] ){
						f = false;
						break;
					}
				}
				if( f ){
					printf("%d\n",i);
					break;
				}
				int sz = vp[0].size();
				f = true;
				rep(j,vp[0].size()){
#if DEB
					if( i==3 ){
						cout << vp[0][j] << " and " << vp[i][sz-j-1] << endl;
					}
#endif
					
					if( vp[0][j]!=vp[i][sz-j-1]*rot[k] ){
						f = false;
						break;
					}
				}
				if( f ){
					printf("%d\n",i);
					break;
				}
			}
		}
		printf("+++++\n");
	}
	return 0;
}