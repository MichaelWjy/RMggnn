#include<iostream>
#include<algorithm>
#define MAX 10001
#define rep(i,n) for(int i=0;i<n;i++)
using namespace std;
int main(){
	int n,m,t,sx[MAX],sy[MAX],nx[MAX],ny[MAX];
	bool flag;
	while(cin>>n,n){
		cin>>m;
		rep(i,m)
		cin>>sx[i]>>sy[i];
		rep(i,n){
			flag=false;
			cin>>t;
			rep(j,t)
				cin>>nx[j]>>ny[j];
			if(t==m){
				for(int k=0;k<4&&!flag;k++){
					rep(j,t){
						swap(sx[j],sy[j]);
						sx[j]=-sx[j];
					}
					rep(j,t-1){
						if(!(nx[j]-nx[j+1]==sx[j]-sx[j+1]&&ny[j]-ny[j+1]==sy[j]-sy[j+1])){
							//cout<<ny[j]-ny[j+1]<<' '<<sx[j]-sx[j+1]<<endl;
							//cout<<ny[j]<<' '<<ny[j+1]<<endl;
							//cout<<"--------"<<j<<endl;
							break;
						}
						if(j==t-2)
							flag=true;
					}
					rep(j,t-1){
						if(!(nx[t-j-2]-nx[t-j-1]==sx[j]-sx[j+1]&&ny[t-j-2]-ny[t-j-1]==sy[j]-sy[j+1])){
							//cout<<"-------"<<j<<endl;
							//	cout<<nx[t-j-2]-nx[t-j-1]<<' '<<sx[j]-sx[j+1]<<endl;
							break;
						}
						if(j==t-2)
							flag=true;
					}
				}
			}
			if(flag)
			cout<<i+1<<endl;
		}
		cout<<"+++++"<<endl;
	}
	return 0;
}