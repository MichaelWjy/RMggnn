#include <string>
#include <algorithm>
#include <vector>
#include <iostream>
#include <cstdio>
#include <cassert>
using namespace std;

using Line = vector< pair<int, int> >;

Line rotate(Line l) {
  int dx = l[1].first - l[0].first;
  int dy = l[1].second - l[0].second;

  if(dx == 0 and dy > 0) return l;
  else if(dx == 0 and dy < 0) {
    for(auto &e : l) e = make_pair(-e.first, -e.second);
  }
  else if(dx > 0 and dy == 0) {
    for(auto &e : l) e = make_pair(-e.second, e.first);
  }
  else if(dx < 0 and dy == 0) {
    for(auto &e : l) e = make_pair(e.second, -e.first);
  }
  else assert(false);
  return l;
}

bool is_valid(Line u, Line v) {
  u = rotate(u);
  v = rotate(v);
  
  if(u.size() != v.size()) return false;
  int N = u.size();
  
  int du = u[1].first - u[0].first + u[1].second - u[0].second;
  int dv = v[1].first - v[0].first + v[1].second - v[0].second;
  for(int i=2; i<N; i++) {
    int dxu = u[i].first - u[i-1].first;
    int dyu = u[i].second - u[i-1].second;
    int dxv = v[i].first - v[i-1].first;
    int dyv = v[i].second - v[i-1].second;

    int gu = 0;
    if(dxu > 0) gu += 1;
    if(dxu < 0) gu += 2;
    gu *= 3;
    if(dyu > 0) gu += 1;
    if(dyu < 0) gu += 2;

    int gv = 0;
    if(dxv > 0) gv += 1;
    if(dxv < 0) gv += 2;
    gv *= 3;
    if(dyv > 0) gv += 1;
    if(dyv < 0) gv += 2;

    if(gu != gv) return false;
    int eu = dxu + dyu;
    int ev = dxv + dyv;
    if(du * ev != dv * eu) return false;
  }
  return true;
}

bool compare(Line u, Line v) {
  for(int i=0; i<2; i++) {
    for(int j=0; j<2; j++) {
      if(is_valid(u, v)) return true;
      reverse(v.begin(), v.end());
    }
    reverse(u.begin(), u.end());
  }
  return false;
}

int solve_testcase() {
  int N; cin >> N;
  if(N == 0) return 1;
  N++;

  vector<int> ans;
  vector<Line> lines;
  for(int i=0; i<N; i++) {
    int M; cin >> M;
    Line L;
    for(int j=0; j<M; j++) {
      int x, y; cin >> x >> y;
      L.emplace_back(x, y);
    }
    lines.emplace_back(L);
  }

  for(int i=1; i<N; i++) {
    Line u = lines[0], v = lines[i];
    if(compare(u, v)) ans.emplace_back(i);
  }

  for(auto e : ans) cout << e << endl;
  cout << "+++++" << endl;
  return 0;
}

int main() {
  while(!solve_testcase());
  return 0;
}

