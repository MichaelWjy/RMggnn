#include<iostream>
#include<algorithm>
#include<string>
#include<sstream>
#include<cctype>
#include<cstdlib>
#include<map>
#include<vector>
#include<complex>
using namespace std;
#define REP(i, j) for(int i = 0; i < j; i++)
#define FOR(i, j, k) for(int i = j; i < k; i++)
#define P complex<int>
#define X real()
#define Y imag()

void toCenter(vector<P> &v){
    P m(v[0].X * -1, v[0].Y * -1);
    REP(i, v.size()) v[i] += m;
}

bool isSame(vector<P> zero, vector<P> v){
    if(zero == v) return true;
    reverse(v.begin(), v.end());
    if(zero == v) return true;
    return false;
}

void disp(vector<P> v){
    REP(i, v.size()) cout <<v[i] <<", ";
    cout <<endl;
}

int main(){
    int n;
    while(cin >>n && n){
        int m, a, b;
        vector< vector<P> > v(n, vector<P>());
        vector<P> zero;
        cin >>m;
        REP(i, m){
            cin >>a >>b;
            zero.push_back( P(a, b) );
        }
        toCenter(zero);
        REP(i, n){
            cin >>m;
            REP(j, m){
                cin >>a >>b;
                v[i].push_back( P(a, b) );
            }
            toCenter(v[i]);
        }

        vector<int> ans;
        REP(i, n){
            REP(j, 4){
                //回転
                REP(k, v[i].size()){
                    swap(v[i][k].Y, v[i][k].X);
                    v[i][k].Y *= -1;
                }
                //普通の方向
                if(isSame(zero, v[i])) ans.push_back(i + 1);
                //今までしっぽだったやつを先頭にして再度中心調整
                reverse(v[i].begin(), v[i].end());
                toCenter(v[i]);
                if(isSame(zero, v[i])) ans.push_back(i + 1);
                //元に戻す
                reverse(v[i].begin(), v[i].end());
                toCenter(v[i]);
            }
        }
        REP(i, (int)ans.size()) cout <<ans[i] <<endl;
        cout <<"+++++" <<endl;
    }
    return 0;
}