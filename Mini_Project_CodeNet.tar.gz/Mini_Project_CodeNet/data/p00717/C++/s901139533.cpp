#include <bits/stdc++.h>
#define REP(i,n,N) for(int i=n;i<N;i++)
#define p(S) cout<<S<<endl
#define PB push_back
using namespace std;


int main(){
	int n;
	map<pair<int,int>,int> mp;
	mp[{0,1}]=mp[{1,2}]=mp[{2,3}]=mp[{3,0}]=1;//clock-wise
	while(cin>>n,n){
		int m;
		int nextx,nexty,nowx,nowy,nextm,nowm=5;
		vector<int> d[51],muki[51],rmuki;
		int mu[51];
		cin>>m;
		cin>>nowx>>nowy;
		REP(i,0,m-1){
			cin>>nextx>>nexty;
			if(nextx-nowx>0)		mu[i]=0;//right
			else if(nexty-nowy<0)	mu[i]=1;//down
			else if(nextx-nowx<0)	mu[i]=2;//left;
			else if(nexty-nowy>0)	mu[i]=3;//up

			d[0].PB(abs(nextx-nowx+nexty-nowy));
			if(i) muki[0].PB(mp[{mu[i-1],mu[i]}]);
			nowx=nextx;
			nowy=nexty;
		}
		for(int i=m-2;i>0;i--){
			rmuki.PB(mp[{mu[i],mu[i-1]}]);
		}
		REP(j,1,n+1){
			cin>>m;
			cin>>nowx>>nowy;
			REP(i,0,m-1){
				cin>>nextx>>nexty;

				if(nextx-nowx>0)		nextm=0;//right
				else if(nexty-nowy<0)	nextm=1;//down
				else if(nextx-nowx<0)	nextm=2;//left;
				else if(nexty-nowy>0)	nextm=3;//up

				d[j].PB(abs(nextx-nowx+nexty-nowy));
				if(i) muki[j].PB(mp[{nowm,nextm}]);

				nowm=nextm;
				nowx=nextx;
				nowy=nexty;

			}
		}
		REP(i,1,n+1){
			if(d[0]==d[i]&&muki[0]==muki[i]){
				p(i);
				continue;
			}

			if(rmuki==muki[i]){
				bool flag=true;
				REP(j,0,m-1){
					if(d[0][j]!=d[i][m-j-2]){
						flag=false;
						break;
					}
				}
				if(flag) p(i);
			}

		}

		p("+++++");
	}


	return 0;
}