#include <bits/stdc++.h>
#define REP(i,n) for (int i=0;i<(n);i++)
#define ALL(a) (a).begin(),(a).end()
#define RFOR(i,a,b) for (int k=(b)-1;k>=(a);k--)
#define REP(i,n) for (int i=0;i<(n);i++)
#define RREP(i,n) for (int i=(n)-1;i>=0;i--)
#define ll long long
#define ull unsigned long long
int dx[4] = {1, 0, -1, 0};
int dy[4] = {0, 1, 0, -1};


using namespace std;
static const double PI = asin(1.0);



int main(){
  //  cin.tie(0);
  //ios::sync_with_stdio(false);
  int n,m;
  while(cin>>n,n){
    map<pair<int,int>,int> mp;
    cin >> m;
    int ddx,ddy;
      
    REP(j,m){
      	int x,y;
      	cin >> x >> y;
      	if(j==0){
			ddx = -x,ddy = -y;
      	}
      	x += ddx;y += ddy;
      	REP(i,4){
      		int ref_x = x*dx[i]-y*dy[i];
			int ref_y = x*dy[i]+y*dx[i];
    	    pair<int,int> poi = make_pair(ref_x, ref_y);
			mp[poi]++;
		}
		    // for(auto itr = mp.begin();itr != mp.end();itr++){
    	// cout << "x = " << itr->first.first << ", y = " << itr->first.second << ", key =  " << itr->second << endl;
	// }
	// cout << "\n";
    }

  vector<pair<int,int>> memoin;
  bool is_match = false;

    REP(i,n){
	    cin >> m;
    	int ct = 0;
	  	int indx = 0;
      	int nx,ny;
      	is_match = false;
      	memoin.resize(m,make_pair(0,0));
      	REP(j,m){
			int x,y;
			cin >> x >> y;
			memoin[j] = make_pair(x,y);
			if(j==0){
		  		nx = -x,ny = -y;
			}
			x += nx;y += ny;
			pair<int,int> poi = make_pair(x,y);

			if(mp[poi]){
				ct++;
				//	  if(indx<mp[poi])indx = mp[poi];
			}
		}
	    if(ct == m){
		cout << i+1 << endl;
		is_match = true;
	    }
    

		if(!is_match){
		    ct = 0;
		    indx = 0;
		    int nx2,ny2;
	      	      
		    REP(j,m){
				int x,y;
				x = memoin[m-1-j].first;
				y = memoin[m-1-j].second;
				if(j==0){
			  		nx2 = -x,ny2 = -y;
			  		// cout << "nx2:" << -x << " ny2:" << -y << endl;
				}
				//if(i==2){
				//	cout << "memoin[m-1-j].x:"<< memoin[m-1-j].first <<", memoin[m-1-j].y:" << memoin[m-1-j].second << endl;
					// cout << x << " " << y << endl;}

				x += nx2;y += ny2;

				pair<int,int> poi = make_pair(x,y);
				if(mp[poi]){
				  ct++;
				  //	  if(indx<mp[poi])indx = mp[poi];
				}
			  }
		      if(ct == m){
				cout << i+1 << endl;
		      }
		memoin.clear();
		}
	}
    cout << "+++++" << endl;
  }
  return 0;
}