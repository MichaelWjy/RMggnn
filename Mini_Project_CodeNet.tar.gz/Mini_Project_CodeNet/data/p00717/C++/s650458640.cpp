#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <climits>
#include <cfloat>
#include <map>
#include <utility>
#include <set>
#include <iostream>
#include <memory>
#include <string>
#include <vector>
#include <algorithm>
#include <functional>
#include <sstream>
#include <complex>
#include <stack>
#include <queue>
#include <numeric>
#include <iomanip>

#define REP(i,n) for(i=0; i < (n); i++)
#define REPONE(i, n) for(i=1; i <= (n); i++)
#define LOOP(n) for(int loopCount=1; loopCount <= (n); loopCount++)
#define ITER(c) __typeof((c).begin())
#define EACH(c,it) for(ITER(c) it =(c).begin(); it!=(c).end(); it++)
#define SZ(c) ((int) (c).size())
#define ALL(c) c.begin(), c.end()
#define SUM(c) accumulate(ALL(c), 0)
#define EXIST(c,v) (find(ALL(c), (v)) != (c).end())
#define PB push_back
#define MP make_pair

using namespace std;
static const double EPS = 1e-9;
static const double PI = 3.141592653589793238462643383279;
typedef long long ll;

vector<pair<int,int> > rot(vector<pair<int,int> > ps){
    int i, s=SZ(ps);
    REP(i,s){
        swap(ps[i].first, ps[i].second);
        ps[i].first *= -1;
    }
    REP(i,s){
        ps[s-1-i].first  -= ps[0].first;
        ps[s-1-i].second -= ps[0].second;
    }
    return ps;
}

int main(){
    int n, m, i, j, k, x, y;

    while(scanf("%d",&n)){
        if(!n) break;
        scanf("%d",&m);
        vector< pair<int,int> > origin;
        vector<int> ans;
        vector< vector< vector<pair<int, int> > > > polys(n);
        REP(i,m){
            scanf("%d%d",&x,&y);
            origin.PB(MP(x,y));
        }
        REP(i,m){
            origin[m-1-i].first  -= origin[0].first;
            origin[m-1-i].second -= origin[0].second;
        }

        REP(i,n){
            scanf("%d",&m);
            polys[i].PB(vector< pair<int, int> >());
            REP(j,m){
                scanf("%d%d",&x,&y);
                polys[i][0].PB(MP(x,y));
            }
            REP(j,3) polys[i].PB(rot(polys[i].back()));
            polys[i].PB(polys[i][0]);
            reverse(polys[i].back().begin(), polys[i].back().end());
            REP(j,m){
                polys[i].back()[m-1-j].first -= polys[i].back()[0].first;
                polys[i].back()[m-1-j].second-= polys[i].back()[0].second;
            }
            REP(j,3) polys[i].PB(rot(polys[i].back()));
        }

        REP(i,n){
            REP(k,4){
                origin = rot(origin);
                REP(j,m)if(polys[i][j] == origin) goto end;
            }
end:;
            if(j<m) ans.PB(i);
        }
        REP(i,SZ(ans)){
            printf("%d\n",ans[i]+1);
        }
        printf("+++++\n");
    }

    return 0;
}