#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <map>
#include <set>
#include <list>
#include <queue>
#include <deque>
#include <stack>
#include <vector>
#include <algorithm>
#include <functional>
#include <cstring>
#include <string>
#include <sstream>
#include <bitset>
using namespace std;
#define INF	100000000
#define MOD 1000000007
#define pb push_back
#define mp make_pair
#define fi first
#define sec second
#define lb lower_bound
#define ub upper_bound
#define SS stringstream
#define rep(i,n) for(int i = 0; i < n; i++)
#define SORT(x) sort((x).begin(), (x).end())
#define clr(a,b) memset((a),(b),sizeof(a))
typedef long long int ll;
typedef pair<int, int> P;
typedef vector<int> Vi;
typedef vector<ll> Vll;
typedef vector<P> Vp;
typedef priority_queue<P, vector<P>, greater<P> > PQ;

int main(){
	int n;
	while(scanf("%d", &n), n){
		Vp base;
		int m;
		scanf("%d", &m);
		rep(i,m){
			int x,y;
			scanf("%d%d", &x,&y);
			base.pb(P(x,y));
		}
		for(int i = 1; i < m; i++){
			base[i].fi -= base[0].fi;
			base[i].sec -= base[0].sec;
		}
		base[0].fi = 0;
		base[0].sec = 0;
		rep(u,n){
			Vp line;
			scanf("%d", &m);
			rep(i,m){
				int x, y;
				scanf("%d%d", &x, &y);
				line.pb(P(x,y));
			}
			if(m != base.size()) continue;
			for(int i = 1; i < m; i++){
				line[i].fi -= line[0].fi;
				line[i].sec -= line[0].sec;
			}
			line[0].fi = 0;
			line[0].sec = 0;
			rep(v,2){
				bool ok = true;
				rep(i,m){
					if(line[i].fi != base[i].fi || line[i].sec != base[i].sec){
						ok = false;
						break;
					}
				}
				if(ok){
					printf("%d\n",u+1);
					break;;
				}
				ok = true;
				rep(i,m){
					if(line[i].fi != -1*base[i].fi || line[i].sec != -1*base[i].sec){
						ok = false;
						break;
					}
				}
				if(ok){
					printf("%d\n",u+1);
					break;
				}
				ok = true;
				rep(i,m){
					if(line[i].fi != base[i].sec || line[i].sec != -1*base[i].fi){
						ok = false;
						break;
					}
				}
				if(ok){
					printf("%d\n",u+1);
					break;
				}
				ok = true;
				rep(i,m){
					if(line[i].fi != -1*base[i].sec || line[i].sec != base[i].fi){
						ok = false;
						break;
					}
				}
				if(ok){
					printf("%d\n",u+1);
					break;
				}
				if(v == 0){
					Vp tmp;
					for(int i = 0; i < m-1; i++){
						line[i].fi -= line[m-1].fi;
						line[i].sec -= line[m-1].sec;
					}
					line[m-1].fi = 0;
					line[m-1].sec = 0;
					tmp = line;
					rep(i,m){
						line[i] = tmp[m-i-1];
					}
				}
			}
		}
		printf("+++++\n");
	}
}