#include <iostream>
#include <vector>
#include <map>
#include <stack>
#include <list>
#include <queue>
#include <string>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <math.h>

#define PREP(i, m, n) for(int i = m; i < n; i++)
#define MREP(i, m, n) for(int i = m - 1; i >= n; i--)
using namespace std;

struct point{
	int x;
	int y;
};

bool checkSame(vector<point> sour, vector<point> dest){
	point harfPI, PI, PIharfPI, sSub, dSub;
	//比較対象はどの頂点を原点とみなしても問題ないので、適当に原点に合わせる
	dSub.x = dest[0].x;
	dSub.y = dest[0].y;
	for(int i = 0; i < sour.size(); i++){
		int count = 0;
		//ある頂点を原点に平行移動させるためのもの
		sSub.x = sour[i].x;
		sSub.y = sour[i].y;
		for(int j = 0; j < sour.size(); j++){
			//ある点を平行移動した後90度回転
			harfPI.x = (sour[j].y - sSub.y) * -1;
			harfPI.y = sour[j].x - sSub.x;
			//ある点を平行移動した後180度回転
			PI.x = (sour[j].x - sSub.x) * -1;
			PI.y = (sour[j].y - sSub.y) * -1;
			//ある点を平行移動した後270度回転
			PIharfPI.x = (harfPI.x - sSub.x) * -1;
			PIharfPI.y = (harfPI.y - sSub.y) * -1;
	
			if((sour[j].x - sSub.x == dest[j].x - dSub.x && sour[j].y - sSub.y == dest[j].y - dSub.y) 
				|| (harfPI.x == dest[j].x - dSub.x && harfPI.y == dest[j].y - dSub.y) 
				|| (PI.x == dest[j].x - dSub.x && PI.y == dest[j].y - dSub.y) 
				|| (PIharfPI.x == dest[j].x - dSub.x && PIharfPI.y == dest[j].y - dSub.y)){
				count++;
			}
		}
		if(count == sour.size()) return true;
	}
	return false;
}

int main(){
	int n = 0;
	while(cin >> n && n != 0){
		vector<vector<point> > vertex;
		vector<int> same;
		for(int i = 0; i < n + 1; i++){
			int m = 0;
			cin >> m;
			
			//折れ線の頂点を収納
			vector<point> a;
			for(int j = 0; j < m; j++){
				point tmp;
				cin >> tmp.x >> tmp.y;
				a.push_back(tmp);
			}
			
			vertex.push_back(a);
			//折れ線一個目ならiを進める
			if(!i){
				continue;
			}
			
			
			//逆順経路の場合に、逆順を元の順に戻す
			vector<point> tmp(m);
			reverse_copy(vertex[i].begin(), vertex[i].end(), tmp.begin());

			//元々受け取った頂点順、もしくは逆順で同じ折れ線になるかをチェックする
			if(checkSame(vertex[0], vertex[i]) || checkSame(vertex[0], tmp)){
				same.push_back(i);
			}
		}
		for(int i = 0; i < same.size(); i++){
			cout << same[i] << endl;
		}
		cout << "+++++" << endl;
	}
	return 0;
}