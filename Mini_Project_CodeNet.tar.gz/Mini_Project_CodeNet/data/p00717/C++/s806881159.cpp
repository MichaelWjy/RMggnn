

#include <bits/stdc++.h>

using namespace std;

//conversion
//------------------------------------------
inline int toInt(string s) {int v; istringstream sin(s);sin>>v;return v;}
inline int toLL(string s) {long long v; istringstream sin(s);sin>>v;return v;}
template<class T> inline string toString(T x) {ostringstream sout;sout<<x;return sout.str();}

//math
//-------------------------------------------
template<class T> inline T sqr(T x) {return x*x;}

//typedef
//------------------------------------------
typedef vector<int> VI;
typedef vector<VI> VVI;
typedef vector<string> VS;
typedef pair<int, int> PII;
typedef long long LL;
typedef unsigned long long ULL;
typedef pair<long,long> PLL;
//container util
//------------------------------------------
#define ALL(a)  (a).begin(),(a).end()
#define RALL(a) (a).rbegin(), (a).rend()
#define PB push_back
#define PF push_front
#define MP make_pair
#define SZ(a) LL((a).size())
#define EACH(i,c) for(typeof((c).begin()) i=(c).begin(); i!=(c).end(); ++i)
#define EXIST(s,e) ((s).find(e)!=(s).end())
#define SORT(c) sort((c).begin(),(c).end())

//repetition
//------------------------------------------
#define FOR(i,a,b) for(long i=(a);i<(b);++i)
#define REP(i,n)  FOR(i,0,n)

//constant
//--------------------------------------------

//clear memory
#define CLR(a) memset((a), 0 ,sizeof(a))

const double EPS=1e-8;

typedef complex<double> P;//座標(x,y)=(p.real,p.imag())


double cross(const P& a, const P& b) {
 	return imag(conj(a)*b);//正なら反時計回りの回転,負なら時計回り,0なら同一直線
}

int ccw(P a, P b, P c) {//点の進行方向a->b->c
	b -= a; c -= a;
  	if (cross(b, c) > 0)   return +1;       // counter clockwise
  	if (cross(b, c) < 0)   return -1;       // clockwise
  	return 0;
}

int len(P a,P b){
	return abs(a.real()-b.real())+abs(a.imag()-b.imag());
}

int main(){
    int N;
	while(cin>>N&&N){
		vector<P>G;
		VI ans[2];
		int m0;
		cin>>m0;
		
		REP(i,m0){
			int x,y;
			cin>>x>>y;
			G.PB(P(x,y));
		}
		
		FOR(i,1,m0-1){
			if(i==1)ans[0].PB(len(G[i-1],G[i]));
			ans[0].PB(ccw(G[i-1],G[i],G[i+1]));
			ans[0].PB(len(G[i],G[i+1]));
		}
		//REP(i,SZ(ans[0]))cout<<ans[0][i]<<" ";
		///cout<<endl;
		VI t=ans[0];
		reverse(ALL(t));
		REP(i,SZ(t)){
			if(i%2==1)ans[1].PB(-t[i]);
			else ans[1].PB(t[i]);
		}
		//REP(i,SZ(ans[1]))cout<<ans[1][i]<<" ";
		//cout<<endl;
		VI res;
		REP(i,N){
			int m,x,y;
			cin>>m;
			VI trace;
			G.clear();
			REP(j,m){
				cin>>x>>y;
				G.PB(P(x,y));
			}
			FOR(j,1,m-1){
				if(j==1)trace.PB(len(G[j-1],G[j]));
				trace.PB(ccw(G[j-1],G[j],G[j+1]));
				trace.PB(len(G[j],G[j+1]));
			}
			//REP(j,SZ(trace))cout<<trace[j]<<" ";
			//cout<<endl;
			if(trace==ans[0]||trace==ans[1])res.PB(i+1);
		}
		
		REP(i,SZ(res))cout<<res[i]<<endl;
		cout<<"+++++"<<endl;
	}
    return 0;
}