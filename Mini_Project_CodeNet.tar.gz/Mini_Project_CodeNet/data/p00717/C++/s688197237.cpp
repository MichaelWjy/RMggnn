
//http://judge.u-aizu.ac.jp/onlinejudge/description.jsp?id=1136&lang=jp

#include<iostream>
#include<map>
#include<vector>
#include<algorithm>
#include<cmath>
#include<climits>
#include<ctime>
#include<cstring>
#include<numeric>

#define ALL(v) (v).begin(),(v).end()
#define REP(i,p,n) for(int i=p;i<(int)(n);++i)
#define rep(i,n) REP(i,0,n)
#define dump(a) (cerr << #a << "=" << (a) << endl)
#define DUMP(list) cout << "{ "; for(auto nth : list){ cout << nth << " "; } cout << "}" << endl;

using namespace std;

struct Point 
{
	int x,y;
	Point(int X, int Y) : x(X), y(Y) {}
};

struct Line 
{
	vector<Point> points;

	Line(int m)
	{	
		int x,y;
		rep(i,m)
		{
			cin >> x >> y;
			add(x,y);
		}
		origin_shift();
	}

	void add(int x, int y){
		points.push_back(Point(x,y));
	}

	void shift(int sx, int sy)
	{
		rep(i,points.size())
		{
			points[i].x -= sx;
			points[i].y -= sy;
		}
	}

	void origin_shift()
	{
		int sx = points[0].x;
		int sy = points[0].y;

		shift(sx,sy);
	}

	void reverse()
	{
		std::reverse(ALL(points));
		origin_shift();
	}

	void rotate()
	{
		rep(i,points.size())
		{
			swap(points[i].x, points[i].y);
			points[i].y *= -1;
		}
	}

	bool isSame(Line line)
	{
		vector<Point> p = line.points;
		
		if(p.size() != points.size()) { return false; }

		rep(i,p.size())
		{
			if(p[i].x != points[i].x || p[i].y != points[i].y){
				return false;
			}
		}
		return true;
	}
};

int main()
{
	int N,M;
	while(cin >> N && N)
	{
		int X,Y;

		cin >> M;
		Line line0(M);

		for(int nth=1; nth<=N; nth++)
		{
			cin >> M;
			Line lineN(M);

			bool is_same=false;

			rep(i,4)
			{
				if( line0.isSame(lineN) )
				{ 
					cout << nth << endl; 
					is_same = true; 
					break;
				}
				lineN.rotate();
			}

			if(is_same){ continue; }

			lineN.reverse();

			rep(i,4)
			{
				if( line0.isSame(lineN) )
				{ 
					cout << nth << endl;
					break;
				}
				lineN.rotate();
			}
		}
		cout << "+++++" << endl;
	}

	return 0;
}