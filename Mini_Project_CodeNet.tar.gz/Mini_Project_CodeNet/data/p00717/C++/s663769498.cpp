#include <cstdio>

using namespace std;

//プロトタイプ宣言
void make_data();
int ab(int a);
int hanten(int a);

//変数宣言
int n;				//探す対称の折れ線の本数
int m0;
int m;
int len0[9];		//探す元の折れ線の簡易データ(線分の長さ)
int direct0[8];		//探す元の折れ線の簡易データ(曲がり方)		
int len[9];		//探す対称の折れ線の簡易データ(線分の長さ)
int direct[8];	//探す対称の折れ線の簡易データ(曲がり方)
int x[10];
int y[10];

int main()
{
	for (;;)
	{
		scanf("%d", &n);
		//printf("n=%d\n", n);
		if (n==0) return 0;
		
		
		
		
		
		//探す元の折れ線の簡易データを作る
		scanf("%d", &m0);
		//printf("m0=%d\n", m0);
		for (int i=0; i<m0; i++)
		{
			scanf("%d %d", &x[i], &y[i]);
			//printf("x[%d]=%d y[%d]=%d\n", i, x[i], i, y[i]);
		}
		
		//簡易データの長さを入力
		for (int i=0; i<m0-1; i++)
		{
			if (ab(x[i+1]-x[i]) > ab(y[i+1]-y[i]))
			{
				//１、２点目を結ぶ線分が水平
				len0[i] = ab(x[i+1]-x[i]);
			}
			else
			{
				//１、２点目を結ぶ線分が垂直
				len0[i] = ab(y[i+1]-y[i]);
			}
			//printf("len0[%d]=%d\n", i, len0[i]);
		}
		//簡易データの曲がり方を入力
		for (int i=0; i<m0-2; i++)
		{
			if (ab(x[i+1]-x[i]) > ab(y[i+1]-y[i]))
			{
				//１、２点目を結ぶ線分が水平
				if (x[i+1]-x[i] > 0)
				{
					//まず、→
					if (y[i+2]-y[i+1] > 0)
					{
						//そして、↑
						direct0[i] = -2;
					}
					else
					{
						//そして、↓
						direct0[i] = -1;
					}
				}
				else
				{
					//次に、←
					if (y[i+2]-y[i+1] > 0)
					{
						//そして、↑
						direct0[i] = -1;
					}
					else
					{
						//そして、↓
						direct0[i] = -2;
					}
				}
			}
			else
			{
				//１、２点目を結ぶ線分が垂直
				if (y[i+1]-y[i] > 0)
				{
					//まず、↑
					if(x[i+2]-x[i+1] > 0)
					{
						//そして、→
						direct0[i] = -1;
					}
					else
					{
						//そして、←
						direct0[i] = -2;
					}
				}
				else
				{
					//次に、↓
					if (x[i+2]-x[i+1] > 0)
					{
						//そして、→
						direct0[i] = -2;
					}
					else
					{
						//そして、←
						direct0[i] = -1;
					}
				}
			}	
			//printf("direct0[%d]=%d\n", i, direct0[i]);
		}
		//以上で探す元の折れ線の簡易データ完成
		
		
		for (int i=0; i<n; i++)
		{
			make_data();
			// if (m!=m0) continue;
			
			bool flag1 = true;
			bool flag2 = true;
			for (int i2=0; i2<m-1; i2++)
			{
				if (len0[i2]!=len[i2])
				{
					flag1 = false;
				}
				//こっちはOK
				if (len0[i2]!=len[m-2-i2])
				{
					flag2 = false;
				}
			}
			for (int i2=0; i2<m-2; i2++)
			{
				if (direct0[i2]!=direct[i2])
				{
					flag1 = false;
				}
				if (direct0[i2]!=hanten(direct[m-3-i2]))
				{
					flag2 = false;
				}
			}
			if (flag1 || flag2) printf("%d\n", i+1);
		}

		printf("+++++\n");
	
	}

}



//今回は、探す対象の折れ線１本を読み込む
//探す元の折れ線は読み込まない
void make_data()
{
	//探す元の折れ線の簡易データを作る
	scanf("%d", &m);
	// printf("m=%d\n", m);
	for (int i=0; i<m; i++)
	{
		scanf("%d %d", &x[i], &y[i]);
		//printf("x[%d]=%d y[%d]=%d\n", i, x[i], i, y[i]);
	}
	//簡易データの長さを入力
	for (int i=0; i<m-1; i++)
	{
		if (ab(x[i+1]-x[i]) > ab(y[i+1]-y[i]))
		{
			//１、２点目を結ぶ線分が水平
			len[i] = ab(x[i+1]-x[i]);
		}
		else
		{
			//１、２点目を結ぶ線分が垂直
			len[i] = ab(y[i+1]-y[i]);
		}
		//printf("len[%d]=%d\n", i, len[i]);
	}
	//簡易データの曲がり方を入力
	for (int i=0; i<m-2; i++)
	{
		if (ab(x[i+1]-x[i]) > ab(y[i+1]-y[i]))
		{
			//１、２点目を結ぶ線分が水平
			if (x[i+1]-x[i] > 0)
			{
				//まず、→
				if (y[i+2]-y[i+1] > 0)
				{
					//そして、↑
					direct[i] = -2;
				}
				else
				{
					//そして、↓
					direct[i] = -1;
				}
			}
			else
			{
				//次に、←
				if (y[i+2]-y[i+1] > 0)
				{
					//そして、↑
					direct[i] = -1;
				}
				else
				{
					//そして、↓
					direct[i] = -2;
				}
			}
		}
		else
		{
			//１、２点目を結ぶ線分が垂直
			if (y[i+1]-y[i] > 0)
			{
				//まず、↑
				if(x[i+2]-x[i+1] > 0)
				{
					//そして、→
					direct[i] = -1;
				}
				else
				{
					//そして、←
					direct[i] = -2;
				}
			}
			else
			{
				//次に、↓
				if (x[i+2]-x[i+1] > 0)
				{
					//そして、→
					direct[i] = -2;
				}
				else
				{
					//そして、←
					direct[i] = -1;
				}
			}
		}	
		//printf("direct[%d]=%d\n", i, direct[i]);
	}
	//以上で探す元の折れ線の簡易データ完成

}

int hanten(int a)
{
	if (a==-1) return -2;
	else return -1;
}

int ab(int a)
{
	if (a>0) return a;
	else return -a;
}