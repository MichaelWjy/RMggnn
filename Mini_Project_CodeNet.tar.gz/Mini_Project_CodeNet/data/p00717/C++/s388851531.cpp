#include<cstdio>
#include<algorithm>

using namespace std;

int n;
int m[20];
int x[51][11],y[51][11];

int main(void){
	while(1){
		scanf("%d",&n);
		if(n==0)break;
		for(int i=0;i<=n;i++){
			scanf("%d",&m[i]);
			for(int j=0;j<m[i];j++){
				scanf("%d %d",&x[i][j],&y[i][j]);
			}
		}
		for(int i=1;i<=n;i++){
			if(m[0]!=m[i])continue;
			int flag2=0;
			for(int w=0;w<=3;w++){
				int flag=1;
				for(int j=0;j<m[0]-1;j++){
					int x1=x[0][j+1]-x[0][j],y1=y[0][j+1]-y[0][j];
					int x2=x[i][j+1]-x[i][j],y2=y[i][j+1]-y[i][j];
					if(w==0 && (x1!=x2 || y1!=y2)){
						flag=0;
					}
					if(w==1 && (x1!=y2 || y1!=-x2))flag=0;
					if(w==2 && (x1!=-x2 || y1!=-y2))flag=0;
					if(w==3 && (x1!=-y2 || y1!=x2))flag=0;
				}
				if(flag==1)flag2=1;
			}
			for(int w=0;w<=3;w++){
				int flag=1;
				for(int j=0;j<m[0]-1;j++){
					int x1=x[0][j+1]-x[0][j],y1=y[0][j+1]-y[0][j];
					int x2=x[i][m[0]-j-2]-x[i][m[0]-j-1],y2=y[i][m[0]-j-2]-y[i][m[0]-j-1];
					if(w==0 && (x1!=x2 || y1!=y2))flag=0;
					if(w==1 && (x1!=y2 || y1!=-x2))flag=0;
					if(w==2 && (x1!=-x2 || y1!=-y2))flag=0;
					if(w==3 && (x1!=-y2 || y1!=x2))flag=0;
				}
				if(flag==1)flag2=1;
			}
			if(flag2==1)printf("%d\n",i);
		}
		printf("+++++\n");
	}
	return 0;
}