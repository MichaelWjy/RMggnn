#include <iostream>
#include <vector>
#include <cmath>
#include <algorithm>
using namespace std;

typedef struct
{
  vector<int> dis;
  vector<bool> dir;
} Data;

void set_d(vector<int> &dis, vector<bool> &dir, int m)
{
  int x[m], y[m];
  cin >> x[0] >> y[0];
  for(int i = 1; i < m; i++){
    cin >> x[i] >> y[i];
    dis.push_back(abs(x[i]-x[i-1])+abs(y[i]-y[i-1]));
    if(i >= 2){
      int a, b;
      a = x[i-1]-x[i-2]+y[i-1]-y[i-2];
      b = x[i]-x[i-1]+y[i]-y[i-1];
      if(a > 0 && b > 0){
        if(x[i] == x[i-1])
          dir.push_back(true);
        else
          dir.push_back(false);
      }else if(a > 0 && b < 0){
        if(x[i] == x[i-1])
          dir.push_back(false);
        else
          dir.push_back(true);
      }else if(a < 0 && b > 0){
        if(x[i] == x[i-1])
          dir.push_back(false);
        else
          dir.push_back(true);
      }else if(a < 0 && b < 0){
        if(x[i] == x[i-1])
          dir.push_back(true);
        else
          dir.push_back(false);
      }
    }
  }
}

int main()
{
  while(1){
    int n;
    cin >> n;
    if(n == 0) break;
    int m;
    cin >> m;
    Data org1, org2;
    set_d(org1.dis, org1.dir, m);
    org2 = org1;
    reverse(org2.dis.begin(),org2.dis.end());
    reverse(org2.dir.begin(),org2.dir.end());
    for(vector<bool>::iterator ite = org2.dir.begin(); ite != org2.dir.end(); ite++)
      *ite = !(*ite);
    for(int i = 1; i <= n; i++){
      cin >> m;
      Data d;
      set_d(d.dis, d.dir, m);
      if((org1.dis == d.dis && org1.dir == d.dir) || (org2.dis == d.dis && org2.dir == d.dir))
        cout  <<  i << endl;
    }
    cout << "+++++" << endl;
  }
}