#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

struct Vertex {
    int x, y;
};

vector<Vertex> inputVertexes(int m) {
    vector<Vertex> vertexes(m);
    int px, py;
    for (vector<Vertex>::iterator it = vertexes.begin(); it != vertexes.end(); it++) {
        cin >> (*it).x >> (*it).y;
        if (it == vertexes.begin()) {
            px = (*it).x;
            py = (*it).y;
        }
        (*it).x -= px;
        (*it).y -= py;
    }
    return vertexes;
}

int main() {
    while (true) {
        int n;
        cin >> n;
        if (n == 0) {
            break;
        }
        int m;
        cin >> m;
        vector<Vertex> patterns = inputVertexes(m);
        for (int i = 0; i < n; i++) {
            int size;
            cin >> size;
            vector<Vertex> subjects = inputVertexes(size);
            if (m != size) {
                continue;
            }
            for (int j = 0; j < 2; j++) {
                for (int k = 0; k < 4; k++) {
                    bool match = true;
                    for (int l = 0; l < m; l++) {
                        if (patterns[l].x != subjects[l].x || patterns[l].y != subjects[l].y) {
                            match = false;
                            break;
                        }
                    }
                    if (match) {
                        cout << i + 1 << endl;
                        goto endMatch;
                    }
                    for (vector<Vertex>::iterator it = subjects.begin(); it != subjects.end(); it++) {
                        int nx = -(*it).y, ny = (*it).x;
                        (*it).x = nx;
                        (*it).y = ny;
                    }
                }
                if (j == 0) {
                    reverse(subjects.begin(), subjects.end());
                    int px, py;
                    for (vector<Vertex>::iterator it = subjects.begin(); it != subjects.end(); it++) {
                        if (it == subjects.begin()) {
                            px = (*it).x;
                            py = (*it).y;
                        }
                        (*it).x -= px;
                        (*it).y -= py;
                    }
                }
            }
        endMatch:;
        }
        cout << "+++++" << endl;
    }
}