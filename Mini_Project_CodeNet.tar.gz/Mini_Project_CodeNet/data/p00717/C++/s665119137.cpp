#include <iostream>
#include <complex>
#include <cmath>
#define MAX_N 60
#define MAX_M 20
using namespace std;

#define P complex<int>

int main(){
  int n, m,mm;
  P org[MAX_M];
  P cmp[MAX_M];
  P d, o,c,deg;

  while( cin>>n && n ){

    cin >> mm;
    for( int i=0;i<mm;i++ )
      cin >> org[i].real() >> org[i].imag();

    d = org[0];
    for( int i=0;i<mm;i++ )
      org[i] = org[i] - d;

    for( int loop=1;loop<=n;loop++ ){
      cin >> m;
      for( int i=0;i<m;i++ )
	cin >> cmp[i].real() >> cmp[i].imag();
      if( m!=mm )
	continue;
      bool f=false;

      d= cmp[0] - org[0];
      for( int i=0;i<m;i++ ) // ツ閉スツ行ツ暗堋督ョ
	cmp[i] = cmp[i] - d;

      o = org[1] / abs(org[1]);
      c = cmp[1] / abs(cmp[1]);
      deg = P( 1,0 );

      while( o!=c ){
	c = c * P( 0,1 );
	deg *= P( 0,1 );
      }

      for( int i=1;i<m;i++ ) // ツ嘉アツ転
	cmp[i] = cmp[i] * deg;

      for( int i=1;i<m;i++ ){
	if( org[i]!=cmp[i] )
	  break;
	if( i==m-1 ) f=true;
      }

      if( !f ){
	d = cmp[m-1] - org[0];
	for( int i=0;i<m;i++ )
	  cmp[i] = cmp[i] - d; // ツ閉スツ行ツ暗堋督ョ
	o = org[1] / abs(org[1]);
	c = cmp[m-2] / abs(cmp[m-2]);
	deg = P( 1,0 );
	while( o!=c ){
	  c = c * P( 0,1 );
	  deg *= P( 0,1 );
	}
	for( int i=0;i<m-1;i++ ) // ツ嘉アツ転
	  cmp[i] = cmp[i] * deg;
	
	for( int i=0;i<m-1;i++ ){
	  if( org[i]!=cmp[m-i-1] )
	    break;
	  if( i==m-2 ) f=true;
	}
      }
      if( f )
	cout << loop << endl;
    
    }
    cout << "+++++"<<endl;
  }

  return 0;
}