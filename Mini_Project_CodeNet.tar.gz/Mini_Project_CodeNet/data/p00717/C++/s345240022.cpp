#include <iostream>
#include <algorithm>
#include <vector>

using namespace std;

//ue 0
//migi 1
//shita 2
//hidari 3

int main(int argc, char const *argv[])
{
	int n;
	int x1,y1,x2,y2;

	while(1){
		cin>>n;
		if(n==0) break;

		int m;
		vector<int> v[n+1];
		for(int i1=0;i1<n+1;i1++){
			cin>>m;
			vector<int> temp;
			for(int i2=0;i2<m;i2++){
				cin>>x2>>y2;

				if(i2!=0) {
					if(x2-x1>0) {//migi
						for(int i3=0;i3<x2-x1;i3++) temp.push_back(1);
					}
					if(x2-x1<0) {//hidari
						for(int i3=0;i3<x1-x2;i3++) temp.push_back(3);
					}
					if(y2-y1>0) {//ue
						for(int i3=0;i3<y2-y1;i3++) temp.push_back(0);
					}
					if(y2-y1<0) {//shita
						for(int i3=0;i3<y1-y2;i3++) temp.push_back(2);
					}
				}
				x1=x2;
				y1=y2;
			}
			v[i1]=temp;
		}

		for(int i1=1;i1<n+1;i1++){

			bool ok = false;
			if(v[i1].size()==v[0].size()){
				for(int i2=0;i2<4;i2++){
					int i3;
					for(i3=0;i3<v[0].size();i3++){
						int dif=(v[0][i3]+i2)%4;
						if(dif!=v[i1][i3]) break;
					}

					if(i3==v[0].size()) ok=true;

					reverse(v[0].begin(), v[0].end());
					for(i3=0;i3<v[0].size();i3++){
						int dif=(v[0][i3]+i2)%4;
						if(dif!=v[i1][i3]) break;
					}

					if(i3==v[0].size()) ok=true;

					reverse(v[0].begin(), v[0].end());
				}

				
			}
			if(ok) cout<<i1<<endl;

		}
		cout<<"+++++"<<endl;


	}
	return 0;
}