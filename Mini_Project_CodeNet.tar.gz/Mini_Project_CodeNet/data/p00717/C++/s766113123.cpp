#include<iostream>
using namespace std;

const int kx[2][4] = { {1,0,-1,0}, {0,-1,0,1} };
const int ky[2][4] = { {1,0,-1,0}, {0,1,0,-1} };

int main(){
  int n;
  int m[55],x[55][15],y[55][15];

  while(cin >> n,n){
    for(int i=0;i<=n;i++){
      cin >> m[i];
      for(int j=0;j<m[i];j++)cin >> x[i][j] >> y[i][j];
    }

    for(int i=1;i<=n;i++){
      if(m[i] != m[0])continue;

      bool exist = false;

      for(int d=0;d<4;d++){
	bool f = true;
	for(int j=1;j<m[i];j++){
	  if(x[0][j]-x[0][0] != kx[0][d]*(x[i][j]-x[i][0]) + ky[1][d]*(y[i][j]-y[i][0]) ||
	     y[0][j]-y[0][0] != ky[0][d]*(y[i][j]-y[i][0]) + kx[1][d]*(x[i][j]-x[i][0])){
	    f = false; break;
	  }
	}
	exist |= f;
      }

      for(int d=0;d<4;d++){
	bool f = true;
	for(int j=1;j<m[i];j++){
	  if(x[0][m[i]-1-j]-x[0][m[i]-1] != kx[0][d]*(x[i][j]-x[i][0]) + ky[1][d]*(y[i][j]-y[i][0]) ||
	     y[0][m[i]-1-j]-y[0][m[i]-1] != ky[0][d]*(y[i][j]-y[i][0]) + kx[1][d]*(x[i][j]-x[i][0]) ){
	    f = false; break;
	  }
	}
	exist |= f;
      }
      if(exist)cout << i << endl;
    }
    cout << "+++++" << endl;
  }
}