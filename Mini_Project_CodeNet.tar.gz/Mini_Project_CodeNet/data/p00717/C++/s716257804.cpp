#include <bits/stdc++.h>
using namespace std;
#define rep(i, n) for(int i=0; i<(n); ++i)

class P{
public:
    int x, y;
    P(int x, int y): x(x), y(y){};
};
int main(void){
    int n;
    while(cin >> n && n) {
        vector<vector<P> > line;
        rep(l, n+1) {
            int m, x, y;
            cin >> m;
            vector<P> tmp;
            rep(i, m) {
                cin >> x >> y;
                tmp.push_back(P(x, y));
            }
            vector<P> tmp2;
            rep(i, m-1) {
                int d;
                if(i==m-2) {
                    d = 0;
                } else if((tmp[i+1].x==tmp[i].x && tmp[i+1].y>tmp[i].y &&
                        tmp[i+2].x>tmp[i+1].x && tmp[i+2].y==tmp[i+1].y) ||
                       (tmp[i+1].y==tmp[i].y && tmp[i+1].x>tmp[i].x &&
                        tmp[i+2].x==tmp[i+1].x && tmp[i+2].y<tmp[i+1].y) ||
                       (tmp[i+1].x==tmp[i].x && tmp[i+1].y<tmp[i].y &&
                        tmp[i+2].y==tmp[i+1].y && tmp[i+2].x<tmp[i+1].x) ||
                       (tmp[i+1].y==tmp[i].y && tmp[i+1].x<tmp[i].x &&
                        tmp[i+2].x==tmp[i+1].x && tmp[i+2].y>tmp[i+1].y)) {
                    d = 1;
                } else {
                    d = -1;
                }
                tmp2.push_back(P(d, abs(tmp[i+1].x-tmp[i].x)
                                    +abs(tmp[i+1].y-tmp[i].y)));
            }
            line.push_back(tmp2);
        }
        for(int i=1; i<line.size(); ++i) {
            bool same, same1, same2;
            same = same1 = same2 = true;
            int len;
            if(line[i].size() != line[0].size()) same = false;
            else {
                len = line[0].size();
            }
            rep(j, len) {
                if(line[i][j].x!=line[0][j].x || line[i][j].y!=line[0][j].y) {
                    same1 = false; break;
                }
            }
            rep(j, len) {
                if(line[i][len-j-1].y!=line[0][j].y) {
                    same2 = false; break;
                }
                if(j<len-1) {
                    if(line[i][len-j-2].x==line[0][j].x) {
                        same2 = false; break;
                    }
                }
            }
            if(same && (same1 || same2)) cout << i << endl;
        }
        cout << "+++++" << endl;
    }
}