#include <algorithm>
#include <cmath>
#include <climits>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iostream>
#include <list>
#include <map>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <string>
#include <vector>
#include <cassert>
#include <functional>

using namespace std;

#define LOG(...) printf(__VA_ARGS__)
//#define LOG(...)
#define FOR(i,a,b) for(int i=(int)(a);i<(int)(b);++i)
#define REP(i,n) for(int i=0;i<(int)(n);++i)
#define ALL(a) (a).begin(),(a).end()
#define RALL(a) (a).rbegin(),(a).rend()
#define EXIST(s,e) ((s).find(e)!=(s).end())
#define SORT(c) sort((c).begin(),(c).end())
#define RSORT(c) sort((c).rbegin(),(c).rend())
#define CLR(a) memset((a), 0 ,sizeof(a))

typedef long long ll;
typedef unsigned long long ull;
typedef vector<bool> vb;
typedef vector<int> vi;
typedef vector<ll> vll;
typedef vector<vb> vvb;
typedef vector<vi> vvi;
typedef vector<vll> vvll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;

const int dx[] = { -1, 0, 1, 0 }; const int dy[] = { 0, 1, 0, -1 };

struct UnionFind {
	vector<int> v;
	UnionFind(int n) : v(n) { for (int i = 0; i < n; i++) v[i] = i; }
	int  find(int x) { return v[x] == x ? x : v[x] = find(v[x]); }
	void unite(int x, int y) { v[find(x)] = find(y); }
};

int main() {
	int n;
	while (cin >> n, n) {
		vector<pii> point;
		vector<pii> sub;
		REP(i, n + 1) {
			int m;
			cin >> m;
			vector<pii> point2;
			vector<vector<pii>> sub2(2);
			REP(j, m) {
				int x, y;
				cin >> x >> y;
				if (i == 0)
					point.push_back(pii(x, y));
				else
					point2.push_back(pii(x, y));
			}
			if (i == 0) {
				REP(j, m-1) {
					sub.push_back(pii(point[j + 1].first - point[0].first, point[j + 1].second - point[0].second));
				}
				continue;
			}
			REP(j, m - 1) {
				sub2[0].push_back(pii(point2[j + 1].first - point2[0].first, point2[j + 1].second - point2[0].second));
			}
			REP(j, m - 1) {
				sub2[1].push_back(pii(point2[m - 1 - 1 - j].first - point2[m-1].first, point2[m-1-1-j].second - point2[m-1].second));
			}
			bool clear = false;
			
			REP(j, 2) {
				REP(k, 4) {
					vector<pii> sub3 = sub2[j];
					if(k%2==1)
						REP(l, sub3.size()) {
						swap(sub3[l].first, sub3[l].second);
						sub3[l].second *= -1;
					}
					if (k > 1)
						REP(l, sub3.size()) {
						sub3[l].first *= -1;
						sub3[l].second *= -1;
					}
					if (sub3 == sub) {
						clear = true;
						break;
					}
				}
				if (clear)
					break;
			}
			if (clear)
				cout << i << endl;
		}
		cout << "+++++" << endl;
	}
}