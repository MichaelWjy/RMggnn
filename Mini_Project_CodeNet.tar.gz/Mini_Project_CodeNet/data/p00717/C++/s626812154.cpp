#include "bits/stdc++.h"

using namespace std;

using i64 = long long;

const i64 MOD = 1e9 + 7;
const i64 INF = i64(1e18) + 7;


template <typename T>
bool chmin(T& x, T y){
    if(x > y){
        x = y;
        return true;
    }
    return false;
}

template <typename T>
bool chmax(T& x, T y){
    if(x < y){
        x = y;
        return true;
    }
    return false;
}


vector<int> dx{0, 1};
vector<int> dy{-1, 0};


struct Data{
    int n;
    vector<int> vx, vy;
    Data(vector<int> vx, vector<int>(vy)) : n(vx.size()), vx(vx), vy(vy){}
    Data(istream& st){
        st >> n;
        for(int i = 0; i < n; ++i){
            int x, y;
            st >> x >> y;
            vx.push_back(x);
            vy.push_back(y);
        }
    }

    vector<Data> get(){
        return vector<Data>{_get(false), _get(true)};
    }

    Data _get(bool inv = false){
        auto x = vx;
        auto y = vy;
        if(inv){
            reverse(x.begin(), x.end());
            reverse(y.begin(), y.end());
        }
        for(int i = n - 1; i >= 0; --i){
            x[i] -= x[0];
            y[i] -= y[0];
        }
        for(int d = 0;; ++d){
            for(int i = 0; i < n; ++i){
                int nx = x[i] * dx[0] + y[i] * dx[1];
                int ny = x[i] * dy[0] + y[i] * dy[1];
                x[i] = nx;
                y[i] = ny;
            }
            if(!x[1] && y[1] > 0)
                break;
        }
        return Data(x, y);
    }

    friend bool operator==(const Data& x, const Data& y){return x.vx == y.vx && x.vy == y.vy;};
};

bool solve(){
    int n;
    cin >> n;
    if(!n)
        return false;
    Data d(cin);
    d = d._get();
    vector<Data> v;
    vector<vector<Data>> w(n);
    for(int i = 0; i < n; ++i){
        v.emplace_back(cin);
        w[i] = v.back().get();
    }
    for(int i = 0; i < n; ++i){
        for(auto& p : w[i])
            if(d == p){
                cout << i + 1 << endl;
                break;
            }
    }
    cout << "+++++\n";
    return true;
}

signed main(){
    while(solve());
}

