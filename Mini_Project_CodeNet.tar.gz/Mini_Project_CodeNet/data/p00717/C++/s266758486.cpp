#include <iostream>
#include <complex>
#include <vector>
using namespace std;

#define pb push_back
#define rep(i,n) rep2(i,0,n)
#define rep2(i,m,n) for(int i=m;i<n;i++)
#define sz size()

typedef complex<int> P;
typedef vector<P> V;

int n;

bool same(V a,V b){
	rep2(i,1,a.sz){
		if(a[i]-b[i]!=a[0]-b[0])return 0;
	}
	return 1;
}

int main(){
	while(cin>>n && n){
		V v;
		int m,x,y;
		cin>>m;
		rep(i,m){
			cin>>x>>y;
			v.pb(P(x,y));
		}
		rep(h,n){
			V w;
			cin>>m;
			rep(i,m){
				cin>>x>>y;
				w.pb(P(x,y));
			}
			if(m!=v.sz)continue;
			rep(i,2){
				rep(j,4){
					if(same(v,w)){
						cout<<h+1<<endl;
						goto out;
					}
					rep(k,m)w[k]=w[k]*P(0,1);
				}
				reverse(w.begin(),w.end());
			}
			out:;
		}
		cout<<"+++++\n";
	}
}