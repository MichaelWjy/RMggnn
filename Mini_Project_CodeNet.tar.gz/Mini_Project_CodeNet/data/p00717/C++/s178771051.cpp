#include <iostream>
#include <algorithm>
#include <set>
#include <vector>
#include <complex>
#include <cmath>
using namespace std;
typedef complex<int> P;

const double PI = acos(-1);


void rotate(vector<P> &p){
	for(int i = 0 ; i < p.size() ; i++){
		p[i] = P(-p[i].imag(),p[i].real());
	}
}

int chk(vector<P> a,vector<P> b){
	if( a == b ) return true;
	reverse(b.begin(),b.end());
	if( a == b ) return true;
}

int issame(vector<P> a,vector<P> b){
	for(int i = 0 ; i < 4 ; i++){
		if( chk(a,b) ) return true;
		rotate(b);
	}
	
	for(int i = 0 ; i < b.size() ; i++){
		b[i] -= b.back();
	}
	
	for(int i = 0 ; i < 4 ; i++){
		if( chk(a,b) ) return true;
		rotate(b);
	}
	return false;
}

int main(){
	int n;
	while(cin >> n && n){
		vector< vector<P> > l(n+1);
		for(int i = 0 ; i <= n ; i++){
			int m;
			cin >> m;
			for(int j = 0 ; j < m ; j++){
				int x,y;
				cin >> x >> y;
				l[i].push_back(P(x,y));
			}
			for(int j = m-1 ; j >= 0 ; j--){
				l[i][j] -= l[i][0];
			}
		}
		for(int i = 1 ; i <= n ; i++){
			if( issame(l[0],l[i]) ) cout << i << endl;
		}
		
		
		cout << "+++++" << endl;
	}
}