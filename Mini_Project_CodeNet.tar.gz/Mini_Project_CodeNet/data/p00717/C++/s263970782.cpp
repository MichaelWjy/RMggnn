#include <bits/stdc++.h>
#define INF 1e18
#define int long long
#define Rep(i, a, n) for (int i = (a); i < (n); i++)
#define rep(i, n) Rep(i, 0, n)
#define all(a) (a).begin(), (a).end()
using namespace std;
typedef pair<int, int> P;
typedef pair<int, P> PP;
const int mod = 1000000007;
//const int mod = 998244353;

signed main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);

    while (1)
    {
        int n;
        cin >> n;
        if (n == 0)
            break;
        int M;
        cin >> M;
        vector<int> X(M), Y(M);
        rep(i, M) cin >> X[i] >> Y[i];
        vector<int> rX(M), rY(M);
        rep(i, M) rX[i] = X[M - i - 1], rY[i] = Y[M - i - 1];
        for (int i = M - 1; i >= 0; i--)
        {
            X[i] -= X[0], Y[i] -= Y[0];
            rX[i] -= rX[0], rY[i] -= rY[0];
        }
        vector<int> ans;
        rep(i, n)
        {
            int m;
            cin >> m;
            vector<int> x(m), y(m);
            rep(j, m) cin >> x[j] >> y[j];
            for (int j = m - 1; j >= 0; j--)
                x[j] -= x[0], y[j] -= y[0];
            if (m != M)
                continue;
            bool f = false;
            for (int j = 0; j < 4; j++) //4方向
            {
                bool F = true;
                rep(k, m) if (X[k] != x[k] || Y[k] != y[k])
                    F = false;
                if (F)
                    f = true;
                F = true;
                rep(k, m) if (rX[k] != x[k] || rY[k] != y[k])
                    F = false;
                if (F)
                    f = true;
                vector<int> nx(m), ny(m);
                rep(k, m) nx[k] = -y[k], ny[k] = x[k];
                x = nx, y = ny;
            }
            if (f)
                ans.push_back(i + 1);
        }
        rep(i, ans.size()) cout << ans[i] << endl;
        cout << "+++++" << endl;
    }
}

