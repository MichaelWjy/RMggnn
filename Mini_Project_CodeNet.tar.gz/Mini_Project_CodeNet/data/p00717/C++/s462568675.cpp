#include <iostream>
#include <cmath>
#include <algorithm>
#define REP(i, a, n) for(int i = ((int) a); i < ((int) n); i++)
#define EPS 1e-10
using namespace std;

int N, M[51], X[51][10], Y[51][10];

int len(int i, int j) {
  return abs(X[i][j] - X[i][j + 1]) + abs(Y[i][j] - Y[i][j + 1]);
}

int dir(int i, int j) {
  int x1 = X[i][j + 1] - X[i][j];
  int y1 = Y[i][j + 1] - Y[i][j];
  int x2 = X[i][j + 2] - X[i][j];
  int y2 = Y[i][j + 2] - Y[i][j];
  double r = atan2(x2, y2) - atan2(x1, y1);
  if(r < M_PI) r += M_PI * 2;
  if(r > M_PI) r -= M_PI * 2;
  if(abs(r) < EPS) return 0;
  return r > 0;
}

int main(void) {
  while(cin >> N, N) {
    REP(i, 0, N + 1) {
      cin >> M[i];
      REP(j, 0, M[i]) cin >> X[i][j] >> Y[i][j];
    }

    REP(i, 1, N + 1) {
      if(M[0] != M[i]) continue;
      bool f1 = true;
      REP(j, 0, M[0] - 1) if(len(0, j) != len(i, j)) f1 = false;
      REP(j, 0, M[0] - 2) if(dir(0, j) != dir(i, j)) f1 = false;
      bool f2 = true;
      reverse(X[i], X[i] + M[0]);
      reverse(Y[i], Y[i] + M[0]);
      REP(j, 0, M[0] - 1) if(len(0, j) != len(i, j)) f2 = false;
      REP(j, 0, M[0] - 2) if(dir(0, j) != dir(i, j)) f2 = false;
      if(f1 || f2) cout << i << endl;
    }
    cout << "+++++" << endl;
  }

  return 0;
}