#include <iostream>
#include <math.h>
#include <cmath>
using namespace std;


/*
double angle_of_line(double x1, double y1, double x2, double y2){
    return  atan2(y2-y1, x2-x1);
}

double angle_of_two_line(double ax, double ay, double bx, double by, double cx, double cy){
    double angle1 = angle_of_line(ax, ay, bx, by);
    double angle2 = angle_of_line(bx, by, cx, cy);
    
    double ret =angle1 + (M_PI-angle2);
    if(ret>=M_PI*2)ret-=M_PI*2;
    if(ret<0)ret+=M_PI*2;
    return ret;
}
*/

double angle_of_two_line(double ax, double ay, double bx, double by, double cx, double cy){
    if(by-ay>0&&cx-bx>0)return 1.0;
    if(by-ay>0&&cx-bx<0)return 2.0;
    if(bx-ax>0&&cy-by>0)return 2.0;
    if(bx-ax>0&&cy-by<0)return 1.0;
    
    if(by-ay<0&&cx-bx>0)return 2.0;
    if(by-ay<0&&cx-bx<0)return 1.0;
    if(bx-ax<0&&cy-by>0)return 1.0;
    if(bx-ax<0&&cy-by<0)return 2.0;
    return 0.0;
    
}

int main()
{

    int n;
    while(cin>>n){
        if(n==0)break;

        int def_x[12]={0};
        int def_y[12]={0};
        double def_len[12]={0};
        double def_ang[12]={0};
        int m;
        cin>>m;
        for(int i=0; i<m; i++){
            cin>>def_x[i]>>def_y[i];
        }
        
        def_x[m]=def_x[0];
        def_y[m]=def_y[0];
        
        for(int i=1; i<m; i++){
            def_len[i-1] = fabs(def_x[i-1]-def_x[i]+def_y[i-1]-def_y[i]);
            if(i<m-1)def_ang[i-1] = angle_of_two_line(def_x[i-1], def_y[i-1], def_x[i], def_y[i], def_x[i+1], def_y[i+1]);
        }
        
        for(int i=1; i<=n; i++){
            int x[12]={0};
            int y[12]={0};
            int x2[12]={0};
            int y2[12]={0};
            double len[12]={0};
            double ang[12]={0};
            double len2[12]={0};
            double ang2[12]={0};
            cin>>m;
            for(int j=0; j<m; j++){
                cin>>x[j]>>y[j];
            }
            
            x[m]=x[0];
            y[m]=y[0];
            
            bool flag = true;
            for(int j=1; j<m; j++){
                len[j-1]=fabs(x[j-1]-x[j]+y[j-1]-y[j]);
                if(j<m-1)ang[j-1]=angle_of_two_line(x[j-1], y[j-1], x[j], y[j], x[j+1], y[j+1]);
                if( !(len[j-1]==def_len[j-1]&&ang[j-1]==def_ang[j-1])){
                    flag=false;
                    break;
                }
            }
            
            if(!flag){
                flag = true;
                for(int j=0; j<m; j++){
                    x2[j]=x[m-j-1];
                    y2[j]=y[m-j-1];
                }
                x2[m]=x2[0];
                y2[m]=y2[0];
                
                for(int j=1; j<m; j++){
                    len2[j-1]=fabs(x2[j-1]-x2[j]+y2[j-1]-y2[j]);
                    if(j<m-1)ang2[j-1]=angle_of_two_line(x2[j-1], y2[j-1], x2[j], y2[j], x2[j+1], y2[j+1]);
                    if( !(len2[j-1]==def_len[j-1]&&ang2[j-1]==def_ang[j-1])){
                        flag=false;
                        break;
                    }
                }
                
                
            }
            if(flag)cout<<i<<endl;

        }
        cout<<"+++++"<<endl;
        
    }
    return 0;
}