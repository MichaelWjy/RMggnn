#include <bits/stdc++.h>
using namespace std;

struct P{
    int x;
    int y;
    P(){}
    ~P(){}
    P(int a, int b): x(a), y(b){}
};

P add(P a, P b){
    return P(a.x + b.x, a.y + b.y);
}

P sub(P a, P b){
    return P(a.x - b.x, a.y - b.y);
}

bool eq(P a, P b){
    return a.x == b.x && a.y == b.y;
}

P rot90(P a){
    return P(-a.y, a.x);
}

bool identical(vector<P> va, vector<P> vb){
    if(va.size() != vb.size()) return false;
    int n = va.size();
    bool flg = true;
    for(int c = 0; c < 4; c++){
        int i;
        for(i = 1; i < n; i++){
            if(!eq(sub(va[i], va[i-1]), sub(vb[i], vb[i-1]))) break;
        }
        if(i == n) return true;
        for(i = 1; i < n; i++){
            if(!eq(sub(va[i], va[i-1]), sub(vb[n-1-i], vb[n-i]))) break;
        }
        if(i == n) return true;
        for(i = 0; i < n; i++) va[i] = rot90(va[i]);
    }
    return false;
}

int main(){
    int n, m;
    while(true){
        scanf("%d", &n);
        if(n == 0) break;
        vector<P> orig, trg;
        scanf("%d", &m);
        for(int j = 0; j < m; j++){
            int x, y;
            scanf("%d%d", &x, &y);
            orig.push_back(P(x, y));
        }
        for(int i = 1; i <= n; i++){
            scanf("%d", &m);
            for(int j = 0; j < m; j++){
                int x, y;
                scanf("%d%d", &x, &y);
                trg.push_back(P(x, y));
            }
            if(identical(orig, trg)){
                printf("%d\n", i);
            }
            trg.clear();
        }
        puts("+++++");
    }
    return 0;
}