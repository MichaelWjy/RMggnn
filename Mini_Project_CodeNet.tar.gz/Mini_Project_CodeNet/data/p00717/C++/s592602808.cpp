#include <cstdio>
#include <complex>
#include <vector>
#include <algorithm>
using namespace std;

typedef complex<int> P;

int cross(const P &v1, const P &v2){
	return v1.real() * v2.imag() - v1.imag() * v2.real();
}

vector<int> lineinfo(const vector<P> &pl){
	vector<int> ret(pl.size() - 1);
	ret[0] = norm(pl[1] - pl[0]);

	for(int i = 1; i + 1 < pl.size(); ++i){
		ret[i] = cross(pl[i] - pl[i-1], pl[i+1] - pl[i]);
	}
	return ret;
}

int main(){
	int n, m;
	vector<P> lines;
	lines.reserve(10);

	int x, y;

	while( scanf("%d%d", &n, &m) == 2 ){
		lines.clear();
		for(int i = 0; i < m; ++i){
			scanf("%d%d", &x, &y);
			lines.push_back( P(x, y) );
		}

		vector<int> v0 = lineinfo(lines);

		for(int i = 1; i <= n; ++i){
			lines.clear();
			scanf("%d", &m);
			for(int j = 0; j < m; ++j){
				scanf("%d%d", &x, &y);
				lines.push_back( P(x, y) );
			}
			
			if( lineinfo(lines) == v0 ){
				printf("%d\n", i);
			}
			else{
				reverse(lines.begin(), lines.end());
				if( lineinfo(lines) == v0 ){
					printf("%d\n", i);
				}
			}
		}
		
		puts("+++++");
	}
}