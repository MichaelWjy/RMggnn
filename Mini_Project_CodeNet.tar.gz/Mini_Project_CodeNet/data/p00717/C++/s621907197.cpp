#include <bits/stdc++.h>
using namespace std;

#define rep(i,n) for (int i=0;i<(n);i++)
#define rep2(i,a,b) for (int i=(a);i<(b);i++)
#define rrep(i,n) for (int i=(n)-1;i>=0;i--)
#define rrep2(i,a,b) for (int i=(b)-1;i>=(a);i--)
#define all(a) (a).begin(),(a).end()

typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef vector<int> vi;
// typedef vector<pll> vp;
typedef vector<ll> vll;

typedef complex<int> P;
typedef vector<P> vp;

int cross(P p1, P p2) {
    return p1.real() * p2.imag() - p1.imag() * p2.real();
}

vi setDist(vp points) {
    vi ret;
    rep(i, points.size() - 1) {
        ret.emplace_back(abs(points[i + 1] - points[i]));
    }
    return ret;
}

vi setClock(vp points) {
    vi ret;
    rep(i, points.size() - 2) {
        ret.emplace_back((cross(points[i + 1] - points[i], points[i + 2] - points[i + 1]) > 0) ? 1 : -1);
    }
    return ret;
}

bool same(vi a, vi b) {
    rep(i, a.size()) {
        if (a[i] != b[i]) return false;
    }
    return true;
}

bool check(vi a, vi a0, vi b, vi b0) {
    if (same(a, a0) && same(b, b0)) return true;
    reverse(all(a));
    reverse(all(b));
    rep(i, b.size()) b[i] = -b[i];  //?????????????????¨?????¢?????????????????????
    if (same(a, a0) && same(b, b0)) return true;
    return false;
}

vp in(int size) {
    vp ret;
    rep(i, size) {
        int x, y;
        cin >> x >> y;
        ret.emplace_back(P(x, y));
    }
    return ret;
}

signed main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(0);

    int n;
    while (cin >> n && n) {
        int m0;
        cin >> m0;

        vp a0 = in(m0);
        vi L0 = setDist(a0);
        vi C0 = setClock(a0);
        rep(i, n) {
            int m;
            cin >> m;
            vp a = in(m);
            if (m != m0) continue;
            vi L = setDist(a);
            vi C = setClock(a);
            if (check(L, L0, C, C0)) {
                cout << i + 1 << endl;
            }
        }
        cout << "+++++" << endl;
    }
}