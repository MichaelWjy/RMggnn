#include "bits/stdc++.h"
using namespace std;

int x_tar[10];
int y_tar[10];
int x[10];
int y[10];

//頂点0を中心に時計回りに90度回転
void rotate(int m)
{
	int newx,newy;
	for(int i=1;i<m;i++)
	{
		newx=(y[i]-y[0]);
		newy=-1*(x[i]-x[0]);
		// if(i==1)
		// 	cerr<<x[i]<<" "<<y[i]<<endl;
		x[i]=newx;
		y[i]=newy;
	}
	return;
}

//回転しながら同じものか確かめる
bool check(int m)
{
	bool f=true;
	for(int i=0;i<4;i++)
	{
		f=true;
		for(int j=0;j<m;j++)
		{
			if(!(x[j]==x_tar[j] && y[j]==y_tar[j]))
			{
				f=false;
				break;
			}
		}
		if(f)
			return true;
		rotate(m);
	}
	return false;
}

int main()
{
	int n;
	int m_tar;
	int m;
	while(1)
	{
		cin>>n;
		if(n==0)
			break;
		//探索元
		cin>>m_tar;
		for(int i=0;i<m_tar;i++)
			cin>>x_tar[i]>>y_tar[i];
		for(int i=m_tar-1;i>-1;i--)
		{
			x_tar[i]-=x_tar[0];
			y_tar[i]-=y_tar[0];
		}
		//ここから探索
		for(int i=0;i<n;i++)
		{
			cin>>m;
			for(int j=0;j<m;j++)
				cin>>x[j]>>y[j];
			if(m!=m_tar)
				continue;
			//頂点0を目標と同じ位置に移動する
			int xdif=x_tar[0]-x[0];
			int ydif=y_tar[0]-y[0];
			//cerr<<xdif<<" "<<ydif<<endl;
			for(int j=0;j<m;j++)
			{
				x[j]+=xdif;
				y[j]+=ydif;
			}
			//cerr<<x[0]<<" "<<y[0]<<endl;
			//頂点0を中心に回転しつつ同じか調べる
			if(check(m))
			{
				cout<<i+1<<endl;
				continue;
			}
			//始点と終点を逆にしてもう一度調べる
			reverse(x,x+m);
			reverse(y,y+m);
			//補正をやり直す
			xdif=x_tar[0]-x[0];
			ydif=y_tar[0]-y[0];
			for(int j=0;j<m;j++)
			{
				x[j]+=xdif;
				y[j]+=ydif;
			}
			if(check(m))
				cout<<i+1<<endl;
		}
		cout<<"+++++"<<endl;
	}
}
