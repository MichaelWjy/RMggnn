#include <algorithm>
#include <cstdio>
#include <iostream>
#include <map>
#include <cmath>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <string>
#include <vector>
#include <stdlib.h>
#include <stdio.h>
#include <bitset>
#include <cstring>
using namespace std;
#define FOR(I,A,B) for(int I = (A); I < (B); ++I)
#define CLR(mat) memset(mat, 0, sizeof(mat))
typedef long long ll;
int x[60][20], y[60][20]; // n=0?????¢??????
int m[60];
int dy[20], dx[20];

bool check(int i, int deg) {
  bool ok = true;
  if(deg==0) {
    ok = true;
    FOR(j,0,m[0]-1) {
      if(dy[j] != y[i][j+1] - y[i][j]) ok = false;
      if(dx[j] != x[i][j+1] - x[i][j]) ok = false;
    }
    if(ok) return true;
    ok = true;
    for(int j = m[0] - 1; j > 0; j--) {
      if(dy[m[0] - 1 - j] != y[i][j-1] - y[i][j]) ok = false;
      if(dx[m[0] - 1 - j] != x[i][j-1] - x[i][j]) ok = false;
    }
    if(ok) return true;
  }
  if(deg==90) {
    ok = true;
    FOR(j,0,m[0]-1) {
      if(-dx[j] != y[i][j+1] - y[i][j]) ok = false;
      if(dy[j] != x[i][j+1] - x[i][j]) ok = false;
    }
    if(ok) return true;
    ok = true;
    for(int j = m[0] - 1; j > 0; j--) {
      if(-dx[m[0] - 1 - j] != y[i][j-1] - y[i][j]) ok = false;
      if(dy[m[0] - 1 - j] != x[i][j-1] - x[i][j]) ok = false;
    }
    if(ok) return true;
  }
  if(deg==180) {
    ok = true;
    FOR(j,0,m[0]-1) {
      if(-dy[j] != y[i][j+1] - y[i][j]) ok = false;
      if(-dx[j] != x[i][j+1] - x[i][j]) ok = false;
    }
    if(ok) return true;
    ok = true;
    for(int j = m[0] - 1; j > 0; j--) {
      if(-dy[m[0] - 1 - j] != y[i][j-1] - y[i][j]) ok = false;
      if(-dx[m[0] - 1 - j] != x[i][j-1] - x[i][j]) ok = false;
    }
    if(ok) return true;
  }
  if(deg==270) {
    ok = true;
    FOR(j,0,m[0]-1) {
      if(dx[j] != y[i][j+1] - y[i][j]) ok = false;
      if(-dy[j] != x[i][j+1] - x[i][j]) ok = false;
    }
    if(ok) return true;
    ok = true;
    for(int j = m[0] - 1; j > 0; j--) {
      if(dx[m[0] - 1 - j] != y[i][j-1] - y[i][j]) ok = false;
      if(-dy[m[0] - 1 - j] != x[i][j-1] - x[i][j]) ok = false;
    }
    if(ok) return true;
  }
  return false;
}
int main()
{
  ios::sync_with_stdio(false);
  cin.tie(0);
  int n;
  while(cin>>n,n) {
    n++;
    FOR(i,0,n) {
      cin >> m[i];
      FOR(j,0,m[i]) cin >> x[i][j] >> y[i][j];
    }
    FOR(i,0,m[0]-1) {
      dy[i] = y[0][i+1] - y[0][i];
      dx[i] = x[0][i+1] - x[0][i];
    }
    FOR(i,1,n) {
      if(m[0] == m[i]) {
        if(check(i,0)||check(i,90)||check(i,180)||check(i,270)) {
          cout << i << endl;
        }
      }
    }
    cout << "+++++" << endl;
  }
  return 0;
}