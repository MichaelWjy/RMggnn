
#include <iostream>
#include <string>
#include <vector>

using namespace std;

struct vect{
	int x, y;
};

bool equals(vector< vect > v1, vector< vect > v2 ){
	bool flg[8];
	bool ret = false;

	if( v1.size() != v2.size() ) return false;

	for(int i = 0; i < 8; i++)
		flg[i] = true;

	for( int i = 0; i < 2; i++ ) {
		int indx;
		for(int j = 0; j < 4; j++) {
			if( i == 0 ) indx = 0;
			else indx = v1.size() - 1;
			for(int _indx = 0; _indx < v2.size(); _indx++) {
				if( j == 0 ) {
					flg[ j + i * 4 ] &= ( v1[indx].x == v2[_indx].x && v1[indx].y == v2[_indx].y );
				} else if( j == 1 ) {
					flg[ j + i * 4 ] &= ( v1[indx].x == -v2[_indx].y && v1[indx].y == v2[_indx].x );
				} else if( j == 2 ) {
					flg[ j + i * 4 ] &= ( v1[indx].x == -v2[_indx].x && v1[indx].y == -v2[_indx].y );
				} else if( j == 3 ) {
					flg[ j + i * 4 ] &= ( v1[indx].x == v2[_indx].y && v1[indx].y == -v2[_indx].x );
				}
				if( i == 0 ) indx ++;
				else indx --;
			}

		}

	}

	for(int i = 0; i < 8; i++)
		ret |= flg[i];

	return ret;
}

int main(void){

	//与えられる座標をベクトルに変換する
	while( 1 ) {
		int n;
		cin >> n;
		if( n == 0 ) break;

		vector< vector< vect > > vv;

		for(int i = 0; i <= n; i++) {
			vector< vect > line;
			int m, px, py;
			cin >> m >> px >> py;
			for(int j = 0; j < m - 1; j++) {
				int x, y;
				cin >> x >> y;
				vect nv;
				nv.x = x - px;
				nv.y = y - py;
				px = x;
				py = y;
				line.push_back( nv );
			}
			vv.push_back( line );
		}

		for(int i = 1; i < vv.size(); i++)
			if( equals( vv[0], vv[i] ) ) cout << i << endl;

		cout << "+++++" << endl;
	}
    return 0;
}