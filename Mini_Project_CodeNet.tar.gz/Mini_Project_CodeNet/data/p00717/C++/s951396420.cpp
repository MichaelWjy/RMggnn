#define	_USE_MATH_DEFINES
#include <iostream>
#include <iomanip>
#include <cctype>
#include <algorithm>
#include <functional>
#include <vector>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <cfloat>
#include <map>
#include <queue>
#include <stack>
#include <list>
#include <string>
#include <set>
#include <complex>
#include <utility>
#include <numeric>
using namespace std;

typedef complex<int> P;

int b[19][19];


int main(){
	
	int n;
	P p[51][11];
	int m[51];
	
	while(cin>>n,n){
		for (int i=0; i<=n; i++) {
      cin >> m[i];
			int a,b;
      for (int j=0; j<m[i]; j++) {
        cin>>a>>b;
      	p[i][j]=P(a,b);
      }
			}
		
		
		for(int i=1;i<=n;i++){
			if(m[0]!=m[i]){
				continue;
			}
			
			bool f;
			int ox1,oy1,ox2,oy2;
			
			for(int k=0;k<4;k++){
				for(int j=0;j<m[0];j++){
					p[0][j]*=P(0,1);
				}
			
			f=true;
			ox1=p[0][0].real(); oy1=p[0][0].imag();
			ox2=p[i][0].real(); oy2=p[i][0].imag();
			for(int j=0;j<m[0];j++){
				if(p[0][j].real()-ox1!=p[i][j].real()-ox2){f=false; break;}
				if(p[0][j].imag()-oy1!=p[i][j].imag()-oy2){f=false; break;}
			}
			if(f){
				cout<<i<<endl;
				break;
			}
			
			f=true;
			ox1=p[0][m[0]-1].real(); oy1=p[0][m[0]-1].imag();
			ox2=p[i][0].real(); oy2=p[i][0].imag();
			for(int j=0;j<m[0];j++){
				if(p[0][m[0]-1-j].real()-ox1!=p[i][j].real()-ox2){f=false; break;}
				if(p[0][m[0]-1-j].imag()-oy1!=p[i][j].imag()-oy2){f=false; break;}
			}
			if(f){
				cout<<i<<endl;
				break;}
			}
		}
	cout<<"+++++"<<endl;
	}
	
}