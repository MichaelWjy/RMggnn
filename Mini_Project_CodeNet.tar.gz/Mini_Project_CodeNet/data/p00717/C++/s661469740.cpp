#include <iostream>
#include <fstream>
#include <cstdio>
#include <cmath>
#include <vector>
#include <cstring>
#include <string>
#include <set>
#include <map>
#include <stack>
#include <queue>
#include <algorithm>
using namespace std;
 
#define REP(i,n) for(int i=0; i<n; ++i)
#define FOR(i,a,b) for(int i=a; i<=b; ++i)
#define FORR(i,a,b) for (int i=a; i>=b; --i)
#define pi M_PI
 
typedef long long ll;
typedef vector<int> VI;
typedef vector<ll> VL;
typedef vector<VI> VVI;
typedef pair<int,int> P;
typedef pair<ll,ll> PL;

int main() {
    int n;
    while (cin >> n && n){
        vector<vector<P> > l(n+2);
        REP(i,n+1){
            int m;
            cin >> m;
            l[i].resize(m-1);
            VI x(m), y(m);
            REP(j,m) cin >> x[j] >> y[j];
            REP(j,m-1){
                l[i][j] = make_pair(x[j+1]-x[j], y[j+1]-y[j]);
            }
        }
        REP(j,l[0].size()){
            l[n+1].push_back(l[0][l[0].size()-1-j]);
            l[n+1][j].first *= -1;
            l[n+1][j].second *= -1;
        }
        REP(i,n+2){
            int x = l[i][0].first, y = l[i][0].second;
            if (x < 0){
                REP(j,l[i].size()){
                    l[i][j].first *= -1;
                    l[i][j].second *= -1;
                }
            }else if (y > 0){
                REP(j,l[i].size()){
                    swap(l[i][j].first, l[i][j].second);
                    l[i][j].second *= -1;
                }
            }else if (y < 0){
                REP(j,l[i].size()){
                    swap(l[i][j].first, l[i][j].second);
                    l[i][j].first *= -1;
                }
            }
        }
        FOR(i,1,n){
            if (l[0] == l[i] || l[n+1] == l[i]) cout << i << endl;
        }
        cout << "+++++" << endl;
    }
    return 0;
}