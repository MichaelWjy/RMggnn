#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

typedef vector<pair<int, int> > VP;

int main(void) {
    while(1) {
        int n;
        cin >> n;
        if (n == 0) {
            break;
        }
        // make base
        int m;
        cin >> m;
        VP base(m);
        VP base2(m);
        VP base3(m);
        VP base4(m);
        for (int j = 0; j < m; j++) {
            int first;
            int second;
            cin >> first >> second;
            base[j] = make_pair(first, second);
        }
        int a = base[0].first;
        int b = base[0].second;
        for (int j = 0; j < m; j++) {
            base[j].first -= a;
            base[j].second -= b;
        }

        for (int j = 0; j < m; j++) {
            base2[j] = make_pair(-base[j].second, base[j].first);
            base3[j] = make_pair(-base[j].first, -base[j].second);
            base4[j] = make_pair(base[j].second, -base[j].first);
        }

        for (int i = 0; i < n; i++) {
            int temp_m;
            cin >> temp_m;
            VP chal(m);
            VP chal2(m);
            for (int j = 0; j < m; j++) {
                int first;
                int second;
                cin >> first >> second;
                chal[j] = make_pair(first, second);
                chal2[m - 1 - j] = make_pair(first, second);
            }
            if (temp_m != m) {
                continue;
            }
            int a2 = chal[0].first;
            int b2 = chal[0].second;
            for (int j = 0; j < m; j++) {
                chal[j].first -= a2;
                chal[j].second -= b2;
            }
            int a3 = chal2[0].first;
            int b3 = chal2[0].second;
            for (int j = 0; j < m; j++) {
                chal2[j].first -= a3;
                chal2[j].second -= b3;
            }
            bool st1 = true;
            bool st2 = true;
            bool st3 = true;
            bool st4 = true;
            bool st12 = true;
            bool st22 = true;
            bool st32 = true;
            bool st42 = true;
            for (int j = 0; j < m; j++) {
                if (!(chal[j].first == base[j].first && chal[j].second == base[j].second)) {
                    st1 = false;
                }
                if (!(chal[j].first == base2[j].first && chal[j].second == base2[j].second)) {
                    st2 = false;
                }
                if (!(chal[j].first == base3[j].first && chal[j].second == base3[j].second)) {
                    st3 = false;
                }
                if (!(chal[j].first == base4[j].first && chal[j].second == base4[j].second)) {
                    st4 = false;
                }
                if (!(chal2[j].first == base[j].first && chal2[j].second == base[j].second)) {
                    st12 = false;
                }
                if (!(chal2[j].first == base2[j].first && chal2[j].second == base2[j].second)) {
                    st22 = false;
                }
                if (!(chal2[j].first == base3[j].first && chal2[j].second == base3[j].second)) {
                    st32 = false;
                }
                if (!(chal2[j].first == base4[j].first && chal2[j].second == base4[j].second)) {
                    st42 = false;
                }
            }
            if (st1 == true || st2 == true || st3 == true || st4 == true || st12 == true || st22 == true || st32 == true || st42 == true) {
                cout << i + 1 << endl;
            }
        }
        cout << "+++++" << endl;
    }

    return 0;
}