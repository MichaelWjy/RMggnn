#include<iostream>
#include<string>
#include<algorithm>
#include<vector>
#include<iomanip>
#include<math.h>
#include<complex>
#include<queue>
#include<deque>
#include<stack>
#include<map>
#include<set>
#include<bitset>
#include<functional>
#include<assert.h>
#include<numeric>
using namespace std;
#define REP(i,m,n) for(int i=(int)(m) ; i < (int) (n) ; ++i )
#define rep(i,n) REP(i,0,n)
using ll = long long;
const int inf=1e9+7;
const ll longinf=1LL<<60 ;
const ll mod=1e9+7 ;


vector<pair<int,int>> encode(){
    int m;
    cin>>m;
    int x[m],y[m];
    rep(i,m){
        cin>>x[i]>>y[i];
    }
    vector<pair<int,int>> ret;
    rep(i,m-1){
        int d=abs(x[i+1]-x[i])+abs(y[i+1]-y[i]);
        int c=0;
        if(x[i]<x[i+1])c=0;
        if(x[i+1]<x[i])c=2;
        if(y[i]<y[i+1])c=1;
        if(y[i]>y[i+1])c=3;
        ret.push_back({d,c});
    }
    return ret;
}
bool check(vector<pair<int,int>>& v,vector<pair<int,int>>& w){
    int n=v.size(),m=w.size();
    if(n!=m)return false;
    rep(i,n)if(v[i].first!=w[i].first)return false;
    int diff=(v[0].second-w[0].second+4)%4;
    rep(i,n){
        if(((v[i].second-w[i].second+4)%4)!=diff)return false;
    }
    return true;
}
int solve(int n){
    vector<vector<pair<int,int>>> v(n+1);
    rep(i,n+1)v[i]=encode();
    rep(i,n){
        if(check(v[0],v[i+1]))cout<<i+1<<endl;
        else {
            reverse(v[i+1].begin(),v[i+1].end());
            if(check(v[0],v[i+1]))cout<<i+1<<endl;
        }
    }
    cout<<"+++++"<<endl;
    return 0;
}


int main(){
    int n;
    while(cin>>n,n!=0)solve(n);
    return 0;
}
