#include <iostream>
#define N 50
#define M 10
using namespace std;

class Point{
public:
  int x;
  int y;
};

main(){
  int n, sm;
  Point moto[2][M];
  Point motolen[2][M];
  Point in[N][M];
  Point inlen[N][M];
  int m[N];

  while(1){
    cin >> n;
    if(n==0) break;

    cin >> sm;
    for(int i=0;i<sm;i++){
      cin >> moto[0][i].x >> moto[0][i].y;
    }

    for(int i=0;i<sm;i++){
      moto[1][i].x=moto[0][sm-i-1].x;
      moto[1][i].y=moto[0][sm-i-1].y;
    }

    for(int i=0;i<n;i++){
      cin >> m[i];
      for(int j=0;j<m[i];j++){
        cin >> in[i][j].x >> in[i][j].y;
      }
    }

    for(int i=0;i<sm-1;i++){
      motolen[0][i].x=moto[0][i+1].x-moto[0][i].x;
      motolen[0][i].y=moto[0][i+1].y-moto[0][i].y;
      motolen[1][i].x=moto[1][i+1].x-moto[1][i].x;
      motolen[1][i].y=moto[1][i+1].y-moto[1][i].y;
    }

    for(int i=0;i<n;i++){
      for(int j=0;j<m[i]-1;j++){
        inlen[i][j].x=in[i][j+1].x-in[i][j].x;
        inlen[i][j].y=in[i][j+1].y-in[i][j].y;
      }
    }

    for(int i=0;i<n;i++){
      if(sm!=m[i]) continue;
      bool flag1=true;
      bool flag2=true;
      for(int j=0;j<sm-1;j++){
        if(motolen[0][j].x!=inlen[i][j].x || motolen[0][j].y!=inlen[i][j].y){
          flag1=false;
        }
        if(motolen[1][j].x!=inlen[i][j].x || motolen[1][j].y!=inlen[i][j].y){
          flag2=false;
        }
      }
      if(flag1 || flag2){
        printf("%d\n", i+1);
        continue;
      }
      flag1=flag2=true;
      for(int j=0;j<sm-1;j++){
        if((motolen[0][j].x*-1)!=inlen[i][j].x || (motolen[0][j].y*-1)!=inlen[i][j].y){
          flag1=false;
        }
        if((motolen[1][j].x*-1)!=inlen[i][j].x || (motolen[1][j].y*-1)!=inlen[i][j].y){
          flag2=false;
        }
      }

      if(flag1 || flag2){
        printf("%d\n", i+1);
        continue;
      }

      flag1=flag2=true;
      for(int j=0;j<sm-1;j++){
        if(motolen[0][j].y!=inlen[i][j].x || (motolen[0][j].x*-1)!=inlen[i][j].y){
          flag1=false;
        }
        if(motolen[1][j].y!=inlen[i][j].x || (motolen[1][j].x*-1)!=inlen[i][j].y){
          flag2=false;
        }
      }

      if(flag1 || flag2){
        printf("%d\n", i+1);
        continue;
      }

      flag1=flag2=true;
      for(int j=0;j<sm-1;j++){
        if((motolen[0][j].y*-1)!=inlen[i][j].x || motolen[0][j].x!=inlen[i][j].y){
          flag1=false;
        }
        if((motolen[1][j].y*-1)!=inlen[i][j].x || motolen[1][j].x!=inlen[i][j].y){
          flag2=false;
        }
      }



      if(flag1 || flag2){
        printf("%d\n", i+1);
      }
    }


    printf("+++++\n");
  }
  return 0;
}