// I SELL YOU...! 
#include<iostream>
#include<vector>
#include<algorithm>
#include<functional>
#include<queue>
#include<chrono>
#include<iomanip>
#include<map>
#include<set>
using namespace std;
using ll = long long;
using P = pair<ll,ll>;
void init_io(){
  cin.tie(0);
  ios::sync_with_stdio(false);
  cout << setprecision(10);
}
ll cosv[] = {1,0,-1,0},sinv[]={0,1,0,-1};
void spin(ll &x,ll &y,ll rec){
  ll tx = x,ty = y;
  x = tx*cosv[rec] - ty*sinv[rec];
  y = tx*sinv[rec] + ty*cosv[rec];
}
ll dec_type(ll x0,ll y0,ll x1,ll y1){
  ll res;
  if(x0==x1){
    if(y0<y1) res = 0;
    else res = 2;
  }else{
    if(x0<x1) res = 1;
    else res = 3;
  }
  return res;
}
void solve(){
  ll n,tx,ty;
  cin >> n;
  if(n==0) return;
  bool ans[n+1];
  fill(ans,ans+n+1,false);
  vector<ll> m(n+1),x[n+1],y[n+1];
  for(int i=0;i<=n;i++){
    cin >> m[i];
    for(int j=0;j<m[i];j++){
      cin >> tx >> ty;
      x[i].push_back(tx);
      y[i].push_back(ty);
    }
  }
  for(int i=0;i<=n;i++){
    tx = x[i][0];
    ty = y[i][0];
    for(int j=0;j<m[i];j++){
      x[i][j] -= tx;
      y[i][j] -= ty;
    }
  }
  for(int i=0;i<=n;i++){
    ll rec = dec_type(x[i][0],y[i][0],x[i][1],y[i][1]);
    for(int j=0;j<m[i];j++){
      spin(x[i][j],y[i][j],rec);
    }
  }
  for(int i=1;i<=n;i++){
    if(m[i]==m[0]){
      bool can = true;
      for(int j=0;j<m[i];j++){
        if((x[i][j] != x[0][j])||(y[i][j]!=y[0][j])){
          can = false;
          break;
        }
      }
      if(can){
        ans[i] = true;
      }
    }
  }
  for(int i=1;i<=n;i++){
    reverse(x[i].begin(),x[i].end());
    reverse(y[i].begin(),y[i].end());
  }
  for(int i=0;i<=n;i++){
    tx = x[i][0];
    ty = y[i][0];
    for(int j=0;j<m[i];j++){
      x[i][j] -= tx;
      y[i][j] -= ty;
    }
  }
  for(int i=0;i<=n;i++){
    ll rec = dec_type(x[i][0],y[i][0],x[i][1],y[i][1]);
    for(int j=0;j<m[i];j++){
      spin(x[i][j],y[i][j],rec);
    }
  }
  for(int i=1;i<=n;i++){
    if(m[i]==m[0]){
      bool can = true;
      for(int j=0;j<m[i];j++){
        if((x[i][j] != x[0][j])||(y[i][j]!=y[0][j])){
          can = false;
          break;
        }
      }
      if(can){
        ans[i] = true;
      }
    }
  }
  for(int i=1;i<=n;i++){
    if(ans[i]) cout << i << endl;
  }
  cout <<"+++++"<<endl;
  solve();
}
signed main(){
  init_io();
  solve();
}

