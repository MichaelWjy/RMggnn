#include <iostream>
#include <cmath>
using namespace std;

class Point{
public:
  double x, y;
  Point(double x=0, double y=0) : x(x), y(y) {}
  Point operator -(Point p) {
    return Point(x-p.x, y-p.y);
  }
};

typedef Point Vector;

double cross(Vector v1, Vector v2) {
  return v1.x*v2.y-v1.y*v2.x;
}

int getL(Point p1, Point p2) {
  return int(abs(p1.x-p2.x) + abs(p1.y-p2.y));
}

bool isEqualOre(double c1[], int l1[], double c2[], int l2[], int cnt) {
  bool flag = true;
  for(int i = 0; i < cnt-2; i++) {
    if(c1[i] != c2[i]) {
      flag = false;
      break;
    }
  }
  if(flag) {
    flag = true;
    for(int i = 0; i < cnt-1; i++) {
      if(l1[i] != l2[i]) {
	flag = false;
	break;
      }
    }
    if(flag) return true;
  }

  for(int i = 0; i < cnt-2; i++) {
    if(c1[i] != -c2[cnt-2-i-1]) {
      return false;
    }
  }
  for(int i = 0; i < cnt-1; i++) {
    if(l1[i] != l2[cnt-1-i-1]) {
      return false;
    }
  }
  return true;
}

main() {
  while(1) {
    int n;
    cin >> n;
    if(n == 0) break;
    int moto_m;
    double moto_cro[10];
    int moto_l[10];
    for(int i = 0; i < n+1; i++) {
      int m;
      double cro[10];
      int l[10];
      cin >> m;
      for(int j = 0; j < m; j++) {
	static Point bfrbfr, bfr;
	Point p;
	cin >> p.x >> p.y;
	if(j >= 1) {
	  if(i == 0)  moto_l[j-1] = getL(p, bfr);
	  else        l[j-1] = getL(p, bfr);
	}
	if(j >= 2) {
	  double tmp = cross(bfr-bfrbfr, p-bfr);
	  //cout << tmp << endl;
	  if(i == 0) moto_cro[j-2] = tmp;
	  else       cro[j-2] = tmp;
	}
	bfrbfr = bfr;
	bfr = p;
      }
      //cout << endl;
      if(i == 0) {
	moto_m = m;
      } else {
	if(moto_m == m && isEqualOre(moto_cro, moto_l, cro, l, m)) cout << i << endl;
      }
    }
    cout << "+++++" << endl;
  }
}