#include <stdio.h>
#include <cctype>
#include <limits.h>
#include <math.h>
#include <complex>
#include <bitset>
#include <vector>
#include <map>
#include <set>
#include <stack>
#include <queue>
#include <cstring>
#include <string>
#include <sstream>
#include <algorithm>
#include <iomanip>
#include <iostream>

#define VARIABLE(x) cerr << #x << "=" << x << endl
#define BINARY(x) static_cast<bitset<16> >(x)
#define rep(i,n) for(int i=0;i<(int)(n);i++)
#define REP(i,m,n) for (int i=m;i<(int)(n);i++)
#define if_range(x, y, w, h) if (0<=(int)(x) && (int)(x)<(int)(w) && 0<=(int)(y) && (int)(y)<(int)(h))
#define ALL(a) (a).begin(),(a).end()
const int INF = 1e9;
int dx[4]={0, 1, 0, -1}, dy[4]={-1, 0, 1, 0};
using namespace std;
typedef long long ll;
//typedef pair<int, int> P;

/* struct P {
	int x, y, n;
	P(int n, int x, int y):n(n), x(x), y(y){}
	P(){}
}; */


/** 幾何ライブラリ **/
#include <complex>

#define X real()
#define Y imag()

const double EPS = 1e-11;
const double PI = acos(-1.0);

typedef double D;
typedef complex<D> P; // Point


/** Problem1136 : Polygonal Line Search **/
typedef vector<P> PS;

bool eq(PS a, PS b)
{
	if (a.size() != b.size()) return false;
	
	bool res1=true, res2=true;
	
	for (int i=0; i<a.size(); i++) {
		if (a[i] != b[i])
			res1 = false;
	}
	
	reverse(ALL(b));
	
	for (int i=0; i<a.size(); i++) {
		if (a[i] != b[i])
			res2 = false;
	}
	
	return res1 | res2;
}


int main()
{
	int N;
	while (cin>>N, N) {
		vector<PS> poly(N+1);
		
		rep(i, N+1) {
			int M; cin>>M;
			rep(j, M) {
				P p; cin>>p.X>>p.Y;
				poly[i].push_back(p);
			}
		}
		
		PS target;
		for (int i=1; i<poly[0].size(); i++) {
			target.push_back(poly[0][i]-poly[0][i-1]);
		}
		
		for (int i=1; i<=N; i++) {
			PS tmp;
			for (int j=1; j<poly[i].size(); j++) {
				tmp.push_back(poly[i][j]-poly[i][j-1]);
			}
			
			rep(j, 4) {
				if (eq(target, tmp)) {
					cout << i << endl;
					goto next;
				}
				
				rep(k, tmp.size()) {
					tmp[k] *= P(0, 1);
				}
			}
					
			next:;
		}
		cout << "+++++" << endl;
	}
}