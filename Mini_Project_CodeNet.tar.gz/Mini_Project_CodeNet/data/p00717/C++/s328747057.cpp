
#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cmath>
#include<cctype>
#include<math.h>
#include<string>
#include<string.h>
#include<stack>
#include<queue>
#include<vector>
#include<utility>
#include<set>
#include<map>
#include<stdlib.h>
#include<iomanip>


using namespace std;

#define ll long long
#define ld long double
#define INF 1e9
#define MOD 1000000007
#define rep(i,n) for(i=0;i<(n);i++)
#define loop(i,a,n) for(i=a;i<(n);i++)
#define all(in) in.begin(),in.end()
#define shosu(x) fixed<<setprecision(x)

typedef vector<int> vi;
typedef vector<string> vs;
typedef pair<int,int> pii;
typedef vector<pii> G;


void turn(G &g){
  for(int i = 1; i < g.size(); i++){
    int a = -g[i].second;
    int b = g[i].first;
    g[i].first = a;
    g[i].second = b;
  }
}

bool same(const G &g1, const G &g2){
  int n = g1.size();
  if(g2.size() != n) return false;
  int i;
  bool c1 = true, c2 = true;
  rep(i,n)
    if(g1[i].first - g2[i].first != g1[0].first - g2[0].first ||
      g1[i].second - g2[i].second != g1[0].second - g2[0].second)
      c1 = false;

//if(c1) cout<<"c1"<<endl;

  G v(n);
  rep(i,n)
    v[i] = g2[n-1-i];

    rep(i,n)
      if(g1[i].first - v[i].first != g1[0].first - v[0].first ||
        g1[i].second - v[i].second != g1[0].second - v[0].second)
        c2 = false;

//if(c2) cout<<"c2"<<endl;

  return c1 || c2;
}

int main(void) {
  int i,j;
  int n;
  while(cin>>n,n){

    vector<G> v(n+1);

    rep(i,n+1){
      int m;
      cin >> m;
      rep(j,m){
        int x,y;
        cin>>x>>y;
        v[i].push_back(pii(x,y));
      }
      loop(j,1,v[i].size()){
        v[i][j].first -= v[i][0].first;
        v[i][j].second -= v[i][0].second;
      }
      v[i][0].first = 0;
      v[i][0].second = 0;
    }
/*
cout << endl;
rep(i,n+1){
  rep(j,v[i].size())
  cout << v[i][j].first << " " << v[i][j].second << endl;
  cout << endl;
}
*/

    loop(i,1,n+1){
      bool c = false;
      rep(j,4){
        if(same(v[0],v[i])) c = true;
        turn(v[i]);
/*
        cout << "! " << i << " " << j << endl;
        int k;
        rep(k,v[i].size())
          cout << v[i][k].first << " " << v[i][k].second << endl;
        cout << endl;
*/
      }
      if(c) cout << i << endl;
    }

  cout << "+++++" << endl;
  }
}

