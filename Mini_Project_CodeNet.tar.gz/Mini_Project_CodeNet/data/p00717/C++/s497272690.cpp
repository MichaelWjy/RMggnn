#include <iostream>
#include <vector>
using namespace std;

int main() {

  while( true ) {

    long long int n;
    cin >> n;
    if ( n == 0 ) break;

    pair< vector< long long int >, vector< long long int > > p;

    for ( long long int i = 0; i <= n; i++ ) {

      long long int m;
      cin >> m;

      vector< long long int > x, y;

      for ( long long int re = 0; re < 2; re++ ) {

	if ( re == 0 ) {
	  for ( long long int j = 0; j < m; j++ ) {
	    long long int in_x, in_y;
	    cin >> in_x >> in_y;
	    if ( j > 0 ) {
	      in_x -= x[0];
	      in_y -= y[0];
	    }
	    x.push_back( in_x );
	    y.push_back( in_y );
	  }
	}else {
	  vector< long long int > z;
	  for ( long long int a = 0; a < m; a++ ) {
	    z.push_back( x[m-a-1] - x[m-1] );
	  }
	  x.swap( z );
	  z.clear();
	  for ( long long int a = 0; a < m; a++ ) {
	    z.push_back( y[m-a-1] - y[m-1] );
	  }
	  y.swap( z );
	}
	x[0] = 0;
	y[0] = 0;
      if ( y[1] > 0 ) {
	for ( long long int j = 1; j < m; j++ ) {
	  long long int k = x[j];
	  x[j] = y[j];
	  y[j] = -k;
	}
      }
      if ( y[1] < 0 ) {
	for ( long long int j = 1; j < m; j++ ) {
	  long long int k = x[j];
	  x[j] = -y[j];
	  y[j] = k;
	}
      }
      if ( x[1] < 0 ) {
	for ( long long int j = 1; j < m; j++ ) {
	  x[j] = -x[j];
	  y[j] = -y[j];
	}
      }
      /*
      cout << " i = " << i << endl;
      for ( long long int j = 0; j < m; j++ ) {
	cout << x[j] << " " << y[j] << endl;
      }
      */
      if ( i == 0 ) {
	p = make_pair( x, y );
      }else {
	if ( x == p.first && y == p.second ) {
	  cout << i << endl;
	  break;
	}
      }
      }
    }

    cout << "+++++" << endl;

  }

  return 0;

}