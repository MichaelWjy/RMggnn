#include<bits/stdc++.h>
using namespace std;
#define reps(i,j,k) for(int i=j;i<k;i++)
#define rep(i,j) reps(i,0,j)
#define pi pair<int,int>
#define mp make_pair
#define fr first
#define sc second
pi ans[10];
pi mt_cul(int mt[2][2],pi vc,int c){
	rep(i,c){
		int buf=vc.fr;
		vc.fr=mt[0][0]*vc.fr+mt[0][1]*vc.sc;
		vc.sc=mt[1][0]*buf+mt[1][1]*vc.sc;
	}
	return vc;
}
int mt[2][2]={{0,-1},{1,0}};
int main(){
	int n;
	while(cin>>n,n){
		int ms;
		cin>>ms;
		int asx,asy;
		cin>>asx>>asy;
		rep(i,ms-1){
			int a,b;
			cin>>a>>b;
			ans[i]=mp(a-asx,b-asy);
		}
		int c=0;
		if(ans[0].sc>0){
			c=3;
		}
		if(ans[0].sc<0){
			c=1;	
		}
		if(ans[0].fr<0){
			c=2;
		}
		rep(i,ms-1){
			ans[i]=mt_cul(mt,ans[i],c);
		}
		reps(q,1,n+1){
			bool flg=true;
			pi buf[15];
			pi bufr[15];
			pi bufe[15];
			int m;
			cin>>m;
			int sx,sy;
			cin>>sx>>sy;
			rep(i,m-1){
				int a,b;
				cin>>a>>b;
				bufe[i]=mp(a,b);
			}
			rep(i,m-1){
				buf[i]=mp(bufe[i].fr-sx,bufe[i].sc-sy);
			}
			int ct=0;
			if(buf[0].sc>0){
				ct=3;
			}
			if(buf[0].sc<0){
				ct=1;
			}
			if(buf[0].fr<0){
				ct=2;
			}
			rep(i,m-1){
				buf[i]=mt_cul(mt,buf[i],ct);
				if(buf[i].fr!=ans[i].fr||buf[i].sc!=ans[i].sc){
					flg=false;
				}
			}
			if(flg){
				cout<<q<<endl;
				continue;
			}
			flg=true;
/*
			rep(i,m-1){
				bufr[i]=mp(bufe[m-i-2].fr-bufe[m-1].fr,bufe[m-i-2].sc-bufe[m-1].sc);
			}
			bufr[m-1]=mp(sx-bufe[m-1].fr,sy-bufe[m-1].sc);
			rep(i,m)cout<<bufr[i].fr<<" "<<bufr[i].sc<<endl;
*/

			int rsx = bufe[m-2].fr;
			int rsy = bufe[m-2].sc;
			
			bufr[m-2].fr = sx-rsx;
			bufr[m-2].sc = sy-rsy;

			rep(i,m-2){
				bufr[i].fr = bufe[m-3-i].fr-rsx;
				bufr[i].sc = bufe[m-3-i].sc-rsy;	
			}
			//printf("##%d##\n",q);
			/*
			rep(i,m-1){
				cout << bufr[i].fr << " " << bufr[i].sc << "\n";
			}
			*/
			ct=0;
			if(bufr[0].sc>0){
				ct=3;
			}
			if(bufr[0].sc<0){
				ct=1;
			}
			if(bufr[0].fr<0){
				ct=2;
			}
			rep(i,m-1){
				bufr[i]=mt_cul(mt,bufr[i],ct);
				if(bufr[i].fr!=ans[i].fr||bufr[i].sc!=ans[i].sc){
					flg=false;
				}
			}
			if(flg)cout<<q<<endl;
		}
		cout<<"+++++"<<endl;
	}
	return 0;
}