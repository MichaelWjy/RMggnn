#include<iostream>
#include<algorithm>
#include<vector>
using namespace std;

bool is_same_shape(vector<int> x_1, vector<int> y_1, vector<int> x_2, vector<int> y_2) {
    if (x_1.size() != x_2.size()) return false;
    for (int cnt = 0; cnt < 4; cnt++) {
        bool is_ok = true;
        for (int i = 0; i < x_1.size() - 1; i++) {
            if (x_1[i] - x_1[i + 1] != x_2[i] - x_2[i + 1]) {
                is_ok = false;
                break;
            }
            if (y_1[i] - y_1[i + 1] != y_2[i] - y_2[i + 1]) {
                is_ok = false;
                break;
            }
        }
        if (is_ok) return true;
        // rotate
        for (int i = 0; i < x_2.size(); i++) {
            int x = x_2[i], y = y_2[i];
            x_2[i] = -y;
            y_2[i] = x;
        }
    }
    return false;
}

void solve(int n) {
    int m;
    cin >> m;
    vector<int> origin_x(m), origin_y(m);
    for (int i = 0; i < m; i++) cin >> origin_x[i] >> origin_y[i];
    vector<int> ans;
    for (int i = 0; i < n; i++) {
        cin >> m;
        vector<int> now_x(m), now_y(m);
        for (int j = 0; j < m; j++) cin >> now_x[j] >> now_y[j];
        if (is_same_shape(origin_x, origin_y, now_x, now_y)) {
            ans.push_back(i + 1);
            continue;
        }
        reverse(now_x.begin(), now_x.end());
        reverse(now_y.begin(), now_y.end());
        if (is_same_shape(origin_x, origin_y, now_x, now_y)) {
            ans.push_back(i + 1);
        }
    }
    for (int i = 0; i < ans.size(); i++) cout << ans[i] << endl;
}

int main() {
    cin.tie(0);
    ios::sync_with_stdio(false);
    int N;
    while (true) {
        cin >> N;
        if (N == 0) break;
        solve(N);
        cout << "+++++" << endl;
    }
    return 0;
}
