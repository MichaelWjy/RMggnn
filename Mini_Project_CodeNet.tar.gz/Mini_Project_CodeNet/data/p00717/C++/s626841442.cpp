// clang-format off
#include <bits/stdc++.h>
using namespace std;
#define int long long
#define main signed main()
#define loop(i, a, n) for (int i = (a); i < (n); i++)
#define rep(i, n) loop(i, 0, n)
#define all(v) (v).begin(), (v).end()
#define rall(v) (v).rbegin(), (v).rend()
#define prec(n) fixed << setprecision(n)
constexpr int INF = sizeof(int) == sizeof(long long) ? 1000000000000000000LL : 1000000000;
constexpr int MOD = 1000000007;
constexpr double PI = 3.14159265358979;
template<typename A, typename B> bool cmin(A &a, const B &b) { return a > b ? (a = b, true) : false; }
template<typename A, typename B> bool cmax(A &a, const B &b) { return a < b ? (a = b, true) : false; }
bool odd(const int &n) { return n & 1; }
bool even(const int &n) { return ~n & 1; }
template<typename T = int> T in() { T x; cin >> x; return x; }
template<typename T = int> T in(T &&x) { T z(forward<T>(x)); cin >> z; return z; }
template<typename T> istream &operator>>(istream &is, vector<T> &v) { for (T &x : v) is >> x; return is; }
template<typename A, typename B> istream &operator>>(istream &is, pair<A, B> &p) { return is >> p.first >> p.second; }
template<typename T> ostream &operator<<(ostream &os, const vector<vector<T>> &v) { int n = v.size(); rep(i, n) os << v[i] << (i == n - 1 ? "" : "\n"); return os; }
template<typename T> ostream &operator<<(ostream &os, const vector<T> &v) { int n = v.size(); rep(i, n) os << v[i] << (i == n - 1 ? "" : " "); return os; }
template<typename A, typename B> ostream &operator<<(ostream &os, const pair<A, B> &p) { return os << p.first << ' ' << p.second; }
template<typename Head, typename Value> auto vectors(const Head &head, const Value &v) { return vector<Value>(head, v); }
template<typename Head, typename... Tail> auto vectors(Head x, Tail... tail) { auto inner = vectors(tail...); return vector<decltype(inner)>(x, inner); }
// clang-format on

main {
  while (true) {
    int n;
    cin >> n;
    if (n == 0) break;
    vector<vector<pair<int, int>>> l(n + 1);
    rep(i, n + 1) {
      int m;
      cin >> m;
      rep(j, m) {
        int x, y;
        cin >> x >> y;
        l[i].emplace_back(x, y);
      }
    }
    auto f = [&](int t) {
      if (l[0].size() != l[t].size()) return false;
      rep(i, 2) {
        rep(j, 4) {
          int dx = l[0][0].first - l[t][0].first, dy = l[0][0].second - l[t][0].second;
          bool f = true;
          rep(i, l[0].size()) {
            f &= l[0][i].first == l[t][i].first + dx;
            f &= l[0][i].second == l[t][i].second + dy;
          }
          if (f) return true;
          rep(k, l[t].size()) {
            swap(l[t][k].first, l[t][k].second);
            l[t][k].first *= -1;
          }
        }
        reverse(all(l[t]));
      }
      return false;
    };
    loop(i, 1, n + 1) if (f(i)) cout << i << endl;
    cout << "+++++" << endl;
  }
}

