#include<iostream>
#include<vector>
#include<algorithm>
#define U 0
#define R 1
#define D 2
#define L 3
using namespace std;
int direct(int prex,int prey,int x,int y)
{
	if (prex < x)
	{
		return R;
	}
	else if (prex > x)
	{
		return L;
	}
	else if (prey < y)
	{
		return U;
	}
	else
	{
		return D;
	}
}

int diff(int direct,int prex,int prey,int x,int y)
{
	if (direct == U)
	{
		return y - prey;
	}
	else if (direct == R)
	{
		return x - prex;
	}
	else if (direct == D)
	{
		return prey - y;
	}
	else
	{
		return prex - x;
	}
}
int main()
{
	int n;
	while (cin >> n && n != 0)
	{
		vector<int> ans(10);
		int a[10], b[10];
		int c = 0;
		for (int i = 0; i <= n; i++)
		{
			int m;
			cin >> m;
			if (i == 0)
			{
				c = m;
			}
			if (c != m)continue;

			int c[10], d[10];
			int prex = 0;
			int prey = 0;
			for (int j = 0; j < m; j++)
			{
				int x, y;
				cin >> x >> y;
				if (i == 0)
				{
					if (j == 0)
					{
						prex = x;
						prey = y;
					}
					else
					{
						a[j - 1] = direct(prex, prey, x, y);
						b[j - 1] = diff(a[j - 1],prex,prey,x,y);
						prex = x;
						prey = y;
					}
				}
				else
				{
					if (j == 0)
					{
						prex = x;
						prey = y;
					}
					else
					{
						c[j - 1] = direct(prex, prey, x, y);
						d[j - 1] = diff(c[j - 1],prex,prey,x, y);
						prex = x;
						prey = y;
					}
				}
			}
			if (i == 0)continue;

			bool ok = false;
			for (int k = 0; k < 4; k++)
			{
				bool ook = true;
				for (int l = 0; l < m - 1; l++)
				{
					if (a[l] == (c[l] + k) % 4 && b[l] == d[l])continue;
					ook = false;
					break;
				}
				if (ook)
				{
					ok = true;
					break;
				}

				ook = true;
				for (int l = 0; l < m - 1; l++)
				{
					if (a[(m - 2 - l)] == (c[l] + k) % 4 && b[(m - 2 - l)] == d[l])continue;
					ook = false;
					break;
				}

				if (ook)
				{
					ok = true;
					break;
				}
			}

			if (ok)
			{
				ans.push_back(i);
			}
		}
		for (int i = 0; i < ans.size(); i++)
		{
			cout << ans[i] << endl;
		}
		cout << "+++++" << endl;
	}
	return 0;
}