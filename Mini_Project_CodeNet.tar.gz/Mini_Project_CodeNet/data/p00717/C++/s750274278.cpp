#include <iostream>
#include <vector>
 
int r[4][2] ={{1,0},{0,1},{-1,0},{0,-1}};//90度毎の回転行列用
 
using namespace std;
 
int main(){
    while(1){
        int n; cin>>n;
        if(!n) break;
 
        int m0; cin>>m0;
        vector<pair<int, int> > t(m0);//探す元となる折れ線
        for(int j=0; j<m0; j++){
            int x, y; cin>>x>>y;
            t[j] = make_pair(x, y);
        }
 
        for(int i=1; i<=n; i++){
            int m; cin>>m;
            vector<pair<int, int> > v(m);
            for(int j=0; j<m; j++){
                int x, y; cin>>x>>y;
                v[j] = make_pair(x, y);
            }
            if(m0 != m) continue;
 
            for(int k=0; k<4; k++){
                int vsin=r[k][0], vcos=r[k][1];
                vector<pair<int, int> > tmp(m);
                for(int j=0; j<m; j++){
                    tmp[j].first  =v[j].first*vcos - v[j].second*vsin;
                    tmp[j].second =v[j].first*vsin + v[j].second*vcos;
                }
 
                bool flag = true;
                int move_x = t[0].first - tmp[0].first;
                int move_y = t[0].second - tmp[0].second;
                for(int j=0; j<m; j++){
                    tmp[j].first += move_x;
                    tmp[j].second += move_y;
                }
                for(int j=0; j<m; j++){
                    if(t[j].first != tmp[j].first || t[j].second != tmp[j].second){
                        flag = false;
                        break;
                    }
                }
                if(flag){
                    cout << i << endl;
                    break;
                }
 
                flag = true;
                move_x = t[m-1].first - tmp[0].first;
                move_y = t[m-1].second - tmp[0].second;
                for(int j=0; j<m; j++){
                    tmp[j].first += move_x;
                    tmp[j].second += move_y;
                }
                for(int j=0; j<m; j++){
                    if(t[m-j-1].first != tmp[j].first || t[m-j-1].second != tmp[j].second){
                        flag = false;
                        break;
                    }
                }
                if(flag){
                    cout << i << endl;
                    break;
                }
            }
        }
        cout <<"+++++"<< endl;
    }
    return 0;
}
