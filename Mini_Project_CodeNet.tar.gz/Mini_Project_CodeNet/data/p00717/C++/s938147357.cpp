#include "bits/stdc++.h"
using namespace std;
typedef long long ll;
typedef pair<int,int> pii;
#define rep(i,n) for(ll i=0;i<(ll)(n);i++)
#define all(a)  (a).begin(),(a).end()
#define pb push_back
#define INF 1LL<<50

void turn(vector<vector<pii> > &line , vector<pii> p){
    line.pb(p);
    vector<pii> tmp;
    rep(i,p.size()){
        tmp.pb(pii( p[i].first*-1 , p[i].second*-1 ));
    }
    line.pb(tmp);
    tmp.clear();

    
    rep(i,p.size()){
        tmp.pb(pii( p[i].second*-1 , p[i].first ));
    }
    line.pb(tmp);
    tmp.clear();

    
    rep(i,p.size()){
        tmp.pb(pii( p[i].second , p[i].first*-1 ));
    }
    line.pb(tmp);
    tmp.clear();
}


void pre(vector<vector<pii> > &line , vector<pii> p){
    int y,x;
    y=p[0].first,x=p[0].second;
    vector<pii> tmp;
    rep(i,p.size())tmp.pb(pii( p[i].first-y , p[i].second-x ));
    turn(line,tmp);

    reverse(all(p));
    y=p[0].first,x=p[0].second;
    tmp.clear();
    rep(i,p.size())tmp.pb(pii( p[i].first-y , p[i].second-x ));
    turn(line,tmp);
}

bool same(vector<pii> line,vector<pii> a){
    rep(i,a.size()){
        if(line[i].first!=a[i].first)return false;
        if(line[i].second!=a[i].second)return false;
    }
    return true;
}

bool is(vector<vector<pii> > line , int t){
    for(int i=t*8;i<t*8+8;i++){
        if(same(line[i],line[0])){
            return true;
        }
    }
    return false;
}


int main(){
    int n;
    while(cin>>n){
        if(n==0)break;
        vector<vector<pii> > line;
        rep(i,n+1){
            int m;
            cin>>m;
            vector<pii> tmp;
            rep(j,m){
                int x,y;
                cin>>x>>y;
                tmp.pb(pii(y,x));
            }
            pre(line,tmp);
        }
        
        for(int i=1;i<n+1;i++){
            if(is(line,i)){
                cout<<i<<endl;
            }
        }
        cout<<"+++++"<<endl;
    }
}