#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <cmath>
#include <complex>
#include <string>
#include <sstream>
#include <algorithm>
#include <vector>
#include <queue>
#include <stack>
#include <functional>
#include <iostream>
#include <map>
#include <set>
using namespace std;
typedef pair<int,int> P;
typedef long long ll;
typedef vector<int> vi;
typedef vector<ll> vll;
#define pu push
#define pb push_back
#define mp make_pair
#define eps 1e-9
#define INF 2000000000
#define sz(x) ((int)(x).size())
#define fi first
#define sec second
#define SORT(x) sort((x).begin(),(x).end())
#define all(x) (x).begin(),(x).end()
struct line{
    int V;
    vector<int> len,dire;
    line():V(0){}
};
int dir(int a,int b){
    if(b==0){
        if(a>0)return 0;
        else return 2;
    }else{
        if(b>0)return 1;
        else return 3;
    }
}
int n;
int m[100];
int x[100][100];
int y[100][100];
line li[100];
bool check(line l1,line l2){
    if(l1.V != l2.V)return false;
    for(int i=0;i<l1.len.size();i++){
        if(l1.len[i]!=l2.len[i])return false;
    }
    int angle = (l1.dire[0]+4-l2.dire[0])%4;
    for(int i=0;i<l1.dire.size();i++){
        if(l1.dire[i]!=(l2.dire[i]+angle)%4)return false;
    }
    return true;
}
int solve(){
    scanf("%d",&n);
    for(int i=0;i<n+2;i++){
        li[i].dire.clear();
        li[i].len.clear();
    }
    if(n==0)return 1;
    for(int i=0;i<=n;i++){
        scanf("%d",&m[i]);
        li[i].V = m[i];
        for(int j=0;j<m[i];j++){
            scanf("%d %d",&x[i][j],&y[i][j]);
        }
        for(int j=1;j<m[i];j++){
            li[i].dire.pb(dir(x[i][j]-x[i][j-1],y[i][j]-y[i][j-1]));
            li[i].len.pb(max(abs(x[i][j]-x[i][j-1]),abs(y[i][j]-y[i][j-1])));
        }
    }
    li[n+1].V=m[0];
        for(int j=m[0]-2;j>=0;j--){
            li[n+1].dire.pb(dir(x[0][j]-x[0][j+1],y[0][j]-y[0][j+1]));
            li[n+1].len.pb(max(abs(x[0][j]-x[0][j+1]),abs(y[0][j]-y[0][j+1])));
        }
    for(int i=1;i<=n;i++){
        if(check(li[0],li[i])||check(li[n+1],li[i]))printf("%d\n",i);
    }
    printf("+++++\n");
    return 0;
}
int main(){
    while(1){
        if(solve())return 0;
    }
    return 0;
}