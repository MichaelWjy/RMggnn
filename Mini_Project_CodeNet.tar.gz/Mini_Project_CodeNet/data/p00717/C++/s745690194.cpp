#include <cmath>
#include <vector>
#include <iostream>

using namespace std;

int main()
{
	int n, m, x, y;

	while (true)
	{
		cin >> n;

		if (n == 0) { break; }

		vector<vector<pair<long double, long double> > > L(n + 1);

		long double theta, theta2, x4, y4;

		for (int i = 0; i <= n; i++)
		{
			cin >> m;

			for (int j = 0; j < m; j++)
			{
				cin >> x >> y;

				L[i].push_back(make_pair(x, y));
			}

			int zx = -L[i][0].second;
			int zy = -L[i][0].first;

			for (int j = 0; j < m; j++)
			{
				L[i][j].first += zx; L[i][j].second += zy;
			}

			theta = -atan2l(L[i][1].second, L[i][1].first);

			for (int j = 1; j < m; j++)
			{
				theta2 = atan2l(L[i][j].second, L[i][j].first) + theta;

				x4 = cosl(theta2) * sqrtl(L[i][j].first * L[i][j].first + L[i][j].second * L[i][j].second);
				y4 = sinl(theta2) * sqrtl(L[i][j].first * L[i][j].first + L[i][j].second * L[i][j].second);

				L[i][j].first = x4; L[i][j].second = y4;
			}
		}

		for (int i = 1; i <= n; i++)
		{
			if (L[0] == L[i])
			{
				cout << i << endl;
			}
		}

		cout << "+++++" << endl;
	}

	return 0;
}