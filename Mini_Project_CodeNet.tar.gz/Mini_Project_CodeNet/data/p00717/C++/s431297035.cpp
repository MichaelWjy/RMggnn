#include <iostream>
#include <iomanip>
#include <cstdio>
#include <string>
#include <cstring>
#include <deque>
#include <list>
#include <queue>
#include <stack>
#include <vector>
#include <utility>
#include <algorithm>
#include <map>
#include <set>
#include <complex>
#include <cmath>
#include <limits>
#include <cfloat>
#include <climits>
#include <ctime>
#include <cassert>
#include <numeric>
#include <functional>
using namespace std;

#define rep(i,a,n) for(int (i)=(a); (i)<(n); (i)++)
#define repq(i,a,n) for(int (i)=(a); (i)<=(n); (i)++)
#define repr(i,a,n) for(int (i)=(a); (i)>=(n); (i)--)
#define int long long int

template<typename T> void chmax(T &a, T b) {a = max(a, b);}
template<typename T> void chmin(T &a, T b) {a = min(a, b);}
template<typename T> void chadd(T &a, T b) {a = a + b;}

typedef pair<int, int> pii;
typedef long long ll;

int dx[] = {0, 0, 1, -1};
int dy[] = {1, -1, 0, 0};
constexpr ll INF = 1001001001001001LL;
constexpr ll MOD = 1000000007LL;

typedef complex<int> P;

#define X real()
#define Y imag()
#define EPS (1e-10)
#define EQ(a,b) (abs((a) - (b)) < EPS)
#define EQV(a,b) ( EQ((a).X, (b).X) && EQ((a).Y, (b).Y) )
#define LE(n, m) ((n) < (m) + EPS)
#define GE(n, m) ((n) + EPS > (m))

// ?????°??? ??? ??§??????
double deg2rad(double x) {return x * M_PI / 180.0;}

// ??? a ???????????¨???????????? b ??? z ????????¢???????????¨????????????
P rotatePoint(P a, P b, double z) {
    // ?????°????????´????????????
    z = deg2rad(z);

    b -= a;
    double rx = b.X * cos(z) - b.Y * sin(z);
    double ry = b.X * sin(z) + b.Y * cos(z);
    P ret(rx, ry); ret += a;
    return ret;
}

int calcdeg(int x, int y) {
    if(x == 0) return y > 0 ? 0 : 2;
    else return x > 0 ? 1 : 3;
}

vector<P> convertLine(vector<P> v) {
    int n = v.size(), deg = 0;
    P prev = P(0, 0);
    vector<P> ret;
    ret.push_back(prev);
    rep(i,0,n-1) {
        int sx = v[i+1].X - v[i].X;
        int sy = v[i+1].Y - v[i].Y;
        // printf("sx = %lf, sy = %lf\n", sx, sy);

        if(i == 0) {
            int temp = calcdeg(sx, sy);
            deg = temp;
        }
        P aft = rotatePoint(P(0, 0), P(sx, sy), 90 * deg);
        ret.push_back(aft + prev);
        prev = aft + prev;
    }
    return ret;
}

int N, M;
signed main() {
    while(cin >> N, N) {
        vector<P> orig;
        cin >> M;
        rep(i,0,M) {
            double x, y; cin >> x >> y;
            orig.push_back(P(x, y));
        }
        orig = convertLine(orig);

        vector<int> ans;
        rep(i,0,N) {
            vector<P> ls;
            cin >> M;
            rep(j,0,M) {
                double x, y; cin >> x >> y;
                ls.push_back(P(x, y));
            }

            vector<P> temp = convertLine(ls);
            if(orig == temp) {
                ans.push_back(i+1);
                continue;
            }

            reverse(ls.begin(), ls.end());
            temp = convertLine(ls);
            if(orig == temp) {
                ans.push_back(i+1);
                continue;
            }
        }

        rep(i,0,ans.size()) cout << ans[i] << endl;
        printf("+++++\n");
    }
    return 0;
}