#include "bits/stdc++.h"

#define REP(i,n) for(ll i=0;i<n;++i)
#define RREP(i,n) for(ll i=n-1;i>=0;--i)
#define FOR(i,m,n) for(ll i=m;i<n;++i)
#define RFOR(i,m,n) for(ll i=n-1;i>=m;--i)
#define ALL(v) (v).begin(),(v).end()
#define PB(a) push_back(a)
#define UNIQUE(v) v.erase(unique(ALL(v)),v.end());
#define DUMP(v) REP(i, (v).size()) { cout << v[i]; if (i != v.size() - 1)cout << " "; else cout << endl; }
#define INF 1000000001ll
#define MOD 1000000007ll
#define EPS 1e-9

const int dx[8] = { 1,1,0,-1,-1,-1,0,1 };
const int dy[8] = { 0,1,1,1,0,-1,-1,-1 };


using namespace std;
typedef long long ll;
typedef vector<int> vi;
typedef vector<ll> vl;
typedef vector<vi> vvi;
typedef vector<vl> vvl;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
ll max(ll a, int b) { return max(a, ll(b)); }
ll max(int a, ll b) { return max(ll(a), b); }
ll min(ll a, int b) { return min(a, ll(b)); }
ll min(int a, ll b) { return min(ll(a), b); }
///(?´????????`)(?´????????`)(?´????????`)(?´????????`)(?´????????`)(?´????????`)///
int main() {
	cin.tie(0);
	ios::sync_with_stdio(false);
	while (1) {
		int n;
		cin >> n;
		if (!n) break;
		int M;
		cin >> M;
		vector<pii>X(M);
		REP(i, M)cin >> X[i].first >> X[i].second;
		REP(i, n) {
			int m;
			cin >> m;
			vector<pii> v(m);
			REP(j, m)cin >> v[j].first >> v[j].second;
			if (m != M)continue;

			int flag = 1;
			REP(k, m - 1) {
				if ((v[k + 1].first - v[k].first != X[k + 1].first - X[k].first) || (v[k + 1].second - v[k].second != X[k + 1].second - X[k].second))flag = 0;
			}
			if (flag) {
				cout << i + 1 << endl;
				continue;
			}
			flag = 1;
			REP(k, m - 1) {

				if ((v[k + 1].first - v[k].first != X[k + 1].second - X[k].second) || (-v[k + 1].second + v[k].second != X[k + 1].first - X[k].first))flag = 0;
			}
			if (flag) {
				cout << i + 1 << endl;
				continue;
			}
			flag = 1;
			REP(k, m - 1) {
				if ((-v[k + 1].first + v[k].first != X[k + 1].first - X[k].first) || (-v[k + 1].second + v[k].second != X[k + 1].second - X[k].second))flag = 0;
			}
			if (flag) {
				cout << i + 1 << endl;
				continue;
			}
			flag = 1;
			REP(k, m - 1) {
				if ((-v[k + 1].first + v[k].first != X[k + 1].second - X[k].second) || (v[k + 1].second - v[k].second != X[k + 1].first - X[k].first))flag = 0;
			}
			if (flag) {
				cout << i + 1 << endl;
				continue;
			}
			flag = 1;
			REP(k, m - 1) {
				if ((v[k + 1].first - v[k].first != X[m - k - 2].first - X[m - k - 1].first) || (v[k + 1].second - v[k].second != X[m - k - 2].second - X[m - k - 1].second))flag = 0;
			}
			if (flag) {
				cout << i + 1 << endl;
				continue;
			}
			flag = 1;
			REP(k, m - 1) {

				if ((v[k + 1].first - v[k].first != X[m - k - 2].second - X[m - k - 1].second) || (-v[k + 1].second + v[k].second != X[m - k - 2].first - X[m - k - 1].first))flag = 0;
			}
			if (flag) {
				cout << i + 1 << endl;
				continue;
			}
			flag = 1;
			REP(k, m - 1) {
				if ((-v[k + 1].first + v[k].first != X[m - k - 2].first - X[m - k - 1].first) || (-v[k + 1].second + v[k].second != X[m - k - 2].second - X[m - k - 1].second))flag = 0;
			}
			if (flag) {
				cout << i + 1 << endl;
				continue;
			}
			flag = 1;
			REP(k, m - 1) {
				if ((-v[k + 1].first + v[k].first != X[m - k - 2].second - X[m - k - 1].second) || (v[k + 1].second - v[k].second != X[m - k - 2].first - X[m - k - 1].first))flag = 0;
			}
			if (flag) {
				cout << i + 1 << endl;
				continue;
			}

		}
		cout << "+++++" << endl;
	}
	return 0;
}