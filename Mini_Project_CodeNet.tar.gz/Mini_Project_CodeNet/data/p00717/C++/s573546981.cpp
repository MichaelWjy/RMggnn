#include <iostream>
#include <vector>
#include <algorithm>

//#define N 20

using namespace std;


int main(void)
{
	int n;
	int m;
	int x,y;
	int dx,dy;

	int i1,i2,i3;
	int temp;



	while(1) {

		vector<int> vx;
		vector<int> vy;


		cin >> n;
		if (n==0) break;

		cin >> m;

		cin >> dx;
		cin >> dy;

		vx.push_back(0);
		vy.push_back(0);

		for(i1=1;i1<m;i1++){
				
			cin >> x;
			cin >> y;

			vx.push_back(x-dx);
			vy.push_back(y-dy);
		}

		for(i1=0;i1<n;i1++){
			vector<int> wx;
			vector<int> wy;
			vector<int> rx;
			vector<int> ry;

			cin >> m;

			cin >> dx;
			cin >> dy;

			wx.push_back(0);
			wy.push_back(0);
			
			for(i2=1;i2<m;i2++){
				cin >> x;
				cin >> y;

				wx.push_back(x-dx);
				wy.push_back(y-dy);

			}

			rx = wx;
			ry = wy;

			reverse(rx.begin(),rx.end());
			reverse(ry.begin(),ry.end());




			dx = rx[0];
			dy = ry[0];

			rx[0] = 0;
			ry[0] = 0;

			for(i2=1;i2<m;i2++){
				rx[i2] -= dx;
				ry[i2] -= dy;
			}

			for(i3=0;i3<3;i3++){
				

				if( (vx==wx && vy==wy) || (vx==rx && vy==ry)) {
					cout << i1+1 << endl;
				}
				for(i2=1;i2<m;i2++){
					temp=wx[i2];
					wx[i2]=wy[i2];
					wy[i2]=-temp;
					
					temp=rx[i2];
					rx[i2]=ry[i2];
					ry[i2]=-temp;
					
				}

			}

			if( (vx==wx && vy==wy) || (vx==rx && vy==ry)) {
					cout << i1+1 << endl;
			}

		}

		cout  << "+++++" << endl;
	}

	return 0;
}