#include<bits/stdc++.h>
#define range(i,a,b) for(int i = (a); i < (b); i++)
#define rep(i,b) range(i,0,b)
#define pb(a) push_back(a)
#define all(a) (a).begin(), (a).end()
#define debug(x) cout << "debug " << x << endl;
using namespace std;

#define EPS (1e-10) //?\??°???????
#define equals(a, b) ( fabs((a) - (b)) < EPS )

class Point{
    public:
        double x, y;

        Point(double x = 0, double y = 0): x(x), y(y) {}

        Point operator + (Point p) { return Point(x + p.x, y + p.y); }
        Point operator - (Point p) { return Point(x - p.x, y - p.y); }
        Point operator * (double a) { return Point(a * x, a * y); }
        Point operator / (double a) { return Point(x / a, y / a); }

        double abs() { return sqrt(norm());}
        double norm() { return x * x + y * y; }

        bool operator < (const Point &p) const {
            return x != p.x ? x < p.x : y < p.y;
        }

        bool operator == (const Point &p) const {
            return fabs(x - p.x) < EPS && fabs(y - p.y) < EPS;
        }
};

typedef Point Vector;
///////////////

double dot(Vector a, Vector b){ //????????????a??¨b?????????
    return a.x * b.x + a.y * b.y;
}

double cross(Vector a, Vector b){ //????????????a??¨b?????????
    return a.x*b.y - a.y*b.x;
}

//????????????A???B???????????¢???
static const int COUNTER_CLOCKWISE = 1; //???????¨???????
static const int CLOCKWISE = -1; //????¨???????
static const int ONLINE_BACK = 2; //2,0,1?????????????????????
static const int ONLINE_FRONT = -2; //0,1,2?????????????????????
static const int ON_SEGMENT = 0; //??????0,1????????????

int ccw(Point p0, Point p1, Point p2){
    Vector a = p1 - p0;
    Vector b = p2 - p0;
    if( cross(a, b) > EPS ) return COUNTER_CLOCKWISE;
    if( cross(a, b) < -EPS ) return CLOCKWISE;
    if( dot(a, b) < -EPS ) return ONLINE_BACK;
    if( a.norm() < b.norm() ) return ONLINE_FRONT;

    return ON_SEGMENT;
}

bool check(int l[55][15][2], int i, int m){
    rep(j,m - 2){
        if(l[0][j][0] != l[i][j][0]) return 1;
    }
    rep(j,m - 1){
        if(l[0][j][1] != l[i][j][1]) return 1;
    }
    cout << i << endl;
    return 0;
}

bool revCheck(int l[55][15][2], int i, int m){
    rep(j,m - 2){
        if(l[0][j][0] != -1 * l[i][m - j - 3][0]) return 1;
    }
    rep(j,m - 1){
        if(l[0][j][1] != l[i][m - j - 2][1]) return 1;
    }
    cout << i << endl;
    return 0;
}

void print(int n, int m, int line[55][15][2]){
    rep(i,n){
        rep(j,m - 2){
            cout << line[i][j][0] <<' ';
        }
        rep(j,m - 1){
            cout << line[i][j][1] << ' ';
        }
        cout << endl;
    }
}

int main(){
    int n;
    while(cin >> n, n){
        int line[55][15][2], m; //line[i][0] = ccw, line[i][1] = abs;
        n++;
        rep(i,n){
            Point p[50];
            cin >> m;
            rep(j,m) cin >> p[j].x >> p[j].y;

            range(j,2,m){
                line[i][j - 2][0] = ccw(p[j - 2], p[j - 1], p[j]);
            }
            range(j,1,m){
                Vector a = p[j - 1] - p[j];
                line[i][j - 1][1] = a.abs();
            }
        }
        range(j,1,n){
            if(check(line, j, m)){
                revCheck(line, j, m);
            }
        }
        cout << "+++++" << endl;
    }
}