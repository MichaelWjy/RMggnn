#include <cassert>

#include <cctype>
#include <cerrno>
#include <cfloat>
#include <ciso646>
#include <climits>
#include <clocale>
#include <cmath>
#include <csetjmp>
#include <csignal>
#include <cstdarg>
#include <cstddef>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <ccomplex>
#include <cfenv>
#include <cinttypes>
#include <cstdbool>
#include <cstdint>
#include <ctgmath>
#include <cwchar>
#include <cwctype>

// C++
#include <algorithm>
#include <bitset>
#include <complex>
#include <deque>
#include <exception>
#include <fstream>
#include <functional>
#include <iomanip>
#include <ios>
#include <iosfwd>
#include <iostream>
#include <istream>
#include <iterator>
#include <limits>
#include <list>
#include <locale>
#include <map>
#include <memory>
#include <new>
#include <numeric>
#include <ostream>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdexcept>
#include <streambuf>
#include <string>
#include <typeinfo>
#include <utility>
#include <valarray>
#include <vector>
#include <array>
#include <atomic>
#include <chrono>
#include <condition_variable>
#include <forward_list>
#include <future>
#include <initializer_list>
#include <mutex>
#include <random>
#include <ratio>
#include <regex>
#include <scoped_allocator>
#include <system_error>
#include <thread>
#include <tuple>
#include <typeindex>
#include <type_traits>
#include <unordered_map>
#include <unordered_set>
//#include <boost/foreach.hpp>
//#include <boost/range/algorithm.hpp>
#define rep(i,j,k) for(int i=(int)j;i<(int)k;i++)
#define ll long long
#define Sort(v) sort(all(v))
#define INF 1e9
#define LINF 1e18
#define END return 0
#define pb push_back
#define se second
#define fi first
#define pb push_back
#define all(v) (v).begin() , (v).end()
#define MP make_pair
#define MOD 1000000007LL
//#define int long long
using namespace std;
int day[12]={31,28,31,30,31,30,31,31,30,31,30,31};
int dx[]={0,1,0,-1};
int dy[]={1,0,-1,0};
struct edge{int to,cost;};
//typedef pair<int,int> P;

bool isupper(char c){if('A'<=c&&c<='Z')return 1;return 0;}
bool islower(char c){if('a'<=c&&c<='z')return 1;return 0;}
bool isPrime(int x){if(x==1)return 0;if(x==2)return 1;if(x%2==0)return 0;for(int i=3;i*i<=x;i++)if(x%i==0)return 0;return 1;}
bool iskaibun(string s){for(int i=0;i<s.size()/2;i++)if(s[i]!=s[s.size()-i-1])return 0;return 1;}
bool isnumber(char c){return ('0'<=c&&c<='9');}
bool isalpha(char c){return (isupper(c)&&islower(c));}
void printvi(vector<int> v){rep(i,0,v.size()){if(i)cout<<" ";cout<<v[i];}cout<<endl;}
void printvil(vector<int> v){rep(i,0,v.size()){cout<<v[i]<<endl;}}
void printvvi(vector<vector<int>> v){
    rep(i,0,v.size()){
        rep(j,0,v[i].size()){
            if(j)cout<<" ";
            cout<<v[i][j];
        }
        cout<<endl;
    }
}
void printvstr(vector<string> v){
    rep(i,0,v.size()){
        cout<<v[i]<<endl;
    }
}

struct S{
   int len;
   int dir; //0,1,2,3
};

struct P{
    int x,y;
};


signed main (){
    int n;
    while(1){
        cin>>n;
        if(n==0)break;
        vector<S> target;
        int m,prex,prey;
        cin>>m;
        rep(i,0,m){//まずは探す元となる折れ線の情報を集める
            int x,y;
            cin>>x>>y;
            if(i==0){
                prex=x; prey=y;
            }else {
                if(prex==x){
                    if(prey<y)target.emplace_back(S{y-prey,0});
                    else target.emplace_back(S{prey-y,2});
                }else {
                    if(prex<x)target.emplace_back(S{x-prex,1});
                    else target.emplace_back(S{prex-x,3});
                }
                prex=x; prey=y;
            }
        }
        rep(gotutiyan,0,n){//このブロックで１つの折れ線
            bool finish=false;
            //まずはその順
            cin>>m;
            vector<P> points(m);
            vector<S> lines;
            rep(i,0,m){
                int x,y;
                cin>>x>>y;
                points[i]=P{x,y};
                if(i==0){
                    prex=x; prey=y;
                }else {
                    if(prex==x){
                        if(prey<y)lines.emplace_back(S{y-prey,0});
                        else lines.emplace_back(S{prey-y,2});
                    }else {
                        if(prex<x)lines.emplace_back(S{x-prex,1});
                        else lines.emplace_back(S{prex-x,3});
                    }
                    prex=x; prey=y;
                }
            }
            if(target.size()!=lines.size())continue;
            //あっているか確認
            rep(i,0,4){
                bool ok=true;
                rep(j,0,m-1){
                    if(!(target[j].len==lines[j].len and (target[j].dir)==(lines[j].dir+i)%4))ok=false;
                }
                if(ok){
                    cout<<gotutiyan+1<<endl;
                    finish=true;
                    break;
                }
            }
            if(finish)continue;
            //ここから逆順
            reverse(all(points));
            lines.clear();
            rep(i,0,m){
                if(i==0){
                    prex=points[i].x;
                    prey=points[i].y;
                }else {
                    if(points[i].x==prex){
                        if(points[i].y>prey)lines.emplace_back(S{points[i].y-prey,0});
                        else lines.emplace_back(S{prey-points[i].y,2});
                    }else {
                        if(prex<points[i].x)lines.emplace_back(S{points[i].x-prex,1});
                        else lines.emplace_back(S{prex-points[i].x,3});
                    }
                    prex=points[i].x; prey=points[i].y;
                }
            }
            //あっているか確認
            rep(i,0,4){
                bool ok=true;
                rep(j,0,m-1){
                    if(!(target[j].len==lines[j].len and (target[j].dir)==(lines[j].dir+i)%4))ok=false;
                }
                if(ok){
                    cout<<gotutiyan+1<<endl;
                    break;
                }
            }
        }
        cout<<"+++++"<<endl;
    }
}
/*
*/

