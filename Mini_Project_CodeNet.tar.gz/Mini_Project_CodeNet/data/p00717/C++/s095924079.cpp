#include<iostream>
#include<vector>
#include<string>
#include<cstring>
#include<algorithm>
using namespace std;
#define INF (1<<29)

void move(int m,int x[10],int y[10]){
	int minx = INF,miny=INF;
	for(int i=0;i<m;i++){
		minx=min(minx,x[i]);
		miny=min(miny,y[i]);
	}
	for(int i=0;i<m;i++){
		x[i] -= minx;
		y[i] -= miny;
	}
}
void rotate(int m,int x[10],int y[10]){
	for(int i=0;i<m;i++){
		int nx,ny;
		nx = -y[i];
		ny = x[i];
		x[i]=nx;
		y[i]=ny;
	}
	move(m,x,y);
}
void reverse(int m,int x[10],int y[10]){
	for(int i=0;i<m/2;i++){
		swap(x[i],x[m-1-i]);
		swap(y[i],y[m-1-i]);
	}
	move(m,x,y);
}
bool same(int m,int x[10],int y[10],int m1,int x1[10],int y1[10]){
	if(m!=m1)return false;
	for(int i=0;i<m;i++){
		if(x[i]!=x1[i]||y[i]!=y1[i])return false;
	}
	return true;
}
int main(){
	int n;
	while(cin>>n&&n){
		int m0,x0[10],y0[10];
		int m,x[10],y[10];
		cin>>m0;
		for(int i=0;i<m0;i++){
			cin>>x0[i]>>y0[i];
		}
		move(m0,x0,y0);
		for(int i=0;i<n;i++){
			cin>>m;
			int j;
			for(j=0;j<m;j++){
				cin>>x[j]>>y[j];
			}
			for(j=0;j<4;j++){
				rotate(m,x,y);
				if(same(m0,x0,y0,m,x,y))break;
				reverse(m,x,y);
				if(same(m0,x0,y0,m,x,y))break;
			}
			if(j!=4)cout<<i+1<<endl;
		}
		cout<<"+++++"<<endl;
	}
	return 0;
}