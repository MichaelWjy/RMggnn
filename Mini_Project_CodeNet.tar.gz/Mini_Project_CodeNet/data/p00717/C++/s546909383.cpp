//1405
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<cassert>
#include<sstream>
#include<iostream>
#include<string>
#include<vector>
#include<queue>
#include<set>
#include<map>
#include<utility>
#include<numeric>
#include<algorithm>
#include<bitset>
#include<complex>

using namespace std;

typedef unsigned uint;
typedef long long Int;
typedef vector<int> vint;
typedef pair<int,int> pint;

int main(){
	int n;
	while(cin >> n){
		vector<pint> a;
		if(n==0) break;
		int m;
		cin >> m;
		pint tmp;
		cin >> tmp.first >> tmp.second;
		a.push_back(pint(0,0));
		for(int i=1;i<m;i++){
			pint in;
			cin >> in.first >> in.second;
			a.push_back(pint(in.first-tmp.first,in.second-tmp.second));
		}
		
		for(int ii=0;ii<n;ii++){
			cin >> m;
			cin >> tmp.first >> tmp.second;
			vector<pint> b;
			b.push_back(pint(0,0));
			for(int i=1;i<m;i++){
				pint in;
				cin >> in.first >> in.second;
//				cout << in.first <<" "<< in.second << endl;
				b.push_back(pint(in.first-tmp.first,in.second-tmp.second));
			}
			if(a.size()==b.size()){
				int f=0;
				for(int k=0;k<4;k++){
					f=0;
					for(int j=0;j<a.size();j++){
//						cout << a[j].first << " " << a[j].second << "   " << b[j].first << " " << b[j].second<< endl;
						if(a[j]!=b[j]) f=1;
					}
					if(f==0){
						cout << ii+1 << endl;
						break;
					}
					for(int j=0;j<b.size();j++){
						swap(b[j].first,b[j].second);
						b[j].first*=-1;
					}
				}
				if(f==1){
					f=0;
					reverse(b.begin(),b.end());
					tmp = b[0];
					for(int j=0;j<b.size();j++){
						b[j].first-=tmp.first;
						b[j].second-=tmp.second;
					}
					for(int k=0;k<4;k++){
						f=0;
						for(int j=0;j<a.size();j++){
							//						cout << a[j].first << " " << a[j].second << "   " << b[j].first << " " << b[j].second<< endl;
							if(a[j]!=b[j]) f=1;
						}
						if(f==0){
							cout << ii+1 << endl;
							break;
						}
						for(int j=0;j<b.size();j++){
							swap(b[j].first,b[j].second);
							b[j].first*=-1;
						}
					}
				}
			}
		}
		cout << "+++++" << endl;
	}
				
			
	
	return 0;
}
	