#include <bits/stdc++.h>
using namespace std;
#define rep(i,a,n) for(int i=a; i<n; i++)
#define repq(i,a,n) for(int i=a; i<=n; i++)
#define repr(i,a,n) for(int i=a; i>=n; i--)
typedef long long ll;
typedef pair<int, int> pii;
#define int ll
 
template<typename T> void chmax(T &a, T b) {a = max(a, b);}
template<typename T> void chmin(T &a, T b) {a = min(a, b);}
template<typename T> void chadd(T &a, T b) {a = a + b;}
 
constexpr ll INF = 1001001001001001LL;
constexpr ll MOD = 1000000007LL;
 
#define X real()
#define Y imag()
typedef complex<double> P;
typedef vector<P> Poly;
 
signed main() {
    int n,dx[4] = {1,0,-1,0}, dy[4] = {0,1,0,-1};
    while(cin >> n, n){
        int m0, m;
        double x, y;
        cin >> m0;
        Poly o;
        for(int i = 0; i < m0; ++i){
            cin >> x >> y;
            o.push_back(P(x,y));
        }
        for(int i = 0; i < n; ++i){
            cin >> m;
            Poly p;
            for(int j = 0; j < m; ++j){
                cin >> x >> y;
                p.push_back(P(x,y));
            }
            if(m == m0){
                for(int j = 0; j < 4; ++j){
                    bool f = true;
                    for(int k = 0; k < m; ++k){
                        P a = o[k]-o[0], b = p[k] - p[0];
                        if(b != P(a.X*dx[j]-a.Y*dy[j], a.X*dy[j]+a.Y*dx[j])){
                            f = false;
                            break;
                        }
                    }
                    if(f){
                        cout << i+1 << endl;
                        break;
                    }
                    f = true;
                    for(int k = m-1; k >= 0; --k){
                        P a = o[m-1-k] - o[0], b = p[k] - p[m-1];
                        if(b != P(a.X*dx[j]-a.Y*dy[j], a.X*dy[j]+a.Y*dx[j])){
                            f = false;
                            break;
                        }                        
                    }
                    if(f){
                        cout << i+1 << endl;
                        break;
                    }                    
                }
            }
        }
        cout << "+++++" << endl;
    }
    return 0;
}