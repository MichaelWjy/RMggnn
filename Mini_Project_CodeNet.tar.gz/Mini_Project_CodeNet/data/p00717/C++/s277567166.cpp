#include <bits/stdc++.h>

using namespace std;
typedef long long ll;
typedef pair<int, int> pii;

struct P {
  int n;
  vector<vector<pii>> d;
  P() {}
  P(int n) : n(n) { d.resize(4, vector<pii>(n)); }
};

int n, m;
int px, py, x, y;
vector<P> v;

bool check(vector<pii>& s, vector<pii>& t, int f) {
  bool res = true;
  int sz = s.size(), sgn = f ? -1 : 1;
  for (int i = 0; i < sz; i++) {
    res &= (s[i].first == sgn * t[i].first && s[i].second == sgn * t[i].second);
  }
  return res;
}

int main() {
  cin.tie(0);
  ios_base::sync_with_stdio(false);
  
  while (cin >> n, n) {
    n++;
    v.resize(n);
    for (int i = 0; i < n; i++) {
      cin >> m;
      v[i] = P(m - 1);
      cin >> px >> py;
      for (int j = 0; j < m - 1; j++) {
        cin >> x >> y;
        v[i].d[0][j] = {x - px, y - py};
        v[i].d[1][j] = {y - py, px - x};
        px = x, py = y;
      }
      for (int j = 0; j < m - 1; j++) {
        pii p0 = v[i].d[0][m - j - 2], p1 = v[i].d[1][m - j - 2];
        v[i].d[2][j] = {-p0.first, -p0.second};
        v[i].d[3][j] = {-p1.first, -p1.second};        
      }
    }

    for (int i = 1; i < n; i++) {
      bool same = false;
      for (int j = 0; j < 4; j++) {
        for (int k = 0; k < 2; k++) {
          same |= check(v[0].d[0], v[i].d[j], k);
        }
      }
      if (same) cout << i << endl;
    }
    cout << "+++++" << endl;
  }  

  return 0;
}
