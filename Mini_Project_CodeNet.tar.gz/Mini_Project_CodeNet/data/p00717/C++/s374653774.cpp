#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<cassert>
#include<iostream>
#include<sstream>
#include<string>
#include<vector>
#include<queue>
#include<set>
#include<map>
#include<utility>
#include<numeric>
#include<algorithm>
#include<bitset>
#include<complex>
#include<stack>

using namespace std;

typedef long long Int;
typedef vector<int> vint;
typedef pair<int,int> pint;
typedef vector<string> vstring;
typedef vector<pint> vpint;

struct Edge{int to,from,cost;};

#ifdef DEBUGLOCAL
#define debug cout
#else
stringstream __ss__;
#define debug __ss__
#endif

template<class T> void pv(T a, T b) { for (T i = a; i != b; ++i) debug << *i << " "; debug << endl; }
template<class T> void chmin(T &t, T f) { if (t > f) t = f; }
template<class T> void chmax(T &t, T f) { if (t < f) t = f; }
int in() { int x; scanf("%d", &x); return x; }

#define rep(i,n) for(int i=0;i<(n);++i)
#define repd(i,n) for(int i=(n)-1;i>=0;i--)
#define repn(i,m,n) for(int i=(m);i<=(n);++i)
#define repnd(i,m,n) for(int i=(n)-1;i>=(m);i--)
#define rep0(i,n) for(i=0;i<(n);++i)
#define all(n) n.begin(),n.end()
#define sz(n) ((int)(n).size())
#define MP make_pair
#define PB push_back
#define SS stringstream
#define X second
#define Y first
#define PUTLINE debug<<"LINE:"<<__LINE__<<endl;

const int INF = 2147483647;
const double EPS = 1e-10;
const double PI = acos(-1.0);

const int dx[]={1,-1,0,0,1,-1,1,-1,0};
const int dy[]={0,0,1,-1,1,-1,-1,1,0};

vpint line[60];

int main() {
	int n,m;
	for(;;){
		cin>>n;
		if(n==0)return 0;
		pint buf,frst;
		rep(i,n+1){
			line[i].clear();
			cin>>m;
			cin>>frst.X>>frst.Y;
			line[i].PB(MP(0,0));
			rep(j,m-1){
				cin>>buf.X>>buf.Y;
				buf.X-=frst.X;
				buf.Y-=frst.Y;
				line[i].PB(buf);
			}
		}
		repn(i,1,n){
			if(sz(line[0])!=sz(line[i]))continue;
			rep(r,4){
				if(line[0]==line[i]){
					cout<<i<<endl;
					break;
				}
				rep(j,sz(line[0])){
					pint buf;
					buf.X=line[i][j].Y;
					buf.Y=-line[i][j].X;
					line[i][j]=buf;
				}
			}
			vpint rev;
			rep(j,sz(line[0])){
				rev.PB(line[i][sz(line[0])-j-1]);
			}
			repd(j,sz(line[0])){
				rev[j].X-=rev[0].X;
				rev[j].Y-=rev[0].Y;
			}
			rep(r,4){
				if(line[0]==rev){
					cout<<i<<endl;
					break;
				}
				rep(j,sz(line[0])){
					pint buf;
					buf.X=rev[j].Y;
					buf.Y=-rev[j].X;
					rev[j]=buf;
				}
			}
		}
		cout<<"+++++\n";
	}
}