#include <bits/stdc++.h>
using namespace std;

class P {
public:
    int x, y;
    P(int x, int y) : x(x), y(y) {}
    bool operator!=(const P &p) {
        return x!=p.x || y!=p.y;
    }
};

class Poly {
public:
    int n;
    vector<int> dx, dy;
    Poly(): n(0) {}
    bool operator==(const Poly &p) {
        if (n != p.n) return false;
        for (int i=0; i<n; ++i) {
            if (dx[i] != p.dx[i] || dy[i] != p.dy[i]) return false;
        }
        return true;
    }
    void add(P p) {
        ps.push_back(p);
    }
    void vectorize() {
        n = (int)ps.size() - 1;
        dx.resize(n);
        dy.resize(n);
        for (int i=0; i<n; ++i) {
            dx[i] = ps[i+1].x - ps[i].x;
            dy[i] = ps[i+1].y - ps[i].y;
        }
    }
    void rotate() {
        for (int i=0; i<n; ++i) {
            swap(dx[i], dy[i]);
            dx[i] = -dx[i];
        }
    }
    void rev() {
        reverse(dx.begin(), dx.end());
        reverse(dy.begin(), dy.end());
        for (int i=0; i<n; ++i) {
            dx[i] = -dx[i];
            dy[i] = -dy[i];
        }
    }
private:
    vector<P> ps;
};

bool equals(Poly a, Poly b) {
    for (int i=0; i<4; ++i) {
        if (a == b) return true;
        b.rotate();
    }
    b.rev();
    for (int i=0; i<4; ++i) {
        if (a == b) return true;
        b.rotate();
    }
    return false;
}

Poly polyInput() {
    int m, x, y;
    cin >> m;
    Poly pl;
    for (int i=0; i<m; ++i) {
        cin >> x >> y;
        pl.add(P(x, y));
    }
    pl.vectorize();
    return pl;
}

int main() {
    int n;
    while (cin >> n, n) {
        Poly pl0 = polyInput(); 
        for (int i=1; i<=n; ++i) {
            Poly pl = polyInput();
            if (equals(pl0, pl)) cout << i << endl;
        }
        cout << "+++++" << endl;
    }
    return 0;
}
