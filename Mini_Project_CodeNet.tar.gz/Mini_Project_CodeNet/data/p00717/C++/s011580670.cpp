#include <iostream>
#include <cmath>
#define MAX_N 50
#define MAX_M 10
using namespace std;

typedef struct {
  int x,y;
} P;

int len( P p, P q ){
  int x = p.x-q.x;
  int y = p.y-q.y;
  return sqrt( x*x + y*y );
}
int dir( P p, P q, P r ){
  if( p.x==q.x ){ // cûü
    if( p.y>q.y ){ // ãü«
      if( p.x<r.x )    return 2;
      else if(p.x>r.x) return 1;
      else             return 0;
    }else {
      if( p.x<r.x )     return 1;
      else if( p.x>r.x) return 2;
      else              return 0;
    }
  }else { // 
    if( p.x>q.x ){
      if( p.y<r.y )     return 1;
      else if(p.y>r.y ) return 2;
      else              return 0;
    }else{
      if( p.y<r.y )      return 2;
      else if( p.y>r.y ) return 1;
      else               return 0;
    }
  }
}

int main(){
  int n, m,mm;
  P org[MAX_M];
  P cmp[MAX_M];

  while( cin>>n && n ){

    cin >> mm;
    for( int i=0;i<mm;i++ )
      cin >> org[i].x >> org[i].y;

    for( int loop=1;loop<=n;loop++ ){
      //      cout << "dataset "<<loop<<endl;

      cin >> m;
      for( int i=0;i<m;i++ )
	cin >> cmp[i].x >> cmp[i].y;
      if( m!=mm )
	continue;

      // 1{ÚÌ·³Ì`FbN
      if( len(org[0],org[1]) == len(cmp[0],cmp[1]) ){
	// ûü
	//	  cout <<"len 0,1"<<endl;
	for( int i=2;i<m;i++ ){ // i-1{ÚÆi{ÚÉÂ¢Ä
	  // ·³
	  //	  cout <<"len "<<i-1<<","<<i<<endl;
	  if( len(org[i-1],org[i])!=len(cmp[i-1],cmp[i]) )
	    break;
	  //	  cout <<" deg "<<i-2<<","<<i-1<<","<<i<< endl;
	  // px
	  if( dir(org[i-2],org[i-1],org[i])!=
	      dir(cmp[i-2],cmp[i-1],cmp[i]) )
	    break;

	  if( i==m-1 )
	    cout << loop << endl;
	}
      }else if( len(org[0],org[1]) == len(cmp[m-1],cmp[m-2]) ){
	//	cout << "m="<<m<<endl;
	// tûü
	for( int i=2;i<m;i++ ){ // orgÌi-1Æi, cmp Ì m-i-1, m-i-2ÉÂ¢Ä
	  //	  cout << "  "<< m-i << ","<< m-i-1 << endl;
	  // ·³
	  if( len(org[i-1],org[i])!=len(cmp[m-i],cmp[m-i-1]) )
	    break;
	  // px
	  if( dir(org[i-2],org[i-1],org[i])!=
	      dir(cmp[m-i+1],cmp[m-i],cmp[m-i-1]) )
	    break;
	  if( i==m-1 )
	    cout << loop << endl;
	}
      }
    }
    cout << "+++++"<<endl;

    //    break;
  }

  return 0;
}