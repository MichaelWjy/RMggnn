#include<bits/stdc++.h>
#define rep(i,n)for(int i=0;i<n;i++)
using namespace std;
typedef pair<pair<int, int>, pair<int, int>>P;

int x[20], y[20];
int main() {
	int n;
	while (scanf("%d", &n), n) {
		vector<P>v[53];
		rep(i, n + 1) {
			int m; scanf("%d", &m);
			rep(j, m)scanf("%d%d", &x[j], &y[j]);
			rep(j, m - 1)
				v[i].push_back(P({ x[j],y[j] }, { x[j + 1],y[j + 1] }));
		}
		vector<int>ans;
		for (int i = 1; i <= n; i++) {
			if (v[0].size() != v[i].size())continue;
			bool ok = true;
			rep(j, v[0].size()) {

			}
			if (ok) {
				ans.push_back(i);
				continue;
			}
		}
		rep(i, ans.size())printf("%d\n", ans[i]);
		puts("+++++");
	}
}