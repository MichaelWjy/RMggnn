#include<iostream>
#include<string>
#include<vector>
#include<algorithm>
using namespace std;

int main() {

	while (1) {
		int i, j, k, n, m, x[3], y[3];
		vector<int> hash[51], hashrev[51];

		cin >> n;
		if (n == 0)break;
		for (i = 0; i <= n; i++) {
			cin >> m;
			cin >> x[0] >> y[0] >> x[1] >> y[1];
			hash[i].push_back((x[0] - x[1]) * (x[0] - x[1]) + (y[0] - y[1]) * (y[0] - y[1]));
			hashrev[i].push_back((x[0] - x[1]) * (x[0] - x[1]) + (y[0] - y[1]) * (y[0] - y[1]));
			for (j = 2; j < m; j++) {
				cin >> x[j % 3] >> y[j % 3];
				if ((x[j % 3] - x[(j - 1) % 3]) * (y[(j - 1) % 3] - y[(j - 2) % 3])
					- (x[(j - 1) % 3] - x[(j - 2) % 3]) * (y[j % 3] - y[(j - 1) % 3]) > 0) {
					hash[i].push_back(-1);
					hashrev[i].push_back(-2);
				} else {
					hash[i].push_back(-2);
					hashrev[i].push_back(-1);
				}
				hash[i].push_back((x[j % 3] - x[(j - 1) % 3]) * (x[j % 3] - x[(j - 1) % 3])
					+ (y[j % 3] - y[(j - 1) % 3]) * (y[j % 3] - y[(j - 1) % 3]));
				hashrev[i].push_back((x[j % 3] - x[(j - 1) % 3]) * (x[j % 3] - x[(j - 1) % 3])
					+ (y[j % 3] - y[(j - 1) % 3]) * (y[j % 3] - y[(j - 1) % 3]));
			}
		}

		for (i = 1; i <= n; i++) {
			reverse(hashrev[i].begin(), hashrev[i].end());
			if (hash[i] == hash[0] || hashrev[i] == hash[0])cout << i << endl;
		}

		cout << "+++++" << endl;


	}

	


	return 0;
}