#include <iostream>
#include <vector>
#include <algorithm>
#include <utility>

using namespace std;
typedef pair<int, int> pii;

vector<pii> normalize(vector<pii> v){
	const int n = v.size(), xofs = v[0].first, yofs = v[0].second;
	for(int i = 0; i < n; ++i){
		v[i].first -= xofs;
		v[i].second -= yofs;
	}
	if(v[1].first == 0){
		if(v[1].second > 0){
			for(int i = 0; i < n; ++i){
				v[i] = pii(v[i].second, -v[i].first);
			}
		}else{
			for(int i = 0; i < n; ++i){
				v[i] = pii(-v[i].second, v[i].first);
			}
		}
	}else if(v[1].first < 0){
		for(int i = 0; i < n; ++i){
			v[i] = pii(-v[i].first, -v[i].second);
		}
	}
	return v;
}

int main(){
	while(true){
		int n;
		cin >> n;
		if(n == 0){ break; }
		vector< vector<pii> > lines(n + 1);
		for(int i = 0; i <= n; ++i){
			int m;
			cin >> m;
			lines[i].resize(m);
			for(int j = 0; j < m; ++j){
				cin >> lines[i][j].first >> lines[i][j].second;
			}
			lines[i] = normalize(lines[i]);
			if(i > 0){
				vector<pii> rline = lines[i];
				reverse(rline.begin(), rline.end());
				rline = normalize(rline);
				if(lines[i] == lines[0] || rline == lines[0]){
					cout << i << endl;
				}
			}
		}
		cout << "+++++" << endl;
	}
	return 0;
}