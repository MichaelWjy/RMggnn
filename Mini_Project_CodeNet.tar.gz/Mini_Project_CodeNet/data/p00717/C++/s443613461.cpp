#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <cstdio>
#include <queue>
#include <map>

#define rep(i, n) for(int i = 0; i < n; i++)
#define FOR(i, a, b) for(int i = a; i < b; i++)
#define all(v) (v).begin(), (v).end()
#define MP make_pair

using namespace std;

typedef vector<int> vi;
typedef vector<vi> vvi;
typedef pair<int, int> P;
typedef vector<P> vp;

void pp(vi v){
	rep(i, v.size()){
		cout << v[i] << ' ';
	}
	cout << endl;
}

void pp(vector<string> v){
	rep(i, v.size()){
		cout << v[i] << endl;
	}
}

void pp(int (*v)[1000], int size = 10){
	rep(i, size){
		rep(j, size){
			cout << v[i][j] << ' ';
		}
		cout << endl;
	}
}

P dif(P &a, P &b){
	return P(a.first-b.first, a.second-b.second);
}

bool equal(P &a, P&b){
	return (a.first == b.first && a.second == b.second);
}

// 平行移動はOK、回転はNG
bool linecmp(vp &a, vp &b){
	if(a.size() != b.size()) return false;
	vp diffs;
	rep(i, a.size()){
		diffs.push_back(dif(a[i], b[i]));
	}
	FOR(i, 1, diffs.size()){
		if( equal(diffs[i], diffs[i-1]) == false) return false;
	}
	return true;
}

int main(){
	int n;
	while(cin >> n,n){
		int m;
		cin >> m;
		vector<vp> target(4);
		target[0].resize(m);
		rep(i, m){	// 探す折れ線
			cin >> target[0][i].first >> target[0][i].second;
		}
		FOR(i, 1, 4){
			target[i].resize(m);
			rep(j, m){	// 90度回転
				target[i][j].first = target[i-1][j].second;
				target[i][j].second = -target[i-1][j].first;
			}
		}

		rep(i, n){	// 探される折れ線たち
			cin >> m;
			vp v(m), rv(m);
			rep(j, m){
				cin >> v[j].first >> v[j].second;
			}
			rv = v;
			reverse(all(rv));
			rep(j, 4){ // 4方向に対して比較
				if(linecmp(target[j], v) || linecmp(target[j], rv)){
//					cout << "***";
					cout << i+1 << endl;
					break;
				}
			}
		}
		cout << "+++++" << endl;
	}

	return 0;
}