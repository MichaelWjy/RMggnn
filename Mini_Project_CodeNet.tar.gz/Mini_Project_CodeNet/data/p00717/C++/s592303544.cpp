#include<stdio.h>
#include<iostream>
#include<algorithm>
#include<vector>
#include<queue>
#include<functional>
 
 
#define rep(i,n) for(int i=0;i<(n);i++)
 
using namespace std;
const int INF = 100000000;
const double EPS = 0.0000001;
typedef pair<int,int> P;

int n;

void solve() {
	int m;
	cin>>m;
	vector<P> vec[51],vec2;
	rep(k,n) {
	rep(i,m) {
		int a;cin>>a;
		rep(j,a) {
			int x,y; cin>>x>>y;
			vec[i].push_back(P(x,y));
		}
		sort(vec[i].begin(),vec[i].end());
	}
	}

	int a;cin>>a;
	rep(i,a) {
		int x,y;cin>>x>>y;
		vec2.push_back(P(x,y));
	}
	sort(vec2.begin(),vec2.end());

	rep(i,m) {
		bool flag=true;
		P p1 = vec[i][0];
		P p2 = vec2[0];
		P diff = P(p1.first-p2.first,p1.second-p2.second);

		rep(j,vec[i].size()) {
			rep(k,vec2.size()) {
				int diff1 = vec[i][j].first-vec2[k].first;
				int diff2 = vec[i][j].second-vec2[k].second;

				if(diff.first!=diff1 || diff.second != diff2) {
					flag=false;
				}
			}
			if(flag) cout<<i+1<<endl;
		}

	}



}

int main() {
	while (cin>>n)
	{
		if(n==0) return 0;
		solve();
		cout<<"+++++"<<endl;
	}
	return 0;
}