#define _USE_MATH_DEFINES
#include <algorithm>
#include <cstdio>
#include <functional>
#include <iostream>
#include <cfloat>
#include <climits>
#include <cstring>
#include <cmath>
#include <map>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <string>
#include <time.h>
#include <vector>
using namespace std;

typedef long long ll;
typedef unsigned long long ull;
typedef pair<int, int> i_i;
typedef pair<ll, int> ll_i;
typedef pair<double, int> d_i;
typedef pair<ll, ll> ll_ll;
typedef pair<double, double> d_d;
struct edge { int u, v; ll w; };

ll MOD = 1000000007;
ll _MOD = 1000000009;
double EPS = 1e-9;

int main() {
	for (;;) {
		int n; cin >> n;
		if (n == 0) break;
		vector< vector<int> > l(n + 1), a(n + 1);
		for (int i = 0; i <= n; i++) {
			int m; cin >> m;
			vector<int> x(m), y(m);
			for (int j = 0; j < m; j++)
				cin >> x[j] >> y[j];
			vector<int> dx(m - 1), dy(m - 1);
			for (int j = 0; j < m - 1; j++) {
				dx[j] = x[j + 1] - x[j];
				dy[j] = y[j + 1] - y[j];
			}
			for (int j = 0; j < m - 1; j++)
				l[i].push_back(abs(dx[j] + dy[j]));
			for (int j = 0; j < m - 2; j++)
				a[i].push_back((dx[j] * dy[j + 1] - dx[j + 1] * dy[j]) / l[i][j] / l[i][j + 1]);
		}
		vector<int> L = l[0], A = a[0];
		vector<int> _L = L, _A = A;
		reverse(_L.begin(), _L.end());
		reverse(_A.begin(), _A.end());
		for (int j = 0; j < _A.size(); j++)
			_A[j] *= -1;
		for (int i = 1; i <= n; i++)
			if ((l[i] == L && a[i] == A) || (l[i] == _L && a[i] == _A))
				cout << i << endl;
		cout << "+++++" << endl;
	}
}