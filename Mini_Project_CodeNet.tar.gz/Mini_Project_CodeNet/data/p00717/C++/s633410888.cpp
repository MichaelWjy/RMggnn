//
//  main.cpp
//  ICPC2005B
//
//  Created by aki33524 on 2014/07/03.
//  Copyright (c) 2014年 aki33524. All rights reserved.
//

#include <iostream>
#include <vector>
#include <complex>
using namespace std;

typedef pair<int, int> PII;
typedef complex<int> CI;

int N;
vector<CI> PolyLines[51];

bool check(vector<CI> poly0, vector<CI> polyn){
    int m = poly0.size();
    if(polyn.size() != m)
        return false;
        
    bool ok = true;
    for(int i=0; i<m-1; i++){
        if(abs(poly0[i+1]-poly0[i]) != abs(polyn[i+1]-polyn[i])){
            ok = false;
            break;
        }
    }
    if(ok){
        for(int i=1; i<m-1; i++){
            CI v01 = poly0[i] - poly0[i-1];
            CI v02 = poly0[i+1] - poly0[i];
            CI vn1 = polyn[i] - polyn[i-1];
            CI vn2 = polyn[i+1] - polyn[i];
            
            int ccw0 = v01.real()*v02.imag() - v02.real()*v01.imag();
            int ccwn = vn1.real()*vn2.imag() - vn2.real()*vn1.imag();
            
            if(ccw0 != ccwn){
                ok = false;
                break;
            }
        }
    }
    if(ok) return true;
    
    ok = true;
    for(int i=0; i<m-1; i++){
        if(abs(poly0[m-1-(i+1)]-poly0[m-1-(i)]) != abs(polyn[i+1]-polyn[i])){
            ok = false;
            break;
        }
    }
    if(ok){
        for(int i=1; i<m-1; i++){
            CI v01 = poly0[m-1-i] - poly0[m-1-(i-1)];
            CI v02 = poly0[m-1-(i+1)] - poly0[m-1-(i)];
            CI vn1 = polyn[i] - polyn[i-1];
            CI vn2 = polyn[i+1] - polyn[i];
            
            int ccw0 = v01.real()*v02.imag() - v02.real()*v01.imag();
            int ccwn = vn1.real()*vn2.imag() - vn2.real()*vn1.imag();
            
            if(ccw0 != ccwn){
                ok = false;
                break;
            }
        }
    }
    return ok;
}


void solve()
{
    vector<CI> poly0 = PolyLines[0];
    
    for(int n=1; n<=N; n++){
        vector<CI> polyn = PolyLines[n];
        if(check(poly0, polyn))
            cout << n << endl;
    }
    cout << "+++++" << endl;
}

int main(int argc, const char * argv[])
{
    while(cin >> N, N){
        
        for(int n=0; n<=N; n++){
            int M;
            cin >> M;
            PolyLines[n].clear();
            int x, y;
            for(int m=0; m<M; m++){
                cin >> x >> y;
                CI c(x, y);
                PolyLines[n].push_back(c);
            }
        }
        solve();
    }
    
    return 0;
}