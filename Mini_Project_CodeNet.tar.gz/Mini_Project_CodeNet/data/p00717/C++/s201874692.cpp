#include<iostream>
#include<algorithm>
using namespace std;

int n,m[51];
int x[51][10],y[51][10];

void slide(int id){
  for(int i=m[id]-1;i>=0;i--){
    x[id][i] -= x[id][0];
    y[id][i] -= y[id][0];
  }
}

void rot(int id){
  for(int i=0;i<m[i];i++){
    int tmp = x[id][i];
    x[id][i] = y[id][i];
    y[id][i] = -tmp;
  }
}

void rev(int id){
  reverse(x[id],x[id]+m[id]);
  reverse(y[id],y[id]+m[id]);
}

bool same(int id){
  for(int i=0;i<m[0];i++){
    if(x[id][i] != x[0][i] || y[id][i] != y[0][i])return false;
  }
  return true;
}

int main(){
  while(cin >> n,n){
    for(int i=0;i<=n;i++){
      cin >> m[i];
      for(int j=0;j<m[i];j++){
	cin >> x[i][j] >> y[i][j];
      }
    }

    slide(0);

    for(int i=1;i<=n;i++){
      if(m[i] != m[0])continue;
      for(int j=0;j<2;j++){
	for(int k=0;k<4;k++){
	  slide(i);

	  if(same(i)){
	    cout << i << endl;
	    goto LoopEnd;
	  }

	  rot(i);
	}
	rev(i);
      }
    LoopEnd:;
    }
    cout << "+++++" << endl;
  }
}