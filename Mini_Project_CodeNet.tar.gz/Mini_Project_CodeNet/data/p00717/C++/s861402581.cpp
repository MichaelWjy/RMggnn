# define _CRT_SECURE_NO_WARNINGS 1
# include <iostream>
# include <numeric>
# include <string>
# include <bitset>
# include <vector>
# include <algorithm>
# include <cstdlib>
# include <cstdio>
# include <cstring>
# include <cstdlib>
# include <iomanip>
# include <queue>
# include <sstream>
# include <climits>
# include <cmath>
# include <list>
# include <functional>
# include <string>
# include <ctime>
# include <set>
# include <forward_list>
# include <map>
# include <stack>
using namespace std;

# define INF ((int)(1<<30))
# define REP(i,n) for(int i=0;i<(int)n;i++)
# define FOR(i,c) for(__typeof((c).begin())i=(c).begin();i!=(c).end();i++)
# define TORAD 2.0*M_PI/360.0
# define INT(x) int x;cin>>x;
# define ALL(x) (x).begin(),(x).end()
# define DEBUG(x) cout<<#x<<" :"<<x<<endl;
# define EPS 1e-12

template<class T> void debug(T a) { for (auto i : a)cout << i << endl; }

typedef vector<int> vi;
typedef vector<string> vs;
typedef pair<int, int> pii;
typedef pair<int, pii> piii;
int dx[4] = { 0,-1,1,0 }, dy[4] = { 1,0,0,-1 };

int dir(pii a, pii b)
{
	if (a.second < b.second)return 0;
	if (a.first < b.first)return 1;
	if (a.second > b.second)return 2;
	if (a.first > b.first)return 3;
}
int dis(pii a, pii b)
{
	return abs(a.first - b.first) + abs(a.second - b.second);
}

int main()
{
	int n;
	while (cin >> n&&n)
	{
		vector<pii> o[100];
		REP(j, n + 1)
		{
			int m;
			cin >> m;
			REP(i, m)
			{
				pii p;
				cin >> p.first >> p.second;
				o[j].push_back(p);
			}
		}

		vector<pii> a[2][100];
		REP(j, n + 1)
		{
			REP(k, 2)
			{
				int b = dir(o[j][0], o[j][1]);
				int d[4][4] = { {0,1,0,-1},{-1,0,1,0},{0,-1,0,1},{1,0,-1,0} };
				REP(i, o[j].size() - 1)
				{
					pii next;
					next.first = d[b][dir(o[j][i], o[j][i + 1])];
					next.second = dis(o[j][i], o[j][i + 1]);
					b = dir(o[j][i], o[j][i + 1]);
					a[k][j].push_back(next);
				}
				reverse(ALL(o[j]));
			}
		}
		for (int i = 1; i <= n; i++)
		{
			if (a[0][0] == a[0][i] || a[0][0] == a[1][i])
				cout << i << endl;
		}
		cout << "+++++" << endl;
	}
}