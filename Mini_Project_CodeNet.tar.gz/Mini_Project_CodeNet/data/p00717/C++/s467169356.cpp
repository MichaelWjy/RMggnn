#include<bits/stdc++.h>
typedef long long ll;
#define REP(i,n) for(int i = 0;i < (n);i++)
#define rep(i,m,n) for(int i = (m);i < (n);i++)
#define P pair<int,int>
#define pb push_back
#define mk make_pair
using namespace std;
#define Vec(a) vector <int> a
const int INF = 1 << 20;
const int MOD = 1e9+7;





int main(){
  
  int n;
  while(cin >> n,n){
    int m;
    cin >> m;
    P xy[4][m-1];
    vector <int> res;
    int x,y;
    REP(i,m){
      int aa,bb;
      if(i == 0){
	cin >> x >> y;
      }
      else{
	
	cin >> aa >> bb;
	if(aa-x == 0){
	  xy[0][i-1] = mk(0,bb-y);
	  xy[1][i-1] = mk(0,bb-y);
	  xy[2][i-1] = mk(y-bb,0);
	  xy[3][i-1] = mk(bb-y, 0);
	}
	else{
	xy[0][i-1] = mk(aa-x,0);
	xy[1][i-1] = mk(x-aa,0);
	xy[2][i-1] = mk(0,aa-x);
	xy[3][i-1] = mk(0, x-aa);

	}
	x = aa;
	y = bb;
      }
    }
    
    REP(i,4){
      cout << endl;
      REP(j,m-1){
	cout << xy[i][j].first << "  " << xy[i][j].second << endl;
      }
      cout << endl << endl;
      }
    
    REP(i,n){
      
      cin >> m;
      P p[m-1];
      //int x,y;
      REP(j,m){
	if(j == 0){
	  cin >> x >> y;
	}
	else{
	  int aa,bb;
	  cin >> aa >> bb;
	  if(aa-x == 0){
	    p[j-1] = mk(0,bb-y);
	  }
	  else{
	    p[j-1] = mk(aa-x,0);

	  }
	  //cout << p[j-1].first << "     " << p[j-1].second << endl;
	  x = aa;
	  y = bb;
	  
	}
      }
      REP(j,m-1){
	cout << p[j].first << "     " << p[j].second << endl;
      }
    
      bool resf = false;
      REP(j,4){
	bool f = true;
	REP(k,m-1){
	  if(p[k] != xy[j][k]){
	    f = false;
	  }
	}
	if(f){
	  resf = true;
	}
      }
      P pp[m-1];
      REP(j,m-1){
	pp[j].first = p[m-2-j].first*-1;
	pp[j].second = p[m-2-j].second*-1;
	cout << pp[j].first << "        " << pp[j].second << endl;
      }
      
      REP(j,4){
	bool f = true;
	REP(k,m-1){
	  if(pp[k] != xy[j][k]){
	    f = false;
	  }
	}
	if(f){
	  resf = true;
	}
      }
      if(resf == true){
	res.pb(i+1);
	cout << i+1 << endl;
      }
    }
    REP(i,res.size()){
      cout << res[i] << endl;
    }
    cout << "+++++" << endl;
  }

  return 0;
}

