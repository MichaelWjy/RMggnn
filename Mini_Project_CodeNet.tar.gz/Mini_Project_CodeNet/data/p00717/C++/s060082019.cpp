//tempaa
//#pragma GCC optimize ("-O3")
#ifdef _DEBUG
#include<cassert>
#include "bits_stdc++.h"
#else
#include <bits/stdc++.h>
#endif
using namespace std;
//@起動時
struct initon {
    initon() {
        cin.tie(0);
        ios::sync_with_stdio(false);
        cout.setf(ios::fixed);
        cout.precision(16);
        srand((unsigned) clock() + (unsigned) time(NULL));
    };
} __initon;
//衝突対策
#define ws ___ws
struct T {
    int f, s, t;
    T() { f = -1, s = -1, t = -1; }
    T(int f, int s, int t) : f(f), s(s), t(t) {}
    bool operator<(const T &r) const {
        return f != r.f ? f < r.f : s != r.s ? s < r.s : t < r.t;
        //return f != r.f ? f > r.f : s != r.s ? s > r.s : t > r.t; 大きい順
    }
    bool operator>(const T &r) const {
        return f != r.f ? f > r.f : s != r.s ? s > r.s : t > r.t;
        //return f != r.f ? f > r.f : s != r.s ? s > r.s : t > r.t; 小さい順
    }
    bool operator==(const T &r) const {
        return f == r.f && s == r.s && t == r.t;
    }
    bool operator!=(const T &r) const {
        return f != r.f || s != r.s || t != r.t;
    }
    int operator[](int i) {
        assert(i < 3);
        return i == 0 ? f : i == 1 ? s : t;
    }
};
#define over4(o1, o2, o3, o4, name, ...) name

#define int long long
#define ll long long
#define double long double
#define ull unsigned long long
using dou = double;
using itn = int;
using str = string;
using bo= bool;
#define au auto
using P = pair<ll, ll>;

#define fi first
#define se second
#define vec vector
#define beg begin
#define rbeg rbegin
#define con continue
#define bre break
#define brk break
#define is ==
using vi = vector<ll>;
using vb = vector<bool>;
using vs = vector<string>;
using vd = vector<double>;
using vc = vector<char>;
using vp = vector<P>;
using vt = vector<T>;

//#define V vector
#define vvt0(t) vector<vector<t>>
#define vvt1(t, a) vector<vector<t>>a
#define vvt2(t, a, b) vector<vector<t>>a(b)
#define vvt3(t, a, b, c) vector<vector<t>> a(b,vector<t>(c))
#define vvt4(t, a, b, c, d) vector<vector<t>> a(b,vector<t>(c,d))

#define vvi(...) over4(__VA_ARGS__,vvt4,vvt3,vvt2 ,vvt1,vvt0)(ll,__VA_ARGS__)
#define vvb(...) over4(__VA_ARGS__,vvt4,vvt3,vvt2 ,vvt1,vvt0)(bool,__VA_ARGS__)
#define vvs(...) over4(__VA_ARGS__,vvt4,vvt3,vvt2 ,vvt1,vvt0)(string,__VA_ARGS__)
#define vvd(...) over4(__VA_ARGS__,vvt4,vvt3,vvt2 ,vvt1,vvt0)(double,__VA_ARGS__)
#define vvc(...) over4(__VA_ARGS__,vvt4,vvt3,vvt2 ,vvt1,vvt0)(char,__VA_ARGS__)
#define vvp(...) over4(__VA_ARGS__,vvt4,vvt3,vvt2 ,vvt1,vvt0)(P,__VA_ARGS__)


#define v3i(a, b, c, d) vector<vector<vi>> a(b, vector<vi>(c, vi(d)))
#define v3d(a, b, c, d) vector<vector<vd>> a(b, vector<vd>(c, vd(d)))
#define v3m(a, b, c, d) vector<vector<vm>> a(b, vector<vm>(c, vm(d)))


#define PQ priority_queue<ll, vector<ll>, greater<ll> >
#define tos to_string
using mapi = map<int, int>;
using mapd = map<dou, int>;
using mapc = map<char, int>;
using maps = map<str, int>;
using seti = set<int>;
using setd = set<dou>;
using setc = set<char>;
using sets = set<str>;
using qui = queue<int>;
#define bset bitset
#define uset unordered_set
#define mset multiset
#define umap unordered_map
#define umapi unordered_map<int,int>
#define umapp unordered_map<P,int>
#define mmap multimap

//マクロ 繰り返し
#define _overloadrep(_1, _2, _3, _4, name, ...) name
# define _rep(i, n) for(int i = 0,_lim=n; i < _lim ; i++)
#define repi(i, m, n) for(int i = m,_lim=n; i < _lim ; i++)
#define repadd(i, m, n, ad) for(int i = m,_lim=n; i < _lim ; i+= ad)
#define rep(...) _overloadrep(__VA_ARGS__,repadd,repi,_rep,)(__VA_ARGS__)
#define _rer(i, n) for(int i = n; i >= 0 ; i--)
#define reri(i, m, n) for(int i = m,_lim=n; i >= _lim ; i--)
#define rerdec(i, m, n, dec) for(int i = m,_lim=n; i >= _lim ; i-=dec)
#define rer(...) _overloadrep(__VA_ARGS__,rerdec,reri,_rer,)(__VA_ARGS__)
#define fora(a, b) for(auto&& a : b)

//マクロ 定数
#define k3 1010
#define k4 10101
#define k5 101010
#define k6 1010101
#define k7 10101010
template<class T> T MAX() { return numeric_limits<T>::max(); }
template<class T> T MIN() { return numeric_limits<T>::min(); }
const int inf = (int) 1e9 + 100;
const ll linf = (ll) 1e18 + 100;
template<class T> T INF() { return MAX<T>() / 2; }
template<> signed INF() { return inf; }
template<> ll INF() { return linf; }
template<> double INF() { return (double) linf * linf; }

const double eps = 1e-9;
const double PI = 3.1415926535897932384626433832795029L;
ll ma = numeric_limits<ll>::min();
ll mi = numeric_limits<ll>::max();
const int y4[] = {-1, 1, 0, 0};
const int x4[] = {0, 0, -1, 1};
const int y8[] = {0, 1, 0, -1, -1, 1, 1, -1};
const int x8[] = {1, 0, -1, 0, 1, -1, 1, -1};

//マクロ省略形 関数等
#define arsz(a) (sizeof(a)/sizeof(a[0]))
#define sz(a) ((int)(a).size())
#define rs resize
#define mp make_pair
#define pb push_back
#define pf push_front
#define eb emplace_back
#define all(a) (a).begin(),(a).end()
#define rall(a) (a).rbegin(),(a).rend()


ll gcd(ll a, ll b) { return b ? gcd(b, a % b) : a; }
ll gcd(vi b) {
    ll res = b[0];
    for (auto &&v :b)res = gcd(v, res);
    return res;
}
ll lcm(ll a, ll b) { return a / gcd(a, b) * b; }
ll rev(ll a) {
    ll res = 0;
    while (a) {
        res *= 10;
        res += a % 10;
        a /= 10;
    }
    return res;
}
template<class T> void rev(vector<T> &a) {
    reverse(all(a));
}
void rev(string &a) {
    reverse(all(a));
}
ll ceil(ll a, ll b) {
    if (b == 0) {
        return -1;
    } else return (a + b - 1) / b;
}
ll sqrt(ll a) {
    if (a < 0) {
        assert(0==1);
    }
    ll res = (ll) std::sqrt(a);
    while (res * res < a)res++;
    return res;
}
double log(double e, double x) { return log(x) / log(e); }
ll sig(ll t) { return (1 + t) * t / 2; }
ll sig(ll s, ll t) { return (s + t) * (t - s + 1) / 2; }

vi divisors(int v) {
    vi res;
    double lim = std::sqrt(v);
    for (int i = 1; i <= lim; ++i) {
        if (v % i == 0) {
            res.pb(i);
            if (i != v / i)res.pb(v / i);
        }
    }
    return res;
}

vb isPrime;
vi primes;

void setPrime() {
    int len = 4010101;
    isPrime.resize(4010101);
//    fill(isPrime, true);
    isPrime[0] = isPrime[1] = false;
    for (int i = 2; i <= sqrt(len) + 5; ++i) {
        if (!isPrime[i])continue;
        for (int j = 2; i * j < len; ++j) {
            isPrime[i * j] = false;
        }
    }
    rep(i, len)if (isPrime[i])primes.pb(i);
}

vi factorization(int v) {
    int tv = v;
    vi res;
    if (isPrime.size() == 0)setPrime();
    for (auto &&p :primes) {
        if (v % p == 0)res.push_back(p);
        while (v % p == 0) {
            v /= p;
        }
        if (v == 1 || p * p > tv)break;
    }
    if (v > 1)res.pb(v);
    return res;
}
inline bool inside(int h, int w, int H, int W) { return h >= 0 && w >= 0 && h < H && w < W; }
inline bool inside(int v, int l, int r) { return l <= v && v < r; }

template<class T> struct ruiC {
    vector<T> rui;
    ruiC(vector<T> &ru) : rui(ru) {}
    /*先頭0*/
    ruiC() : rui(1, 0) {}
    T operator()(ll l, ll r) {
        if (l > r) {
            cerr << "ruic ";
//            deb(l, r);
            assert(0);
        }
        return rui[r] - rui[l];
    }
    T operator()(int r = inf) { return operator()(0, min(r, sz(rui) - 1)); }
    T operator[](ll i) { return rui[i]; }
    /*0から順に追加される必要がある*/
    void operator+=(T v) { rui.push_back(rui.back() + v); }
    void add(int i, T v) {
//        if (sz(rui) - 1 != i)ole();
        operator+=(v);
    }
    T back() { return rui.back(); }
    ll size() { return rui.size(); }
    auto begin() { return rui.begin(); }
    auto end() { return rui.end(); }
};
template<class T> ostream &operator<<(ostream &os, ruiC<T> a) {
    fora(v, a.rui)os << v << " ";
    return os;
}
template<class T> vector<T> ruiv(vector<T> &a) {
    vector<T> ret(a.size() + 1);
    rep(i, a.size())ret[i + 1] = ret[i] + a[i];
    return ret;
}
template<class T> ruiC<T> ruic(vector<T> &a) {
    vector<T> ret = ruiv(a);
    return ruiC<T>(ret);
}
template<class T> ruiC<T> ruic() { return ruiC<T>(); }
//imoは0-indexed
//ruiは1-indexed
template<class T> vector<T> imo(vector<T> &v) {
    vector<T> ret = v;
    rep(i, sz(ret) - 1)ret[i + 1] += ret[i];
    return ret;
}

#define ins inside
ll u(ll a) { return a < 0 ? 0 : a; }
template<class T> vector<T> u(const vector<T> &a) {
    vector<T> ret = a;
    fora(v, ret)v = u(v);
    return ret;
}
#define MIN(a) numeric_limits<a>::min()
#define MAX(a) numeric_limits<a>::max()

void yn(bool a) {
    if (a)cout << "yes" << endl;
    else cout << "no" << endl;
}
void Yn(bool a) {
    if (a)cout << "Yes" << endl;
    else cout << "No" << endl;
}
void YN(bool a) {
    if (a)cout << "YES" << endl;
    else cout << "NO" << endl;
}
void fyn(bool a) {
    if (a)cout << "yes" << endl;
    else cout << "no" << endl;
    exit(0);
}
void fYn(bool a) {
    if (a)cout << "Yes" << endl;
    else cout << "No" << endl;
    exit(0);
}
void fYN(bool a) {
    if (a)cout << "YES" << endl;
    else cout << "NO" << endl;
    exit(0);
}
void Possible(bool a) {
    if (a)cout << "Possible" << endl;
    else cout << "Impossible" << endl;
    exit(0);
}
void POSSIBLE(bool a) {
    if (a)cout << "POSSIBLE" << endl;
    else cout << "IMPOSSIBLE" << endl;
    exit(0);
}
template<class T, class U> set<T> &operator+=(set<T> &a, U v) {
    a.insert(v);
    return a;
}
template<class T, class U> vector<T> &operator+=(vector<T> &a, U v) {
    a.pb(v);
    return a;
}
template<class T> T sum(vector<T> &v, int s = 0, int t = inf) {
    T ret = 0;
    rep(i, s, min(sz(v), t))ret += v[i];
    return ret;
}
void mod(int &a, int m) { a = (a % m + m) % m; }
template<class F> inline int mgr(int ok, int ng, F f) {
#define _mgrbody int mid = (ok + ng) / 2; if (f(mid))ok = mid; else ng = mid;
    if (ok < ng)while (ng - ok > 1) { _mgrbody } else while (ok - ng > 1) { _mgrbody }
    return ok;
}

template<class F> inline int mgr(int ok, int ng, int second, F f) {
#define _mgrbody2 int mid = (ok + ng) / 2; if (f(mid, second))ok = mid; else ng = mid;
    if (ok < ng) while (ng - ok > 1) { _mgrbody2 } else while (ok - ng > 1) { _mgrbody2 }
    return ok;
}
template<typename T> ostream &operator<<(ostream &os, vector<T> &m) {
    for (auto &&v:m) os << v << " ";
    return os;
}
constexpr bool bget(ll m, int keta) { return (m >> keta) & 1; }
int bget(ll m, int keta, int sinsuu) {
    m /= (ll) pow(sinsuu, keta);
    return m % sinsuu;
}
ll bit(int n) { return (1LL << (n)); }
ll bit(int n, int sinsuu) { return (ll) pow(sinsuu, n); }
int mask(int n) { return (1ll << n) - 1; }
#define bcou __builtin_popcountll
template<class T, class U> inline bool chma(T &a, const U &b) {
    if (a < b) {
        a = b;
        return true;
    }
    return false;
}
template<class U> inline bool chma(const U &b) { return chma(ma, b); }
template<class T, class U> inline bool chmi(T &a, const U &b) {
    if (b < a) {
        a = b;
        return true;
    }
    return false;
}
template<class U> inline bool chmi(const U &b) { return chmi(mi, b); }
#define unique(v) v.erase( unique(v.begin(), v.end()), v.end() );
int max(vi &a) {
    int res = a[0];
    fora(v, a) {
        res = max(res, v);
    }
    return res;
}
int min(vi &a) {
    int res = a[0];
    fora(v, a) {
        res = min(res, v);
    }
    return res;
}
/*@formatter:off*/
template<typename T> class fixed_point        : T {public:    explicit constexpr fixed_point(T &&t) noexcept: T(std::forward<T>(t)) {}    template<typename... Args> constexpr decltype(auto) operator()(Args &&... args) const { return T::operator()(*this, std::forward<Args>(args)...); }};template<typename T> static inline constexpr decltype(auto) fix(T &&t) noexcept { return fixed_point<T>{std::forward<T>(t)}; }
constexpr ll h4[] = {1, -1, 0, 0};
constexpr ll w4[] = {0, 0, -1, 1};
constexpr ll h8[] = {0, 1, 0, -1, -1, 1, 1, -1};
constexpr ll w8[] = {1, 0, -1, 0, 1, -1, 1, -1};
int mei_inc(int h, int w, int H, int W, int i) {while (++i < 4) { if (inside(h + h4[i], w + w4[i], H, W))return i; }return i;}
#define mei(nh, nw, h, w) for (int i = mei_inc(h, w, H, W, -1), nh = i<4? h + h4[i] : 0, nw = i<4? w + w4[i] : 0; i < 4; i=mei_inc(h,w,H,W,i), nh = h+h4[i], nw = w+w4[i])
int mei_inc8(int h, int w, int H, int W, int i) {    while (++i < 8) {        if (inside(h + h8[i], w + w8[i], H, W))return i;    }    return i;}
#define mei8(nh, nw, h, w) for (int i = mei_inc8(h, w, H, W, -1), nh = i<8? h + h8[i] : 0, nw = i<8? w + w8[i] : 0; i < 8; i=mei_inc8(h,w,H,W,i), nh = h+h8[i], nw = w+w8[i])
int mei_incv(int h, int w, int H, int W, int i, vp &p) {    while (++i < sz(p)) { if (inside(h + p[i].fi, w + p[i].se, H, W))return i; }    return i;}
#define meiv(nh, nw, h, w, p) for (int i = mei_incv(h, w, H, W, -1, p), nh = i<sz(p)? h + p[i].fi : 0, nw = i<sz(p)? w + p[i].se : 0; i < sz(p); i=mei_incv(h,w,H,W,i,p), nh = h+p[i].fi, nw = w+p[i].se)

template<class T> void out2(T head) {    cout << head;}
template<class T, class... U> void out2(T head, U ... tail) {    cout << head << " ";      out2(tail...);}
template<class T, class... U> void out(T head, U ... tail) {    cout << head << " ";        out2(tail...);    cout << "" << endl;}
template<class T> void out(T head) {    cout << head << endl; }
void out() { cout << "" << endl; }


/*@formatter:on*/
int N, M, H, W;
vi A, B, C;
/*@formatter:off*/
//整数用幾何ライブラリ   *@formatter:off*/
vp ort_next_ = {{1, 0}, {0,  1}, {-1, 0}, {0,  -1}, {1,  0}};
vp ort_prev_ = {{1, 0}, {1,  0}, {0, 1}, {-1,  0}, {0,  -1}};
class D {
public:
    int x, y;
    D(): x(0), y(0) {}
    D(int x, int y): x(x), y(y) {}
    D(P p): x(p.first), y(p.second){}
    D& operator+=( D& v) { x += v.x; y += v.y; return *this;}
    D operator+( D& v)  { return D(*this) += v;}
    D& operator-=( D& v) { x -= v.x; y -= v.y; return *this;}
    D operator-( D& v)  { return D(*this) -= v;}
    D& operator*=(int s) { x *= s; y *= s; return *this;}
    D operator*(int s)  { return D(*this) *= s;}
    D& operator/=(int s) { x /= s; y /= s; return *this;}
    D operator/(int s)  { return D(*this) /= s;}
    bool operator==(D & v) {return x == v.x && y == v.y;}
    bool operator!=(D & v) {return !operator==(v);}
    //内積
    int dot( D& v)  { return x*v.x + y*v.y;}
    //外積
    int cross( D& v)  { return x*v.y - v.x*y;}
    int cross( int rx,int ry)  { return x*ry - rx*y;}
    //距離の2乗
    int norm2()  { return x*x + y*y;}
    double norm()  { return sqrt(norm2());}
    //単位ベクトルを返す
    D unit(){return (*this)/ norm();}
    // 象限
    int ort()  {        if (abs(x) < eps && abs(y) <= eps) return 0;        if (y > 0) return x>0 ? 1 : 2;        else return x<0 ? 3 : 4;    }
    int ort(int x,int y)  {        if (abs(x) < eps && abs(y) <= eps) return 0;        if (y > 0) return x>0 ? 1 : 2;        else return x<0 ? 3 : 4;    }
    //偏角でソート出来る
    bool operator<(const D &v) const {return x == v.x ? y < v.y : x < v.x;}
    bool operator>(D &v) {return x == v.x ? y > v.y : x > v.x;}
    /*@formatter:off*/
    //反時計回りで隣接する象限との境界にある、長さ1の点を返す
    //(+,+)で呼ぶと(0, 1)が返る
    D ort_bound_next(){        int i=ort();        assert(i);        return D(ort_next_[i]);    }
    //時計回り
    D ort_bound_prev(){        int i=ort();        assert(i);        return D(ort_prev_[i]);    }
};
//反時計回り
class rot {//@formatter:off
    vector<vc> pre;//今が斜めでないときは使えない
    int preAdd=0;    void rot90() {        preAdd += 2;        swap(H, W);        vvc(nv, H, W);        rep(fh, W) {            rep(fw, H) {                int th = H - fw - 1;                int tw = fh;                nv[th][tw] = v[fh][fw];            }        }        swap(v, nv);    }    void rot180() {        preAdd += 4;        vvc(nv, H, W);        rep(fh, H) {            rep(fw, W) {                int th = H - fh - 1;                int tw = W - fw - 1;                nv[th][tw] = v[fh][fw];            }        }        swap(v, nv);    }    void rot270() {        preAdd += 6;        swap(H, W);        vvc(nv, H, W);        rep(fh, W) {            rep(fw, H) {                int th = fw;                int tw = W - 1 - fh;                nv[th][tw] = v[fh][fw];            }        }        swap(v, nv);    }
public:
    vector<vc> v;
    int H, W;
    bool naname = 0;
    rot(vector<vc> &b) : v(b), H(sz(b)), W(sz(b[0])) {}
    P rot45(int h, int w) { return P(h - w + W - 1, h + w); }
    P rot45_rev(int h, int w) { return P(h + w, -h + w + H - 1); }
    rot &operator++() {        /*preを90度回転させる*/        if (naname) {            H = sz(pre[0]);            W = sz(pre);            vvc(nv, H, W);            rep(fh, W) {                rep(fw, H) {                    int th = H - fw - 1;                    int tw = fh;                    nv[th][tw] = pre[fh][fw];                }            }            swap(pre, v);            swap(v, nv);            naname ^= 1;            operator+=(preAdd);            preAdd = 0;            return *this;        } else {            int NH = H + W - 1;            int NW = H + W - 1;            vvc(a, NH, NW);            /*h += Wとする*/            rep(h, H) {                rep(w, W) {                    int nh, nw;                    tie(nh, nw) = rot45(h, w);                    a[nh][nw] = v[h][w];                }            }            swap(a, v);            swap(pre, a);            H = NH;            W = NW;            naname ^= 1;            return *this;        }    }
    rot operator++(signed) {        rot ret = *this;        operator++();        return ret;    }
    rot operator+(int k) {        rot ret = *this;        ret.operator+=(k);        return ret;    }
    void operator+=(int k) {        k %= 8;        if (k >= 6) {            rot270();            k -= 6;        } else if (k >= 4) {            rot180();            k -= 4;        } else if (k >= 2) {            rot90();            k -= 2;        }        if (k)operator++();    }
    /*反時計回りで統一しないと、preがおかしくなる*/
    /*preを廃止して遷移するのは実装がつらい上に見返りが少なそう*/
    /*必要になったら作る*/
    rot &operator--() {        rot270();        return operator++();    }
    rot operator--(signed) {        rot ret = *this;        operator--();        return ret;    }
    rot operator-(int k) {        rot ret = *this;        ret.operator-=(k);        return ret;    }
    void operator-=(int k) { operator+=(((-k % 8) + 8) % 8); }
    int size() { return H; }
    vector<vector<char>>& operator()(){return v;}
    vc &operator[](int i) { return v[i]; }
    operator vector<vc> &() { return v; }
};
ostream &operator<<(ostream &os, rot &v) {os << v.v;return os;}
using dots = vector<D>;
//線分
struct E { D f, t; E(D f = D(), D t = D()) : f(f), t(t) {}};
bool eq(dots &a, dots &b) {    if (sz(a) != sz(b))return false;    rep(i, sz(a)) { if (a[i] != b[i])return false; }    return true;}
//fを中心として、tを90*inc度 反時計回りに回転
D rot90(D &f, D &t, int inc) {    inc %= 4;    D ret = t - f;    if (inc < 0) {        while (inc) {            ret = D(ret.y, -ret.x);            inc++;        }    } else if (inc > 0) {        while (inc > 0) {            ret = D(-ret.y, ret.x);            inc--;        }    }    return f + ret;}
dots rot90(D &f, dots &t, int inc) {    int N = sz(t);    dots res(N);    rep(i, N) { res[i] = rot90(f, t[i], inc); }    return res;}
istream &operator>>(istream &ist, D &v) {    ist >> v.x >> v.y;    return ist;}ostream &operator<<(ostream &os, D &v) {    os << "(" << v.x << "," << v.y << ")";    return os;}
vector<D> operator-=(dots &a, D &b) {    fora(v, a) { v -= b; }    return a;}
vector<D> operator-(dots &a, D &b) {    dots c(sz(a));    int i = 0;    fora(v, a) { c[i++] = v - b; }    return c;}
/*@formatter:on*/
//反時計回り

//反時計回り

void solve() {
    while (1) {
        int N;
        cin>>N;
        if (N == 0)break;
        vector<dots> ds(N + 1);
        vb ok(N + 1);
        rep(i, N + 1) {
            int len;
            cin>>len;
            ds[i].resize(len);
            rep(j, len) {
                cin >> ds[i][j];
            }
//            na(ds[i], len);
            if (i) {
                auto dec = ds[i][0] - ds[0][0];
                fora(v, ds[i]) {
                    v -= dec;
                }
            }
        }
////        \deb(ds);
        rep(i, 1, N + 1) {
            rep(r, 4) {
                ds[i] = rot90(ds[i][0], ds[i], 1);
                if (eq(ds[i], ds[0])) {
                    ok[i] = 1;
//                    out(i);
                    break;
                }
            }
        }
        //
        rep(i, sz(ds[0]) / 2)swap(ds[0][i], ds[0][sz(ds[0]) - 1 - i]);
//        ds[0] = rev(ds[0]);
        rep(i, N + 1) {
            if (i) {
                auto dec = ds[i][0] - ds[0][0];
                fora(v, ds[i]) {
                    v -= dec;
                }
            }
        }
////        \deb(ds);
        rep(i, 1, N + 1) {
            rep(r, 4) {
                ds[i] = rot90(ds[i][0], ds[i], 1);
                if (eq(ds[i], ds[0])) {
                    ok[i] = 1;
//                    out(i);
                    break;
                }
            }
        }
        rep(i, 1, N + 1) {
            if (ok[i])out(i);
        }
        out("+++++");
    }


}


signed main() {
    solve();
    return 0;
}
