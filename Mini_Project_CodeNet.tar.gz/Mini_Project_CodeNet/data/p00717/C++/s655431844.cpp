#include <iostream>
#include <algorithm>
#include <vector>
#include <stack>
#include <queue>
#include <map>
#include <cmath>
#include <string>
#include <sstream>
#include <iomanip>
#include <complex>
using namespace std;

#define ll long long
#define vvi vector< vector<int> >
#define vi vector<int>
#define All(X) X.begin(),X.end()
#define FOR(i,a,b) for(int i=(int)(a);i<(int)(b);i++)
#define REP(i,n) for(int i=0;i<(int)(n);i++)
#define pb push_back
#define pii pair<int,int>
#define mp make_pair
#define pi 3.14159265359
#define shosu(X) fixed << setprecision(X)
ll gcd(ll a,ll b){return b?gcd(b,a%b):a;}
ll lcm(ll a,ll b){return a/gcd(a,b)*b;}

int GetDir(int x1,int y1,int x2,int y2){
	if(x1<x2) return 1;//right
	else if(x1>x2) return 3;//left
	else if(y1>y2) return 4;//down
	else if(y1<y2) return 2;//up
	return 0;
}
vi GetMageData(vi x,vi y){
	vi rst;
	int olddir = GetDir(x[0],y[0],x[1],y[1]);
	FOR(i,1,x.size()){
		int newdir = GetDir(x[i],y[i],x[i+1],y[i+1]);
		int mage;
		if(olddir==1){
			if(newdir==2) mage=1;//hantai
			else mage = 0;//clock
		}else if(olddir==2){
			if(newdir==3) mage=1;
			else mage = 0;
		}else if(olddir==3){
			if(newdir==4) mage=1;
			else mage = 0;
		}else{
			if(newdir==1) mage=1;
			else mage=0;
		}
		rst.pb(mage);
		olddir = newdir;
	}
	return rst;
}

vi GetDisData(vi x,vi y){
	vi rst;
	int sx = 0,sy = 0;
	FOR(i,1,x.size()){
		x[i] -= x[0];
		y[i] -= y[0];
	}
	x[0] = 0; y[0] = 0;
	FOR(i,1,x.size()){
		rst.pb((x[i]-sx)*(x[i]-sx)+(y[i]-sy)*(y[i]-sy));
		sx = x[i]; sy  =y[i];
	}
	return rst;
}
int main(){
	int n;
	vi len01,mag01,len02,mag02;
	int num0;
	while(1){
		cin >> n;
		if(n==0) break;
		//0
		vi tx,ty,tx2,ty2;
		cin >> num0;
		REP(i,num0){
			int xx,yy;
			cin >> xx >> yy;
			tx.pb(xx);
			ty.pb(yy);
		}
		len01.clear();
		len02.clear();
		mag02.clear();
		mag02.clear();

		tx2 = tx,ty2 = ty;
		len01 = GetDisData(tx,ty);
		mag01 = GetMageData(tx,ty);
		reverse(All(tx2));
		reverse(All(ty2));
		len02 = GetDisData(tx2,ty2);
		mag02 = GetMageData(tx2,ty2);

		/*REP(kk,len01.size()){
			cout << len01[kk] << " ";
		}
		cout << endl;
		REP(kk,mag01.size()){
			cout << mag01[kk] << " ";
		}
		cout << endl;
		REP(kk,len02.size()){
			cout << len02[kk] << " ";
		}
		cout << endl;
		REP(kk,mag02.size()){
			cout << mag02[kk] << " ";
		}
		cout <<"hogehogehoge"<< endl;*/

		REP(i,n){
			int k;
			vi l,m;
			vi dx,dy;
			cin >> k;
			REP(j,k){
				int xxx,yyy;
				cin >> xxx >> yyy;
				dx.pb(xxx); dy.pb(yyy);
			}
			l = GetDisData(dx,dy);
			m = GetMageData(dx,dy);

			/*REP(kk,l.size()){
				cout << l[kk] << " ";
			}
			cout << endl;
			REP(kk,m.size()){
				cout << m[kk] << " ";
			}
			cout << endl;*/
			bool flg = false;
			if(l==len01&&m==mag01) flg = true;
			if(l==len02&&m==mag02) flg = true;
			if(flg) cout << i+1 << endl;
		}
		cout << "+++++" << endl;
	}
}