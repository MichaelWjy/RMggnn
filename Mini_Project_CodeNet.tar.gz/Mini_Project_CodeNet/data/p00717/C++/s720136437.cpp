#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;
#define REP(i, a, n) for(int i=a; i<n; i++)
#define RREP(i, a, n) for(int i=n-1; i>=a; i--)

int th90[2][2] = { {0, -1}, {1, 0} };
int main() {
	int n;
	while (cin >> n, n) {
		vector<pair<int, int>> origin;
		int m, y[11], x[11];
		cin >> m;
		REP(i, 0, m) cin >> x[i] >> y[i];
		REP(i, 0, m - 1) {
			origin.emplace_back(y[i + 1] - y[i], x[i + 1] - x[i]);
		}

		REP(i, 0, n) {
			vector<pair<int, int>> tmp;
			cin >> m;
			REP(j, 0, m) cin >> x[j] >> y[j];
			REP(j, 0, m - 1) {
				tmp.emplace_back(y[j + 1] - y[j], x[j + 1] - x[j]);
			}

			if (origin.size() != tmp.size()) continue;
			
			bool match = false;
			REP(j, 0, 4) {
				bool flag = true;

				REP(k, 0, origin.size()) {
					int yy = tmp[k].first, xx = tmp[k].second;
					REP(l, 0, j) {
						int yyy = yy, xxx = xx;
						xx = th90[0][0] * xxx + th90[0][1] * yyy;
						yy = th90[1][0] * xxx + th90[1][1] * yyy;
					}

					if (origin[k].first != yy || origin[k].second != xx) {
						flag = false;
						break;
					}
				}

				if (flag) {
					match = true;
					break;
				}
			}

			if (match) {
				cout << i + 1 << endl;
				continue;
			}

			match = false;
			REP(j, 0, 4) {
				bool flag = true;

				RREP(k, 0, origin.size()) {
					int yy = tmp[k].first, xx = tmp[k].second;
					REP(l, 0, j) {
						int yyy = yy, xxx = xx;
						xx = th90[0][0] * xxx + th90[0][1] * yyy;
						yy = th90[1][0] * xxx + th90[1][1] * yyy;
					}

					if (origin[origin.size() - 1 - k].first != yy || origin[origin.size() - 1 - k].second != xx) {
						flag = false;
						break;
					}
				}

				if (flag) {
					match = true;
					break;
				}
			}

			if (match) cout << i + 1 << endl;
		}

		cout << "+++++" << endl;
	}
	return 0;
}