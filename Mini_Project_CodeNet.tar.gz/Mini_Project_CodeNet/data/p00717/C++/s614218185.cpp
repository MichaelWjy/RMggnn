#include<bits/stdc++.h>
#define rep(i,n)for(int i=0;i<n;i++)
using namespace std;
typedef pair<int, int>P;

vector<int>x[51], y[51];

bool judge(int a) {
	if (x[0].size() != x[a].size())return false;
	rep(i, 4) {
		swap(x[a], y[a]);
		for (int&k : x[a])k = -k;
		int d1 = x[a][0], d2 = y[a][0];
		for (int&k : x[a])k -= d1;
		for (int&k : y[a])k -= d2;
		bool ok = true;
		rep(i, x[0].size()) {
			if (x[0][i] != x[a][i] || y[0][i] != y[a][i]) {
				ok = false; break;
			}
		}
		if (ok)return true;
	}
	return false;
}
int main() {
	int n;
	while (scanf("%d", &n), n) {
		rep(i, n + 1) {
			int m; scanf("%d", &m);
			x[i] = y[i] = vector<int>(m);
			rep(j, m)scanf("%d%d", &x[i][j], &y[i][j]);
		}
		judge(0);
		for (int i = 1; i <= n; i++) {
			if (judge(i)) {
				printf("%d\n", i); continue;
			}
			reverse(x[i].begin(), x[i].end());
			reverse(y[i].begin(), y[i].end());
			if (judge(i)) {
				printf("%d\n", i);
			}
		}
		puts("+++++");
	}
}