#include <bits/stdc++.h>
using namespace std;
#define pp pair<int,int>
#define rep(i,n) for(int (i)=0;(i)<(n);(i)++)
#define ll long long
#define ld long double
#define all(a) (a).begin(),(a).end()
#define mk make_pair
ll MOD=1000000007;
int inf=1000001000;
ll INF=100000000000000000;


int main() {
    while(true){
        int n;
        cin >> n;
        if (n==0) break;
        int m1;
        cin >> m1;
        int x1,y1;
        cin >> x1 >> y1;
        vector<pp> b(m1-1),bb(m1-1);
        int ty;
        vector<pp> z(m1-1);
        z[m1-2]=mk(x1,y1);
        int x3,y3;
        rep(i,m1-1){
            int x,y;
            cin >> x >> y;
            if (i==m1-2) {x3=x;y3=y;}
            else z[m1-3-i]=mk(x,y);
            x=x-x1;y=y-y1;
            if (i==0){
                if (x>0) ty=0;
                if (x<0) ty=1;
                if (y>0) ty=2;
                if (y<0) ty=3;
            }
            if (ty==1){
                x*=-1;
                y*=-1;
            }
            if (ty==2){
                swap(x,y);
                y*=-1;
            }
            if (ty==3){
                swap(x,y);
                x*=-1;
            }
            b[i]=mk(x,y);
        }
        rep(i,m1-1){
            int x,y;
            x=z[i].first-x3;y=z[i].second-y3;
            if (i==0){
                if (x>0) ty=0;
                if (x<0) ty=1;
                if (y>0) ty=2;
                if (y<0) ty=3;
            }
            if (ty==1){
                x*=-1;
                y*=-1;
            }
            if (ty==2){
                swap(x,y);
                y*=-1;
            }
            if (ty==3){
                swap(x,y);
                x*=-1;
            }
            bb[i]=mk(x,y);
        }
        rep(h,n){
        int m2;
        cin >> m2;
        bool t=true,tt=true;
        if (m2!=m1) {t=false;tt=false;}
        int x2,y2;
        cin >> x2 >> y2;
        int tyy;
        rep(i,m2-1){
            int x,y;
            cin >> x >> y;
            x=x-x2;y=y-y2;
            if (i==0){
                if (x>0) tyy=0;
                if (x<0) tyy=1;
                if (y>0) tyy=2;
                if (y<0) tyy=3;
            }
            if (tyy==1){
                x*=-1;
                y*=-1;
            }
            if (tyy==2){
                swap(x,y);
                y*=-1;
            }
            if (tyy==3){
                swap(x,y);
                x*=-1;
            }
            if (b[i]!=mk(x,y)) t=false;
            if (bb[i]!=mk(x,y)) tt=false;
        }
        if (t || tt) {cout << h+1 << endl;}
    }
    cout << "+++++" << endl;
}}


