#include "bits/stdc++.h"

using namespace std;

using ll = long long;
using ld = long double;
using P = pair<int, int>;
constexpr ld EPS = 1e-12;
constexpr int INF = numeric_limits<int>::max() / 2;
constexpr int MOD = 1e9 + 7;

int main()
{
    cin.tie(0);
    ios::sync_with_stdio(false);

    int n;
    while (cin >> n, n)
    {
        int m;
        cin >> m;
        vector<vector<P>> v(8, vector<P>(m));
        for (int i = 0; i < m; i++)
        {
            int x, y;
            cin >> x >> y;
            v[0][i] = P(x, y);
        }
        for (int i = 0; i < m; i++)
        {
            v[4][i] = v[0][m - 1 - i];
        }
        for (int i = 1; i < m; i++)
        {
            v[0][i].first -= v[0][0].first;
            v[0][i].second -= v[0][0].second;
        }
        v[0][0] = P(0, 0);
        for (int i = 1; i < 4; i++)
        {
            for (int j = 1; j < m; j++)
            {
                v[i][j].first = -v[i - 1][j].second;
                v[i][j].second = v[i - 1][j].first;
            }
        }
        for (int i = 1; i < m; i++)
        {
            v[4][i].first -= v[4][0].first;
            v[4][i].second -= v[4][0].second;
        }
        v[4][0] = P(0, 0);
        for (int i = 5; i < 8; i++)
        {
            for (int j = 1; j < m; j++)
            {
                v[i][j].first = -v[i - 1][j].second;
                v[i][j].second = v[i - 1][j].first;
            }
        }
        for (int i = 1; i <= n; i++)
        {
            int m2;
            cin >> m2;
            vector<P> w(m2);
            for (int j = 0; j < m2; j++)
            {
                int x, y;
                cin >> x >> y;
                w[j] = P(x, y);
                if (j != 0)
                {
                    w[j].first -= w[0].first;
                    w[j].second -= w[0].second;
                }
            }
            w[0] = P(0, 0);
            bool f = false;
            for (int j = 0; j < 8; j++)
            {
                if (v[j] == w)
                    f = true;
            }
            if (f)
                cout << i << endl;
        }
        for (int i = 0; i < 5; i++)
            cout << "+";
        cout << endl;
    }
}

