#include <iostream>
#include <utility>
#include <string>
#include <cstring>
#include <vector>
#include <map>
#include <algorithm>

using namespace std;

#define rep(i, n) for(int i = 0; i < (int)(n); ++i)

pair<int, int> rotate(pair<int, int> p) {
  return pair<int, int>( p.second, -p.first );
}

pair<int, int> diff(pair<int, int> a, pair<int, int> b) {
  return pair<int, int>( a.first - b.first, a.second - b.second );
}

int main()
{
  int n;
  while(cin >> n, n) {
    vector<vector<pair<int, int>>> list;
    rep(i, n + 1) {
      vector<pair<int, int>> lines;
      int m;
      cin >> m;
      rep(j, m) {
        int x, y;
        cin >> x >> y;
        lines.push_back(pair<int, int>(x, y));
      }
      list.push_back(lines);
    }

    vector<vector<pair<int, int>>> keys;
    vector<pair<int, int>> key = list[0];
    rep(i, 4) {
      keys.push_back(key);
      rep(j, key.size()) {
        key[j] = rotate(key[j]);
      }
    }

    for(int i = 1; i <= n; ++i) {
      bool ok = false;
      if( list[0].size() != list[i].size() ) continue;
      int len = list[0].size();
      rep(j, 4) {
        bool flag = true;
        pair<int, int> atom = diff(list[i][0], keys[j][0]);
        rep(k, len) {
          flag &= atom == diff(list[i][k], keys[j][k]);
        }
        ok |= flag;
        flag = true;
        atom = diff(list[i][len - 1], keys[j][0]);
        rep(k, len) {
          flag &= atom == diff(list[i][len - 1 - k], keys[j][k]);
        }
        ok |= flag;
      }
      if(ok) {
        cout << i << endl;
      }
    }

    cout << "+++++" << endl;
  }

  return 0;
}