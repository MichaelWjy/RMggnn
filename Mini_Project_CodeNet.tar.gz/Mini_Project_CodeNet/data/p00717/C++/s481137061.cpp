#include<iostream>

#define rep(i,n) for(int i=0; i<n; i++)

int main(){
	int n;
	int m;
	int x[100][10], y[100][10];
	int tmp,xtmp,ytmp;
	int ans[100];

	while(std::cin >> n && n){
		std::cin >> m;
		int count[100];

		rep(j,m) {
			std::cin >> x[0][j] >> y[0][j];
		}
		rep(i,n){
			std::cin >> m;
			rep(j,m){
				std::cin >> x[i+1][j] >> y[i+1][j];
				x[i+1+n][m-1-j] = x[i+1][j];
				y[i+1+n][m-1-j] = y[i+1][j];
			}
		}
		rep(i,2*n+1){
			ans[i] = 0;
			count[i] = 0;
			int xdif =0 - x[i][0];
			int ydif =0 - y[i][0];
			rep(j,m){
				x[i][j] += xdif;
				y[i][j] += ydif;
			}
		}
		rep(i,2*n){
			rep(k,4){
				rep(j,m){
					if (k == 0) {
						xtmp = -y[i + 1][j];
						ytmp = x[i + 1][j];
					}
					if (k == 1) {
						xtmp = -x[i + 1][j];
						ytmp = -y[i + 1][j];
					}
					if (k == 2) {
						xtmp = y[i + 1][j];
						ytmp = -x[i + 1][j];
					}
					if (k == 3) {
						xtmp = x[i + 1][j];
						ytmp = y[i + 1][j];
					}
					if(xtmp == x[0][j] && ytmp == y[0][j]){
						count[i+1]++;
						if(count[i+1] == m)ans[i+1] = 1;
					}
					else{
						count[i+1] = 0;
						break;
					}
				}
				if(ans[i+1] == 1)break;
			}
		}
		rep(i,n){
			if(ans[i+1+n] == 1){
				ans[i+1] = 1;
			}
		}
		rep(i,n){
			if(ans[i+1] == 1){
				std::cout << i+1 << std::endl;
			}
		}
		std::cout << "+++++" << std::endl;
	}
	return 0;
}