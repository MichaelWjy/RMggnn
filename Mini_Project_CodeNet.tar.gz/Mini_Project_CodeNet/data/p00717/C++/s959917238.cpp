#include "iostream"
#include "climits"
#include "list"
#include "queue"
#include "stack"
#include "set"
#include "functional"
#include "algorithm"
#include "string"
#include "map"
#include "unordered_map"
#include "unordered_set"
#include "iomanip"
#include "cmath"
#include "random"
#include "bitset"
#include "cstdio"

using namespace std;

const long long int MOD = 1000000007;


long long int N, M, K, H, W, L, R;

int main() {
	ios::sync_with_stdio(false);
	cin.tie(0);

	vector<string>ans;
	cin >> N;
	while (N) {
		map <vector<pair<int, int>>, int> m;
		for (int i = 0; i <= N; i++) {
			if (!i) {
				cin >> K;
				vector<pair<int, int>>vv(K);
				for (int j = 0; j < K; j++) {
					cin >> vv[j].first >> vv[j].second;
				}
				vector<pair<int, int>>v;
				for (int j = 0; j < K; j++) {
					v.push_back({ vv[j].first - vv[0].first,vv[j].second - vv[0].second });
				}
				m[v]++;
				vector<pair<int, int>>w(K);
				for (int j = 0; j < K; j++) {
					w[j].first = -v[j].first;
					w[j].second = -v[j].second;
				}
				m[w]++;
				for (int j = 0; j < K; j++) {
					w[j].first = v[j].second;
					w[j].second = -v[j].first;
				}
				m[w]++;
				for (int j = 0; j < K; j++) {
					w[j].first = -v[j].second;
					w[j].second = v[j].first;
				}
				m[w]++;
				for (int j = 0; j < K; j++) {
					v[j] = { vv[K - 1 - j].first - vv[K - 1].first ,vv[K - 1 - j].second - vv[K - 1].second };
				}
				m[v]++;
				for (int j = 0; j < K; j++) {
					w[j].first = -v[j].first;
					w[j].second = -v[j].second;
				}
				m[w]++;
				for (int j = 0; j < K; j++) {
					w[j].first = v[j].second;
					w[j].second = -v[j].first;
				}
				m[w]++;
				for (int j = 0; j < K; j++) {
					w[j].first = -v[j].second;
					w[j].second = v[j].first;
				}
				m[w]++;
			}
			else {
				cin >> K;
				vector<pair<int, int>>w(K);
				for (int j = 0; j < K; j++) {
					cin >> w[j].first >> w[j].second;
				}
				for (int j = K - 1; j >= 0; j--) {
					w[j].first -= w[0].first;
					w[j].second -= w[0].second;
				}
				if (m[w]) {
					ans.push_back(to_string(i));
				}
			}
		}
		ans.push_back("+++++");
		cin >> N;
	}
	for (auto i : ans)cout << i << endl;
	return 0;
}
