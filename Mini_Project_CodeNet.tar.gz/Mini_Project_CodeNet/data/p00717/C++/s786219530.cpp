#include<iostream>
#include<sstream>
#include<algorithm>
#include<numeric>
#include<vector>
#include<map>
#include<set>
#include<queue>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cassert>

#define rep(i,n) for(int i=0;i<n;i++)
#define all(c) (c).begin(),(c).end()
#define fr(i,c) for(__typeof((c).begin()) i=(c).begin();i!=(c).end();i++)
#define mp make_pair
#define pb push_back
#define dbg(x) cerr<<#x<<" = "<<(x)<<endl

using namespace std;

typedef long long ll;
typedef vector<int> vi;
typedef pair<int,int> pi;

const int inf=1<<28;
const double INF=1e12,EPS=1e-9;

void rot(vector<pi> &v){
  int n=v.size();
  rep(i,n){
    int a=v[i].first,b=v[i].second;
    v[i].first=-b,v[i].second=a;
  }
}

int main()
{
  int n;
  while(cin>>n,n){
    vector<vector<pi> > line,base;
    rep(i,n+1){
      int m,px,py; cin>>m>>px>>py;
      vector<pi> v;
      rep(j,m-1){
	int x,y; cin>>x>>y;
	v.pb(mp(x-px,y-py));
	px=x,py=y;
      }
      if(i)line.pb(v);
      else base.pb(v);
    }
    
    vector<pi> v=base[0],u=v;
    int m=v.size();
    reverse(all(v));
    
    base.pb(v);
    v=base[0],u=base[1];
    /*
    rep(i,m)cerr<<u[i].first<<" "<<u[i].second<<endl;
    rep(i,m)cerr<<v[i].first<<" "<<v[i].second<<endl;
    */
    rep(i,3){
      rot(v); rot(u);
      base.pb(v); base.pb(u);
    }

    rep(i,n){
      bool ok=0;
      fr(j,base)if(line[i]==*j)ok=1;
      if(ok)cout<<i+1<<endl;
    }
    cout<<"+++++"<<endl;
  }
  return 0;
}