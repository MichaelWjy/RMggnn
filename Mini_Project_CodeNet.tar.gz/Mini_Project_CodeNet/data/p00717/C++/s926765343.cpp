#include "bits/stdc++.h"
using namespace std;
#define TEST 0
#if TEST
FILE *in = freopen("./Q/question.txt", "r", stdin);
FILE *out = freopen("./A/answer.txt", "w", stdout);
#endif

int main(){
  int n,nm,m;
  vector<int> ans;
  while(1){
    cin >> n;
    if(!n)break;
    cin >> m;
    nm=m;
    int state[n]={0};
    int nx[m],ny[m];
    int x[n][m],y[n][m];
    int dx,dy;
    for(int i=0 ; i<m; ++i)cin >> nx[i] >> ny[i]; //?????¨????????????

    for(int i=0; i<n; ++i){
      cin >> m;
      if(m!=nm)state[i]=2;
      for(int j=0; j<m; ++j){
        cin >> x[i][j] >> y[i][j];
      }
    }

    for(int a=0;a<n ;++a){
      for(int i=0;i<4;++i){
        for(int j=0;j<n;++j){
          for(int k=0; k<m ;++k){
            if(state[j]==1)break;
            dx=nx[0]-x[j][0];
            dy=ny[0]-y[j][0];
            if(x[j][k]+dx!=nx[k]||y[j][k]+dy!=ny[k]) break;
            if(k==m-1&&state[j]!=2)state[j]=1;
          }
        }
        for(int j=0;j<n;++j){
          for(int k=0; k<m ;++k){
            if(state[j]==1)break;
            dx=nx[0]-x[j][m-1];
            dy=ny[0]-y[j][m-1];
            if(x[j][m-k-1]+dx!=nx[k]||y[j][m-k-1]+dy!=ny[k]) break;
            if(k==m-1&&state[j]!=2)state[j]=1;
          }
        }
        for(int i=0;i<m;++i){ //?????¢
          int tmp=nx[i];
          nx[i]=(-ny[i]);
          ny[i]=tmp;
        }
      }
    }
    for(int i=0;i<n;++i){
      if(state[i]==1)cout << i+1 << endl;
    }
    cout << "+++++" << endl;
  }
  #if TEST
  fclose(in);
  fclose(out);
  #endif
  return 0;
}