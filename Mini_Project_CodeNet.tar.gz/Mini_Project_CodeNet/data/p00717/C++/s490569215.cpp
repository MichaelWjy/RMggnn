#include "bits/stdc++.h"
using namespace std;

//#define int int64_t

//#define CHOOSE(a) CHOOSE2 a
//#define CHOOSE2(a0,a1,a2,a3,x,...) x
//#define REP1(i, s, cond, cal) for (signed i = signed(s); i cond; i cal)
//#define REP2(i, s, n) REP1(i, s, < signed(n), ++)
//#define REP3(i, n) REP2(i, 0, n)
//#define rep(...) CHOOSE((__VA_ARGS__,REP1,REP2,REP3))(__VA_ARGS__)

#define rep(i, n) for(int i = 0; i < n; i++)

#define all(c) begin(c), end(c)
#define maxup(ans, x) (ans = (ans < x ? x : ans))
#define minup(ans, x) (ans = (ans > x ? x : ans))

#define breakif(cond) if(cond) break; else

template<typename T>
inline void input(vector<T>& v) { for (auto& x : v) cin >> x; }

using VV = vector<vector<int>>;
using V = vector<int>;
//using P = pair<int, int>;
//using IP = pair<int, P>;

using P = complex<double>;
using L = vector<P>;
bool operator < (const P& a, const P& b) {
	return real(a) != real(b) ? real(a) < real(b) : imag(a) < imag(b);
}
P rs[] = { P(1, 0), P(0, 1), P(-1, 0), P(0, -1) };
L rotate(L line, int idx) {
	L ret = line;
	for (auto& x : ret) {
		x *= rs[idx];
	}
	return ret;
};
L move(L line) {
	P sub = *min_element(all(line));
	L ret = line;
	for (auto& x : ret) {
		x -= sub;
	}
	return ret;
};
L input(){
	int m; cin >> m;
	L l(m);
	rep(i, m) {
		int x, y; cin >> x >> y;
		l[i] = P(y, x);
	}
	return l;
};
bool equal(L l1, L l2) {
	L l22 = l2;
	reverse(all(l22));
	rep(i, 4) {
		if (move(l1) == move(rotate(l2, i)) || move(l1) == move(rotate(l22, i))) return true;
	}
	return false;
};

signed main() {
	int n;
	while (cin >> n && n) {
		vector<L> lines(n - 1);
		L line;
		
		line = input();
		stringstream ss;
		rep(i, n) {
			if (equal(line, input())) {
				ss << i + 1 << endl;
			}
		}
		ss << "+++++" << endl;
		cout << ss.str();
	}
}