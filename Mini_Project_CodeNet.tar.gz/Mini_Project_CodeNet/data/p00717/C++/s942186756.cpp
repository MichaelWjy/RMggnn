#include <iostream>
#include <algorithm>
#include <bitset>
#include <deque>
#include <fstream>
#include <map>
#include <queue>
#include <set>
#include <stack>
#include <string>
#include <vector>
using namespace std;

typedef long long ll;
#define rep(i, n) for(ll i = 0; i < n; i++)
#define revrep(i, n) for(ll i = n-1; i >= 0; i--)
#define pb push_back
#define f first
#define s second
ll INFL = 1LL << 60;//10^18 = 2^60
int INF = 1 << 30;//10^9
ll MOD = 1e9 + 7;
//ll MOD  = 998244353;
//vector<ll> dy = {0, 0, 1, -1, 1, 1, -1, -1, 0};
//vector<ll> dx = {1, -1, 0, 0, 1, -1, 1, -1, 0};

ll max(ll a, ll b){return (a > b) ? a : b;}
ll min(ll a, ll b){return (a < b) ? a : b;}
ll pow_long(ll x, ll k){
  ll res = 1;
  while(k > 0){
    if(k % 2) res *= x;
    x *= x;
    k /= 2;
  }
  return res;
}

ll pow_mod(ll x, ll k){
  x %= MOD; x += MOD; x %= MOD;
  ll res = 1;
  while(k > 0){
    if(k % 2){
      res *= x; res %= MOD;
    }
    x *= x; x %= MOD;
    k /= 2;
  }
  return res;
}
ll inverse(ll x){return pow_mod(x, MOD - 2);};

ll gcd(ll a, ll b){
    if(b == 0) return a;
    return gcd(b, a % b);
}
ll lcm(ll x, ll y){return x / gcd(x, y) * y % MOD;};

int main(){
  while(true){
    int n; cin >> n;
    if(n == 0){
      break;
    }
    int m; cin >> m;
    vector<int> x(m), y(m);
    rep(i, m) cin >> x[i] >> y[i];
    vector<pair<int, int>> dx(m-1);
    rep(j, m-1){
      if(x[j+1] == x[j]){
        if(y[j+1] - y[j] > 0){
          dx[j].s = 0;
          dx[j].f = y[j+1] - y[j];
        }else{
          dx[j].s = 2;
          dx[j].f = abs(y[j+1] - y[j]);
        }
      }else{
        if(x[j+1] - x[j] > 0){
          dx[j].s = 1;
          dx[j].f = x[j+1] - x[j];
        }else{
          dx[j].s = 3;
          dx[j].f = abs(x[j+1] - x[j]);
        }
      }
    }

    for(int i = 1; i <= n; i++){
      int M; cin >> M;
      bool xx = 1;
      if(m != M) xx = 0;
      vector<int> nx(M), ny(M);
      rep(j, M) cin >> nx[j] >> ny[j];
      if(xx == 0) continue;
      vector<pair<int, int>> ndx(m-1);
      rep(j, m-1){
        if(nx[j+1] == nx[j]){
          if(ny[j+1] - ny[j] > 0){
            ndx[j].s = 0;
            ndx[j].f = ny[j+1] - ny[j];
          }else{
            ndx[j].s = 2;
            ndx[j].f = abs(ny[j+1] - ny[j]);
          }
        }else{
          if(nx[j+1] - nx[j] > 0){
            ndx[j].s = 1;
            ndx[j].f = nx[j+1] - nx[j];
          }else{
            ndx[j].s = 3;
            ndx[j].f = abs(nx[j+1] - nx[j]);
          }
        }
      }
      bool l = 1;
      rep(j, m-1){
        if(dx[j].f != ndx[j].f) l = 0;
      }
      if(l){
        //方向
        l = 1;
        rep(j, m-1){
          if((dx[j].s + 0) % 4 != ndx[j].s) l = 0;
        }
        if(l){
          cout << i << endl;
          continue;
        }
        l = 1;
        rep(j, m-1){
          if((dx[j].s + 1) % 4 != ndx[j].s) l = 0;
        }
        if(l){
          cout << i << endl;
          continue;
        }
        l = 1;
        rep(j, m-1){
          if((dx[j].s + 2) % 4 != ndx[j].s) l = 0;
        }
        if(l){
          cout << i << endl;
          continue;
        }
        l = 1;
        rep(j, m-1){
          if((dx[j].s + 3) % 4 != ndx[j].s) l = 0;
        }
        if(l){
          cout << i << endl;
          continue;
        }
      }

      //2
      l = 1;
      rep(j, m-1){
        if(dx[m-2-j].f != ndx[j].f) l = 0;
      }
      if(l){
        //方向
        l = 1;
        rep(j, m-1){
          if((dx[m-2-j].s + 0) % 4 != ndx[j].s) l = 0;
        }
        if(l){
          cout << i << endl;
          continue;
        }
        l = 1;
        rep(j, m-1){
          if((dx[m-2-j].s + 1) % 4 != ndx[j].s) l = 0;
        }
        if(l){
          cout << i << endl;
          continue;
        }
        l = 1;
        rep(j, m-1){
          if((dx[m-2-j].s + 2) % 4 != ndx[j].s) l = 0;
        }
        if(l){
          cout << i << endl;
          continue;
        }
        l = 1;
        rep(j, m-1){
          if((dx[m-2-j].s + 3) % 4 != ndx[j].s) l = 0;
        }
        if(l){
          cout << i << endl;
          continue;
        }
      }
      //2

    }
    cout << "+++++" << endl;
  }
}

