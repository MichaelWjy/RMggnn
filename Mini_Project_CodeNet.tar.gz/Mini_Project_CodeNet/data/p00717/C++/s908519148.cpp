#include <iostream>
#include<cstdlib>
#include<queue>
#include<set>
#include<vector>
#include<string>
#include<algorithm>
#include<sstream>
#include<cmath>
#include<stack>
#include<map>
#include<cstdio>
using namespace std;
#define rep(i,a) for(int i=0;i<a;i++)
#define mp make_pair
#define pb push_back
#define P pair<int,int>
#define ll __int64

int n,m;

int p[50][3][50];
int pp[3][50];
int dx[4]={1,0,-1,0};
int dy[4]={0,1,0,-1};
bool check(int c){
	//cout<<"N"<<n<<" "<<m<<endl;

	
	for(int k=0;k<4;k++){
	for(int i=0;i<m;i++)pp[0][i]=p[c][0][i],pp[1][i]=p[c][1][i];

		for(int i=0;i<m;i++){
			int nx=pp[0][i],ny=pp[1][i];
			pp[0][i]=nx*dx[k]-ny*dy[k];
			pp[1][i]=nx*dy[k]+ny*dx[k];
		}
		//if(c==3)rep(j,m)cout<<"A"<<pp[0][j]<<" "<<pp[1][j]<<" "<<p[0][0][j]<<" "<<p[0][1][j]<<endl;
		bool ok=1,ok2=1;
		int ax1,ax2,ay1,ay2;
		for(int i=1;i<m;i++){
			ax1=p[0][0][i]-p[0][0][i-1];
			ay1=p[0][1][i]-p[0][1][i-1];

			ax2=pp[0][i]-pp[0][i-1];
			ay2=pp[1][i]-pp[1][i-1];
			//if(c==3)cout<<ax2<<" "<<ay2<<" "<<ax1<<" "<<ay1<<endl;
			if(ax1!=ax2||ay1!=ay2)ok=0;
		}

		for(int i=m-1;i>=1;i--){
			ax1=p[0][0][i]-p[0][0][i-1];
			ay1=p[0][1][i]-p[0][1][i-1];

			ax2=pp[0][m-i]-pp[0][m-i-1];
			ay2=pp[1][m-i]-pp[1][m-i-1];
			//if(c==3)cout<<ax2<<" "<<ay2<<" "<<ax1<<" "<<ay1<<endl;
			if(ax1!=ax2||ay1!=ay2)ok2=0;
		}

		//cout<<endl;
		if(ok||ok2)return 1;
	}
	return 0;
}

int main(){

while(cin>>n,n){

rep(i,50)rep(j,2)rep(k,50)p[i][j][k]=0;

rep(i,n+1){
	cin>>m;
	rep(j,m){
		cin>>p[i][0][j]>>p[i][1][j];
	}
	//if(i>=1&&check(i))cout<<i<<endl;
}

for(int i=1;i<=n;i++)if(check(i))cout<<i<<endl;
cout<<"+++++\n";
}

	return 0;
}
