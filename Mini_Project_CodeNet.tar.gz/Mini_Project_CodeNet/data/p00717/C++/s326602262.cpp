#include "bits/stdc++.h"
using namespace std;
typedef long long ll;
typedef pair<int,int> pii;
#define rep(i,n) for(ll i=0;i<(ll)(n);i++)
#define all(a)  (a).begin(),(a).end()
#define pb emplace_back
#define INF (1e9+1)
//#define INF (1LL<<59)

vector<pii> norm(vector<pii> vp){
    int y = vp[0].first, x = vp[0].second;
    
    for(auto &e:vp)e.first-=y, e.second-=x;
    
    return vp;
}

vector<pii> f(vector<pii> vp){
    vp = norm(vp);
    for(auto &e:vp){
        int nx = e.first;
        int ny = -e.second;
        e = pii(ny,nx);
    }
    
    return vp;
}

int main(){
    int n;
    while(cin>>n&&n){
        vector<pii> base;
        int m;
        cin>>m;
        rep(i,m){
            int x,y;
            cin>>x>>y;
            base.pb(pii(y,x));
        }
        base = norm(base);
        
        vector<vector<pii>> vs;
        rep(i,n){
            cin>>m;
            vector<pii> tmp;
            rep(j,m){
                int x,y;
                cin>>x>>y;
                tmp.pb(pii(y,x));
            }
            vs.pb(norm(tmp));
            vs.pb(norm(f(tmp)));
            vs.pb(norm(f(f(tmp))));
            vs.pb(norm(f(f(f(tmp)))));

            reverse(all(tmp));
            vs.pb(norm(tmp));
            vs.pb(norm(f(tmp)));
            vs.pb(norm(f(f(tmp))));
            vs.pb(norm(f(f(f(tmp)))));
}
        
        set<int> st;
        rep(i,vs.size()){
            if(base==vs[i]){
                st.insert(1+i/8);
            }
        }
        for(auto e:st)cout<<e<<endl;
        cout<<"+++++"<<endl;
    }
}