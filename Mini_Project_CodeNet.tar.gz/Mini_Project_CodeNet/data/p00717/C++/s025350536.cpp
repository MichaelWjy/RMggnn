#include <iostream>
#include <string.h>
#include <math.h>
#include <complex>
using namespace std;

typedef complex<double> P;

int main(){

  int n,m,bx,by,x,y,sampm;
  P samp[9],vec[9],vec2[9],test;

  while(1){
  
      cin>>n;if(n==0)return 0;
      cin>>m;sampm=m;
      for(int i=0;i<m;i++){
        cin>>x>>y;
        if(i!=0){samp[i-1]=P(x-bx,y-by);}
        bx=x;by=y;
      }
      for(int h=1;h<=n;h++){
        cin>>m;
        for(int i=0;i<m;i++){
	  cin>>x>>y;
          if(i!=0){vec[i-1]=P(x-bx,y-by);}
          bx=x;by=y;
        }
        int same=0;
        for(int i=0;i<4;i++){
          int p=0;
          for(int j=0;j<m-1;j++)if(vec[j]!=samp[j])p=1;
          if(p==0){same=1;break;}
          for(int j=0;j<m-1;j++){vec[j]=vec[j]*P(0,1);}
	}
        if(same==0){
          for(int i=0;i<m-1;i++){vec2[i]=vec[m-2-i];}
          for(int i=0;i<4;i++){
          int p=0;
          for(int j=0;j<m-1;j++)if(vec2[j]!=samp[j])p=1;
          if(p==0){same=1;break;}
          for(int j=0;j<m-1;j++){vec2[j]=vec2[j]*P(0,1);}
  	  }
	}
        if(same==1&&m==sampm)cout<<h<<endl;
      }
      cout<<"+++++"<<endl;
    }
}