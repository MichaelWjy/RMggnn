#include <bits/stdc++.h>
#define For(i, a, b) for(int (i)=(int)(a); (i)<(int)(b); ++(i))
#define rFor(i, a, b) for(int (i)=(int)(a)-1; (i)>=(int)(b); --(i))
#define rep(i, n) For((i), 0, (n))
#define rrep(i, n) rFor((i), (n), 0)
#define fi first
#define se second
using namespace std;
typedef long long lint;
typedef unsigned long long ulint;
typedef pair<int, int> pii;
typedef pair<int, lint> pil;
typedef pair<lint, lint> pll;
template<class T> bool chmax(T &a, const T &b){if(a<b){a=b; return true;} return false;}
template<class T> bool chmin(T &a, const T &b){if(a>b){a=b; return true;} return false;}
template<class T> T div_floor(const T a, const T b){return a>=0 ? a/b : (a+1)/b-1;}
template<class T> T div_ceil(const T a, const T b){return a>=0 ? (a-1)/b+1 : a/b;}

constexpr lint mod = 1e9+7;
constexpr lint INF = mod*mod;
constexpr int MAX = 100010;

constexpr double eps=1e-9;
constexpr double PI=3.14159265358979323846264338327950;

inline int sgn(double x){
    if(x<-eps) return -1;
    if(x>eps) return 1;
    return 0;
}

inline bool EQ(double x, double y){
    return sgn(x-y)==0;
}

inline bool GE(double x, double y){
    return sgn(x-y)==1;
}

inline bool LE(double x, double y){
    return sgn(x-y)==-1;
}

inline bool GEQ(double x, double y){
    return sgn(x-y)>=0;
}

inline bool LEQ(double x, double y){
    return sgn(x-y)<=0;
}

struct Point{
    double x, y;
    Point(double x=0, double y=0): x(x), y(y){}

    Point operator+(const Point &p){
        return {x+p.x, y+p.y};
    }

    Point operator-(const Point &p){
        return {x-p.x, y-p.y};
    }

    Point operator*(const double k){
        return {k*x, k*y};
    }

    Point operator/(const double k){
        return {x/k, y/k};
    }

    double operator*(const Point &p){
        return x*p.x+y*p.y;
    }

    double operator^(const Point &p){
        return x*p.y-y*p.x;
    }

    bool operator==(const Point &p){
        return EQ(x, p.x) && EQ(y, p.y);
    }

    bool operator<(const Point &p) const{
        if(EQ(x, p.x)) return LE(y, p.y);
        return LE(x, p.x);
    }
};

using Vec=Point;
using Polygon=vector<Point>;

double norm(Point p){
    return p.x*p.x+p.y*p.y;
}

double abs(Point p){
    return sqrt(norm(p));
}

double arg(Point p){
    return atan2(p.y, p.x);
}

Point rot(Point p, double t){
    return {p.x*cos(t)-p.y*sin(t), p.x*sin(t)+p.y*cos(t)};
}

Point proj(Point a, Vec v, Point p){
    double t=v*(p-a)/norm(v);
    return a+v*t;
}

Point refl(Point a, Vec v, Point p){
    return proj(a, v, p)*2-p;
}

constexpr int CCW_COUNTER_CLOCKWISE=1; //反時計回り
constexpr int CCW_CLOCKWISE=-1; //時計回り
constexpr int CCW_ONLINE_BACK=-2; //一直線, C->A->B
constexpr int CCW_ONLINE_FRONT=2; //一直線, A->B->C
constexpr int CCW_ON_SEGMENT=0; //一直線, A->C->B

inline int ccw(Point a, Point b, Point c){
    Vec v=b-a, w=c-a;
    if(GE(v^w, 0)) return CCW_COUNTER_CLOCKWISE;
    if(LE(v^w, 0)) return CCW_CLOCKWISE;
    if(LE(v*w, 0)) return CCW_ONLINE_BACK;
    if(LE((a-b)*(c-b), 0)) return CCW_ONLINE_FRONT;
    return CCW_ON_SEGMENT;
}

bool isParallel(Vec v, Vec w){
    return EQ(v^w, 0);
}

bool isOrthogonal(Vec v, Vec w){
    return EQ(v*w, 0);
}

bool intersectSS(Point a, Point b, Point c, Point d){
    return ccw(a, b, c)*ccw(a, b, d)<=0 && ccw(c, d, a)*ccw(c, d, b)<=0;
}

Point getCrossPointLL(Point a, Vec v, Point b, Vec w){
    double t=((b-a)^w)/(v^w);
    return a+v*t;
}

double getDistanceLP(Point a, Vec v, Point p){
    return abs(v^(p-a)/abs(v));
}

double getDistanceSP(Point a, Point b, Point p){
    if(LE((b-a)*(p-a), 0)) return abs(p-a);
    if(LE((a-b)*(p-b), 0)) return abs(p-b);
    return getDistanceLP(a, b-a, p);
}

double getDistanceLL(Point a, Vec v, Point b, Vec w){
    if(isParallel(v, w)) return getDistanceLP(a, v, b);
    return 0;
}

double getDistanceLS(Point a, Vec v, Point c, Point d){
    Point b=a+v;
    if(ccw(a, b, c)*ccw(a, b, d)<=0) return 0;
    return min(getDistanceLP(a, v, c), getDistanceLP(a, v, d));
}

double getDistanceSS(Point a, Point b, Point c, Point d){
    if(intersectSS(a, b, c, d)) return 0;
    return min({getDistanceSP(a, b, c), getDistanceSP(a, b, d),
                getDistanceSP(c, d, a), getDistanceSP(c, d, b)});
}

double getAreaP(Polygon &p){
    double ret=0;
    rep(i, (int)p.size()) ret+=p[i]^p[(i+1)%p.size()]/2;
    return abs(ret);
}

bool isConvex(Polygon &p){
    int n=p.size();
    bool flag1=false, flag2=false;
    rep(i, n){
        int tmp=ccw(p[(i+n-1)%n], p[i], p[(i+1)%n]);
        if(tmp==CCW_COUNTER_CLOCKWISE){
            if(flag2) return false;
            flag1=true;
        }
        else if(tmp==CCW_CLOCKWISE){
            if(flag1) return false;
            flag2=true;
        }
    }
    return true;
}

Polygon convex_hull(Polygon p){
    int n=p.size();
    sort(p.begin(), p.end());
    Polygon ch(2*n);
    int k=0;
    rep(i, n){
        while(k>1 && LE((ch[k-1]-ch[k-2])^(p[i]-ch[k-1]), 0)) --k;
        ch[k++]=p[i];
    }
    for(int i=n-2, t=k; i>=0; --i){
        while(k>t && LE((ch[k-1]-ch[k-2])^(p[i]-ch[k-1]), 0)) --k;
        ch[k++]=p[i];
    }
    ch.resize(k-1);
    return ch;
}

int intersectCC(Point c1, double r1, Point c2, double r2){
    if(r1<r2){
        swap(c1, c2);
        swap(r1, r2);
    }
    double d=abs(c1-c2), r=r1+r2;
    if(GE(d, r)) return 4;
    if(EQ(d, r)) return 3;
    if(EQ(d+r2, r1)) return 1;
    if(LE(d+r2, r1)) return 0;
    return 2;
}

bool intersectCL(Point c, double r, Point a, Vec v){
    return LEQ(getDistanceLP(a, v, c), r);
}

bool intersectCS(Point c, double r, Point a, Point b){
    return LEQ(getDistanceSP(a, b, c), r) && GEQ(max(abs(a-c), abs(b-c)), r);
}

Polygon getCrossPointCL(Point c, double r, Point a, Vec v){
    Polygon ps;
    if(!intersectCL(c, r, a, v)) return ps;
    Point p=proj(a, v, c);
    double t=sqrt(max((double)0.0, (r*r-norm(p-c))/norm(v)));
    ps.push_back(p+v*t);
    if(!EQ(t, 0)) ps.push_back(p-v*t);
    return ps;
}

Polygon getCrossPointCC(Point c1, double r1, Point c2, double r2){
    Polygon ps;
    Vec v=c2-c1, w(v.y*-1, v.x);
    double d=abs(v);
    double x=(d*d+r1*r1-r2*r2)/(2*d);
    double y=sqrt(max(r1*r1-x*x, (double)0.0));
    ps.push_back(c1+v*x/d+w*y/d);
    if(intersectCC(c1, r1, c2, r2)!=2) return ps;
    ps.push_back(c1+v*x/d-w*y/d);
    return ps;
}

double getAreaCC(Point c1, double r1, Point c2, double r2){
    int flag=intersectCC(c1, r1, c2, r2);
    if(flag>=3) return 0;
    if(flag<=1){
        double r=min(r1, r2);
        return PI*r*r;
    }
    double d=abs(c1-c2);
    double ret=0;
    rep(i, 2) {
        double x=(d*d+r1*r1-r2*r2)/(2*d);
        double t=acos(x/r1)*2;
        ret+=(t-sin(t))*r1*r1/2;
        swap(c1, c2);
        swap(r1, r2);
    }
    return ret;
}

Polygon Tangent(Point c, double r, Point p){
    Polygon ps;
    double d=abs(p-c);
    double t=acos(r/d);
    ps.push_back(c+rot(p-c, t)*r/d);
    ps.push_back(c+rot(p-c, -t)*r/d);
    return ps;
}

Polygon getCommonTangent(Point c1, double r1, Point c2, double r2){
    Polygon ps;
    int flag=intersectCC(c1, r1,c2, r2);
    if(flag>=2){
        double d=abs(c2-c1);
        double t=acos(abs(r1-r2)/d);
        if(LE(r1, r2)) t=PI-t;
        ps.push_back(c1+rot(c2-c1, t)*r1/d);
        ps.push_back(c1+rot(c2-c1, -t)*r1/d);
    }
    if(flag==4){
        double d=abs(c2-c1);
        double L=d*r1/(r1+r2);
        double t=acos(r1/L);
        ps.push_back(c1+rot(c2-c1, t)*r1/d);
        ps.push_back(c1+rot(c2-c1, -t)*r1/d);
    }
    if(flag==3 || flag==1){
        Polygon tg=getCrossPointCC(c1, r1, c2, r2);
        ps.push_back(tg[0]);
    }
    return ps;
}

Point getO(Point a, Point b, Point c){
    Point M=(a+b)/2, N=(a+c)/2;
    Vec v={-(b-a).y, (b-a).x}, w={-(c-a).y, (c-a).x};
    return getCrossPointLL(M, v, N, w);
}

Point getI(Point a, Point b, Point c){
    double A=abs(b-c), B=abs(c-a), C=abs(a-b);
    return (a*A+b*B+c*C)/(A+B+C);
}

Point getH(Point a, Point b, Point c){
    Vec v={-(c-b).y, (c-b).x}, w={-(c-a).y, (c-a).x};
    return getCrossPointLL(a, v, b, w);
}

pair<Point, double> MinimumBoundingCircle(Polygon &p){
    Point C;
    double r;
    if(p.size()==1) C=p[0], r=0;
    else if(p.size()==2) C=(p[0]+p[1])/2, r=abs(p[0]-C);
    else{
        r=INF;
        Polygon ch=convex_hull(p);
        int K=ch.size();
        auto check=[&](Point tc, double tr){
            rep(i, K){
                if(GE(abs(ch[i]-tc), tr)) return false;
            }
            return true;
        };
        rep(i, K)For(j, i+1, K){
            Point tc=(ch[i]+ch[j])/2;
            double tr=abs(ch[i]-tc);
            if(check(tc, tr) && chmin(r, tr)) C=tc;
            For(k, j+1, K){
                int ccw_flag=ccw(ch[i], ch[j], ch[k]);
                if(ccw_flag!=CCW_COUNTER_CLOCKWISE && ccw_flag!=CCW_CLOCKWISE) continue;
                tc=getO(ch[i], ch[j], ch[k]);
                tr=abs(ch[i]-tc);
                if(check(tc, tr) && chmin(r, tr)) C=tc;
            }
        }
    }
    return {C, r};
}

bool f(Polygon &p, Polygon &q){
    rep(i, p.size()-1)if(!EQ(abs(p[i]-p[i+1]), abs(q[i]-q[i+1]))) return false;
    rep(i, p.size()-2){
        if(ccw(p[i], p[i+1], p[i+2]) != ccw(q[i], q[i+1], q[i+2])) return false;
    }
    return true;
}

bool check(Polygon &p, Polygon &q){
    if(p.size() != q.size()) return false;
    if(f(p, q)) return true;
    reverse(q.begin(), q.end());
    return f(p, q);
}

int main(){
    int n;
    while(scanf("%d", &n) && n){
        Polygon p[n+1];
        rep(i, n+1){
            int m;
            scanf("%d", &m);
            p[i].resize(m);
            rep(j, m) scanf("%lf%lf", &p[i][j].x, &p[i][j].y);
        }
        For(i, 1, n+1)if(check(p[0], p[i])) printf("%d\n", i);
        puts("+++++");
    }
}
