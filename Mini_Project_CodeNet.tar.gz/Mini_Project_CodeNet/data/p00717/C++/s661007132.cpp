 
#include <bits/stdc++.h>
using namespace std;
using vi=vector<int>;
using vvi=vector<vi>;
using vs=vector<string>;
using msi=map<string,int>;
using mii=map<int,int>;
using pii=pair<int,int>;
using vlai=valarray<int>;
using ll=long long;
#define rep(i,n) for(int i=0;i<n;i++)
#define range(i,s,n) for(int i=s;i<n;i++)
#define all(a) a.begin(),a.end()
#define rall(a) a.rbegin(),a.rend()
#define fs first
#define sc second
#define pb push_back
#define eb emplace_back
#define mp make_pair
#define INF 1e9
#define EPS 1e-9
using Edge=pii;
#define l first
#define d second
bool isSame(vector<Edge> a, vector<Edge> b){
    int r=b[0].d-a[0].d;
    for(auto &e:a) e.d=(e.d+r+4)%4;
    return a==b;
}

int main(){
	int n;
	while(cin>>n,n){
		vector<vector<Edge>> edge(n+1,vector<Edge>(0));
		rep(i,n+1){
    		int t; cin>>t;
    		int x,y; cin>>x>>y;
    		rep(j,t-1){
    		    int tx,ty; cin>>tx>>ty;
    		    edge[i].eb(abs(tx+ty-x-y), x==tx?(ty>y?0:2):(tx>x?1:3));
    		    x=tx,y=ty;
    		}
		}
		range(i,1,n+1){
		    auto e=edge[i]; reverse(all(e));
		    if(isSame(edge[0],edge[i])||isSame(edge[0],e)){
		        cout<<i<<endl;
		    }
		}
		cout<<"+++++"<<endl;
	}
	return 0;
}