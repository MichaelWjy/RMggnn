#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;


bool compPol(vector<pair<int,int> > &schPol,vector<pair<int,int> > col){
	if(schPol.size() != col.size())
		return false;

	pair<int,int> diff;
	diff.first = schPol[0].first - col[0].first;
	diff.second = schPol[0].second - col[0].second;

	for(int i = 0; i < col.size(); i++){
		col[i].first += diff.first;
		col[i].second += diff.second;
	}

	for(int l = 0; l < 4; l++){
		// 90xñ]µÄêv·é©`FbN
		bool f = false;
		vector<pair<int,int> > npol;
		npol.push_back(col[0]);
		for(int i = 1; i < schPol.size(); i++){
			pair<int,int> pointDiff;
			pointDiff.first = col[i].first - col[0].first;
			pointDiff.second = col[i].second - col[0].second;
			// ÀWðñ]
			swap(pointDiff.first,pointDiff.second);
			pointDiff.second = -pointDiff.second;
			
			pair<int,int> distP = col[0];
			distP.first += pointDiff.first;
			distP.second += pointDiff.second;
			// êv
			if(distP.first == schPol[i].first && distP.second == schPol[i].second){
				npol.push_back(distP);
			}
			else{
				f=true;
			//	break;
				npol.push_back(distP);
			}
		}
		if(f){
			for(int i = 0; i < npol.size(); i++){
				col[i] = npol[i];
			}
			npol.clear();
		}
		else{
			return true;
		}
	}
	return false;
}

int main(){

	int n;
	while(cin >> n && n != 0){
		vector<vector<pair<int,int> > > lines;
		for(int i = 0; i < n+1; i++){
			int m;
			cin >> m;
			vector<pair<int,int> > vpii;
			for(int j = 0; j < m; j++){
				pair<int,int> p;
				cin >> p.second >> p.first;
				vpii.push_back(p);
			}
			lines.push_back(vpii);
		}

		vector<int> matchNumList;
		vector<pair<int,int> > schPol = lines[0];
		// vZ
		for(int i = 1; i < n+1; i++){
			vector<pair<int,int> > col = lines[i];
			// är
			if(compPol(schPol,col)){
				matchNumList.push_back(i);
			}
			else{
				reverse(col.begin(),col.end());
				if(compPol(schPol,col)){
					matchNumList.push_back(i);
				}
			}
		}
		if(matchNumList.size() == 0){
		}
		else{
			for(int i = 0; i < matchNumList.size(); i++){
				cout << matchNumList[i] << endl;
			}
		}
		cout << "+++++" << endl;
	}

	return 0;
}