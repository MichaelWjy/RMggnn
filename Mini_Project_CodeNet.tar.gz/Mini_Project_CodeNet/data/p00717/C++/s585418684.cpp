#include <iostream>
#include <vector>
#include <complex>
#include <algorithm>
using namespace std;

typedef complex<int> P;

int main(){
     int N;
     while(cin>>N,N){
	  vector< P > source[8];
	  vector< P > temp;
	  vector< P > ore[N+1];

	  int M;
	  cin>>M;
	  for(int i=0;i<M;i++){
	       int x,y;
	       cin>>x>>y;
	       temp.push_back(P(x,y));
	  }
	  int x1=temp[0].real();
	  int y1=temp[0].imag();
	  for(int i=0;i<M;i++){
	       P a=P(temp[i].real()-x1,temp[i].imag()-y1);
	       for(int j=0;j<4;j++){
		    source[j].push_back(a);
		    a*=P(0,1);
	       }
	  }
	  x1=temp[M-1].real();
	  y1=temp[M-1].imag();
	  for(int i=M-1;i>-1;i--){
	       P a=P(temp[i].real()-x1,temp[i].imag()-y1);
	       for(int j=0;j<4;j++){
		    source[j+4].push_back(a);
		    a*=P(0,1);
	       }
	  }
//±Á©çÜêü1~n
	  for(int i=1;i<N+1;i++){
	       int M;
	       cin>>M;
	       int x1,y1;
	       cin>>x1>>y1;
	       ore[i].push_back(P(0,0));
	       for(int j=1;j<M;j++){
		    int xi,yi;
		    cin>>xi>>yi;
		    ore[i].push_back(P(xi-x1,yi-y1));
	       }
	  }
	  vector<int> ans;
	  ans.clear();
	  for(int i=1;i<N+1;i++){
	       for(int j=0;j<8;j++){
		    if(source[j]==ore[i]){
			 ans.push_back(i);//±ÌÜÜ¾Æ¦d¡·é©çÓ
			 break;//½Ôñ±êÅãÍð
		    }
	       }
	  }
	  sort(ans.begin(),ans.end());
	  for(int i=0;i<ans.size();i++){
	       cout<<ans[i]<<endl;
	  }
     
	  cout<<"+++++"<<endl;
     }
}