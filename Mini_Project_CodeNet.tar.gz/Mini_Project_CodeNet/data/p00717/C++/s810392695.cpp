#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
#include <numeric>
using namespace std;

typedef struct
{
	int x, y;
} Point;

void rotate(int&x, int&y)
{
	swap(x, y);
	x = -x;
}

int main()
{
	int n;
	while (cin >> n) {
		if (n == 0)
			break;

		vector<vector<Point> > p;
		for (int i = 0; i < n+1; ++i) {
			int m;
			cin >> m;
			vector<Point> tmp(m);
			for (int j = 0; j < m; ++j)
				cin >> tmp[j].x >> tmp[j].y;
			p.push_back(tmp);
		}

		vector<Point> base1 = *p.begin();
		vector<Point> base2 = *p.begin();
		p.erase(p.begin());

		reverse(base2.begin(), base2.end());
		for (unsigned int i = 1; i < base1.size(); ++i) {
			base1[i].x -= base1[0].x;
			base1[i].y -= base1[0].y;
			base2[i].x -= base2[0].x;
			base2[i].y -= base2[0].y;
		}
		base1[0].x = base1[0].y = base2[0].x = base2[0].y = 0;

		vector<vector<Point> > p1(p);
		for (unsigned int i = 0; i < p1.size(); ++i) {
			for (unsigned int j = 1; j < p1[i].size(); ++j) {
				p1[i][j].x -= p1[i][0].x;
				p1[i][j].y -= p1[i][0].y;
			}
			p1[i][0].x = p1[i][0].y = 0;
		}

		vector<int> ans;
		for (unsigned int i = 0; i < p1.size(); ++i) {
			if (base1.size() != p1[i].size())
				continue;

			for (int r = 0; r < 4; ++r) {
				for (unsigned int j = 0; j < p1[i].size(); ++j)
					rotate(p1[i][j].x, p1[i][j].y);

				int match1 = 0, match2 = 0;
				for (unsigned int j = 0; j < base1.size(); ++j) {
					if (base1[j].x == p1[i][j].x && base1[j].y == p1[i][j].y)
						++match1;
					if (base2[j].x == p1[i][j].x && base2[j].y == p1[i][j].y)
						++match2;
				}
				if (match1 == base1.size() || match2 == base2.size()) {
						ans.push_back(i);
				}
			}
		}

		for (unsigned int i = 0; i < ans.size(); ++i)
			cout << ans[i]+1 << endl;
		cout << "+++++" << endl;

	}
	return 0;
}