#include<cstdio>
#include<cmath>
using namespace std;

int n, m, mtemp, x[10], y[10];

struct line{
  int len[9], right[8];
};

int det(int x1, int y1, int x2, int y2) {
  return x1 * y2 - x2 * y1;
}

line l[51];
bool ok[51];

bool same(line l1, line l2) {
  bool flag = true;
  for (int i = 0; i < m - 1 && flag; i++) if (l1.len[i] != l2.len[i]) flag = false;
  for (int i = 0; i < m - 2 && flag; i++) if (l1.right[i] != l2.right[i]) flag = false;
  if (flag) return true;
  flag = true;
  for (int i = 0; i < m - 1 && flag; i++) if (l1.len[i] != l2.len[m - 2 - i]) flag = false;
  for (int i = 0; i < m - 2 && flag; i++) if (l1.right[i] == l2.right[m - 3 - i]) flag = false;
  if (flag) return true;
  return false;
}

int main() {
  while (1) {
    scanf("%d", &n);
    if (n == 0) break;
    for (int i = 0; i <= n; i++) {
      scanf("%d", &mtemp);
      for (int j = 0; j < mtemp; j++) scanf("%d%d", &x[j], &y[j]);
      if (i == 0) m = mtemp;
      else if (m != mtemp) { ok[i] = false; continue; }
      else ok[i] = true;
      for (int j = 0; j < mtemp - 1; j++) {
        if (x[j] == x[j + 1]) l[i].len[j] = abs(y[j + 1] - y[j]);
        else l[i].len[j] = abs(x[j + 1] - x[j]);
      }
      for (int j = 0; j < mtemp - 2; j++) {
        if (det(x[j] - x[j + 1], y[j] - y[j + 1], x[j + 2] - x[j + 1], y[j + 2] - y[j + 1]) > 0)
          l[i].right[j] = 1;
        else l[i].right[j] = -1;
      }
    }
    for (int i = 1; i <= n; i++) if (ok[i] && same(l[0], l[i])) printf("%d\n", i);
    printf("+++++\n");
  }
}

