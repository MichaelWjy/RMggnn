#include<iostream>
using namespace std;
int main(){
	int n;
	while(cin>>n,n){
		int m;
		cin>>m;
		int x[m],y[m],r[m],v[m];
		cin>>x[0]>>y[0];
		for(int i=1;i<m;i++){
			cin>>x[i]>>y[i];
			r[i-1]=x[i]-x[i-1]+y[i]-y[i-1];
			if(r[i-1]<0)
				r[i-1]=-r[i-1];
			if(x[i]-x[i-1]>0)
				v[i-1]=1;
			else if(x[i]-x[i-1]<0)
				v[i-1]=3;
			else if(y[i]-y[i-1]>0)
				v[i-1]=0;
			else if(y[i]-y[i-1]<0)
				v[i-1]=2;
		}
		for(int j=1;j<=n;j++){
			int mi;
			cin>>mi;
			if(mi!=m)
			continue;
			int xi[mi],yi[mi],ri[mi],vi[mi],a=0;
			cin>>xi[0]>>yi[0];
			for(int i=1;i<mi;i++){
				cin>>xi[i]>>yi[i];
				ri[i-1]=xi[i]-xi[i-1]+yi[i]-yi[i-1];
				if(ri[i-1]<0)
					ri[i-1]=-ri[i-1];
				if(xi[i]-xi[i-1]>0)
					vi[i-1]=1;
				else if(xi[i]-xi[i-1]<0)
					vi[i-1]=3;
				else if(yi[i]-yi[i-1]>0)
					vi[i-1]=0;
				else if(yi[i]-yi[i-1]<0)
					vi[i-1]=2;
			}
			a=v[0]-vi[0];
			int f=1;
			for(int i=0;i<mi-1;i++){
				if(r[i]!=ri[i] || v[i]!=(vi[i]+a)%4){
					f=0;
					break;
				}
			}
			if(f==0){
				f=1;
				int ai=v[mi-2]-vi[0];
				for(int i=0;i<mi-1;i++){
					if(r[mi-2-i]!=ri[i] || v[mi-2-i]!=(vi[i]+ai)%4){
						f=0;
						break;
					}
				}
			}
			if(f)
			 cout<<j<<endl;
		}
		cout<<"+++++"<<endl;
	}
	return 0;
}