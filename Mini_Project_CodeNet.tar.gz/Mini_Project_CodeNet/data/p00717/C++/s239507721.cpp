#include<bits/stdc++.h>
using namespace std;

bool comp(vector<vector<int> >& a, vector<vector<int> >& b, int m){
    for(int i = 0; i < m; i++){
        if(a[0][i] != b[0][i] || a[1][i] != b[1][i]) return false;
    }
    return true;
}

int main(void){
    int n, m;

    vector<vector<int> > A(2, vector<int>(20, 0));
    vector<vector<int> > B(2, vector<int>(20, 0));

    while(1){
        cin >> n;
        if(n == 0) break;

        for(int i = 0; i <= n; i++){
            if(i == 0){//??¢????????¨??¨???????????????
                cin >> m;
                for(int j = 0; j < m; j++){
                    cin >> A[0][j] >> A[1][j];
                }
                //A????§???????????????????????§????
                for(int j = 0; j < m; j++){
                    A[0][j] -= A[0][0];
                    A[1][j] -= A[1][0];
                }
                continue;
            }else{
                int flag = 0; //?????????????????????????????´?????????????????°???????????????
                int mm;
                cin >> mm;
                if(m != mm) continue;
                for(int j = 0; j < m; j++){
                    cin >> B[0][j] >> B[1][j];
                }

                for(int j = 0; j < m; j++){
                    B[0][j] -= B[0][0];
                    B[1][j] -= B[1][0];
                }

                if(comp(A, B, m)) flag = 1; //???????????????
                for(int k = 0; k < 3; k++){
                    for(int j = 0; j < m; j++){
                        int temp;
                        temp = B[0][j];
                        B[0][j] = -B[1][j];
                        B[1][j] = temp;
                    }
                    if(comp(A, B, m)) flag = 1; //?????????????????????
                }

                for(int j = 0; j < m; j++){
                    B[0][j] -= B[0][m-1];
                    B[1][j] -= B[1][m-1];
                }
                int C[2][20];
                for(int j = 0; j < m; j++){
                    C[0][j] = B[0][j];
                    C[1][j] = B[1][j];
                }
                for(int j = 0; j < m; j++){
                    B[0][j] = C[0][m-1-j];
                    B[1][j] = C[1][m-1-j];
                }

                if(comp(A, B, m)) flag = 1; //????????????5
                for(int k = 0; k < 3; k++){
                    for(int j = 0; j < m; j++){
                        int temp;
                        temp = B[0][j];
                        B[0][j] = -B[1][j];
                        B[1][j] = temp;
                    }
                    if(comp(A, B, m)) flag = 1; //????????????6???8
                }

                if(flag) cout << i << endl;
            }
        }
        cout << "+++++" << endl;
    }
    return 0;
}