#include <bits/stdc++.h>
#define r(i,n) for(int i=0;i<n;i++)
#define EPS (1e-10)
using namespace std;
class Point{
  public:
  double x,y;
  Point(double x=0,double y=0):x(x),y(y){}
  Point operator + (Point p){return Point(x+p.x,y+p.y);}
  Point operator - (Point p){return Point(x-p.x,y-p.y);}
  Point operator * (double a){return Point(a*x,a*y);}
  Point operator / (double a){return Point(x/a,y/a);}

  bool operator < (const Point &p) const{
    return x!=p.x?x<p.x:y<p.y;
  }
  bool operator == (const Point &p) const{
    return fabs(x-p.x)<EPS&&fabs(y-p.y)<EPS;
  }
};
double norm(Point p){return p.x*p.x+p.y*p.y;}
double abs(Point p){return sqrt(norm(p));}
double cross(Point a,Point b){return a.x*b.y-a.y*b.x;}
double dot(Point a,Point b){return a.x*b.x+a.y*b.y;}
double getDistancePP(Point a,Point b){return abs(a-b);}
int CCW(Point p0,Point p1,Point p2){
  Point a=p1-p0;
  Point b=p2-p0;
  if(cross(a,b)>EPS)return 1;
  if(cross(a,b)<-EPS)return -1;
  if(dot(a,b)<-EPS)return 2;
  if(norm(a)<norm(b))return -2;
  return 0;
}
int main(){
  int n,m;
  Point p;
  while(cin>>n,n){
    vector<Point>a[51];
    cin>>m;
    while(m--){cin>>p.x>>p.y;a[0].push_back(p);}
    int cc[10],cp[10];
    r(i,a[0].size()-2)cc[i]=CCW(a[0][i],a[0][i+1],a[0][i+2]);
    r(i,a[0].size()-1)cp[i]=getDistancePP(a[0][i],a[0][i+1]);
    r(i,n){cin>>m;
      while(m--){
        cin>>p.x>>p.y;
        a[i+1].push_back(p);
      }
    }
    for(int j=1;j<n+1;j++){
      if(a[0].size()!=a[j].size())continue;
      int dd[10],d2[10],d=0,d3=0,dp[10],o=0,oo=0,pd[10];
    r(i,a[j].size()-2)dd[i]=CCW(a[j][i],a[j][i+1],a[j][i+2]);
    r(i,a[j].size()-2)if(dd[i]!=cc[i])d++;int c=a[j].size()-3;
    r(i,a[j].size()-2)if(dd[i]==cc[c--])d3++;
    r(i,a[j].size()-1)dp[i]=getDistancePP(a[j][i],a[j][i+1]);
    c=a[j].size()-2;
    r(i,a[j].size()-1)if(dp[i]!=cp[i])o++;
    r(i,a[j].size()-1)if(dp[i]!=cp[c--])oo++;
    if((!oo&&!d3)||(!d&&!o))cout<<j<<endl;
    }
    cout<<"+++++"<<endl;
  }
}