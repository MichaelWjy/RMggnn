#include <iostream>
#include <algorithm>
#include <string>
#include <vector>
#include <queue>
#include <complex>
using namespace std;

typedef complex<int> Point;

Point line_ori[10];
Point lines[50][10];

int main() {

	int n;
	while(cin >> n && n != 0) {
		int m,x,y;
		cin >> m;
		for(int i = 0;i < m;i++) {
			cin >> x >> y;
			line_ori[i] = Point(x,y);
		}
		Point p = line_ori[0];
		for(int i = 0;i < m;i++) line_ori[i] -= p;
		int ct = 0;
		for(int i = 0;i < 3;i++) {
			if(line_ori[1].real() > 0) break;
			line_ori[1] *= Point(0,-1);
			ct++;
		}
		for(int i = 2;i < m;i++) {
			for(int j = 0;j < ct;j++) line_ori[i] *= Point(0,-1);
		}

		for(int i = 0;i < n;i++) {
			cin >> m;
			for(int j = 0;j < m;j++) {
				cin >> x >> y;
				lines[i][j] = Point(x,y);
			}
			Point p = lines[i][0];
			for(int j = 0;j < m;j++) lines[i][j] -= p;

			ct = 0;
			for(int j = 0;j < 3;j++) {
				if(lines[i][1].real() > 0) break;
				lines[i][1] *= Point(0,-1);
				ct++;
			}
			for(int j = 2;j < m;j++) {
				for(int k = 0;k < ct;k++) lines[i][j] *= Point(0,-1);
			}

			bool f = true;
			for(int j = 0;j < m;j++) {
				f = f && (lines[i][j] == line_ori[j] || lines[i][j] == line_ori[m - j - 1]);
			}
			if(f) cout << i + 1 << endl;
		} 
		cout << "+++++" << endl;

	}

}