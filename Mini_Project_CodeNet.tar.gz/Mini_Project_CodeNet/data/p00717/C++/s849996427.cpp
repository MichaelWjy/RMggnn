#include <iostream>
#include <complex>
#include <vector>
#include <algorithm>
using namespace std;
typedef complex<double> Point;

Point rot(Point p, Point center) {
	p -= center;
	p *= Point(0, 1);
	p += center;
	return p;
}

vector<Point> reverse(vector<Point> oresen) {
	int l = 0, r = oresen.size() - 1;
	while (l < r) {
		swap(oresen[l], oresen[r]);
		l++;
		r--;
	}
	return oresen;
}

bool isMatch(vector<Point> sen1, vector<Point> sen2) {
	if (sen1.size() != sen2.size()) return false;
	int n = sen1.size();
	int i;
	
	for (int dir = 0; dir < 4; dir++) {
		for (i = 0; i < n; i++) {
			sen2[i] = rot(sen2[i], sen2[0]);
		}
		
		Point diff = sen1[0] - sen2[0];
		for (i = 1; i < n; i++) {
			if (diff != sen1[i] - sen2[i]) {
				break;
			}
		}
		if (i == n) return true;
	}
	return false;
}

vector<Point> getOresen() {
	vector<Point> ret;
	
	int m;
	cin >> m;
	for (int i = 0; i < m; i++) {
		int x, y;
		cin >> x >> y;
		ret.push_back(Point((double)x, (double)y));
	}
	return ret;
}

int n;
vector<Point> oresen[51];

int main() {
	while (cin >> n) {
		if (n == 0) break;
		for (int i = 0; i <= n; i++) oresen[i] = getOresen();
		for (int i = 1; i <= n; i++) {
			if (isMatch(oresen[0], oresen[i]) || isMatch(oresen[0], reverse(oresen[i]))) {
				cout << i << endl;
			}
		}
		cout << "+++++" << endl;
	}
	return 0;
}