#include<bits/stdc++.h>

using namespace std;

#define reps(i,f,n) for(int i=f;i<int(n);i++)
#define rep(i,n) reps(i,0,n)


typedef pair<int,int> pii;
class Line{
public:
  vector<pii> x;
  Line(){};
  Line(vector<pii> s){
    reps(i,0,s.size()){
      x.push_back(pii(s[i].first-s[0].first, s[i].second-s[0].second));
    }
    while(!rotateOk())rotate();
  }
  bool rotateOk(){
    return x[0].first < x[1].first;
  }
  void rotate(){
    rep(i,x.size()){
      int f = -x[i].second;
      int s = x[i].first;
      x[i] = pii(f,s);
    }
  }
  bool ok(Line& line){
    if(line.x.size() != x.size())return false;
    rep(i,x.size()){
      if(line.x[i] != x[i])return false;
    }
    return true;
  }
};


vector<Line> lines;
Line base;

void init(){
  lines.clear();
}

Line getLine(){
  vector<pii> x;
  int a;
  cin>>a;
  rep(i,a){
    int c,d;
    cin>>c>>d;
    x.push_back(pii(c,d));
  }
  return Line(x);
}
bool input(){
  int n;
  cin>>n;
  if(n==0)return false;

  base = getLine();
  rep(i,n){
    lines.push_back(getLine());
  }
  return true;
}


int solve(){
  vector<pii> copy = base.x;
  reverse(copy.begin(),copy.end());

  Line base2(copy);

  int sum = 0;
  rep(i,lines.size()){
    if(base.ok(lines[i]) || base2.ok(lines[i])){
      printf("%d\n",i+1);
    }
  }
  puts("+++++");
  return sum;
}


int main(){
  while(init(),input())solve();
}