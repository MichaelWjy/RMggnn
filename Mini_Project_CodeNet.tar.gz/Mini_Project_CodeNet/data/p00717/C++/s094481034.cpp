#include<bits/stdc++.h>
#define rep(i,n)for(int i=0;i<n;i++)
using namespace std;
typedef pair<int,int>P;

int main() {
	int n;
	while(scanf("%d",&n),n){
		vector<P>v[50];
		rep(i,n+1){
			int m;scanf("%d",&m);
			rep(j,m){
				int x,y;scanf("%d%d",&x,&y);
				v[i].push_back(P(x,y));
			}
		}
		vector<int>ans;
		for(int i=1;i<=n;i++){
			if(v[0].size()!=v[i].size())continue;
			bool ok=true;
			rep(j,v[0].size()){
				if(!(v[i][j].first-v[i][0].first==v[0][j].first-v[0][0].first&&
				v[i][j].second-v[i][0].second==v[0][j].second-v[0][0].second)){
					ok=false;break;
				}
			}
			if(ok){
				ans.push_back(i);
				continue;
			}
			ok=true;
			rep(j,v[0].size()){
				if(!(v[i][v[i].size()-j-1].first-v[i][0].first==v[0][j].first-v[0][0].first&&
				v[i][v[i].size()-j-1].second-v[i][0].second==v[0][j].second-v[0][0].second)){
					ok=false;break;
				}
			}
			if(ok)ans.push_back(i);
		}
		rep(i,ans.size()){
			printf("%d",ans[i]);
			if(i==ans.size()-1)printf(" ");
			else printf("\n");
		}
	}
}