#include <algorithm>
#include <iostream>
#include <vector>
#include <cmath>
#define N 51
using namespace std;
char Change(char,char);
bool Check(vector<int>,vector<char>,vector<int>,vector<char>);

int main(){
  int n,m,x,y,bx,by;
  char d;
  vector<int> v[N];
  vector<char> c[N],dir[N];
  while(1){
    cin>>n;
    if(!n) break;
    for(int i=0;i<=n;i++){
      cin>>m;
      for(int j=0;j<m;j++){
	cin>>x>>y;
	if(j){
	  v[i].push_back(max(abs(bx-x),abs(by-y)));
	  if(by==y){
	    if(x-bx>0) d='r';
	    else d='l';
	  }else{
	    if(y-by>0) d='u';
	    else d='d';
	  }
	  c[i].push_back(d);
	}
	bx=x,by=y;
      }
      for(int j=0;j<c[i].size()-1;j++) dir[i].push_back(Change(c[i][j],c[i][j+1]));
    }
    for(int i=1;i<=n;i++)
      if(Check(v[0],dir[0],v[i],dir[i])) cout<<i<<endl;
    cout<<"+++++"<<endl;
    for(int i=0;i<=n;i++) v[i].clear(),c[i].clear(),dir[i].clear();
  }
  return 0;
}

char Change(char a,char b){
  if((a=='u'&&b=='r')||(a=='r'&&b=='d')||(a=='d'&&b=='l')||(a=='l'&&b=='u')) return 'l';
  return 'r';
}

bool Check(vector<int> a,vector<char> b,vector<int> c,vector<char> d){
  //if(a.size()!=c.size()) return false;
  if(a==c&&b==d) return true;
  reverse(c.begin(),c.end());
  reverse(d.begin(),d.end());
  for(int i=0;i<d.size();i++) d[i]=='l'?d[i]='r':d[i]='l';
  if(a==c&&b==d) return true;
  return false;
}