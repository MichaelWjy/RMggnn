#include <iostream>
#include <vector>
#include <string>
#include <cstring>
#include <algorithm>

#define REP(i,k,n) for(int i=k;i<n;i++)
#define rep(i,n) for(int i=0;i<n;i++)
#define mp make_pair

using namespace std;
typedef long long ll;
typedef pair<int,int> P;

P pointRotate(P p) {
    int nx = p.first * 0 + p.second * (-1);
    int ny = p.first * 1 + p.second * 0;

    return mp(nx,ny);
}

P pointShift(P p,int x,int y) {
    return mp(p.first + x,p.second + y);
}

bool pointSame(vector<P> s,vector<P> t) {
    if(s.size() != t.size()) return false;

    bool flag = true;
    rep(i,s.size()) {
        if(s[i].first != t[i].first || s[i].second != t[i].second) {
            flag = false;
        }
    }

    return flag;
}

bool same(vector<P> s,vector<P> t) {
    if(s.size() != t.size()) return false;

    bool flag = false;
    rep(i,4) {
        vector<P> v,v2;

        rep(j,s.size()) {
            P temp = s[j];
            rep(k,i) {
                temp = pointRotate(temp);
            }

            v.push_back(temp);
            v2.push_back(temp);
        }

        int nx = t[0].first - v[0].first;
        int ny = t[0].second - v[0].second;

        rep(j,v.size()) {
            v[j] = pointShift(v[j],nx,ny);
        }

        if(pointSame(v,t)) {
            flag = true;
        }

        reverse(v2.begin(),v2.end());

        nx = t[0].first - v2[0].first;
        ny = t[0].second - v2[0].second;

        rep(j,v2.size()) {
            v2[j] = pointShift(v2[j],nx,ny);
        }

        if(pointSame(v2,t)) {
            flag = true;
        }
    }

    return flag;
}

int main()
{
    int n;
    while(cin >> n && n) {
        
        vector<P> v;
        int m;
        cin >> m;

        rep(i,m) {
            int x,y;
            cin >> x >> y;

            v.push_back(mp(x,y));
        }

        vector< vector<P> > p(n);
        rep(i,n) {
            cin >> m;

            rep(j,m) {
                int x,y;
                cin >> x >> y;

                p[i].push_back(mp(x,y));
            }
        }

        bool flag = true;
        vector<int> ans;
        rep(i,n) {
            if(same(v,p[i])) {
                flag = false;
                ans.push_back(i);
            }
        }

        if(!flag) rep(i,ans.size()) cout << ans[i]+1 << endl;
        cout << "+++++" << endl;
    }

    return 0;
}