#include <iostream>
#include <algorithm>
#include <vector>
#include <map>
#include <complex>
#include <vector>
using namespace std;
typedef complex<int> P;
typedef vector<P > Poly;
int n;
bool operator == (const Poly& a,const Poly& b){
  if(a.size()!=b.size()) return false;
  for(int i=0;i<a.size();++i) if(a[i]!=b[i]) return false;
  return true;
}

vector<int> solve(vector<Poly> D){
  Poly s = D[0];
  vector<int> ret;
  for(int u=0;u<2;++u){
    for(int t=0;t<4;++t){
      for(int i=1;i<=n;++i)
	if(s==D[i]) ret.push_back(i);
      for(int i=0;i<s.size();++i){
	s[i]*=P(0,1);
      }
    }
    reverse(s.begin(),s.end());
    for(int i=s.size()-1;i>=0;--i) s[i]-=s[0];
  }
  sort(ret.begin(), ret.end());
  return ret;
}

int main(){
  while(cin>>n,n){
    vector<Poly> inp(n+1);
    for(int i=0;i<=n;++i){
      int m;cin>>m;
      for(int j=0;j<m;++j){
	int a,b;
	cin >> a >> b;
	inp[i].push_back(P(a,b));
      }
      for(int j=m-1;j>=0;--j) inp[i][j]-=inp[i][0];
    }
    vector<int> ans = solve(inp);
    for(int i=0;i<ans.size();++i) cout << ans[i] << endl;
    cout << "+++++" << endl;
  }
  
  return 0;
}