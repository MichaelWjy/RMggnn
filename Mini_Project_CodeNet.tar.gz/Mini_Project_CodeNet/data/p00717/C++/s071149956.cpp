#include <bits/stdc++.h>

using namespace std;

typedef pair<int, int> Point;
#define xx first
#define yy second

void rotate(vector<Point> &p)
{
  for(int i = 0; i < p.size(); i++){
    Point o = p[i];
    p[i].xx = o.yy;
    p[i].yy = -o.xx;
  }
  return;
}

bool overlap(vector<Point> &o, vector<Point> &p)
{
  for(int i = 0; i < o.size(); i++){
    if(o[i].xx - o[0].xx != p[i].xx - p[0].xx ||
       o[i].yy - o[0].yy != p[i].yy - p[0].yy){
      return false;
    }
  }
  return true;
}

vector<Point> reverse(vector<Point> &p)
{
  vector<Point> q = p;
  reverse(q.begin(), q.end());
  return q;
}

bool same(vector<Point> &o, vector<Point> &p)
{
  vector<Point> q = reverse(p);
  return overlap(o, p) | overlap(o, q);
}

int main()
{
  int n;
  while(cin >> n, n){
    vector< vector<Point> > ps(n + 1);
    for(int i = 0; i <= n; i++){
      int m;
      cin >> m;
      for(int j = 0; j < m; j++){
	Point p;
	cin >> p.xx >> p.yy;
	ps[i].push_back(p);
      }
    }
    for(int i = 1; i <= n; i++){
      if(ps[0].size() != ps[i].size()) continue;
      bool flag = false;
      for(int dig = 0; dig < 4; dig++){
	rotate(ps[i]);	
	flag |= same(ps[0], ps[i]);
      }
      if(flag) cout << i << endl;
    }
    cout << "+++++" << endl;
  }
  return 0;
}