#include<iostream>
using namespace std;
int n;
int X[10],Y[10],M;
bool check()
{
	int m,x[10],y[10];
	cin>>m;
	for(int i=0;i<m;i++)cin>>x[i]>>y[i];
	if(m!=M)return 0;
	bool f=1;
	for(int i=1;i<m;i++)
	{
		f&=abs(x[i]-x[i-1])+abs(y[i]-y[i-1])
			==abs(X[i]-X[i-1])+abs(Y[i]-Y[i-1]);
	}
	for(int i=1;i<m-1;i++)
	{
		f&=((x[i-1]-x[i])*(y[i+1]-y[i])-(y[i-1]-y[i])*(x[i+1]-x[i])>0)
			==((X[i-1]-X[i])*(Y[i+1]-Y[i])-(Y[i-1]-Y[i])*(X[i+1]-X[i])>0);
	}
	if(f)return 1;
	f=1;
	for(int i=1;i<m;i++)
	{
		f&=abs(x[i]-x[i-1])+abs(y[i]-y[i-1])
			==abs(X[m-i-1]-X[m-i])+abs(Y[m-i-1]-Y[m-i]);
	}
	for(int i=1;i<m-1;i++)
	{
		f&=((x[i-1]-x[i])*(y[i+1]-y[i])-(y[i-1]-y[i])*(x[i+1]-x[i])>0)
			==((X[m-i]-X[m-i-1])*(Y[m-i-2]-Y[m-i-1])-(Y[m-i]-Y[m-i-1])*(X[m-i-2]-X[m-i-1])>0);
	}
	return f;
}
main()
{
	while(cin>>n,n)
	{
		cin>>M;
		for(int i=0;i<M;i++)cin>>X[i]>>Y[i];
		for(int i=0;i<n;i++)if(check())cout<<i+1<<endl;
		cout<<"+++++"<<endl;
	}
}

