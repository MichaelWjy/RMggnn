#include<iostream>
#include<vector>

using namespace std;


struct Coordinate
{
    int x;
    int y;

    bool operator == (const Coordinate &other) const 
    {
        return this->x == other.x && this->y == other.y;
    }
};

int check_direction(int _dx, int _dy, int _base_direction)
{
    int direction = 0;
    if(_dx == 0 && _dy > 0)direction = 0;//???
    else if(_dx > 0 && _dy == 0)direction = 1;//???
    else if(_dx == 0 && _dy < 0)direction = 2;//???
    else if(_dx < 0 && _dy == 0)direction = 3;//???
    else cout << "error? : " << _dx << " " << _dy << " \n\n";

    return (100 + direction - _base_direction) % 4;
}

int main()
{
    int n = 101010;
    while(cin >> n, (n))
    {
        int m;
        cin >> m;

        int count = 0;

        vector<Coordinate> base(m);

        for(int j = 0; j < m; j++)
        {
            cin >> base[j].x;
            cin >> base[j].y;
        }

        vector<Coordinate> path_front(m - 1);
        int base_direction_front = check_direction(base[1].x - base[0].x, base[1].y - base[0].y, 0);

        for(int i = 0; i < m - 1; i++)
        {
            int dx = base[i + 1].x - base[i].x;
            int dy = base[i + 1].y - base[i].y;

            //?§???????
            int differ = max ( abs(dx), abs(dy) );

            //??????
            int direction = check_direction(dx, dy, base_direction_front);

            path_front[i].x = differ;
            path_front[i].y = direction;
        }


        //????????¨???????????????
        vector<Coordinate> path_back(m - 1);
        int base_direction_back = check_direction(base[m - 2].x - base[m - 1].x, base[m - 2].y - base[m - 1].y, 0);
        for(int i = m - 1; i >= 1; i--)
        {
            int dx = base[i - 1].x - base[i].x;
            int dy = base[i - 1].y - base[i].y;

            //?§???????
            int differ = max ( abs(dx), abs(dy) );

            //??????
            int direction = check_direction(dx, dy, base_direction_back);

            path_back[m - 1 - i].x = differ;
            path_back[m - 1 - i].y = direction;
        }

        /*
        for(int j = 0; j < m - 1; j++)
            cout << path_front[j].x << " " << path_front[j].y << endl;
        cout << "------\n";
        for(int j = 0; j < m - 1; j++)
            cout << path_back[j].x << " " << path_back[j].y << endl;
        cout << "======\n";
        //*/
        
        for(int i = 0; i < n; i++)
        {
            cin >> m;
            vector<Coordinate> poly(m);

            for(int j = 0; j < m; j++)
            {
                cin >> poly[j].x;
                cin >> poly[j].y;
            }

            //??????????????????
            vector<Coordinate> path(m - 1);//[0 ~ m-2]
            int base_direction = check_direction(poly[1].x - poly[0].x, poly[1].y - poly[0].y, 0);

            for(int j = 0; j < m - 1; j++)
            {
                int dx = poly[j + 1].x - poly[j].x;
                int dy = poly[j + 1].y - poly[j].y;

                //?§???????
                int differ = max ( abs(dx), abs(dy) );

                //??????
                int direction = check_direction(dx, dy, base_direction);

                path[j].x = differ;
                path[j].y = direction;

            }
            /*
            for(int j = 0; j < m - 1; j++)
                cout << count << " : " << path[j].x << " " << path[j].y << endl;
            //*/

            count++;
            if(path == path_back || path == path_front)cout << count << endl;
        }
        cout << "+++++\n";
    }
    return 0;
}