#include <bits/stdc++.h>
using namespace std;

// region template
#define rep(i, a, b) for (int i = (a); i < (b); ++i)
#define trav(a, x) for (auto &a : x)
#define all(x) begin(x), end(x)
#define sz(x) (int)(x).size()
typedef long long ll;
typedef unsigned long long ull;
typedef pair<int, int> pii;
typedef vector<int> vi;

ll gcd(ll a, ll b) { return __gcd(a, b); }

ll euclid(ll a, ll b, ll &x, ll &y) {
    if (b) { ll d = euclid(b, a % b, y, x);
        return y -= a/b * x, d; }
    return x = 1, y = 0, a;
}

typedef unsigned long long ull;
typedef long double ld;
ull mod_mul(ull a, ull b, ull M) {
    ll ret = a * b - M * ull(ld(a) * ld(b) / ld(M));
    return ret + M * (ret < 0) - M * (ret >= (ll)M);
}
ull mod_pow(ull b, ull e, ull mod) {
    ull ans = 1;
    for (; e; b = mod_mul(b, b, mod), e /= 2)
        if (e & 1) ans = mod_mul(ans, b, mod);
    return ans;
}

const ll mod = 1000000007;
struct Mod {
    ll x;
    Mod(ll xx) : x(xx) {}
    Mod operator+(Mod b) { return Mod((x + b.x) % mod); }
    Mod operator-(Mod b) { return Mod((x - b.x) % mod); }
    Mod operator*(Mod b) { return Mod((x * b.x) % mod); }
    Mod operator/(Mod b) { return *this * invert(b); }
    Mod invert(Mod a) {
        ll x, y, g = euclid(a.x, mod, x, y);
        assert(g == 1); return Mod((x + mod) % mod);
    }
    Mod operator^(ll e) {
        if (!e) return Mod(1);
        Mod r = *this ^ (e / 2); r = r * r;
        return e & 1 ? *this * r : r;
    }
};
// endregion

struct Point {
    ll x, y;
    const Point operator-(const Point p) const {
        Point r;
        r.x = x - p.x, r.y = y - p.y;
        return r;
    }
    const ll norm2() const { return x * x + y * y; }
};

ll cross(Point p0, Point p1) {
    return p0.x * p1.y - p1.x * p0.y;
}

ll sqr(ll x) { return x * x; }

vector<ll> encode(vector<Point> p) {
    vector<ll> vals;
    rep(i, 0, p.size() - 1) {
        vals.push_back((p[i + 1] - p[i]).norm2());
        if (i + 2 < p.size()) {
            vals.push_back(cross(p[i + 1] - p[i], p[i + 2] - p[i + 1]));
        }
    }
    return vals;
}

vector<Point> getline() {
    int m; cin >> m;
    vector<Point> p(m);
    rep(i, 0, m) cin >> p[i].x >> p[i].y;
    return p;
}

void out(vector<ll> v) {
    for (int h : v) cout << h << " ";
}
void out(vector<Point> v) {
    for (Point h : v) cout << "(" << h.x << ", " << h.y << "), ";
}

int main() {
    for (;;) {
        int n; cin >> n; if (!n) break;
        vector<Point> base = getline();
        vector<Point> baser(base.rbegin(), base.rend());
        vector<ll> s1 = encode(base), s2 = encode(baser);

        vector<int> ans;
        rep(i, 1, n + 1) {
            vector<ll> e = encode(getline());
            if (e == s1 || e == s2) {
                ans.push_back(i);
            }
        }
        for (int h : ans) cout << h << endl;
        cout << "+++++" << endl;
    }
}
