#include <iostream>
#include <vector>
#include <tuple>
#include <algorithm>
using namespace std;

using P = pair<int,int>;

void align(vector<P> &line){
    int m=line.size();
    int x,y;
    tie(x,y)=line[0];
    for(auto &p:line){
        p.first-=x;
        p.second-=y;
    }

    if(line[1].first!=0){
        if(line[1].first>0){
            // cout<<'A'<<endl;
            return;
        }else{
            // cout<<'B'<<endl;
            for(int i=0;i<m;i++){
                int x,y;
                tie(x,y)=line[i];
                line[i]=P(-x,-y);
            }
        }
    }else{
        if(line[1].second>0){
            // cout<<'C'<<endl;
            for(int i=0;i<m;i++){
                int x,y;
                tie(x,y)=line[i];
                line[i]=P(y,-x);
            }
        }else{
            // cout<<'D'<<endl;
            for(int i=0;i<m;i++){
                int x,y;
                tie(x,y)=line[i];
                line[i]=P(-y,x);
            }
        }
    }
    return;
}

int main(){
    int n;
    while(cin>>n,n){
        vector<P> model,obj;
        int m;
        cin>>m;
        for(int i=0;i<m;i++){
            int x,y;
            cin>>x>>y;
            model.emplace_back(x,y);
        }
        align(model);
        for(int i=0;i<n;i++){
            cin>>m;
            obj.clear();
            for(int j=0;j<m;j++){
                int x,y;
                cin>>x>>y;
                obj.emplace_back(x,y);
            }
            align(obj);
            if(model==obj) cout<<i+1<<endl;
            else{
                reverse(obj.begin(), obj.end());
                align(obj);
                if(model==obj) cout<<i+1<<endl;            
            }
        }
        cout<<"+++++"<<endl;
    }

    return 0;
}