#include<bits/stdc++.h>
using namespace std;
#define fs first
#define sc second
#define pb push_back
#define mp make_pair
#define eb emplace_back
#define ALL(A) A.begin(),A.end()
#define RALL(A) A.rbegin(),A.rend()
typedef long long ll;
typedef pair<int,int> P;
const ll mod=1000000007;
const ll LINF=1LL<<60;
const int INF=1<<30;

int main(){
    int n;cin>>n;
    while(n != 0){
    int m;cin>>m;
    vector<vector<P>> af(4);
    vector<vector<P>> ar(4);
    int dist_x,dist_y;
    vector<P> tmp;
    for(int i = 0; i < m; i++) {
        int x,y;cin>> x>>y;
        tmp.pb(mp(x,y));
    }
    for(int i = 0; i < m; i++) {
        if (i == 0){
            dist_x = tmp[0].fs;
            dist_y = tmp[0].sc;
        }
        else{
            int x,y;
            x = tmp[i].fs;
            y = tmp[i].sc;
            x -= dist_x;
            y -= dist_y;
            af[0].pb(mp(x,y));
        }
    }
    for(int i = 1; i < 4; i++) {
        if (i == 1){
            for(int j = 0; j < af[0].size(); j++) {
                af[1].pb(mp(-af[0][j].sc,af[0][j].fs));
            }
        }
        else if(i == 2){
            for(int j = 0; j < af[0].size(); j++) {
                af[2].pb(mp(-af[0][j].fs,-af[0][j].sc));

            }

        }
        else{
            for(int j = 0; j < af[0].size(); j++) {
                af[3].pb(mp(af[0][j].sc,-af[0][j].fs));
            }
        } 
    }

    for(int i = 0; i < m; i++) {
        if (i == 0){
            dist_x = tmp[m - 1].fs;
            dist_y = tmp[m - 1].sc;
        }
        else{
            int x,y;
            x = tmp[m - i - 1].fs;
            y = tmp[m - i - 1].sc;
            x -= dist_x;
            y -= dist_y;
            ar[0].pb(mp(x,y));
        }
    }
    for(int i = 1; i < 4; i++) {
        if (i == 1){
            for(int j = 0; j < ar[0].size(); j++) {
                ar[1].pb(mp(-ar[0][j].sc,ar[0][j].fs));
            }
        }
        else if(i == 2){
            for(int j = 0; j < ar[0].size(); j++) {
                ar[2].pb(mp(-ar[0][j].fs,-ar[0][j].sc));

            }

        }
        else{
            for(int j = 0; j < ar[0].size(); j++) {
                ar[3].pb(mp(ar[0][j].sc,-ar[0][j].fs));
            }

        } 
    }


    
    vector<vector<P>> b(n);
    vector<int> ans;
    for(int i = 0; i < n; i++) {
        cin>>m;
        vector<P> tmp2(m + 1,mp(0,0));
        for(int j = 0; j < m; j++) {
            int x,y;cin>>x>>y;
            tmp2[j] = mp(x,y);
        }
        for(int j = 0; j < m; j++) {
             if (j == 0){
                dist_x = tmp2[0].fs;
                dist_y = tmp2[0].sc;
            }
            else{
                int x,y;x = tmp2[j].fs;y = tmp2[j].sc;
                x -= dist_x;
                y -= dist_y;
                b[i].pb(mp(x,y));
            }
        }

        for(int j = 0; j < 4; j++) {
            if (b[i].size() == af[j].size()){
                bool flag = true;
                for(int k = 0; k < b[i].size(); k++) {
                    if (b[i][k] != af[j][k]){
                        flag = false;
                        break;
                    }
                }
                if (flag){
                    ans.pb(i + 1);
                }
            }
        }

        for(int j = 0; j < 4; j++) {
            if (b[i].size() == ar[j].size()){
                bool flag = true;
                for(int k = 0; k < b[i].size(); k++) {
                    if (b[i][k] != ar[j][k]){
                        flag = false;
                        break;
                    }
                }
                if (flag){
                    ans.pb(i + 1);
                }
            }
        }
        
    }
    for(int i = 0; i < ans.size(); i++) {
        cout << ans[i] << endl;
    }
    cout << "+++++" << endl;
    cin>>n;
    }
    return 0;
}
