#include <bits/stdc++.h>

using namespace std;

bool isOK(auto &x, auto &y)
{
	if (x.size() != y.size())
	{
		return 0;
	}
	for (int i = 0; i < x.size(); ++i)
	{
		if (x[i] != y[i])
			return 0;
	}
	return 1;
}

int main()
{
	int n;
	while (cin >> n, n)
	{
		int m;
		cin >> m;
		vector<pair<int, int>> o(m - 1), p(m - 1), q(m - 1), r(m - 1);
		int prex, prey;
		cin >> prex >> prey;
		for (int i = 1; i < m; ++i)
		{
			int x, y, xx, yy;
			cin >> x >> y;
			xx = x;
			yy = y;
			x -= prex;
			y -= prey;
			o[i - 1] = {x, y};
			p[i - 1] = {-x, -y};
			q[i - 1] = {-y, x};
			r[i - 1] = {y, -x};
			prex = xx;
			prey = yy;
		}
		for (int i = 0; i < n; ++i)
		{
			cin >> m;
			vector<pair<int, int>> s(m - 1);
			cin >> prex >> prey;
			for (int i = 1; i < m; ++i)
			{
				int x, y, xx, yy;
				cin >> x >> y;
				xx = x;
				yy = y;
				x -= prex;
				y -= prey;
				s[i - 1] = {x, y};
				prex = xx;
				prey = yy;
			}
			if (isOK(o, s))
			{
				cout << i + 1 << endl;
				continue;
			}
			if (isOK(p, s))
			{
				cout << i + 1 << endl;
				continue;
			}
			if (isOK(q, s))
			{
				cout << i + 1 << endl;
				continue;
			}
			if (isOK(r, s))
			{
				cout << i + 1 << endl;
				continue;
			}
			reverse(s.begin(), s.end());
			if (isOK(o, s))
			{
				cout << i + 1 << endl;
				continue;
			}
			if (isOK(p, s))
			{
				cout << i + 1 << endl;
				continue;
			}
			if (isOK(q, s))
			{
				cout << i + 1 << endl;
				continue;
			}
			if (isOK(r, s))
			{
				cout << i + 1 << endl;
				continue;
			}
		}
		cout << "+++++" << endl;
	}
}
