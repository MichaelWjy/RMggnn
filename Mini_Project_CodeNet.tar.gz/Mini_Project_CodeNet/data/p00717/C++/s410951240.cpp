#include <iostream>
#define REP(i, a, n) for(int i = (a); i <= (n); i++)
using namespace std;

int N, M[51], X[51][11], Y[51][11], l[51][10], d[51][10], c[2][51][9];

int corner(int d1, int d2) {
  return (d2 - d1 + 4) % 4;
}

int main(void) {
  while(cin >> N, N) {
    REP(i, 0, N) {
      cin >> M[i];
      REP(j, 1, M[i]) cin >> X[i][j] >> Y[i][j];

      REP(j, 1, M[i] - 1) {
        if(X[i][j] == X[i][j + 1] && Y[i][j + 1] - Y[i][j] > 0) {
          l[i][j] = Y[i][j + 1] - Y[i][j];
          d[i][j] = 0;
        }
        if(X[i][j] == X[i][j + 1] && Y[i][j + 1] - Y[i][j] < 0) {
          l[i][j] = Y[i][j] - Y[i][j + 1];
          d[i][j] = 2;
        }
        if(Y[i][j] == Y[i][j + 1] && X[i][j + 1] - X[i][j] > 0) {
          l[i][j] = X[i][j + 1] - X[i][j];
          d[i][j] = 1;
        }
        if(Y[i][j] == Y[i][j + 1] && X[i][j + 1] - X[i][j] < 0) {
          l[i][j] = X[i][j] - X[i][j + 1];
          d[i][j] = 3;
        }
      }

      REP(j, 1, M[i] - 2) {
        c[0][i][j] = (d[i][j + 1] - d[i][j] + 4) % 4;
        c[1][i][j] = (d[i][M[i] - j - 1] - d[i][M[i] - j] + 4) % 4;
      }
    }

    REP(i, 1, N) {
      if(M[i] != M[0]) continue;
      bool same = true;
      REP(j, 1, M[i] - 1) if(l[i][j] != l[0][j]) same = false;
      REP(j, 1, M[i] - 2) if(c[0][i][j] != c[0][0][j]) same = false;
      bool reverse = true;
      REP(j, 1, M[i] - 1) if(l[i][M[i] - j] != l[0][j]) reverse = false;
      REP(j, 1, M[i] - 2) if(c[1][i][j] != c[0][0][j]) reverse = false;
      if(same || reverse) cout << i << endl;
    }
    cout << "+++++" << endl;
  }

  return 0;
}