#include <bits/stdc++.h>
using namespace std;
void rotate(vector<pair<int, int>> &L){
  int m = L.size();
  for (int i = 0; i < m; i++){
    int x = L[i].first;
    int y = L[i].second;
    L[i] = make_pair(y, -x);
  }
}
void standardize(vector<pair<int, int>> &L){
  int m = L.size();
  if (L[0].first == L[1].first && L[0].second > L[1].second){
    rotate(L);
  }
  if (L[0].first > L[1].first && L[0].second == L[1].second){
    rotate(L);
  }
  if (L[0].first == L[1].first && L[0].second < L[1].second){
    rotate(L);
  }
  int x = L[0].first;
  int y = L[0].second;
  for (int i = 0; i < m; i++){
    L[i].first -= x;
    L[i].second -= y;
  }
}
int main(){
  while (1){
    int n;
    cin >> n;
    if (n == 0){
      break;
    }
    vector<vector<pair<int, int>>> L(n + 1);
    for (int i = 0; i <= n; i++){
      int m;
      cin >> m;
      L[i] = vector<pair<int, int>>(m);
      for (int j = 0; j < m; j++){
        int x, y;
        cin >> x >> y;
        L[i][j] = make_pair(x, y);
      }
    }
    for (int i = 0; i <= n; i++){
      standardize(L[i]);
    }
    vector<bool> same(n, false);
    for (int i = 1; i <= n; i++){
      if (L[0] == L[i]){
        same[i - 1] = true;
      }
    }
    reverse(L[0].begin(), L[0].end());
    standardize(L[0]);
    for (int i = 1; i <= n; i++){
      if (L[0] == L[i]){
        same[i - 1] = true;
      }
    }
    for (int i = 0; i < n; i++){
      if (same[i]){
        cout << i + 1 << endl;
      }
    }
    cout << "+++++" << endl;
  }
}
