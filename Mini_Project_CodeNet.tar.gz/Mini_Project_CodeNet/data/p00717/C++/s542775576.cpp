#include <bits/stdc++.h>
using namespace std;
using lint = long long;
template<class T = int> using V = vector<T>;
template<class T = int> using VV = V< V<T> >;

bool eql(V<> l, V<> r) {
  for (auto&& e : l) e -= l.back();
  for (auto&& e : r) e -= r.back();
  return l == r;
}
struct S {
  int m;
  V<> x, y;
  bool operator==(S r) const {
    for (int i = 0; i < 4; ++i) {
      if (eql(x, r.x) and eql(y, r.y)) return true;
      for (int j = 0; j < r.m; ++j) {
        tie(r.x[j], r.y[j]) = make_pair(-r.y[j], r.x[j]);
      }
    }
    reverse(begin(r.x), end(r.x));
    reverse(begin(r.y), end(r.y));
    for (int i = 0; i < 4; ++i) {
      if (eql(x, r.x) and eql(y, r.y)) return true;
      for (int j = 0; j < r.m; ++j) {
        tie(r.x[j], r.y[j]) = make_pair(-r.y[j], r.x[j]);
      }
    }
    return false;
  }
  friend istream& operator>>(istream& i, S& s) {
    cin >> s.m;
    s.x.resize(s.m), s.y.resize(s.m);
    for (int i = 0; i < s.m; ++i) cin >> s.x[i] >> s.y[i];
    return i;
  }
};

int main() {
  cin.tie(nullptr); ios::sync_with_stdio(false);
  while (true) {
    int n; cin >> n;
    if (!n) break;
    V<S> a(n + 1); for (auto&& e : a) cin >> e;
    for (int i = 1; i <= n; ++i) if (a[i] == a[0]) {
      cout << i << '\n';
    }
    cout << "+++++" << '\n';
  }
}
