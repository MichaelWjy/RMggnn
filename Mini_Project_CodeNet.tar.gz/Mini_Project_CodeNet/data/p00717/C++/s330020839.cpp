#include <iostream>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>
#include <utility>
#include <complex>
#include <set>
#include <map>
#include <queue>
#include <stack>
#include <deque>
#include <tuple>
#include <bitset>
#include <algorithm>
using namespace std;
typedef long double ld;
typedef long long ll;
typedef vector<int> vint;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef pair<double, double> pdd;
typedef complex<double> comd;
#define rep(i,n)	for(int i=0;i<n;i++)
#define srep(i,a,n)	for(int i=a;i<n;i++)
#define REP(i,n)	for(int i=0;i<=n;i++)
#define SREP(i,a,n)	for(int i=a;i<=n;i++)
#define rrep(i,n)	for(int i=n-1;i>=0;i--)
#define RREP(i,n)	for(int i=n;i>=0;i--)
#define all(a)	(a).begin(),(a).end()
#define mp(a,b)	make_pair(a,b)
#define mt	make_tuple
#define fst	first
#define scn second
#define bucnt(x)	__buildin__popcount(x)
#define debug(x)	cout<<"debug: "<<x<<endl

const ll inf = (ll)1e9;
const ll mod = (ll)1e9 + 7;
const ld eps = 1e-9;
const int dx[] = { 0,1,0,-1 };
const int dy[] = { 1,0,-1,0 };

vector<pii> rotate(vector<pii> a) {
	while (!(a[0].fst < a[1].fst&&a[0].scn == a[1].scn)) {
		rep(i, a.size())	a[i] = mp(a[i].scn, -a[i].fst);
	}
	return a;
}

int main() {
	while(true){
		int n;	cin >> n;
		if (n == 0)	break;
		vector<pii> base;
		int cnt = 0;
		REP(i, n) {
			int m;	cin >> m;
			vector<pii> v(m, mp(0, 0));
			rep(j, m) {
				cin >> v[j].fst >> v[j].scn;
			}
			rrep(j, m) {
				v[j].fst -= v[0].fst;
				v[j].scn -= v[0].scn;
			}
			v = rotate(v);
			vector<pii> v2 = v;
			reverse(all(v2));
			rrep(j, m) {
				v2[j].fst -= v2[0].fst;
				v2[j].scn -= v2[0].scn;
			}
			v2 = rotate(v2);
			if (i == 0)	base = v;
			else if (base == v || base == v2)	cout << i << endl;
		}
		cout << "+++++" << endl;
	}
	return 0;
}