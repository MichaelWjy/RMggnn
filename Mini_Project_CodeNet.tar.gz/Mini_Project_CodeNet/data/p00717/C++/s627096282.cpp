#include <iostream>
#include <algorithm>
#include <iomanip>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <numeric>
#include <bitset>
#include <cmath>

static const int MOD = 1000000007;
using ll = long long;
using u32 = uint32_t;
using namespace std;

template<class T> constexpr T INF = ::numeric_limits<T>::max() / 32 * 15 + 208;

int main() {
    int n;
    using P = pair<int, int>;
    auto f = [](P a){ return P(-a.second, a.first); };
    while(cin >> n, n){
        n++;
        vector<vector<P>> v(n);
        for (int i = 0; i < n; ++i) {
            int m;
            cin >> m;
            for (int j = 0; j < m; ++j) {
                int x, y;
                scanf("%d %d", &x, &y);
                v[i].emplace_back(x, y);
            }

        }

        for (int k = (int)v[0].size()-1; k >= 0; --k) {
            v[0][k].first -= v[0][0].first;
            v[0][k].second -= v[0][0].second;
        }
        int ans = 0;
        for (int i = 1; i < n; ++i) {
            int ok = 0;
            if(v[0].size() != v[i].size()) continue;
            for (int l = 0; l < 2; ++l) {
                for (int j = 0; j < 4; ++j) {
                    auto X = v[i][0];
                    for (auto &&k : v[i]) {
                        k.first -= X.first;
                        k.second -= X.second;
                    }
                    for (auto &&k : v[i]){
                        k = f(k);
                    }
                    int cnt = 0;
                    for (int k = 0; k < v[i].size(); ++k) {
                        if(v[0][k] == v[i][k]) cnt++;
                    }
                    if(cnt == v[i].size()) ok = 1;
                }
                reverse(v[i].begin(),v[i].end());
            }
            if(ok) cout << i << "\n";
        }
        puts("+++++");
    }
    return 0;
}
