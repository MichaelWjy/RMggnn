#include<bits/stdc++.h>
using namespace std;
int n,m,x[4][10],y[4][10],nm,nx[2][10],ny[2][10];

bool check(){
  if(m!=nm)return 0;
  int res=0;
  for(int i=0;i<m;i++)nx[1][m-i-1]=nx[0][i],ny[1][m-i-1]=ny[0][i];
  for(int i=m-1;i>=0;i--)
    for(int j=0;j<2;j++)nx[j][i]-=nx[j][0],ny[j][i]-=ny[j][0];
  for(int i=0;i<4;i++)
    for(int j=0;j<2;j++){
      int f=1;
      for(int k=0;k<m;k++)
	if(x[i][k]!=nx[j][k]||y[i][k]!=ny[j][k])f=0;
      if(f)res=1;
  }
  return res;
}

int main(){
  while(cin>>n,n){
    cin>>m;
    for(int i=0;i<m;i++)cin>>x[0][i]>>y[0][i];
    for(int i=m-1;i>=0;i--)
      x[0][i]-=x[0][0],y[0][i]-=y[0][0];
    for(int i=1;i<4;i++){
      for(int j=0;j<m;j++)
	x[i][j]=-y[i-1][j],y[i][j]=x[i-1][j];
    }
    for(int i=1;i<=n;i++){
      cin>>nm;
      for(int j=0;j<nm;j++)cin>>nx[0][j]>>ny[0][j];
      if(check())cout<<i<<endl;
    }
    cout<<"+++++"<<endl;
  }
  return 0;
}