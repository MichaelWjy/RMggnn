#include<bits/stdc++.h>

#define INF 1e9
#define llINF 1e18
#define MOD 1e9+7
#define pb push_back
#define mp make_pair 
#define F first
#define S second
#define ll long long
using namespace std;
typedef struct po{
  int x,y;
}Point;
class polygon{
public:
  int mm;
  vector<Point> p;
  polygon(int m){
    mm = m;
    p.resize(mm);
    for(int i=0;i<mm;i++){
      cin>>p[i].x>>p[i].y;
    }
  }
  void rotate(){
    for(int i=0;i<mm;i++){
      Point tmp=p[i];
      p[i].x=-tmp.y;
      p[i].y=tmp.x;
    }
  }

  bool check(Point a,Point b,Point a2,Point b2){
    return ((b.x-a.x)==(b2.x-a2.x)&&(b.y-a.y)==(b2.y-a2.y));
  }

  bool search(vector<Point> origin){
    bool flag1=true;
    bool flag2=true;
    if(origin.size()!=p.size())return false;
    for(int i=0;i<mm-1;i++){
      if(!check(p[i],p[i+1],origin[i],origin[i+1]))
	flag1=false;
      if(!check(p[mm-(i+1)],p[mm-(i+2)],origin[i],origin[i+1]))
	flag2=false;
    }
    if(flag1||flag2)
      return true;
    else
      return false;
  }
};
int main(){
  int n;
  while(cin>>n,n){
    vector<int>ans;
    int mm;cin>>mm;
    polygon origin(mm);
    for(int i=1;i<=n;i++){
      int m;cin>>m;
      polygon pg(m);
      for(int j=0;j<4;j++){
	if(pg.search(origin.p)){
	  ans.pb(i);
	  break;
	}
	pg.rotate();
      }
    }
    for(int i=0;i<ans.size();i++)
      cout<<ans[i]<<endl;
    cout<<"+++++"<<endl;
  }
  return 0;
}

