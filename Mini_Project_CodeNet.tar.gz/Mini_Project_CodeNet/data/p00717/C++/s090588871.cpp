#include <bits/stdc++.h>
using namespace std;

#define rep(i,a,b) for(int i=a;i<b;i++)

typedef pair<int, int> pii;
typedef vector<pii> vpii;

bool solve(vpii temp, vpii target)
{
	rep(i, 1, target.size())
		target[i] = make_pair(target[i].first - target[0].first, target[i].second - target[0].second);
	target[0] = make_pair(0, 0);

	rep(i, 0, 4)
	{
		bool ok = true;
		rep(j, 0, target.size())
		{
			if (temp[j].first != target[j].first || temp[j].second != target[j].second) ok = false;
		}
		if (ok) return true;

		rep(j, 0, target.size())
		{
			target[j] = make_pair(-target[j].second, target[j].first);
		}
	}

	rep(i, 0, target.size() / 2)
	{
		pii p = target[i];
		target[i] = target[target.size() - 1 - i];
		target[target.size() - 1 - i] = p;
	}

	rep(i, 1, target.size())
		target[i] = make_pair(target[i].first - target[0].first, target[i].second - target[0].second);
	target[0] = make_pair(0, 0);

	rep(i, 0, 4)
	{
		bool ok = true;
		rep(j, 0, target.size())
		{
			if (temp[j].first != target[j].first || temp[j].second != target[j].second) ok = false;
		}
		if (ok) return true;

		rep(j, 0, target.size())
		{
			target[j] = make_pair(-target[j].second, target[j].first);
		}
	}

	return false;
}

int main()
{
	while (1)
	{
		int n; cin >> n;
		if (n == 0) return 0;

		int tm; cin >> tm;
		vpii temp(tm);
		rep(i, 0, tm)
		{
			int x, y; cin >> x >> y;
			temp[i] = make_pair(x, y);
		}
		rep(i, 1, tm) temp[i] = make_pair(temp[i].first - temp[0].first, temp[i].second - temp[0].second);
		temp[0] = make_pair(0, 0);
		
		rep(i, 1, n + 1)
		{
			int m; cin >> m;
			vpii target(m);
			rep(j, 0, m)
			{
				int x, y; cin >> x >> y;
				target[j] = make_pair(x, y);
			}

			if (tm != m) continue;

			if (solve(temp, target))
				cout << i << endl;
		}

		cout << "+++++" << endl;
	}
}