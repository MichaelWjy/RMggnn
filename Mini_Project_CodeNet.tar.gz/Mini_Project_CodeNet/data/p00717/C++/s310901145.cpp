#include<iostream>
#include<cstdio>
#include<string>
#include<vector>
#include<cmath>
#include<algorithm>
#include<functional>
#include<iomanip>
#include<queue>
#include<ciso646>
#include<random>
#include<map>
#include<set>
using namespace std;
typedef long long ll;
const ll MOD = 1000000007;
const ll INF = (ll)1000000007 * 1000000007;
const double EPS = 1e-9;
typedef pair<int, int> P;
typedef unsigned int ui;
#define stop char nyaa;cin>>nyaa;
#define rep(i,n) for(int i=0;i<n;i++)
#define Rep(i,sta,n) for(int i=sta;i<n;i++)
#define rep1(i,n) for(int i=1;i<=n;i++)
#define per1(i,n) for(int i=n;i>=1;i--)
int main() {
	int n,m,x,y;
	int t[4][4] = {};
	t[0][1] = t[1][2] = t[2][3] = t[3][0] = 1;
	t[1][0] = t[2][1] = t[3][2] = t[0][3] = -1;
	while (cin >> n, n) {
		vector<int> v[51]; vector<int>u;
		rep(i, n+1) {
			vector<P> p;
			cin >> m;
			int memo;
			rep(j, m) {
				cin >> x >> y;
				p.push_back({ x,y });
			}
			rep(j, m - 1) {
				int dir;
				if (p[j + 1].first > p[j].first) {
					dir = 1;
				}
				else if (p[j + 1].first < p[j].first) {
					dir = 3;
				}
				else if (p[j + 1].second > p[j].second) {
					dir = 0;
				}
				else dir = 2;
				if (j) {
					v[i].push_back(t[memo][dir]);
				}
				v[i].push_back(abs(p[j + 1].first - p[j].first + p[j + 1].second - p[j].second));
				memo = dir;
			}
			if (i == 0) {
				for(int j=m-1;j>0;j--) {
					int dir;
					if (p[j - 1].first > p[j].first) {
						dir = 1;
					}
					else if (p[j - 1].first < p[j].first) {
						dir = 3;
					}
					else if (p[j - 1].second > p[j].second) {
						dir = 0;
					}
					else dir = 2;
					if (j<m-1) {
						u.push_back(t[memo][dir]);
					}
					u.push_back(abs(p[j - 1].first - p[j].first + p[j - 1].second - p[j].second));
					memo = dir;
				}
			}
		}
		rep1(i, n) {
			if (v[0] == v[i]) {
				cout << i << endl; continue;
			}
			if (u == v[i]) {
				cout << i << endl;
			}
		}
		cout << "+++++" << endl;
	}
	return 0;
}
