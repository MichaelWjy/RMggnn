#include <bits/stdc++.h>
using namespace std;

#define iota(i,n,b,s) for(int i=int(b);i!=int((b)+(s)*(n));i+=(s))
#define range(i,n,m) iota(i,(((n)>(m))?((n)-(m)):((m)-(n))),(n),((n)>(m)?-1:1))
#define rep(i,n) iota(i,(n),0,1)
#define loop for(;;)

#define INF (1e9)
#define EPS (1e-9)
#define cons(a,b) (make_pair(a,b))
#define car(a) (a.first)
#define cdr(a) (a.second)
#define cadr(a) (car(cdr(a)))
#define cddr(a) (cdr(cdr(a)))
#define all(a) a.begin(), a.end()
#define trace(var) cerr<<">>> "<<#var<<" = "<<var<<endl;

typedef long long Integer;
typedef double Real;
typedef vector<int> vi;
typedef vector<string> vs;
typedef map<string,int> Dictionary;
const Real PI = acos(-1);
typedef pair<Real, Real> P; // Point
typedef pair<P, P> L; // segment or line

template<class S, class T>
ostream& operator<<(ostream& os, pair<S,T> p) {
  os << '(' << car(p) << ", " << cdr(p) << ')';
  return os;
}

template<class T>
ostream& operator<<(ostream& os, vector<T> v) {
  if (v.size() == 0) {
    os << "(empty)";
    return os;
  }
  os << v[0];
  for (int i=1, len=v.size(); i<len; ++i) os << ' ' << v[i];
  return os;
}


/* inner dot */
Real dot(P a, P b) {
  return car(a) * car(b) + cdr(a) * cdr(b);
}
Real operator*(P&a, P&b) {
  return car(a) * car(b) + cdr(a) * cdr(b);
}

/* scalar multiple */
P operator*(P a, Real c) {
  return cons(c * car(a), c * cdr(a));
}
P operator*(Real c, P a) {
  return cons(c * car(a), c * cdr(a));
}

P operator/(P a, Real d) {
  return cons(car(a) / d, cdr(a) / d);
}

Real det(P a, P b) {
  return car(a) * cdr(b) - cdr(a) * car(b);
}

/* vector operator */
P operator+(P a, P b) {
  return cons(car(a) + car(b), cdr(a) + cdr(b));
}

P operator-(P a) {
  return cons(-car(a), -cdr(a));
}

P operator-(P a, P b) {
  return cons(car(a) - car(b), cdr(a) - cdr(b));
}

/* distance */
Real Manhattan(P a, P b) {
  return abs(car(a) - car(b)) + abs(cdr(a) - cdr(b));
}
Real Euclidean(P a, P b) {
  P p = a - b;
  return sqrt(pow(car(p), 2) + pow(cdr(p), 2));
}

/* equality with EPS (default: 1e-9) */
bool eq(Real x, Real y) {
  return abs(x - y) < EPS;
}
bool operator==(P a, P b) {
  return eq(car(a), car(b)) && eq(cdr(a), cdr(b));
}

int sign(Real a) {
  if (eq(a, 0)) return 0;
  return a > 0 ? 1 : -1;
}

bool* PrimeSieve(int n) {
  bool*s = new bool[n];
  for (int i = 0; i < n; ++i) s[i] = true;
  s[0] = s[1] = false;
  for (int i = 2; i < n; ++i)
    if (s[i]) for (int j = i << 1; j < n; j += i) s[j] = false;
  return s;
}

tuple<vector<Real>, vector<Real>, vector<Real>>
read_g() {
  int m; cin >> m;
  vector<P> ps;

  rep (i, m) {
    Real x, y; cin >> x >> y;
    ps.push_back(P(x, y));
  }

  vector<Real> ds, ss, cs;

  rep (i, m - 1) {
    ds.push_back(Euclidean(ps[i], ps[i+1]));
  }

  rep (i, m - 2) {
    ss.push_back(det(ps[i] - ps[i+1], ps[i+2] - ps[i+1]));
    //cs.push_back(dot(ps[i] - ps[i+1], ps[i+2] - ps[i+1]));
  }

  return make_tuple(ds, ss, cs);
}

int main() {
  for (int n; cin >> n, n; ) {
    auto g = read_g();
    //trace(get<3>(g));
    rep (i, n) {
      auto f = read_g();
      if (f == g) {
        cout << i+1 << endl;
      } else {
        reverse(all(get<0>(f)));
        reverse(all(get<1>(f)));
        int m = get<1>(f).size();
        rep (j, m) get<1>(f)[j] *= -1;
        if (f == g) {
          cout << i+1 << endl;
        }
      }
    }
    cout << "+++++" << endl;
  }

  return 0;
}