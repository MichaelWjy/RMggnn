#include <bits/stdc++.h>
using namespace std;
using Int = int_fast64_t;

class A{
public:
	Int n;
	vector<Int> d, l;
	A(Int _n){
		n = _n;
		d.resize(n);
		l.resize(n);
	}
	void b(Int i, Int x1, Int y1, Int x2, Int y2){
//		cout << i << " " << x1 << " " << y1 << " " << x2 << " " << y2 << "\n";
		if(x1 == x2){
			if(y1 < y2){
				d[i] = 0;
				l[i] = y2 - y1;
			}else{
				d[i] = 3;
				l[i] = y1 - y2;
			}
		}else{
			if(x1 < x2){
				d[i] = 1;
				l[i] = x2 - x1;
			}else{
				d[i] = 2;
				l[i] = x1 - x2;
			}
		}
	}
	void print(){
		for(Int i=0; i<n; ++i)
			cout << i << " " << d[i] << " " << l[i] << "\n";
	}
};

A D(A a){
	A r(a);
	for(Int i=0; i<a.n; ++i){
		r.l[i] = a.l[a.n-1-i];
		r.d[i] = 3 - a.d[a.n-1-i];
	}
	return r;
}

bool C(A a, A b){
	if(a.n != b.n) return false;
	vector<Int> e = {2, 0, 3, 1};
	for(Int i=0; i<4; ++i){
//		a.print();
//		b.print();
		bool f = true;
		for(Int j=0; j<a.n; ++j)
			if(a.d[j] != b.d[j] || a.l[j] != b.l[j])
				f = false;
		if(f) return true;
		for(Int j=0; j<b.n; ++j)
			b.d[j] = e[b.d[j]];
	}
	return false;
}

void solve(Int n){
	Int m, x, y; cin >> m >> x >> y;
	A a0(m-1);
	for(Int i=0; i<m-1; ++i){
		Int z, w; cin >> z >> w;
		a0.b(i, x, y, z, w);
		x = z;
		y = w;
	}
//	a0.print();
	for(Int i=0; i<n; ++i){
		cin >> m >> x >> y;
		A a(m-1);
//		cout << "1\n";
//		a.print();
		for(Int j=0; j<m-1; ++j){
			Int z, w; cin >> z >> w;
			a.b(j, x, y, z, w);
			x = z;
			y = w;
		}
//		cout << "2\n";
//		a.print();
		if(C(a0, a) || C(a0, D(a))) cout << i+1 << "\n";
	}
	cout << "+++++\n";
}

int main(){
	cin.tie(0);
	ios::sync_with_stdio(false);
	while(1){
		Int n; cin >> n;
		if(n == 0) break;
		solve(n);
	}
}
