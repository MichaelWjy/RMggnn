#include<iostream>
#include<cmath>
using namespace std;

struct Image {
	bool f;
	int len[10];
	int com[10];
};

Image images[50];

int main()
{
	int n, m, tm, x, y, d, px, py, pd, j;

	while (cin >> n , n) {
		for (int i = 0; i <= n; i++) {
			if (i == 0) cin >> m;
			else {
				cin >> tm;
				if (tm == m) images[i].f = true;
				else {
					images[i].f = false;
					continue;
				}
			} 
			for (j = 0; j < m; j++) {
				cin >> x >> y;
				if (j != 0) {
					d = (x == px ? y - py : x - px);
					images[i].len[j - 1] = abs(d);
					if (j == 1) {
						images[i].com[j - 1] = 0;
					} else if (x == px) {
						images[i].com[j - 1] = (pd * d > 0 ? 1 : -1);
					} else {
						images[i].com[j - 1] = (pd * d > 0 ? -1 : 1);
					}
				}
				px = x;
				py = y;
				pd = d;
			}
			images[i].com[j] = 0;
		}
		m--;
		for (int i = 1; i <= n; i++) {
			if (!images[i].f) continue;
			
			for (j = 0; j < m; j++) {
				if (images[0].len[j] != images[i].len[j] ||
				 images[0].com[j] != images[i].com[j]) break;
			}
			if (j == m) {
				cout << i << endl;
				continue;
			}
			
			for (j = 0; j < m; j++) {
				if (images[0].len[j] != images[i].len[m - 1 - j] ||
				 images[0].com[j] != -images[i].com[m - j]) break;
			}
			if (j == m) {
				cout << i << endl;
				continue;
			}
		}
		cout << "+++++" << endl;
	}
	
	return 0;
}