#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <iostream>
#include <sstream>
#include <vector>
#include <string>
#include <queue>
#include <set>
#include <map>
#include <utility>
#include <algorithm>
#include <functional>
#include <complex>

using namespace std;

#define REP(i,n) for((i)=0;(i)<(int)(n);(i)++)

typedef int Element;
typedef complex<Element> Point;

Element dot(const Point& a, const Point& b){
  return (a.real() * b.real() + a.imag() * b.imag());
}

Element cross(const Point& a, const Point& b){
  return (a.real() * b.imag() - a.imag() * b.real());
}

int ccw(Point a, Point b, Point c){
  b -= a; c -= a;
  if(cross(b,c) > 0) return +1;    // counter clock wise
  if(cross(b,c) < 0) return -1;    // clock wise
  if(dot(b,c) < 0) return +2;      // c--a--b
  if(norm(b) < norm(c)) return -2; // a--b--c
  return 0;                        // a--c--b || b == c
}

int main(){
  int N,M,i,j,x;
  vector< complex<Element> > origin;
  vector< complex<Element> > v[60];

  while(1){
    scanf("%d",&N);
    if(N == 0) break;
    scanf("%d",&M);
    origin.resize(M);
    REP(i,M) scanf("%d %d",&origin[i].real(),&origin[i].imag());
    REP(i,N){
      scanf("%d",&M);
      v[i].resize(M);
      REP(j,M) scanf("%d %d",&v[i][j].real(),&v[i][j].imag());
    }

    bool used[10];
    vector<int> res;
    REP(i,10) used[i] = false;
    REP(x,2) REP(i,N){
      bool same = true;
      if(x == 1) reverse(v[i].begin(),v[i].end());
      if(v[i].size() != origin.size()) continue;
      REP(j,origin.size()-1){
        if(abs(v[i][j].real() - v[i][j+1].real()) != abs(origin[j].real() - origin[j+1].real())) same = false;
        if(abs(v[i][j].imag() - v[i][j+1].imag()) != abs(origin[j].imag() - origin[j+1].imag())) same = false;
      }
      REP(j,origin.size()-2) if(ccw(v[i][j],v[i][j+1],v[i][j+2]) != ccw(origin[j],origin[j+1],origin[j+2])) same = false;
      if(same && !used[i]){
        res.push_back(i+1);
        used[i] = true;
      }
    }

    sort(res.begin(),res.end());
    REP(i,res.size()) cout << res[i] << endl;
    cout << "+++++" << endl;    
  }

  return 0;
}