#include <iostream>
#include <vector>
#include <algorithm>
#include <numeric>
#include <set>
#include <map>
#include <string>
#include <stack>
#include <queue>
#include <cmath>
#include <cstdio>
#include <istream>
#include <sstream>
#include <iomanip>
#include <iterator>
#include <climits>
using namespace std;

typedef ostringstream OSS;
typedef istringstream ISS;

typedef vector<int> VI;
typedef vector< VI > VVI;

typedef long long LL;

typedef pair<int, int> PII;
typedef vector<PII> VPII;

#define X first
#define Y second

const LL MOD = 1000000007;

template<typename T>
void dump(T a, int n) { for (int i = 0; i < n; i++) cout << a[i] << (i == n - 1 ? '\n' : ' '); }

template<typename T>
void dump(T a) { dump<T>(a, a.size()); }

VPII offset(VPII line) {
	int x0 = line[0].X, y0 = line[0].Y;
	for (int i = 0; i < (int)line.size(); i++) {
		line[i].X -= x0;
		line[i].Y -= y0;
	}

	return line;
}

VPII rotate90(VPII line) {
	for (auto &l : line) {
		swap(l.X, l.Y);
		l.X *= -1;
	}
	return line;
}

bool same(VPII &line1, VPII &line2) {
	if (line1.size() != line2.size()) {
		return false;
	}

	for (int i = 0; i < (int)line1.size(); i++) {
		if (line1[i] != line2[i]) {
			return false;
		}
	}

	return true;
}

bool some(vector< VPII > &lines0, VPII &line, VPII &rline) {
	for (int i = 0; i < 4; i++) {
		if (same(lines0[i], line) || same(lines0[i], rline)) {
			return true;
		}
	}
	
	return false;
}

int main(void) {
	for (int N; cin >> N, N;) {
		vector< VPII > lines0(4);
		vector< VPII > lines(N + 1);
		vector< VPII > rlines(N + 1);

		for (int i = 0; i <= N; i++) {
			int M, x, y;
			cin >> M;

			for (int j = 0; j < M; j++) {
				cin >> x >> y;
				lines[i].emplace_back(x, y);
			}
		}

		// reverse set
		for (int i = 0; i <= N; i++) {
			rlines[i] = VPII(lines[i].rbegin(), lines[i].rend());
		}

		// lines0 4dt set
		lines0[0] = lines[0];
		for (int i = 1; i < 4; i++) {
			lines0[i] = rotate90(lines0[i - 1]);
		}

		// offset
		transform(lines.begin(), lines.end(), lines.begin(), offset);
		transform(rlines.begin(), rlines.end(), rlines.begin(), offset);
		transform(lines0.begin(), lines0.end(), lines0.begin(), offset);

		// diff
		for (int i = 1; i <= N; i++) {
			if (some(lines0, lines[i], rlines[i])) {
				cout << i << endl;
			}
		}
		cout << "+++++" << endl;
	}

	return 0;
}