#include<bits/stdc++.h>
using namespace std;

int n, bm, sm;
vector< complex<double> > b;
vector< complex<double> > s;

void rotate(){
  for(int i=0; i<sm; i++){
    double tmp=s[i].real();
    s[i].real()=s[i].imag();
    s[i].imag()=-tmp;
  }
}

bool comp(){
  for(int i=0; i<sm; i++){
    if(b[i].real()-b[0].real() != s[i].real()-s[0].real())return false;
    if(b[i].imag()-b[0].imag() != s[i].imag()-s[0].imag())return false;
  }
  return true;
}

bool solve(){
  if(bm!=sm)return false;
  for(int i=0; i<4; i++){
    if(comp())return true;
    rotate();
  }
  reverse(s.begin(), s.end());
  for(int i=0; i<4; i++){
    if(comp())return true;
    rotate();
  }
}

int main(){
  while(cin>>n, n!=0){
    b.clear();
    cin>>bm;
    for(int i=0; i<bm; i++){
      complex<double> tmp;
      cin>>tmp.real()>>tmp.imag();
      b.push_back(tmp);
    }

    for(int i=1; i<=n; i++){
      s.clear();
      cin>>sm;
      for(int j=0; j<sm; j++){
        complex<double> tmp;
        cin>>tmp.real()>>tmp.imag();
        s.push_back(tmp);
      }
      if(solve())cout<<i<<endl;
    }
    cout<<"+++++"<<endl;
  }
  return 0;
}