#include<iostream>
#include<vector>
#include<queue>
using namespace std;
#define rep(i,a) for(int i = 0 ; i < a ; i ++)
#define loop(i,a,b) for(int i = a ; i < b ; i ++)

int main(void){
  int n;
  while(cin>>n,n){
    if(n == 1)cout<<"1 1"<<endl;
    else{
      vector<vector<int> > ary(n+1,vector<int>(4,0)),cp;
      int ni,di;
      rep(i,n-1){
        cin>>ni>>di;
        ary[ni][di]=i+1;
      }
      cp = ary;
      queue<pair<int,int> > q;
      int ml = 0,mr = 0,mt = 0,mb = 0;
      q.push(make_pair(0,0));
      while(!q.empty()){
        pair<int,int> front = q.front(); q.pop();
        ml = max(ml,front.second);
        int now = front.first;

        if(ary[now][0])
          q.push(make_pair(ary[now][0],front.second+1));
        if(ary[now][1])
          q.push(make_pair(ary[now][1],front.second));
        if(ary[now][3])
          q.push(make_pair(ary[now][3],front.second));
        rep(i,4)ary[now][i] = 0;

      }


      q.push(make_pair(0,0));
      ary = cp;
      while(!q.empty()){
        pair<int,int> front = q.front(); q.pop();
        mr = max(mr,front.second);
        int now = front.first;
        if(ary[now][2])
          q.push(make_pair(ary[now][2],front.second+1));
        if(ary[now][1])
          q.push(make_pair(ary[now][1],front.second));
        if(ary[now][3])
          q.push(make_pair(ary[now][3],front.second));
        rep(i,4)ary[now][i] = 0;
        
      }


      q.push(make_pair(0,0));
      ary = cp;
      while(!q.empty()){
        pair<int,int> front = q.front(); q.pop();
        mt = max(mt,front.second);
        int now = front.first;
        
        if(ary[now][1])
          q.push(make_pair(ary[now][1],front.second+1));
        if(ary[now][0])
          q.push(make_pair(ary[now][0],front.second));
        if(ary[now][2])
          q.push(make_pair(ary[now][2],front.second));
        rep(i,4)ary[now][i] = 0;
      }
      


      q.push(make_pair(0,0));
      ary = cp;
      while(!q.empty()){
        pair<int,int> front = q.front(); q.pop();
        mb= max(mb,front.second);
        int now = front.first;

        if(ary[now][3])
          q.push(make_pair(ary[now][3],front.second+1));
        if(ary[now][2])
          q.push(make_pair(ary[now][2],front.second));
        if(ary[now][0])
          q.push(make_pair(ary[now][0],front.second));
        rep(i,4)ary[now][i] = 0;
      }
      //cout<<ml<<" "<<mr<<" "<<mt<<" "<<mb<<endl;
      cout<<ml+mr+1<<" "<<mt+mb+1<<endl;
    }
  }
}