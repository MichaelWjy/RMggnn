#include <iostream>
#include <vector>
using namespace std;

int main(){
	int n;
	int m;
	const int nmax = 50;
	const int mmax = 10;
	while(cin >> n){
		double x[nmax+1][mmax];
		double y[nmax+1][mmax];
		double dis[nmax+1][mmax];
		int direction[nmax+1][mmax];
		int size[nmax+1];
		if(n == 0) break;
		for(int i = 0; i <= n; i++){
			cin >> m;
			size[i] = m;
			for(int j = 0; j < m; j++){
				cin >> x[i][j] >> y[i][j];
			}
			for(int j = 1; j < m; j++){
				double dx = x[i][j] - x[i][j-1];
				double dy = y[i][j] - y[i][j-1];
				dis[i][j] = dx * dx + dy * dy;
				if(dx == 0){
					if(dy > 0){
						direction[i][j] = 0;
					}else direction[i][j] = 2;
				}else{
					if(dx > 0){
						direction[i][j] = 1;
					}else direction[i][j] = 3;
				}
			}
		}
		for(int i = 1; i <= n; i++){
			if(size[0] != size[i]) continue;
			for(int j = 0; j < 4; j++){
				bool f = true;
				for(int k = 1; k < m; k++){
					if(direction[0][k] != ((direction[i][k] + j) % 4)
						|| dis[0][k] != dis[i][k])
					{
				
					f = false;
						break;
					}
					
				}
				if(f){ 
					cout << i << endl;
					break;
				}
				f = true;
				for(int k = 1; k < m; k++){
					if(direction[0][k] != ((direction[i][m-k] + j) % 4)
						|| dis[0][k] != dis[i][m-k])
					{
						f = false;
						break;
					}
				}
				if(f){
					cout << i << endl;
					break;
				}
			}
		}
		cout << "+++++" << endl;
	}
	return 0;
}