#include<iostream>
#include<sstream>
#include<vector>
#include<algorithm>
#include<complex>
#include<set>
#include<map>
#include<queue>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cassert>
#define rep(i,n) for(int i=0;i<(int)n;i++)
#define each(i,c) for(__typeof (c.begin()) i=c.begin(); i!=c.end(); i++)
#define all(c) (c).begin(), (c).end()
#define pb push_back
#define mp make_pair
#define F first
#define S second
#define dbg(x) cerr<<__LINE__<<": "<<#x<<" = "<<x<<endl
using namespace std;
typedef pair<int,int> P;
const int Cos[3] = {0,-1,0};
const int Sin[3] = {1,0,-1};
vector<P> Dini[20],Dini2[20];
vector<P> nH;
void Move(vector<P> s){
  rep(i,s.size()){
    nH.push_back(P(s[i].F-s[0].F,s[i].S-s[0].S));
  }
}


void CreateDiniAndDini2(vector<P> Must){
  rep(i,Must.size()){
    Dini[0].push_back(P(Must[i].F-Must[0].F,Must[i].S-Must[0].S));
    Dini2[0].push_back(P(Must[i].F-Must[Must.size()-1].F,Must[i].S-Must[Must.size()-1].S));   
  }
  reverse(all(Dini2[0]));

  rep(i,3){
    rep(j,Must.size()){
      Dini[i+1].push_back(P(Dini[0][j].F*Cos[i]-Dini[0][j].S*Sin[i], Dini[0][j].F*Sin[i]+Dini[0][j].S*Cos[i]));
      Dini2[i+1].push_back(P(Dini2[0][j].F*Cos[i]-Dini2[0][j].S*Sin[i],Dini2[0][j].F*Sin[i]+Dini2[0][j].S*Cos[i]));
    }
  }   
}

bool _check(int a,int b){
  return a == b?true:false;
}

bool IC(vector<P> isono){
  bool Isxo[8];
  if(Dini2[0].size() != isono.size())return false;
  rep(i,8)Isxo[i] = true;

  if(!(isono[0].F == 0 && isono[0].S == 0))reverse(all(isono));
 

  rep(i,Dini[0].size()){
    if(!(_check(Dini[0][i].F,isono[i].F) && _check(Dini[0][i].S,isono[i].S)))Isxo[0] = false;
    if(!(_check(Dini[1][i].F,isono[i].F) && _check(Dini[1][i].S,isono[i].S)))Isxo[1] = false;
    if(!(_check(Dini[2][i].F,isono[i].F) && _check(Dini[2][i].S,isono[i].S)))Isxo[2] = false;
    if(!(_check(Dini[3][i].F,isono[i].F) && _check(Dini[3][i].S,isono[i].S)))Isxo[3] = false;
    if(!(_check(Dini2[0][i].F,isono[i].F) && _check(Dini2[0][i].S,isono[i].S)))Isxo[4] = false;
    if(!(_check(Dini2[1][i].F,isono[i].F) && _check(Dini2[1][i].S,isono[i].S)))Isxo[5] = false;
    if(!(_check(Dini2[2][i].F,isono[i].F) && _check(Dini2[2][i].S,isono[i].S)))Isxo[6] = false;
    if(!(_check(Dini2[3][i].F,isono[i].F) && _check(Dini2[3][i].S,isono[i].S)))Isxo[7] = false;
  }
  rep(i,8)if(Isxo[i])return true;
  return false;
}


int main(){
  int m,n,x,y;
  vector<P> n0; 

  while(cin >> n && n){
    n0.clear();
    rep(i,20){
      Dini[i].clear();
      Dini2[i].clear();
    }
    cin >> m; 
    rep(i,m){
      cin >> x >> y;
      n0.push_back(P(x,y));
    }
    CreateDiniAndDini2(n0);

    rep(i,n){
      cin >> m;
      n0.clear();
      rep(j,m){
	cin >> x >> y;
	n0.push_back(P(x,y));
      }
      nH.clear();
      Move(n0);
      if(IC(nH))cout << i+1 << endl;
    }
    cout << "+++++" << endl;

  }
  return 0;
}