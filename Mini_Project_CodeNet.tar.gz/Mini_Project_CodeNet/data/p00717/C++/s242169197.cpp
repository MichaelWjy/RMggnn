#include "bits/stdc++.h"
using namespace std;
#define mod 1000000007
#define all(c) begin(c),end(c)
template <typename T> T &chmin(T &a, const T &b) { return a = min(a, b); }
template <typename T> T &chmax(T &a, const T &b) { return a = max(a, b); }
using ll = long long;
int dd[] = { 0, 1, 0, -1, 0 }; //→↓←↑

void solve()
{
	while (true)
	{
		int N;
		cin >> N;
		if (N == 0)break;

		int M;
		cin >> M;

		vector<pair<int, int>> V(M);
		for (int i = 0; i < M; i++)
		{
			int x, y;
			cin >> x >> y;
			V[i] = make_pair(x, y);
		}
		vector<int> S(M - 1);
		for (int i = 0; i < M - 1; i++)
		{
			S[i] = V[i + 1].first + V[i + 1].second - V[i].first - V[i].second;
			//cout << " " << S[i];
		}
		//cout << endl;

		bool B = (V[0].first == V[1].first);
		int ans = 0;

		for (int i = 0; i < N; i++)
		{
			int m;
			cin >> m;
			vector<pair<int, int>> v(m);
			for (int j = 0; j < m; j++)
			{
				int x, y;
				cin >> x >> y;
				v[j] = make_pair(x, y);
			}
			if (m != M)continue;
			vector<int> s(m - 1);
			for (int j = 0; j < m - 1; j++)
			{
				s[j] = v[j + 1].first + v[j + 1].second - v[j].first - v[j].second;
				//cout << " " << s[j];
			}
			//cout << endl;

			bool ans = false;
			for (int k = 0; k < 2; k++)
			{
				bool b = (v[0].first == v[1].first);
				if (B == b)
				{
					int dx[] = { 1,-1 };
					int dy[] = { 1,-1 };
					bool flag = true;
					for (int r = 0; r < 2; r++)
					{
						flag = true;
						for (int j = 0; j < M - 1; j++)
						{
							if (j % 2 == 0 && S[j] != s[j] * dx[r])
							{
								flag = false;
								break;
							}
							else if (j % 2 == 1 && S[j] != s[j] * dy[r])
							{
								flag = false;
								break;
							}
						}
						if (flag)
						{
							ans = true;
						}
					}
				}
				else
				{
					int dx[] = { 1,-1 };
					int dy[] = { -1,1 };
					bool flag = true;
					for (int r = 0; r < 2; r++)
					{
						flag = true;
						for (int j = 0; j < M - 1; j++)
						{
							if (j % 2 == 0 && S[j] != s[j] * dx[r])
							{
								flag = false;
								break;
							}
							else if (j % 2 == 1 && S[j] != s[j] * dy[r])
							{
								flag = false;
								break;
							}
						}
						if (flag)
						{
							ans = true;
						}
					}
				}

				reverse(all(s));
				reverse(all(v));
			}
			
			if (ans)cout << (i + 1) << endl;

		}

		cout << "+++++" << endl;

	}
}

int main()
{
	cin.tie(0);
	ios::sync_with_stdio(false);
	solve();
	return 0;
}
