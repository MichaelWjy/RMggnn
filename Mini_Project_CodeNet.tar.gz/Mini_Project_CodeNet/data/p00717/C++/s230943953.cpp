#include <bits/stdc++.h>
using namespace std;

typedef int64_t Int;
#define all(x) (x).begin(), (x).end()
 
const double EPS = 1e-10;
const Int INF = 1e18;
const int inf = 1e9;
const Int mod = 1e9+7;

bool print_space_enable = false;
void print() { 
    cout << '\n'; 
    print_space_enable = false;
}

template <class Head, class... Tail>
void print(Head&& head, Tail&&... tail) {
    if (print_space_enable) cout << " ";
    cout << fixed << setprecision(15) << head;
    print_space_enable = true;
    print(std::forward<Tail>(tail)...);
}

template<typename T>
void print(vector<T> v) {
    for (size_t i = 0; i < v.size(); i++) {
        if (i > 0) std::cout << " ";
        std::cout << v[i];
    }
    std::cout << '\n';
}

int main() {
    Int n;
    while (cin >> n and n) {
        Int m;
        cin >> m;
        vector<vector<pair<Int, Int>>> a(4, vector<pair<Int, Int>>(m - 1));
        vector<pair<Int, Int>> p(m);
        for (Int i = 0; i < m; i++) {
            cin >> p[i].first >> p[i].second;
        }
        for (Int i = 0; i < m - 1; i++) {
            a[0][i] = {p[i + 1].first - p[i].first, p[i + 1].second - p[i].second};
            a[1][i] = {-a[0][i].second, a[0][i].first};
            a[2][i] = {-a[0][i].first, -a[0][i].second};
            a[3][i] = {-a[1][i].first, -a[1][i].second};
        }
        vector<vector<pair<Int, Int>>> b(n);
        for (Int i = 0; i < n; i++) {
            Int l;
            cin >> l;
            vector<pair<Int, Int>> c(l);
            for (Int j = 0; j < l; j++) {
                cin >> c[j].first >> c[j].second;
            }
            b[i].reserve(l - 1);
            for (Int j = 0; j < l - 1; j++) {
                b[i][j] = {c[j + 1].first - c[j].first, c[j + 1].second - c[j].second};
            }
            if (m != l) continue;
            vector<pair<Int, Int>> d(l - 1);
            for (Int k = 0; k < l - 1; k++) {
                d[k] = b[i][k];
            }
            reverse(all(d));
            for (Int j = 0; j < l - 1; j++) {
                d[j] = {-d[j].first, -d[j].second};
            }
            bool check = false;
            for (Int j = 0; j < 4; j++) {
                bool check2 = true;
                for (Int k = 0; k < min(l - 1, m - 1); k++) {
                    if (a[j][k] != b[i][k]) {
                        check2 = false;
                    }
                }
                if (check2) {
                    check = true;
                }
            }
            for (Int j = 0; j < 4; j++) {
                bool check2 = true;
                for (Int k = 0; k < min(l - 1, m - 1); k++) {
                    if (a[j][k] != d[k]) {
                        check2 = false;
                    }
                }
                if (check2) {
                    check = true;
                }
            }
            if (check) {
                print(i + 1);
            }
        }
        print("+++++");
    }
    return 0;
}

