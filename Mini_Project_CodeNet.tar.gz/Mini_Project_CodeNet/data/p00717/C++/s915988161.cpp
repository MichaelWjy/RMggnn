#include <iostream>
#include <cstdio>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <deque>
#include <stack>
#include <algorithm>
#include <cstring>
#include <functional>
#include <cmath>
using namespace std;
#define rep(i,n) for(int i=0;i<(n);++i)
#define rep1(i,n) for(int i=1;i<=(n);++i)
#define all(c) (c).begin(),(c).end()
#define fs first
#define sc second
#define pb push_back
#define show(x) cout << #x << " " << x << endl
int m,di;
vector<int> sx,sy;
bool can(vector<int> x,vector<int> y){
	int md=0;
	if(x[0]==x[1]&&y[0]<y[1]) md=0;
	if(x[0]==x[1]&&y[0]>y[1]) md=2;
	if(x[0]<x[1]&&y[0]==y[1]) md=1;
	if(x[0]>x[1]&&y[0]==y[1]) md=3;
	int k=(md-di+4)%4;
	if(k==1){
		rep(i,m){
			swap(x[i],y[i]);
			x[i]=-x[i];
		}
	}
	if(k==2){
		rep(i,m){
			x[i]=-x[i],y[i]=-y[i];
		}
	}
	if(k==3){
		rep(i,m){
			swap(x[i],y[i]);
			y[i]=-y[i];
		}
	}
	rep(i,m){
		if(x[0]-x[i]!=sx[0]-sx[i]) return false;
		if(y[0]-y[i]!=sy[0]-sy[i]) return false;
	}
	return true;
}
int main(){
	while(true){
		int tt;
		cin>>tt;
		if(tt==0) break;
		sx.clear();
		sy.clear();
		cin>>m;
		rep(i,m){
			int p,q;
			cin>>p>>q;
			sx.pb(p);
			sy.pb(q);
		}
		if(sx[0]==sx[1]&&sy[0]<sy[1]) di=0;
		if(sx[0]==sx[1]&&sy[0]>sy[1]) di=2;
		if(sx[0]<sx[1]&&sy[0]==sy[1]) di=1;
		if(sx[0]>sx[1]&&sy[0]==sy[1]) di=3;
		rep1(t,tt){
			int mm;
			vector<int> x,y;
			cin>>mm;
			if(mm!=m){
				int p;
				rep(i,mm) cin>>p>>p;
				continue;
			}
			rep(i,mm){
				int p,q;
				cin>>p>>q;
				x.pb(p);
				y.pb(q);
			}
			bool ok=can(x,y);
			reverse(all(x));
			reverse(all(y));
			ok|=can(x,y);
			if(ok) cout<<t<<endl;
		}
		puts("+++++");
	}
}