#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;
void base_0(vector<pair<int,int> > &vec){
  int base_x,base_y;
  base_x = vec[0].first;
  base_y = vec[0].second;
  vec[0].first = 0;
  vec[0].second = 0;
  for(int i = 1;i < vec.size();i++){
	vec[i].first -= base_x;
	vec[i].second -= base_y;
  }
}
bool check_pair_eq(pair<int,int> &a,pair<int,int> &b){
  if(a.first == b.first && a.second == b.second){
	return true;
  }
  return false;
}
vector<int> cal(vector< vector<pair<int,int> > > &vec){
  vector<int> ans = vector<int>();
  for(int i = 1;i < vec.size();i++){
	int flag = 0;
	for(int j = 0;j < vec[i].size();j++){
	  if(vec[0].size() != vec[1].size() || !check_pair_eq(vec[0][j],vec[i][j])){
		flag = 1;
		break;
	  }
	}
	if(flag == 0){
	  ans.emplace_back(i);
	}
  }
  
  return ans;
}
vector<int>  vectoadd(vector<int> const &a,vector<int> const &b){

  vector<int> res = vector<int>();

  for(int i = 0;i < a.size();i++){
	res.push_back(a[i]);
  }

  for(int i = 0;i < b.size();i++){
	res.push_back(b[i]);
  }

  return res;
}
void rotate_r_90(vector<pair<int,int> > &vec){
  for(int i = 0;i < vec.size();i++){
	int x = vec[i].first;
	int y = vec[i].second;
	vec[i].first = -1*y;
	vec[i].second = x;
  }
}
int main(){
  
  int n;
  while(cin >> n && n != 0){
	
	vector<vector<pair<int,int> > > poly(n+1);
	for(int i = 0;i <= n;i++){
	  int m;
	  cin >> m;
	  poly[i] = vector<pair<int,int> > ();
	  for(int j = 0;j < m;j++){
		int x,y;
		cin >> x >> y;
		poly[i].emplace_back(x,y);
	  }
	}

	vector<int> ans = vector<int>();
	for(int i = 0;i <= n;i++){
	  base_0(poly[i]);
	}
	for(int i = 0;i < 4;i++){
	  for(int j = 1;j <= n;j++){
		rotate_r_90(poly[j]);
	  }
	  ans = vectoadd(ans, cal(poly));
	}

	for(int i = 1;i <= n;i++){
	  reverse(poly[i].begin(),poly[i].end());
	  base_0(poly[i]);
	}
	for(int i = 0;i < 4;i++){
	  for(int j = 1;j <= n;j++){
		rotate_r_90(poly[j]);
	  }
	  ans = vectoadd(ans, cal(poly));
	}
	


	sort(ans.begin(),ans.end());
	if(ans.size())
	  cout << ans[0] << endl;
	for(int i = 1;i < ans.size();i++){
	  if(ans[i-1] != ans[i]){
		cout << ans[i] << endl;
	  }
	}
	cout << "+++++" << endl;
	
	
  }  
  return 0;
}