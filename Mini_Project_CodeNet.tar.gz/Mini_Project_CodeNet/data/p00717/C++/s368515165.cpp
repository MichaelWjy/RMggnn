#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;
int main() {
	int n;

	while (cin >> n, n) {
		int m0;
		cin >> m0;
		vector<int> x0(m0);
		int x, y, X, Y;
		for (int i = 0; i < m0; i++) {
			cin >> X >> Y;
			if (i > 0) {
				x0[i] = (x - X) + (y - Y);
			}
			x = X;
			y = Y;
		}

		for (int i = 0; i < n; i++) {
			int m;
			cin >> m;
			vector<int> line(m);
			int x, y, X, Y;
			for (int i = 0; i < m0; i++) {
				cin >> X >> Y;
				if (i > 0) {
					line[i] = (x - X) + (y - Y);
				}
				x = X;
				y = Y;
			}
			if (m0 == m) {
				if (x0 == line) {
					cout << i + 1 << endl;
				} else {
					reverse(begin(line), end(line));
					if (x0 == line) {
						cout << i + 1 << endl;
					}
				}
			}
		}

		cout << "+++++" << endl;
	}



	return 0;
}