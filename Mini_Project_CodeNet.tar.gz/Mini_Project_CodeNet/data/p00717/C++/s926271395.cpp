#include <iostream>
#include <string>
#include <vector>
#include <cmath>
#include <algorithm>
#include <cstdlib>
#include <ctime>
#include <cstdio>
#include <functional>
#include <set>
#include <sstream>
#include <map>
#include <queue>
#include <stack>

using namespace std;


const int six_dx[]={1,1,0,-1,-1,0};
const int six_dy[]={1,0,-1,-1,0,1};

int main()
{
    int n;
    while(cin>>n,n){
        //?¬????????????¨????????¢?????????
        int m;
        cin>>m;
        vector<pair<int,int> > p0;
        int x0,y0;
        cin>>x0>>y0;
        for(int j=1;j<m;j++){
            int x,y;
            cin>>x>>y;
            int len=abs(x0-x)+abs(y0-y);
            if(y0<y) p0.push_back(make_pair(len,0));
            if(x0<x) p0.push_back(make_pair(len,1));
            if(y0>y) p0.push_back(make_pair(len,2));
            if(x0>x) p0.push_back(make_pair(len,3));
            x0=x; y0=y;
        }
        
        vector<int> d0;
        for(int i=0;i<p0.size();i++) d0.push_back(p0[i].second);
        vector<int> dd0;
        for(int i=1;i<d0.size();i++) dd0.push_back((d0[i]-d0[i-1]+4)%4);
/*
        string dir[]={"U","R","D","L"};
        cout<<"p0=[";
        for(int i=0;i<p0.size();i++) cout<<"("<<p0[i].first<<","<<dir[p0[i].second]<<") ";
        cout<<"]"<<endl;
        cout<<"d0=[";
        for(int i=0;i<d0.size();i++) cout<<d0[i]<<" ";
        cout<<"]"<<endl;
        cout<<"dd0=[";
        for(int i=0;i<dd0.size();i++) cout<<dd0[i]<<" ";
        cout<<"]"<<endl;
*/
        for(int i=1;i<=n;i++){
            cin>>m;
            vector<pair<int,int> > p;
            cin>>x0>>y0;
            for(int j=1;j<m;j++){
                int x,y;
                cin>>x>>y;
                int len=abs(x0-x)+abs(y0-y);
                if(y0<y) p.push_back(make_pair(len,0));
                if(x0<x) p.push_back(make_pair(len,1));
                if(y0>y) p.push_back(make_pair(len,2));
                if(x0>x) p.push_back(make_pair(len,3));
                x0=x; y0=y;
            }
            vector<int> d;
            for(int j=0;j<p.size();j++) d.push_back(p[j].second);
            vector<int> dd;
            for(int j=1;j<d.size();j++) dd.push_back((d[j]-d[j-1]+4)%4);
/*
            cout<<"p"<<i<<"=[";
            for(int j=0;j<p.size();j++) cout<<"("<<p[j].first<<","<<dir[p[j].second]<<") ";
            cout<<"]"<<endl;
            cout<<"d=[";
            for(int j=0;j<d.size();j++) cout<<d[j]<<" ";
            cout<<"]"<<endl;
            cout<<"dd=[";
            for(int j=0;j<dd.size();j++) cout<<dd[j]<<" ";
            cout<<"]"<<endl;
*/
            
            if(p0.size()!=p.size()) continue;
            
            bool ok=true;
            for(int j=0;j<p.size();j++) if(p0[j].first!=p[j].first) ok=false;
            for(int j=0;j<dd.size();j++) if(dd0[j]!=dd[j]) ok=false;
            if(ok) cout<<i<<endl;
            else{
                reverse(p.begin(),p.end());
                for(int j=0;j<p.size();j++) p[j].second=(p[j].second+2)%4;
                d.clear();
                for(int j=0;j<p.size();j++) d.push_back(p[j].second);
                dd.clear();
                for(int j=1;j<d.size();j++) dd.push_back((d[j]-d[j-1]+4)%4);
                ok=true;
                for(int j=0;j<p.size();j++) if(p0[j].first!=p[j].first) ok=false;
                for(int j=0;j<dd.size();j++) if(dd0[j]!=dd[j]) ok=false;
                if(ok) cout<<i<<endl;
            }
            
        }
        cout<<"+++++"<<endl;

    }
    
    return 0;
}