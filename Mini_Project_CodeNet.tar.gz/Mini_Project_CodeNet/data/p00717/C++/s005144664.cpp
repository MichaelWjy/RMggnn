#include <bits/stdc++.h>
using namespace std;


// type {{{
using ll = long long;
using ull = unsigned long long;
using ld = long double;
using P = pair<int,int>;
using vi = vector<int>;
using vll = vector<ll>;
using vvi = vector<vector<int>>;
using vvll = vector<vector<ll>>;
// }}}


// macro {{{
#define rep(i,n) for (ll i=0, i##_len=(n); i<i##_len; ++i)
#define reps(i,n) for (ll i=1, i##_len=(n); i<=i##_len; ++i)
#define FOR(i,a,n) for (ll i=(a), i##_len=(n); i<i##_len; ++i)
#define SZ(x) ((ll)(x).size())
#define all(x) begin(x),end(x)
// }}}


// debug {{{
#define dump(x) cerr<<#x<<" = "<<(x)<<endl
#define debug(x) cerr<<#x<<" = "<<(x)<<" (L"<<__LINE__<<")"<< endl;

template<typename T>
ostream& operator<<(ostream& os, const vector<T>& v) {
    os << "[";
    rep (i, SZ(v)) {
        if (i) os << ", ";
        os << v[i];
    }
    return os << "]";
}

template<typename T, typename U>
ostream& operator<<(ostream& os, const pair<T, U>& p) {
    return os << "(" << p.first << " " << p.second << ")";
}
// }}}


// chmax, chmin {{{
template<class T>
bool chmax(T& a, const T& b) {
    if (a < b) { a = b; return true; }
    return false;
}
template<class T>
bool chmin(T& a, const T& b) {
    if (b < a) { a = b; return true; }
    return false;
}
// }}}



// constants {{{
#define inf(T) numeric_limits<T>::max()
const ll MOD = 1e9+7;
const ld EPS = 1e-9;
// }}}

using Point = array<int,2>;
using Line = vector<Point>;

Line reverse(Line line) {
    reverse(all(line));
    return line;
}

Line shiftToZero(Line line) {
    FOR(j, 1, SZ(line)) {
        line[j][0] -= line[0][0];
        line[j][1] -= line[0][1];
    }
    line[0][0] = line[0][1] = 0;
    return line;
}

Point rotate(Point point, int dir) {
    if (dir == 0) {
        return point;
    }
    if (dir == 1) {
        return { -point[1], point[0] };
    }
    if (dir == 2) {
        return { -point[0], -point[1] };
    }
    return { point[1], -point[0] };
}

Line rotate(Line line, int dir) {
    rep(i, SZ(line)) {
        line[i] = rotate(line[i], dir);
    }
    return line;
}

int main()
{
    cin.tie(0);
    ios::sync_with_stdio(false);
    cout << fixed << setprecision(10);

    for (;;) {
        int n; cin >> n;
        if (n == 0) break;
        vector<Line> lines(n+1);
        rep(i, n+1) {
            int m; cin >> m;
            lines[i].resize(m);
            rep(j, m) {
                cin >> lines[i][j][0] >> lines[i][j][1];
            }
        }
        lines[0] = shiftToZero(lines[0]);

        map<int,bool> ans;
        reps(i, n) {
            if (SZ(lines[0]) != SZ(lines[i])) continue;
            rep(t, 2) {
                rep(dir, 4) {
                    bool valid = true;
                    Line line = lines[i];
                    if (t) line = reverse(line);
                    line = shiftToZero(line);
                    line = rotate(line, dir);

                    rep(j, SZ(line)) {
                        if (lines[0][j][0] != line[j][0] or
                            lines[0][j][1] != line[j][1]) {
                            valid = false;
                            break;
                        }
                    }
                    if (valid) {
                        ans[i] = true;
                    }
                }
            }
        }

        for (auto& tp : ans) {
            cout << tp.first << endl;
        }
        cout << "+++++" << endl;
    }

    return 0;
}

