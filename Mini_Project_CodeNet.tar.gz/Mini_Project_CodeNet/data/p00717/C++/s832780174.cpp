#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <cctype>
#include <string>
#include <cstring>
#include <ctime>
#include <fstream>
#include <queue>

#pragma warning( disable: 4996 )

using namespace std;

typedef long long ll;

#define INF 100000000
#define EPS 1e-9

#define MAX_N 51
#define MAX_M 10

#define PI 3.141592

int n;
int m[MAX_N];
int x[MAX_N][MAX_M];
int y[MAX_N][MAX_M];
int vec_x[4][MAX_N];
int vec_y[4][MAX_N];

int main(){

	while (true){
	
		cin >> n;
		if (n == 0)
			break;

		//元の折れ線
		cin >> m[0];
		for (int i = 0; i < m[0]; i++){
			cin >> x[0][i] >> y[0][i];
			if (i > 0){
				vec_x[0][i - 1] = x[0][i] - x[0][i - 1];
				vec_y[0][i - 1] = y[0][i] - y[0][i - 1];

				if (vec_y[0][i - 1] == 0){
					vec_x[1][i - 1] = 0;
					vec_y[1][i - 1] = vec_x[0][i - 1];
				}

				else{
					vec_x[1][i - 1] = vec_y[0][i - 1] * -1;
					vec_y[1][i - 1] = 0;
				}

				vec_x[2][i - 1] = vec_x[0][i - 1] * -1;
				vec_y[2][i - 1] = vec_y[0][i - 1] * -1;

				vec_x[3][i - 1] = vec_x[1][i - 1] * -1;
				vec_y[3][i - 1] = vec_y[1][i - 1] * -1;

			}
		}

		//探す折れ線 1から添え字は始まる
		for (int i = 0; i < n; i++){
			cin >> m[i+1];
			for (int j = 0; j < m[i+1]; j++){
				cin >> x[i + 1][j] >> y[i + 1][j];
			}
		}

		for (int i = 1; i <= n; i++){
			bool flag1 = true, flag2 = true;
			int tmp;

			//視点が一致する場合
			for (int j = 0; j < m[i] - 1; j++){
				int vec_xx = x[i][j + 1] - x[i][j];
				int vec_yy = y[i][j + 1] - y[i][j];
				if (j == 0){
					for (tmp = 0; tmp < 4; tmp++){
						if (vec_xx == vec_x[tmp][0] && vec_yy == vec_y[tmp][0]){
							break;
						}
					}
					if (tmp == 4){
						flag1 = false;
						break;
					}
				}

				else{
					if (vec_xx != vec_x[tmp][j] || vec_yy != vec_y[tmp][j]){
						flag1 = false;
						break;
					}
				}

			}

			//始点と終点が一致する場合
			for (int j = m[i] - 1; j > 0; j--){
				int vec_xx = x[i][j - 1] - x[i][j];
				int vec_yy = y[i][j - 1] - y[i][j];
				if (j == m[i] - 1){
					for (tmp = 0; tmp < 4; tmp++){
						if (vec_xx == vec_x[tmp][0] && vec_yy == vec_y[tmp][0]){
							break;
						}
					}
					if (tmp == 4){
						flag2 = false;
						break;
					}
				}

				else{
					if (vec_xx != vec_x[tmp][m[i] - 1 - j] || vec_yy != vec_y[tmp][m[i] - 1 - j]){
						flag2 = false;
						break;
					}
				}

			}

			if (flag1 || flag2)
				cout << i << endl;

		}

		cout << "+++++" << endl;
	
	
	}

	return 0;

}