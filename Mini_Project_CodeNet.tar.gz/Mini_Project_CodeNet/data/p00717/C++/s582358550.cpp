#include<iostream>
#include<list>
#include<cstring>
#include<algorithm>
#include <utility>
#include<stdio.h>
#include<climits>
#include <vector>
#include <queue>
#include <cmath>

using namespace std;

struct line{
    int x0,y0,vx,vy;
    vector<double> vd;
    vector<int> vi;
    void add(int x,int y){
        int i,j;
        i = x;j = y;
        x -= x0;
        y -= y0;
        vd.push_back(sqrt(x*x+y*y));
        if(vd.size() > 1){
            vi.push_back(vx*y-vy*x > 0);
        }
        x0 = i;y0 = j;vx = x;vy = y;
    }
    bool equal(struct line l){
        int i,j;
        bool f = true;
        if(vd.size() != l.vd.size()) return false;
        for(i = 0;i < vd.size();i++){
            if(vd[i] != l.vd[i]) f = false;
        }
        for(i = 0;i < vi.size();i++){
            if(vi[i] != l.vi[i]) f = false;
        }
        if(!f){
            f = true;
            for (i = 0; i < vd.size(); i++) {
                if (vd[vd.size()-i-1] != l.vd[i]) f = false;
            }
            for (i = 0; i < vi.size(); i++) {
                if (vi[vi.size()-i-1] == l.vi[i]) f = false;
            }
        }
        return f;
    }
    void ini(int x,int y){
        x0 = x;y0 = y;
        vd.clear();vi.clear();
    }
};

int main(){
    int i,j,k;
    int n,m,x,y;
    line l0,li;
    while(1){
        cin >> n;
        if(!n) break;
        cin >> m;
        cin >> x >> y;
        l0.ini(x,y);
        for(j = 1;j < m;j++){
            cin >> x >> y;
            l0.add(x, y);
        }
        for (i = 0; i < n; i++) {
            cin >> m;
            cin >> x >> y;
            li.ini(x, y);
            for (j = 1; j < m; j++) {
                cin >> x >> y;
                li.add(x, y);
            }
            if(l0.equal(li)) cout << i+1 << endl;
        }
        cout << "+++++" << endl;
    }
}