#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

class P {
public:
	int x, y;

	P operator - (const P& obj)
	{
		P ret;

		ret.x = x - obj.x;
		ret.y = y - obj.y;

		return ret;
	}

	bool operator == (const P& obj) const
	{
		return x == obj.x&&y == obj.y;
	}

	bool operator != (const P& obj) const
	{
		return !(*this == obj);
	}
};

vector<P> p_rotate(vector<P> p, int num)
{
	vector<P> ret = p;
	unsigned int size = p.size();

	switch (num) {
	case 0:
		break;
	case 1:
		for (unsigned int i = 0; i < size; i++) {
			ret[i].x = -p[i].y;
			ret[i].y = p[i].x;
		}
		break;
	case 2:
		for (unsigned int i = 0; i < size; i++) {
			ret[i].x = -p[i].x;
			ret[i].y = -p[i].y;
		}
		break;
	case 3:
		for (unsigned int i = 0; i < size; i++) {
			ret[i].x = p[i].y;
			ret[i].y = -p[i].x;
		}
		break;
	}

	return ret;
}

bool check(vector<P> p1, vector<P> p2)
{
	bool flag = true;
	unsigned int size = p1.size();

	if (size != p2.size()) {
		flag = false;
	}
	else {
		for (unsigned int i = 1; i < size; i++) {
			P dist1 = p1[i] - p1[i - 1];
			P dist2 = p2[i] - p2[i - 1];

			if (dist1 != dist2) {
				flag = false;
				break;
			}
		}
	}

	return flag;
}

int main()
{
	while (true) {
		int n;
		cin >> n;

		if (n == 0) {
			break;
		}

		vector<vector<P>> line(n + 1);

		for (int i = 0; i <= n; i++) {
			int m;
			cin >> m;

			for (int j = 0; j < m; j++) {
				P temp;
				cin >> temp.x >> temp.y;
				line[i].push_back(temp);
			}
		}

		for (int i = 1; i <= n; i++) {
			bool flag = false;

			for (int j = 0; j < 4; j++) {
				flag = check(line[0], p_rotate(line[i], j));
				if (flag == true) {
					goto End;
				}
			}

			reverse(line[i].begin(), line[i].end());

			for (int j = 0; j < 4; j++) {
				flag = check(line[0], p_rotate(line[i], j));
				if (flag == true) {
					goto End;
				}
			}

		End:

			if (flag == true) {
				cout << i << endl;
			}
		}

		cout << "+++++" << endl;
	}

	return 0;
}