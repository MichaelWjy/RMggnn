#include<cstdio>
#include<string.h>
#include<iostream>
#include<cmath>
#include<complex>
#include<string>
#include<map>
using namespace std;
typedef complex<double> xy_t;

int main(){
  while(1){
    int n;
    int m[55];
    double x[55][11],y[55][11];
    xy_t p[55][11];
    xy_t s[4][55];
    memset(m,0,sizeof(m));
    memset(x,0,sizeof(x));
    memset(y,0,sizeof(y));
    memset(p,0,sizeof(p));
    memset(s,0,sizeof(s));


    scanf("%d",&n);
    if(n==0) break;
    for(int i=0;i<=n;i++){
      scanf("%d",&m[i]);
      for(int j=0;j<m[i];j++){
        scanf("%lf%lf",&x[i][j],&y[i][j]);
        p[i][j]=(xy_t(x[i][j]-x[0][0],y[i][j]-y[0][0]));
      }
    }

    for(int i=0;i<m[0];i++){
      s[0][i]=p[0][i];
      s[1][i]=p[0][i]*(xy_t(0,1));
      s[2][i]=p[0][i]*(xy_t(-1,0));
      s[3][i]=p[0][i]*(xy_t(0,-1));
    }


    for(int j=1;j<=n;j++){
      bool flg=false;
      if(m[0]!=m[j]) continue;
      for(int i=0;i<4;i++){
        bool flg2=true;
        bool flg3=true;
        for(int u=0;u<m[0];u++){
          if(s[i][u]+p[j][0]!=p[j][u]) {flg2=false;break;}
        }
        for(int u=0;u<m[0];u++){
          if(s[i][u]+p[j][m[0]-1]!=p[j][m[0]-u-1]) {flg3=false;break;}
        }
        if(flg2==true || flg3==true) {flg=true;break;}
      }
      if(flg==true) printf("%d\n",j);
    }

    printf("+++++\n");
  }


  return 0;

}