#include <bits/stdc++.h>
#define rep(i,n) for(int i=0;i<(n);i++)
#define rrep(i,n) for(int i=(n);i>=0;i--)
using namespace std;

typedef struct{
  int x,y;
} point;

void shift_o(point ep, point *line, int m){ // ????????????????????????????????????
  rep(i,m){
    line[i].x -= ep.x;
    line[i].y -= ep.y;
  }
}

void round(point *line, int m){
  rep(i,m){
    point tmp = line[i];
    line[i].x = -(tmp.y);
    line[i].y = tmp.x;
  }
}

bool IsSame(point *base, point *line, int m){
  rep(i,m){
    if(line[i].x != base[i].x || line[i].y != base[i].y)
      return false;
  }
  return true;
}

void CopyLine(const point *original, point *copy, int m){
  while(m-->0){
    *copy++ = *original++;
  }
}

void revline(point *line,int m){ 
  point tmp;
  rep(i,m/2){
    tmp=line[i];
    line[i]=line[m-i-1];
    line[m-i-1]=tmp;
  }
}

void Plus5(){
  rep(i,5){
    putchar('+');
  }
  putchar('\n');
}

int main(){
  for(;;){
    int n;
    scanf("%d",&n);
    if(!n) break;

    //0??????????????????
    int m0;
    point base[10];
    scanf("%d",&m0);
    rep(i,m0){
      scanf("%d %d",&base[i].x,&base[i].y);
    }

    //1????????\???????????????
    int m[50];
    point line[50][10];
    rep(i,n){
      scanf("%d",&m[i]);
      rep(j,m[i]){
	scanf("%d %d",&line[i][j].x,&line[i][j].y);
      }
    }

    // base??????????????????
    point ep1=base[0] ,ep2=base[m0-1];

    point copy[10];
    CopyLine(base,copy,m0);

    shift_o(ep1,base,m0);
    shift_o(ep2,copy,m0);

    rep(i,n){
      if(m[i]==m0){
	shift_o(line[i][0], line[i], m0);
	if(IsSame(base,line[i],m0)||IsSame(copy,line[i],m0)){
	  printf("%d\n",i+1);
	  continue;
	}
	revline(line[i], m0);
	shift_o(line[i][0], line[i], m0);
	if(IsSame(base,line[i],m0)||IsSame(copy,line[i],m0)){
	  printf("%d\n",i+1);
	  continue;
	}
	revline(line[i], m0);
	shift_o(line[i][0], line[i], m0);
	rep(j,3){
	  round(line[i],m0);
	  if(IsSame(base,line[i],m0)||IsSame(copy,line[i],m0)){
	    printf("%d\n",i+1);
	    break;
	  }
	  revline(line[i], m0);
	  shift_o(line[i][0], line[i], m0);
	  if(IsSame(base,line[i],m0)||IsSame(copy,line[i],m0)){
	    printf("%d\n",i+1);
	    break;
	  }
	}
      }
    }  
    Plus5();
  } 
}