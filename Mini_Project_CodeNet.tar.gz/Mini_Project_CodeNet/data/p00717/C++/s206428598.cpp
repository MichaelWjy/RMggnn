#include <iostream>
#include <vector>
#include <algorithm>
#ifndef LIB_REPEAT_HPP
#define LIB_REPEAT_HPP
#define repeat(i,n) for (int i = 0; i < (n); ++i)
#define repeat_from(i,m,n) for (int i = (m); i < (n); ++i)
#define repeat_one(i,n) for (int i = 1; i <= (n); ++i)
#define repeat_rev(i,n) for (int i = (n)-1; 0 <= i; --i)
#define foreach(it, cont) for (typeof(cont.begin()) it = cont.begin(); it != cont.end(); ++it)
#endif
#ifndef LIB_TYPEDEF_LL_HPP
#define LIB_TYPEDEF_LL_HPP
typedef long long ll;
typedef unsigned long long ull;
#endif
#ifndef LIB_DEBUG_HPP
#define LIB_DEBUG_HPP
#ifdef DEBUG
#include <cassert>
#define debug(a) a
#else
#define debug(a)
#endif
#endif
#ifndef LIB_GEOMETRY_POINT_HPP
#define LIB_GEOMETRY_POINT_HPP
#include <iostream>
#include <cmath>
#include <utility>

template <typename T>
struct point {
    T x, y;
    point() : x(0.0), y(0.0) {}
    point(T x, T y) : x(x), y(y) {}
    template <typename S> point(const point<S> & a) : x(a.x), y(a.y) {}
    template <typename S, typename U> point(const std::pair<S,U> & a) : x(a.first), y(a.second) {}
    template <typename S> point<T> & operator = (const point<S> & a) { x = a.x; y = a.y; return *this; }
    template <typename S, typename U> point<T> & operator = (const std::pair<S,U> & a) { x = a.first; y = a.second; return *this; }

    point<T> operator + (const point<T> & a) const { return point<T>(x + a.x, y + a.y); }
    point<T> operator - (const point<T> & a) const { return point<T>(x - a.x, y - a.y); }
    point<T> operator - () const { return point<T>(- x, - y); }
    bool operator < (const point<T> & a) const { return x != a.x ? x < a.x : y < a.y; }
    bool operator == (const point<T> & a) const { return x == a.x and y == a.y; }

    double cross(const point<T> & a) const { return y * a.x - x * a.y; }
    double dot(const point<T> & a) const { return x * a.x + y * a.y; }
    double atan() const { return std::atan2(x, y); }
    double length_squared() const { return this->dot(*this); }
    double length() const { return std::sqrt(length_squared()); }
    double grad() const { return y /(double) x; }
    double distance(const point<T> & a) const { return (a - *this).length(); }

    friend std::istream & operator >> (std::istream & in, point<T> & p) { return in >> p.x >> p.y; }
    friend std::ostream & operator << (std::ostream & out, const point<T> & p) { return out << p.x << " " << p.y; }
};
#endif
using namespace std;
typedef point<int> pointi;
void rotate_n90(vector<pointi>::iterator first, vector<pointi>::iterator last, bool neg_x, bool neg_y) {
    while (first != last) {
        if (neg_x) first->x *= -1;
        if (neg_y) first->y *= -1;
        swap(first->x, first->y);
        ++ first;
    }
}
void rotate90 (vector<pointi>::iterator first, vector<pointi>::iterator last) { rotate_n90(first, last, false, true); }
void rotate180(vector<pointi>::iterator first, vector<pointi>::iterator last) { rotate_n90(first, last, true, true); }
void rotate270(vector<pointi>::iterator first, vector<pointi>::iterator last) { rotate_n90(first, last, true, false); }
void shift(vector<pointi>::iterator first, vector<pointi>::iterator last) {
    pointi orig = *first;
    while (first != last) {
        *first = *first - orig;
        ++ first;
    }
}
void rotate(vector<pointi>::iterator first, vector<pointi>::iterator last) {
    vector<pointi>::iterator second = first + 1;
    if        (0 < second->x) { // ok
    } else if (second->x < 0) { rotate180(first, last);
    } else if (0 < second->y) { rotate270(first, last);
    } else if (second->y < 0) { rotate90 (first, last);
    }
}
void normalize(vector<pointi> & v) {
    shift(v.begin(), v.end());
    rotate(v.begin(), v.end());
}
int main() {
    ios_base::sync_with_stdio(false);
    while (true) {
        int n; cin >> n; if (n == 0) break;
        int m0; cin >> m0;
        vector<pointi> line0(m0); repeat (i,m0) cin >> line0[i];                     normalize(line0);
        vector<pointi> line1(m0); copy(line0.rbegin(), line0.rend(), line1.begin()); normalize(line1);
        repeat_one (query,n) {
            int m; cin >> m;
            vector<pointi> line(m); repeat (i,m) cin >> line[i];
            if (m == m0) {
                normalize(line);
                if (       equal(line.begin(), line.end(), line0.begin())
                        or equal(line.begin(), line.end(), line1.begin())) {
                    cout << query << endl;
                }
            }
        }
        cout << "+++++" << endl;
    }
    return 0;
}