#include <iostream>
#include <vector>
#include <utility>
using namespace std;
using P = pair<int, int>;

int main() {
    int n;
    while(cin >> n, n) {
        vector<vector<P>> target(4);
        vector<vector<P>> lines(n);
        for(int i=0; i<=n; ++i) {
            int m;
            cin >> m;
            int prev_x = 0, prev_y = 0;
            for(int j=0; j<m; ++j) {
                int x, y;
                cin >> x >> y;
                if(j != 0) {
                    if(i == 0) {
                        target[0].push_back(make_pair(x - prev_x, y - prev_y));
                    } else {
                        lines[i-1].push_back(make_pair(x - prev_x, y - prev_y));
                    }
                }
                prev_x = x;
                prev_y = y;
            }
        }
        for(int i=0; i<target[0].size(); ++i) {
            int x1 = -target[0][i].first, y1 = -target[0][i].second;
            target[1].push_back(make_pair(x1, y1));

            int x2 = target[0][i].second, y2 = -target[0][i].first;
            target[2].push_back(make_pair(x2, y2));

            int x3 = -target[0][i].second, y3 = target[0][i].first;
            target[3].push_back(make_pair(x3, y3));
        }

        vector<int> ret;
        for(int i=0; i<n; ++i) {
            bool ok = false;
            for(int j=0; j<4; ++j) {
                if(target[j].size() != lines[i].size()) {
                    break;
                }

                for(int k=0; k<lines[i].size(); ++k) {
                    if(lines[i][k] != target[j][k]) {
                        break;
                    }
                    if(k == lines[i].size()-1) {
                        ok = true;
                    }
                }
                for(int k=0; k<lines[i].size(); ++k) {
                    if(lines[i][k] != target[j][lines[i].size()-k-1]) {
                        break;
                    }
                    if(k == lines[i].size()-1) {
                        ok = true;
                    }
                }
            }
            if(ok) {
                ret.push_back(i+1);
            }
        }
        for(auto x : ret) {
            cout << x << endl;
        }
        cout << "+++++" << endl;
    }
}
