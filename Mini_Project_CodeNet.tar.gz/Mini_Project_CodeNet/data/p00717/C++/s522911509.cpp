#include<bits/stdc++.h>
#define f first
#define s second
#define mp make_pair
#define inf 1000000000
#define eps (1e-11)
#define equals(a,b) (fabs((a)-(b))<eps)
using namespace std;

class Point{
public:
  double x,y;
  Point(double x=0,double y=0):x(x),y(y){}

  Point operator+(Point p){ return Point(x+p.x,y+p.y);}
  Point operator-(Point p){ return Point(x-p.x,y-p.y);}
  Point operator*(double k){ return Point(x*k,y*k);}
  Point operator/(double k){ return Point(x/k,y/k);}
  bool operator<(Point p)const{ return (x!=p.x ? x<p.x : y<p.y);}
  bool operator==(Point p)const{ return fabs(x-p.x)<eps && fabs(y-p.y)<eps;}

  double abs(){ return sqrt(norm());}
  double norm(){ return (x*x+y*y);}
};
typedef Point Vector;
typedef vector<Point> Polygon;

double norm(Vector a){ return (a.x*a.x+a.y*a.y);}
double abs(Vector a){ return sqrt(norm(a));}
double dot(Vector a,Vector b){ return (a.x*b.x+a.y*b.y);}
double cross(Vector a,Vector b){ return (a.x*b.y-a.y*b.x);}

static const int COUNTER_CLOCKWISE=1;
static const int CLOCKWISE=-1;
static const int ONLINE_BACK=2;
static const int ONLINE_FRONT=-2;
static const int ON_SEGMENT=0;

int ccw(Point p0,Point p1,Point p2){
  Vector a=p1-p0;
  Vector b=p2-p0;
  if(cross(a,b)>eps)return COUNTER_CLOCKWISE;
  if(cross(a,b)<-eps)return CLOCKWISE;
  if(dot(a,b)<-eps)return ONLINE_BACK;
  if(a.norm()<b.norm())return ONLINE_FRONT;
  return ON_SEGMENT;
}

bool PolygonalLineSearch(Polygon p1,Polygon p2){
  if(p1.size()!=p2.size())return false;
  int n=p1.size();
  for(int i=0;i<n-1;i++){
    Vector a=p1[i+1]-p1[i];
    Vector b=p2[i+1]-p2[i];
    if(a.norm()!=b.norm())return false;
  }
  for(int i=1;i<n-1;i++){
    if(ccw(p1[i-1],p1[i],p1[i+1])!=ccw(p2[i-1],p2[i],p2[i+1]))return false;
  }
  return true;
}

int main()
{
  int n,m;
  vector<Polygon> p;

  while(1){
    cin>>n;
    if(n==0)break;
    n++;
    p.resize(n);
    for(int i=0;i<n;i++){
      cin>>m;
      p[i].resize(m);
      for(int j=0;j<m;j++)cin>>p[i][j].x>>p[i][j].y;
    }
    for(int i=1;i<n;i++){
      bool x=false;
      if(PolygonalLineSearch(p[0],p[i]))x=true;
      reverse(p[i].begin(),p[i].end());
      if(PolygonalLineSearch(p[0],p[i]))x=true;
      if(x)cout<<i<<endl;
    }
    cout<<"+++++"<<endl;
  }
  return 0;
}