#include <iostream>
#include <utility>
using namespace std;

pair<int, int> points[52][11];
int pointsCount[52];
int n, m;

int r90[] = {
	0, -1,
	1, 0,
};

int lineCheck1(int num)
{
	for (int j = 0; j < pointsCount[0]; j++)
	{
		if (points[0][j].first != points[num][j].first
			|| points[0][j].second != points[num][j].second) return 0;
	}
	return 1;
}

int lineCheck2(int num)
{
	int ofX = points[num][pointsCount[0] - 1].first;
	int ofY = points[num][pointsCount[0] - 1].second;
	for (int j = 0; j < pointsCount[0]; j++)
	{
		if (points[0][j].first != points[num][pointsCount[0] - j - 1].first - ofX
			|| points[0][j].second != points[num][pointsCount[0] - j - 1].second - ofY) return 0;
	}
	return 1;
}

int solve()
{
	int firstNum = 1;
	for (int i = 1; i < n + 1; i++)
	{
		int output = 0;
		if (pointsCount[0] != pointsCount[i]) continue;
		for (int k = 0; k < 4; k++)
		{
			for (int j = 0; j < pointsCount[0]; j++)
			{
				int newX = (-1) * points[i][j].second;
				int newY = points[i][j].first;
				points[i][j].first = newX;
				points[i][j].second = newY;
			}
			if (output) continue;
			if (lineCheck1(i) || lineCheck2(i))
			{
//				if (firstNum) firstNum = 0;
//				else cout << '\n';
				cout << i << endl;;
				output = 1;
				break;
			}
		}
	}
}

int main()
{
	int firstFlg = 1;
	while(1)
	{
		if (firstFlg) firstFlg = 0;
		else cout << "+++++" << endl;
		cin >> n;
		if (n == 0) break;
		
		for (int i = 0; i < n + 1; i++)
		{
			cin >> pointsCount[i];
			pair<int, int> first;
			cin >> first.first >> first.second;
			points[i][0].first = points[i][0].second = 0;
			for (int j = 1; j < pointsCount[i]; j++)
			{
				cin >> points[i][j].first >> points[i][j].second;
				points[i][j].first -= first.first;
				points[i][j].second -= first.second;
			}
		}
		solve();
	}
	return 0;
}