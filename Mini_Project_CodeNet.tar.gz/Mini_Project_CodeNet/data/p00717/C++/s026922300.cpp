#include <iostream>
#include <iomanip>
#include <string>
#include <sstream>
#include <algorithm>
#include <vector>
#include <utility>
#include <stack>
#include <queue>
#include <map>
#include <set>
#include <functional>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <cassert>
 
using namespace std;
 
#define REP(i,s,e) for(int i=(s); i<(int)(e); i++)
#define rep(i,n) REP(i, 0, n)
#define pb push_back
#define mp make_pair
#define all(r) (r).begin(),(r).end()
#define rall(r) (r).rbegin(),(r).rend()
#define fi first
#define se second
#define DBG(X) cout<<" "<<#X<<" : "<<X<<endl
 
typedef long long ll;
typedef vector<int> vi;
typedef vector<ll> vl;
typedef pair<int, int> pii;

const int INF = 1e9;
const double EPS = 1e-8;
const int mod = 1e9 + 7;
const ll LINF = 1e18;
const double PI = acos(-1);

struct Input
{
	int n;char c;char str[1024];string s;ll l;
	int nextInt(){scanf("%d", &n);return n;}
	ll nextLong(){scanf("%lld", &l);return l;}
	char nextChar(){scanf("%c", &c);return c;}
	string next(){scanf("%s", str);return string(str);}
	string nextLine(){getline(cin, s);return s;}
};
Input in;

struct Data{
	vi x, y;
	int id;
	Data(){};
	Data(const vi& x_, const vi& y_, int id_) : x(x_), y(y_), id(id_){
		int sx = x[0], sy = y[0];
		rep(i, x.size()){
			x[i] -= sx;
			y[i] -= sy;
		}	
	};

	const bool operator ==(const Data& d)const{
		if(x.size() != d.x.size()) return false;
		rep(i, x.size()){
			if(x[i] != d.x[i] || y[i] != d.y[i]) return false;
		}
		return true;
	}
	// const bool operator <(const Data& d) const{
	// 	if(x.size() != d.x.size()) return x.size() < d.x.size();
	// 	rep(i, x.size()) if(x[i] != d.x[i]) return x[i] < d.x[i];
	// 	rep(i, y.size()) if(y[i] != d.y[i]) return y[i] < d.y[i];
	// 	if(id != d.id) return id < d.id;
	// 	return false;
	// }
};

int main(){
	while(1){
		int n = in.nextInt();
		//DBG(n);
		
		if(n == 0) break;
		Data d;
		vector<Data> v;
		rep(i, n + 1){
			int m = in.nextInt();
			//DBG(m);
			vi x(m), y(m), mx(m), my(m);
			rep(j, m) x[j] = in.nextInt(), y[j] = in.nextInt(), mx[j] = -x[j], my[j] = -y[j];
			if(i == 0){
				d = {x, y, 0};
			}
			else{
				v.pb({x, y, i});
				v.pb({my, x, i});
				v.pb({mx, my, i});
				v.pb({y, mx, i});

				reverse(all(x));
				reverse(all(mx));
				reverse(all(y));
				reverse(all(my));

				v.pb({x, y, i});
				v.pb({my, x, i});
				v.pb({mx, my, i});
				v.pb({y, mx, i});
			}
		}
		set<int> ans;
		rep(i, v.size()){
			if(d == v[i]) ans.insert(v[i].id);
		}
		for(auto a : ans){
			cout<<a<<endl;
		}
		cout<<"+++++"<<endl;
	}
}