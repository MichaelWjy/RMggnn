#include <iostream>
#include <string>
#include <queue>
#include <stack>
#include <algorithm>
#include <list>
#include <vector>
#include <complex>
#include <utility>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <climits>
#include <bitset>
#include <ctime>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <cassert>
#include <cstddef>
#include <iomanip>
#include <numeric>
#include <tuple>
#include <sstream>
#include <fstream>

using namespace std;
#define REP(i, n) for (int (i) = 0; (i) < (n); (i)++)
#define FOR(i, a, b) for (int (i) = (a); (i) < (b); (i)++)
#define RREP(i, a) for(int (i) = (a) - 1; (i) >= 0; (i)--)
#define FORR(i, a, b) for(int (i) = (a) - 1; (i) >= (b); (i)--)
#define DEBUG(C) cerr << #C << " = " << C << endl;
using LL = long long;
using VI = vector<int>;
using VVI = vector<VI>;
using VL = vector<LL>;
using VVL = vector<VL>;
using VD = vector<double>;
using VVD = vector<VD>;
using PII = pair<int, int>;
using PDD = pair<double, double>;
using PLL = pair<LL, LL>;
using VPII = vector<PII>;
template<typename T> using VT = vector<T>;
#define ALL(a) begin((a)), end((a))
#define RALL(a) rbegin((a)), rend((a))
#define SORT(a) sort(ALL((a)))
#define RSORT(a) sort(RALL((a)))
#define REVERSE(a) reverse(ALL((a)))
#define MP make_pair
#define FORE(a, b) for (auto &&a : (b))
#define FIND(s, e) ((s).find(e) != (s).end())
#define EB emplace_back
template<typename T>inline bool chmax(T &a,T b){if(a<b){a=b;return true;}return false;}
template<typename T>inline bool chmin(T &a,T b){if(a>b){a=b;return true;}return false;}

const int INF = 1e9;
const int MOD = INF + 7;
const LL LLINF = 1e18;

void init() {

}

using matrix = vector<vector<int>>;
matrix makeRotationMatrix(double theta) {
    matrix res(3, vector<int>(3, 0));
    for (int i = 0; i < 2; i++) {
        for (int j = 0; j < 2; j++) {
            res[i][j] = (i == j ? cos(theta) : i ? sin(theta) : -sin(theta));
        }
    }
    res[2][2] = 1;
    return res;
}

matrix mul(matrix A, matrix B) {
    matrix res(A.size(), vector<int>(B.front().size(), 0));
    for (int i = 0; i < A.size(); i++) {
        for (int k = 0; k < B.size(); k++) {
            for (int j = 0; j < B.front().size(); j++) {
                res[i][j] += A[i][k] * B[k][j];
            }
        }
    }
    return res;
}

void solve(int n) {
    int m;
    scanf("%d", &m);
    vector<vector<pair<int, int>>> keyvec(2, vector<pair<int, int>>(m));
    for (int i = 0; i < m; i++) {
        int x, y;
        scanf("%d%d", &x, &y);
        keyvec[0][i] = make_pair(x, y);
        keyvec[1][i] = make_pair(x, y);
    }
    reverse(begin(keyvec[1]), end(keyvec[1]));
    for (int c = 0; c < 2; c++) {
        int X, Y;
        tie(X, Y) = keyvec[c][0];
        for (int i = 1; i < m; i++) {
            int x, y;
            tie(x, y) = keyvec[c][i];
            keyvec[c][i] = make_pair(x - X, y - Y);
        }
        keyvec[c][0] = make_pair(0, 0);
    }

    vector<vector<pair<int, int>>> vec(n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &m);
        vec[i].resize(m);
        for (int j = 0; j < m; j++) {
            int x, y;
            scanf("%d%d", &x, &y);
            if (j == 0) vec[i][j] = make_pair(x, y);
            else vec[i][j] = make_pair(x - vec[i][0].first, y - vec[i][0].second);
        }
        vec[i][0] = make_pair(0, 0);
    }

    const long double PI = acos(-1.0);
    const long double theta[] = {0, PI / 2, PI, PI * 1.5};
    set<int> ans;
    for (int c = 0; c < 2; c++) {
        for (int i = 0; i < n; i++) {
            for (auto e : theta) {
                auto cpvec = vec[i];
                auto rotmat = makeRotationMatrix(e);
                for (int j = 0; j < (int)cpvec.size(); j++) {
                    matrix mat(3);
                    mat[0].emplace_back(cpvec[j].first);
                    mat[1].emplace_back(cpvec[j].second);
                    mat[2].emplace_back(1);
                    mat = mul(rotmat, mat);
                    cpvec[j] = make_pair(mat[0][0], mat[1][0]);
                }
                if (cpvec == keyvec[c]) {
                    ans.insert(i);
                }
            }
        }
    }

    for (int e : ans) {
        printf("%d\n", e + 1);
    }
    puts("+++++");
}

int main(void) {
	int a, b, c, x, y, z, n, m, p;
	string s;
	while (cin >> n, n) {
		solve(n);
		//break;
	}
}