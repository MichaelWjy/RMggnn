#include <iostream>
#include <vector>
using namespace std;

struct Line {
	int vertex_count;
	int directions[10];
	int path_sizes[12];
};

Line lines[52];

Line inversed;

enum {
	TURN_LEFT = 0,
	TURN_RIGHT
};
enum {
	UP = 0,
	RIGHT,
	DOWN,
	LEFT
};

int abs(int i) {
	return i > 0 ? i : -i;
}

int main() {
	while(true) {
		int n;
		cin >> n;
		if(n == 0)
			break;

		for (int i = 0; i <= n; i++) {
			int m;
			cin >> m;
			lines[i].vertex_count = m;
			int direction;
			int prev_direction;
			int x, y, prev_x, prev_y;
			for (int j = 0; j < m; j++) {
				cin >> x >> y;
				if(j > 0) {
					if(x == prev_x)
						direction = y > prev_y ? UP : DOWN;
					if(y == prev_y)
						direction = x > prev_x ? RIGHT : LEFT;

					if(j > 1) {
						int diff = direction - prev_direction;
						if(diff == 1 || diff == -3)
							lines[i].directions[j-2] = TURN_RIGHT;
						else
							lines[i].directions[j-2] = TURN_LEFT;
					}

					prev_direction = direction;

					lines[i].path_sizes[j-1] = abs(x - prev_x) + abs(y - prev_y);
				}
				prev_x = x;
				prev_y = y;
			}
		}

		inversed.vertex_count = lines[0].vertex_count;

		for (int i = 0; i < inversed.vertex_count - 2; i++) {
			inversed.directions[i] =
					(lines[0].directions[inversed.vertex_count - 3 - i] == TURN_RIGHT)
					? TURN_LEFT
					: TURN_RIGHT;
		}
		for (int i = 0; i < inversed.vertex_count - 1; i++) {
			inversed.path_sizes[i] = lines[0].path_sizes[inversed.vertex_count - 2 - i];
		}

		for (int i = 1; i <= n; i++) {
			if(lines[0].vertex_count != lines[1].vertex_count)
				continue;

			bool is_same = true, is_inversing_same = true;

			for (int j = 0; j < lines[0].vertex_count - 1; j++) {
				if(lines[0].path_sizes[j] != lines[i].path_sizes[j])
					is_same = false;
				if(inversed.path_sizes[j] != lines[i].path_sizes[j])
					is_inversing_same = false;
			}
			for (int j = 0; j < lines[0].vertex_count - 2; j++) {
				if(lines[0].directions[j] != lines[i].directions[j])
					is_same = false;
				if(inversed.directions[j] != lines[i].directions[j])
					is_inversing_same = false;
			}

			if(is_same || is_inversing_same) {
				cout << i << endl;
			}
		}
		cout << "+++++" << endl;
	}
	return 0;
}