#include <bits/stdc++.h>
using namespace std;
typedef pair<int, int> P;
const int mysin[] = {0, 1, 0, -1};
const int mycos[] = {1, 0, -1, 0};

int main(void){
  int n, m;
  while(cin >> n, n){
    vector< vector<P> > c(n);
    vector< vector<P> > target;
    cin >> m;
    target = vector< vector<P> >(8, (vector<P>(m)));
    int subx, suby;
    for(int i=0; i < m; i++){
      cin >> target[0][i].first >> target[0][i].second;
      if(i == 0) subx = target[0][i].first, suby = target[0][i].second;
      target[0][i].first -= subx;
      target[0][i].second -= suby;
    }

    for(int i=1; i < 4; i++){
      //x'+y'i = (x+yi)(cost + isint)
      //       = (xcost - ysint) + (xsint + ycost)i
      for(int j=0; j < m; j++){
        target[i][j].first = target[0][j].first*mycos[i]
        - target[0][j].second*mysin[i];
        target[i][j].second = target[0][j].first*mysin[i]
        + target[0][j].second*mycos[i];
      }
    }
    reverse_copy(target[0].begin(), target[0].end(), target[4].begin());
    subx = target[4][0].first; suby = target[4][0].second;
    for(int j=0; j < m; j++){
      target[4][j].first -= subx;
      target[4][j].second -= suby;
    }
    for(int i=5; i < 8; i++){
      for(int j=0; j < m; j++){
        target[i][j].first = target[4][j].first*mycos[i-4]
        - target[4][j].second*mysin[i-4];
        target[i][j].second = target[4][j].first*mysin[i-4]
        + target[4][j].second*mycos[i-4];
      }
    }


    for(int p=0; p < n; p++){
      cin >> m;
      c[p].resize(m);
      for(int q=0; q < m; q++){
        if(q == 0){
          cin >> subx >> suby;
          c[p][q].first = 0;
          c[p][q].second = 0;
        }else{
          cin >> c[p][q].first >> c[p][q].second;
          c[p][q].first -= subx;
          c[p][q].second -= suby;
        }
      }
      for(int r=0; r < target.size(); r++){
        bool flg = true;
        if(target[r].size() != c[p].size()){
          continue;
        }
        for(int s=0; s < target[r].size(); s++){
          if(!(target[r][s].first == c[p][s].first && target[r][s].second == c[p][s].second)){
            flg = false;
          }
        }
        if(flg){
          cout << p+1 << endl;
          continue;
        }
      }

    }
    cout << "+++++" << endl;
  }

  return 0;
}