#include <iostream>
#include <algorithm>
#include <cstdio>
#include <string>
#include <cstring>
#include <cctype>
#include <cstdlib>
#include <cmath>
#include <vector>
#include <set>
#include <queue>
#include <stack>
#include <map>
#include <complex>
using namespace std;

#define REP(i, s, e) for (int i = (s); i < (e); i++)
#define REPI(i, s, e) for (int i = (s); i <= (e); i++)
#define rep(i, n) REP(i, 0, n)
#define repi(i, n) REPI(i, 0, n)
#define ALL(v) (v).begin(), (v).end()

#define dump(x) (cout << #x << " = " << x << endl)
#define dump2(x, y) (cout << "(" << #x << ", " << #y << ") = (" << x << ", " << y << ")" << endl)
#define dump3(x, y, z) (cout << "(" << #x << ", " << #y << ", " << #z << ") = (" << x << ", " << y << ", "<< z << ")" << endl)

typedef long long ll;
typedef pair<int, int> pii;
typedef complex<double> pt;

int n, m;
vector< vector<pt> > ls;

pt unit(pt p) { return p/abs(p); }
pt rotate(pt p, int i)
{
	double x, y;
	x = p.real()*cos(i*M_PI/2.0) - p.imag()*sin(i*M_PI/2.0);
	y = p.real()*sin(i*M_PI/2.0) + p.imag()*cos(i*M_PI/2.0);
	return pt(x, y);
}

#define EPS 1e-9
#define EQ(x, y) ((x)-EPS <= (y) && (y) <= (x)+EPS)

bool same(vector<pt> l1, vector<pt> l2)
{
	if (l1.size() != l2.size()) return false;

	rep(r, 4) {
		bool f = true;
		rep(i, l1.size()) {
			pt b = rotate(l1[i], r);
			if (!(EQ(b.real(), l2[i].real()) && EQ(b.imag(), l2[i].imag()))) {
				f = false;
				break;
			}
		}
		if (f)
			return true;
	}
	return false;
}

int main(void)
{
	while (cin >> n, n) {
		ls = vector< vector<pt> >();
		rep(i, n+1) {
			cin >> m;

			vector<pii> ps = vector<pii>(m);
			rep(j, m)
				cin >> ps[j].first >> ps[j].second;

			vector<pt> line;
			REP(j, 1, ps.size()) line.push_back(pt(ps[j].first, ps[j].second)-pt(ps[j-1].first, ps[j-1].second));

			ls.push_back(line);
		}

		vector<pt> rls0 = vector<pt>(ls[0]);
		reverse(ALL(rls0));
		REP(i, 1, ls.size())
			if (same(ls[0], ls[i]) || same(rls0, ls[i]))
				cout << i << endl;
		cout << "+++++" << endl;
	}
	return 0;
}