
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <climits>
#include <cfloat>
#include <cstring>
#include <map>
#include <utility>
#include <set>
#include <iostream>
#include <memory>
#include <string>
#include <vector>
#include <algorithm>
#include <functional>
#include <sstream>
#include <complex>
#include <stack>
#include <queue>
#include <unordered_set>
#include <unordered_map>
using namespace std;

using LL = unsigned long long;

const LL P = 1e9 + 7;

int main(void)
{
	int n;
	while (cin >> n, n)
	{
		vector<LL>hash;
		for (int i = 0; i <= n; ++i)
		{
			int m;
			cin >> m;
			LL hs = 0;
			int x, y;
			cin >> x >> y;
			int tx = 0, ty = 0;
			bool swap = false;
			for (int j = 1; j < m; ++j)
			{
				int xx, yy;
				cin >> xx >> yy;
				xx -= x;
				yy -= y;
				if (j == 1)
				{
					if (yy > 0)
					{
						tx = 1, ty = 1;
					}
					else if (yy < 0)
					{
						tx = -1, ty = -1;
					}
					else if (xx > 0)
					{
						tx = 1, ty = -1;
						swap = true;
					}
					else
					{
						tx = -1, ty = 1;
						swap = true;
					}
				}
				if (swap)
				{
					hs *= P;
					hs += yy * ty;
					hs *= P;
					hs += xx * tx;
				}
				else
				{
					hs *= P;
					hs += xx * tx;
					hs *= P;
					hs += yy * ty;
				}
			}
			hash.push_back(hs);
		}
		for (int i = 1; i <= n; ++i)
		{
			if (hash[0] == hash[i])
			{
				cout << i << endl;
			}
		}
		cout << "+++++\n";
	}
	return 0;
}