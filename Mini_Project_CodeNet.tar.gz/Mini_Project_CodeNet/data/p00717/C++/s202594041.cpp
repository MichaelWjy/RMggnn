#include <bits/stdc++.h>
#define REP(i,n) for (int i=0;i<(n);i++)
#define ALL(a) (a).begin(),(a).end()
#define RFOR(i,a,b) for (int k=(b)-1;k>=(a);k--)
#define REP(i,n) for (int i=0;i<(n);i++)
#define RREP(i,n) for (int i=(n)-1;i>=0;i--)
#define ll long long
#define ull unsigned long long
int dx[4] = {1, 0, -1, 0};
int dy[4] = {0, 1, 0, -1};
  
  
using namespace std;
static const double PI = asin(1.0);
  
  
  
int main(){
    cin.tie(0);
  ios::sync_with_stdio(false);
  int n,m;
  while(cin>>n,n){
    cin >> m;
        int def_m = m;
    int begin_dec_x,begin_dec_y,end_dec_x,end_dec_y;
        vector<int> def_x(m),def_y(m);
    vector<vector<pair<int,int>>> defP(8,vector<pair<int,int> >(m));
    REP(i,m){//input
        int x,y;
        cin >> x >> y;
                def_x[i] = x;
                def_y[i] = y;
                if(i==0){
                    begin_dec_x = -x,begin_dec_y = -y;
        }else if (i==m-1){
                    end_dec_x = -x,end_dec_y = -y;
                }
                
        }

         
        REP(i,m){//memo
            int x = def_x[i];
            int y = def_y[i];
            x += begin_dec_x;y += begin_dec_y;
            REP(j,4){
                int ref_x = x*dx[j]-y*dy[j];
                int ref_y = x*dy[j]+y*dx[j];
                defP[j][i] = pair<int,int>(ref_x, ref_y);
            }
        }
        REP(i,m){//reverse memo
            int x = def_x[m-1-i];
            int y = def_y[m-1-i];
            x += end_dec_x;y += end_dec_y;
        REP(j,4){
            int ref_x = x*dx[j]-y*dy[j];
            int ref_y = x*dy[j]+y*dx[j];
            defP[j+4][i] = make_pair(ref_x, ref_y);
        }
        }


        REP(i,n){
            cin >> m;
            int jud_x[m],jud_y[m];
            REP(j,m){//input
		        int x,y;
			    cin >> x >> y;
                jud_x[j] = x;
                jud_y[j] = y;
                if(j==0){
                    begin_dec_x = -x,begin_dec_y = -y;
                }
                jud_x[j] += begin_dec_x;
                jud_y[j] += begin_dec_y;
            }
            REP(j,8){//pattern
                int ct = 0;
                REP(k,defP[j].size()){//match
                    if(jud_x[k] == defP[j][k].first && jud_y[k] == defP[j][k].second){
                    	    ct++;
                	}
                }
            	if(ct == defP[j].size()){
                	cout << i+1 << endl;
                	break;
            	}
            }
        }
        cout << "+++++" << endl;
    }
  return 0;
}