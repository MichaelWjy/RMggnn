#include<vector>
#include<algorithm>
//#define DEBUG
using namespace std;

typedef vector< pair<int, int> > vecs;
vector<vecs> table;
vector<vecs> rev_table;
int N, M;

vecs mov(vecs x){
	int tmp;
	#ifdef DEBUG_mov
	for(vecs::iterator p = x.begin(); p != x.end(); p++){
		cout<<"before: "<< p->first <<", "<< p->second << endl;
	}
	#endif
	for(vecs::iterator p = x.begin(); p != x.end(); p++){
		tmp = p->first;
		p->first = -(p->second);
		p->second = tmp;
	}
	#ifdef DEBUG_mov
	for(vecs::iterator p = x.begin(); p != x.end(); p++){
		cout<<"after: "<< p->first <<", "<< p->second << endl;
	}
	#endif
	return x;
}
bool veq(vecs a, vecs b){
	//90ツ度ツづ慊づュツつキ
	vecs tmp = a;
	for(int i = 0; i < 4; i++){
		#ifdef DEBUG
		for(vecs::iterator p = tmp.begin(); p != tmp.end(); p++){
			cout<<"tmp: "<< p->first <<", "<< p->second << endl;
		}
		for(vecs::iterator p = b.begin(); p != b.end(); p++){
			cout<<"b: "<< p->first <<", "<< p->second << endl;
		}
		#endif
		if(tmp == b)return true;
		tmp = mov(tmp);
	}
	return false;
}

int main(){
	while(cin>>N, N){
		int i, j;
		table.clear(); rev_table.clear();
		for(int i = 0; i <= N; i++){
			cin>>M;
			int x, y; int x0, y0;
			cin>>x0>>y0;
			vecs tmpv;
			for(int j = 0; j < M-1; j++){
				cin>>x>>y;
				tmpv.push_back(make_pair(x-x0, y-y0));
				x0 = x; y0 =  y;
			}
			table.push_back(tmpv);
			reverse(tmpv.begin(), tmpv.end());
			rev_table.push_back(tmpv);
		}
		#ifdef DEBUG_in
		for(vector<vecs>::iterator p = table.begin(); p != table.end(); p++){
			for(vecs::iterator q = p->begin(); q != p->end(); q++){
				cout<< q->first <<", "<< q->second <<endl;
			}
			cout<<endl;
		}
		#endif
		for(i = 1; i <= N; i++){
			if(veq(table[i], table[0]) || veq(table[i], rev_table[0])){
				cout<<i<<endl;
			}
		}
		cout<<"+++++"<<endl;
	}
	return 0;
}