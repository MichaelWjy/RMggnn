#include <iostream>  
#include <vector>  
#include <map>  
#include <set>  
#include <string.h>  

using namespace std;
struct xy {  
    int first;  
    int second;  
};  
  
xy presets1[1000];  
xy input[1000];  

void solve()
{
	int n;  
    while (1) {  
        cin >> n;  
        if (n == 0) {  
            break;  
        }  
          
        memset(presets1 , 0 , sizeof(presets1));  
        memset(input , 0 , sizeof(input));  
        int m;  
        cin >> m;  
        for (int i = 0 ; i < m ; i++) {  
            cin >> presets1[i].first >> presets1[i].second;  
        }  
  
        for (int i = 0 ; i < n ; i++) {  
            int check;  
            cin >> check;  
            for (int j = 0 ; j < check ; j++) {  
                cin >> input[j].first >> input[j].second;  
            }  
            if (m != check) {  
                continue;  
            }  
            for (int k = 0 ; k < 4 ; k++) {  
                int ix0 = input[0].first;  
                int iy0 = input[0].second;  
                int px0 = presets1[0].first;  
                int py0 = presets1[0].second;  
                for (int j = 0 ; j < check ; j++) {  
                    if (presets1[j].first - px0 != input[j].first - ix0 || presets1[j].second - py0 != input[j].second - iy0) {  
                        goto NEXT;  
                    }  
                }  
                cout << i + 1 << endl;  
                goto END;  
    NEXT:;  
                px0 = presets1[check - 1].first;  
                py0 = presets1[check - 1].second;  
                for (int j = 0 ; j < check ; j++) {  
                    if (presets1[check - j - 1].first - px0 != input[j].first - ix0 || presets1[check - j - 1].second - py0 != input[j].second - iy0) {  
                        goto NEXT2;  
                    }  
                }  
                cout << i + 1 << endl;  
                goto END;  
NEXT2:;  
                //ñ]ìÆ  
                for (int j = 0 ; j < check ; j++) {  
                    int temp = input[j].first;  
                    input[j].first = input[j].second;  
                    input[j].second = -temp;  
                }  
            }  
END:;  
        }  
        cout << "+++++" << endl;  
    }  
}

int main()
{
	solve();
	return(0);
}