#include <bits/stdc++.h>
using namespace std;
#define min(a,b) ((a)<(b)?(a):(b))
#define max(a,b) ((a)>(b)?(a):(b))
#define REP(i,n) for(int i=0;i<n;i++)
#define FOR(i,n1,n2) for(int i=n1;i<n2;i++)
#define bFOR(i,n1,n2) for(int i=n1;i>=n2;i--)
#define speed_up    ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);

typedef long long int ll;
typedef pair<int,int> Pi;
const int INF=(ll)(1LL<<31)-1;
const ll INFl=(ll)9223372036854775807;
const int MAX=10000;
const ll MOD=(ll)1e9+7;
ll gcd(ll a,ll b){return b?gcd(b,a%b):a;}
ll lcm(ll a,ll b){return a/gcd(a, b)*b;}
//int dx[4]={1,0,-1,0},dy[4]={0,1,0,-1};

template<typename A, size_t N, typename T>
void Fill(A (&array)[N], const T &val){
    std::fill( (T*)array, (T*)(array+N), val );
}

int n;
int m;
Pi xy[11];
vector<Pi> PP[8];
Pi rotate(Pi p){
	Pi re;
	if(p.second!=0){
		re.first=p.second;
		re.second=0;
	}else{
		re.first=0;
		re.second=-1*p.first;
	}
	return re;
}

int main(){
	while(1){
		cin>>n;
		if(n==0)break;
		cin>>m;
		FOR(i,0,8)
			PP[i].clear();
		REP(i,m){
			int x,y;
			cin>>x>>y;
			xy[i]=Pi(x,y);
		}
		FOR(i,1,m)
			PP[0].push_back(Pi(xy[i].first-xy[i-1].first,xy[i].second-xy[i-1].second));
		
		for(int i=m-2;i>=0;i--){
			Pi t;
			t.first=PP[0][i].first*-1;
			t.second=PP[0][i].second*-1;
			PP[4].push_back(t);
		}
		
		FOR(i,1,4){
			FOR(j,0,PP[i-1].size()){
				PP[i].push_back(rotate(PP[i-1][j]));
			}
		}		
		FOR(i,5,8){
			FOR(j,0,PP[i-1].size()){
				PP[i].push_back(rotate(PP[i-1][j]));
			}
		}
		
		/*for(int i=0;i<8;i++){
			for(int j=0;j<PP[i].size();j++){
				printf("%d %d//",PP[i][j].first,PP[i][j].second);
			}
			printf("\n");
		}*/
		vector<Pi> rv;
		vector<Pi> vv;
		vector<int> ans;
		ans.clear();
		for(int i=1;i<=n;i++){
			rv.clear();
			vv.clear();
			int tm;
			cin>>tm;
			for(int j=0;j<tm;j++){
				int a,b;
				cin>>a>>b;
				rv.push_back(Pi(a,b));
			}
			for(int j=1;j<tm;j++)
				vv.push_back(Pi(rv[j].first-rv[j-1].first,rv[j].second-rv[j-1].second));
			int flag=0;
			if(tm!=m)continue;
			for(int j=0;j<8;j++){
				for(int k=0;k<tm-1;k++){
					if(PP[j][k]!=vv[k]){
						break;
					}
					if(k==tm-2)flag=1;
				}
			
			
			}
			if(flag){
				//printf("%d\n",i);
				ans.push_back(i);
			}
		}
		REP(i,ans.size()){
			cout<<ans[i]<<endl;
		}
		printf("+++++\n");
	}
	return 0;
}
