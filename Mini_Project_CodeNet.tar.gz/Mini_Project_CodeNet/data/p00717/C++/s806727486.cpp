#include<iostream>
#include<string>
#include<algorithm>
#include<vector>
#include<cstdio>
#include<cstring>
using namespace std;

#define rep(i,n) for(int i=0;i<n;i++)
#define REP(n) rep(i,n)
#define all(n) n.begin(),n.end()

int MAXN = 55, MAXM = 11;
const int R = 0, L = 1;
const int E = 0, N = 1, W = 2, S = 3;

const int rxx[4] = {1, 0, -1, 0}, rxy[4] = {0, -1, 0, 1}, ryx[4] = {0, 1, 0, -1}, ryy[4] = {1, 0, -1, 0};

int main()
{
    int m0, v0[2][MAXM];
    int m, v[2][MAXM];
    int x[MAXN], y[MAXN];

    int n;
    while(cin >> n && n)
    {
        cin >> m0;
        REP(m0) cin >> x[i] >> y[i];
        REP(m0 - 1) { x[i + 1] -= x[0]; y[i + 1] -= y[0]; }
        x[0] = y[0] = 0;

        int vec;
        if(x[1] - x[0] > 0) vec = E;
        if(y[1] - y[0] > 0) vec = N;
        if(x[1] - x[0] < 0) vec = W;
        if(y[1] - y[0] < 0) vec = S;
        for(int i = 0;i < m0;i++) 
        {
            v0[0][i] = rxx[vec] * x[i] + ryx[vec] * y[i];   
            v0[1][i] = rxy[vec] * x[i] + ryy[vec] * y[i];
        }

        rep(setnum, n )
        {
            cin >> m;
            REP(m) cin >> x[i] >> y[i];
            if(m != m0) continue;

            REP(m - 1){ x[i + 1] -= x[0]; y[i + 1] -= y[0];}
            x[0] = y[0] = 0;
            if(x[1] > 0) vec = E;
            if(y[1] > 0) vec = N;
            if(x[1] < 0) vec = W;
            if(y[1] < 0) vec = S;
            for(int i = 0;i < m;i++) 
            {
                v[0][i] = rxx[vec] * x[i] + ryx[vec] * y[i];   
                v[1][i] = rxy[vec] * x[i] + ryy[vec] * y[i];
            }
            int f = 1;
            REP(m0)if(v0[0][i] != v[0][i] || v0[1][i] != v[1][i]) { f = 0; break;}
            if(f) { cout << setnum + 1 << endl; continue;}
            reverse(&x[0], &x[m]); reverse(&y[0], &y[m]);

            REP(m - 1){ x[i + 1] -= x[0]; y[i + 1] -= y[0];}
            x[0] = y[0] = 0;
            if(x[1] > 0) vec = E;
            if(y[1] > 0) vec = N;
            if(x[1] < 0) vec = W;
            if(y[1] < 0) vec = S;
            for(int i = 0;i < m;i++) 
            {
                v[0][i] = rxx[vec] * x[i] + ryx[vec] * y[i];   
                v[1][i] = rxy[vec] * x[i] + ryy[vec] * y[i];
            }
            f = 1;
            REP(m0)if(v0[0][i] != v[0][i] || v0[1][i] != v[1][i]) { f = 0; break;}
            if(f) { cout << setnum + 1 << endl; continue;}

        }
        cout << "+++++" << endl;
    }

    return 0;
}