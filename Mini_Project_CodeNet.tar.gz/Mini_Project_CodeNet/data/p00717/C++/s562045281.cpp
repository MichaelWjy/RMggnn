#include <iostream>
#include <iomanip>
#include <sstream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <climits>
#include <cfloat>
#include <vector>
#include <string>
#include <stack>
#include <queue>
#include <set>
#include <map>
#include <algorithm>
#include <functional>
#include <utility>
#include <numeric>
#include <iterator>

using namespace std;

typedef long long LL;
typedef unsigned long long ULL;
typedef vector<int> VI;
typedef vector<VI> VVI;
typedef vector<string> VS;
typedef pair<int,int> PII;
typedef vector<PII> VPII;
typedef istringstream ISS;
typedef ostringstream OSS;

#define REP( i, m, n ) for ( int i = (int)( m ); i < (int)( n ); ++i )
#define FOR( v, c ) for ( auto &v : c )
#define EACH( it, c ) for ( auto it = c.begin(); it != c.end(); ++it )
#define ALL( c ) (c).begin(), (c).end()
#define DRANGE( c, p ) (c).begin(), (c).begin() + p, (c).end()

#define PB( n ) push_back( n )
#define MP( a, b ) make_pair( ( a ), ( b ) )
#define EXIST( c, e ) ( (c).find( e ) != (c).end() )

#define fst first
#define snd second

#define DUMP( x ) cerr << #x << " = " << ( x ) << endl
#define DEBUG( x ) cerr << __FILE__ << ":" << __LINE__ << ": " << #x << " = " << ( x ) << endl

#include <complex>
typedef complex<int> Point;

const int EPS = 0;

// 外積（クロス積）
double cross( const Point &a, const Point &b )
{
	return a.real() * b.imag() - a.imag() * b.real();
}

// cin >> Point
istream& operator >> ( istream &s, Point &a )
{
	double r, i;
	s >> r >> i;
	a = Point( r, i );
	return s;
}

// CCW 関数　a -> b -> c と進むとき、反時計回りなら -1, 直進なら 0, 時計回りなら 1
int ccw( const Point &a, const Point &b, const Point &c )
{
	if ( cross( ( b - a ), ( c - a ) ) < -EPS )
	{
		return -1;
	}
	else if ( EPS < cross( ( b - a ), ( c - a ) ) )
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

int main()
{
	cin.tie( 0 );
	ios::sync_with_stdio( false );

	for ( int n; cin >> n, n; )
	{
		VVI segss;
		REP( i, 0, n + 1 )
		{
			int m;
			cin >> m;

			vector<Point> ps( m );
			FOR( p, ps )
			{
				cin >> p;
			}

			VI segs;
			segs.PB( abs( ps[0] - ps[1] ) );
			REP( i, 0, m - 2 )
			{
				segs.PB( ccw( ps[ i + 2 ], ps[ i + 1 ], ps[i] ) );
				segs.PB( abs( ps[ i + 2 ] - ps[ i + 1 ] ) );
			}
			segss.PB( segs );
		}

		VI rev = segss[0];
		REP( i, 0, rev.size() )
		{
			if ( i % 2 )
			{
				rev[i] *= -1;
			}
		}
		reverse( ALL( rev ) );

		REP( i, 1, n + 1 )
		{
			if ( segss[0] == segss[i] || rev == segss[i] )
			{
				cout << i << endl;
			}
		}
		cout << "+++++" << endl;
	}
			

	return 0;
}