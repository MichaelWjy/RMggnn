#include<iostream>
#include<vector>
#include<map>
#include<set>
#include<algorithm>
#include<cstdio>
#include<cmath>
#include<cstdlib>
#include<cstring>
#include<string>
#include<queue>
#include<complex>
#include<numeric>
#include<bitset>
#define INF 1001001001
#define EPS 0.000001
#define x first
#define y second

using namespace std;
typedef vector<int> vint;
typedef vector<vint> vvint;
typedef pair<int,int> pint;

vector<pint> oresens[100];
int chk[100];
int n;

void culc(void){
	int i,j;
	for(i=1;i<=n;i++){
		if(oresens[0].size()==oresens[i].size()){
			for(j=0;j<oresens[0].size();j++){
				if(oresens[0][j]!=oresens[i][j]) break;
			}
			if(j==oresens[0].size()) chk[i]=1;
		}
	}
}


int main(){
	while(cin >> n){
		if(n==0) break;
		int i,j;
		for(i=0;i<=n;i++) oresens[i].clear();
		int m;
		for(i=0;i<=n;i++){
			cin >> m;
			int x,y,x2,y2;
			cin >> x >> y;
			pint p;
			for(j=0;j<m-1;j++){
				cin >> x2 >> y2;
				oresens[i].push_back(pint(x2-x,y2-y));
				x=x2;
				y=y2;
			}
		}
		for(i=0;i<100;i++) chk[i]=0;
		
		culc();
		for(i=0;i<oresens[0].size();i++){
			swap(oresens[0][i].x,oresens[0][i].y);
			oresens[0][i].x*=-1;
		}
		culc();
		for(i=0;i<oresens[0].size();i++){
			swap(oresens[0][i].x,oresens[0][i].y);
			oresens[0][i].x*=-1;
		}
		culc();
		for(i=0;i<oresens[0].size();i++){
			swap(oresens[0][i].x,oresens[0][i].y);
			oresens[0][i].x*=-1;
		}
		culc();
		for(i=0;i<oresens[0].size();i++){
			swap(oresens[0][i].x,oresens[0][i].y);
			oresens[0][i].x*=-1;
		}
		reverse(&oresens[0][0],&oresens[0][oresens[0].size()]);
		for(i=0;i<oresens[0].size();i++){
			oresens[0][i].x*=-1;
			oresens[0][i].y*=-1;
		}
		culc();
		for(i=0;i<oresens[0].size();i++){
			swap(oresens[0][i].x,oresens[0][i].y);
			oresens[0][i].x*=-1;
		}
		culc();
		for(i=0;i<oresens[0].size();i++){
			swap(oresens[0][i].x,oresens[0][i].y);
			oresens[0][i].x*=-1;
		}
		culc();
		for(i=0;i<oresens[0].size();i++){
			swap(oresens[0][i].x,oresens[0][i].y);
			oresens[0][i].x*=-1;
		}
		culc();
		
		for(i=0;i<100;i++) if(chk[i]==1) cout << i << endl;
		cout << "+++++" << endl;
	}
		
	return 0;
}