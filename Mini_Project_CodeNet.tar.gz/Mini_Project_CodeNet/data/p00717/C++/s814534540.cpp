#include <iostream>
#include <math.h>
#include <algorithm>
#include <cstring>
#include <vector>
#include <fstream>

using namespace std;

typedef long long ll;

struct P{
    int x, y;
};
int N;

int main(){
    while(1){
        N = 0;
        cin >> N;
        if(!N) break;
        // origin
        vector<P> ps;
        // cout << " asdfasdf"<< endl;
        int o_m; cin >> o_m;
        int ori_x, ori_y;
        for(int i=0; i<o_m; i++){
            int x, y; cin >> x >> y;
            // cout << "asdfa"<< endl;
            ps.push_back({x, y});
            if(!i){
                ori_x = x; ori_y = y;
            }
            ps[i].x -= ori_x; ps[i].y -= ori_y;
        }
        // cout << "111" << endl;
        vector<vector<P> > res(8);
        res[0] = ps;
        for(int i=1; i<4; i++){
            for(P u : res[i-1]){
                P nU = {u.y * -1, u.x};
                res[i].push_back(nU);
            }
        }
        for(int i=4; i<8; i++){
            for(P u : res[i-4]){
                P last = res[i-4][res[i-4].size()-1];
                P nU = {u.x - last.x, u.y - last.y};
                res[i].push_back(nU);
            }
            reverse(res[i].begin(), res[i].end());
        }   

        // if(N== 4)
        // for(int i=0; i<8; i++){
        //     for(P u : res[i]){
        //         cout << u.x << " " << u.y << endl;
        //     }
        //     cout << endl;
        // }

        // cout <<"--------" << endl;
        // cout << N;

        // cout << "111" << endl;

        for(int _=0; _<N; _++){
            // cout << "a" << endl;
            int m; cin >> m;
            int ori_x2, ori_y2;
            vector<P> ps2;
            for(int i=0; i<m; i++){
                int x, y; cin >> x >> y;
                ps2.push_back({x, y});
                if(!i){
                    ori_x2 = x; ori_y2 = y;
                }
                ps2[i].x -= ori_x2; ps2[i].y -= ori_y2;
            }
            // cout << "a"<< endl;
            // if(N== 4)
            // for(P u : ps2){
            //     cout << u.x << " " << u.y << endl;
            // }
            // cout << endl;
            if(m != o_m) continue;
            bool ok = true;
            for(int j=0; j<8; j++){
                for(int i=0; i<m; i++){
                    if(res[j][i].x != ps2[i].x) ok = false;
                    if(res[j][i].y != ps2[i].y) ok = false;
                    if(!ok) break;
                }
                if(ok){
                    cout << _+1 << endl;
                    break;
                }
                ok = true;
            }
        }

        cout << "+++++" << endl;
        // if(N == 4) break;
        // int a; cin >> a; cout << a << endl;
        // break;
    }

    return 0;
}

/*
5
5
0 0
2 0
2 1
4 1
4 0
5
0 0
0 2
-1 2
-1 4
0 4
5
0 0
0 1
-2 1
-2 2
0 2
5
0 0
0 -1
2 -1
2 0
4 0
5
0 0
2 0
2 -1
4 -1
4 0
5
0 0
2 0
2 1
4 1
4 0
*/
