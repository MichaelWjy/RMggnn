#include <bits/stdc++.h>
using namespace std;

// #define int long long // intで書いたけど心配なときにlong longに変換する
struct Fast {Fast(){std::cin.tie(0);ios::sync_with_stdio(false);}} fast;

/* short */
#define pb push_back
#define eb emplace_back
#define mp make_pair
#define Fi first
#define Se second
#define ALL(v) begin(v), end(v)
#define RALL(v) rbegin(v), rend(v)
#define X real()
#define Y imag()

/* REPmacro */
#define REPS(i, a, n) for (ll i = (a); i < (ll)(n); ++i)
#define REP(i, n) REPS(i, 0, n)
#define RREP(i, n) REPS(i, 1, n + 1)
#define DEPS(i, a, n) for (ll i = (a); i >= (ll)(n); --i)
#define DEP(i, n) DEPS(i, n, 0)
#define EACH(i, n) for (auto&& i : n)

/* debug */
#define debug(x) cerr << x << " " << "(L:" << __LINE__ << ")" << '\n';

/* alias */
using ll = long long;
using ull = unsigned long long;
using vi = vector<int>;
using vvi = vector<vi>;
using vvvi = vector<vvi>;
using pii = pair<int, int>;
using D = double;
using P = complex<D>;
using vs = vector<string>;
template <typename T> using PQ = priority_queue<T>;
template <typename T> using minPQ = priority_queue<T, vector<T>, greater<T>>;

/* const */
const int INF = 1001001001;
const ll LINF = 1001001001001001001ll;
const int MOD = 1e9 + 7;
const D EPS = 1e-9;
// const int dx[] = {0, 1, 0, -1, 1, -1, 1, -1}, dy[] = {1, 0, -1, 0, 1, -1, -1, 1};

/* func */
inline bool inside(int y, int x, int H, int W) {return y >= 0 && x >= 0 && y < H && x < W;}
inline int in() {int x; cin >> x; return x;}
inline ll IN() {ll x; cin >> x; return x;}
inline vs split(const string& t, char c) {vs v; stringstream s(t); string b; while(getline(s, b, c)) v.eb(b); return v;}
template <typename T> inline bool chmin(T& a, const T& b) {if (a > b) a = b; return a > b;}
template <typename T> inline bool chmax(T& a, const T& b) {if (a < b) a = b; return a < b;}
template <typename T, typename S> inline void print(const pair<T, S>& p) {cout << p.first << " " << p.second << endl;}
template <typename T> inline void print(const T& x) {cout << x << '\n';}
template <typename T, typename S> inline void print(const vector<pair<T, S>>& v) {for (auto&& p : v) print(p);}
template <typename T> inline void print(const vector<T>& v, string s = " ") {REP(i, v.size()) cout << v[i] << (i != (ll)v.size() - 1 ? s : "\n");}

int basem;
int compm;
int basex[11];
int basey[11];
int compx[11];
int compy[11];

int sign(int A) {
    if(A>0) return 1;
    else if(A<0) return -1;
    else return 0;
}

int rot(int* x, int* y, int mode) {
    int xx = *x, yy = *y;
    if (mode == 0) {
        *x = xx;
        *y = yy;
    } else if (mode == 1) {
        *x = -yy;
        *y = xx;
    } else if (mode == 2) {
        *x = -xx;
        *y = -yy;
    } else if (mode == 3) {
        *x = yy;
        *y = -xx;
    }
}

void solve(int n) {
    // base
    cin >> basem;
    REP(j, basem) {
        cin >> basex[j] >> basey[j];
    }

    // compare
    REP(i, n) {
        cin >> compm;
        REP(j, compm) {
            cin >> compx[j] >> compy[j];
        }
        if(basem != compm) continue;
        bool match;
        int rotmode;
        int basexsig, baseysig;
        int compxsig, compysig;
        int basedx, basedy;
        int compdx, compdy;
        basexsig = sign(basex[1] - basex[0]);
        baseysig = sign(basey[1] - basey[0]);
        // dir1
        match = true;
        compxsig = sign(compx[1] - compx[0]);
        compysig = sign(compy[1] - compy[0]);
        rotmode = -1;
        REP(mode, 4) {
            int x, y;
            x = compxsig;
            y = compysig;
            rot(&x, &y, mode);
            if(x == basexsig && y == baseysig) {
                rotmode = mode;
                break;
            }
        }
        // cout << basexsig << " " << baseysig << " " << compxsig << " " << compysig << " " << rotmode << endl;
        REP(j, compm) {
            basedx = basex[j] - basex[0];
            basedy = basey[j] - basey[0];
            compdx = compx[j] - compx[0];
            compdy = compy[j] - compy[0];
            rot(&compdx, &compdy, rotmode);
            if (basedx != compdx || basedy != compdy) {
                match = false;
                break;
            }
        }
        if (match) {
            cout << i+1 << endl;
            continue;
        }
        // dir2
        match = true;
        compxsig = sign(compx[compm-2] - compx[compm-1]);
        compysig = sign(compy[compm-2] - compy[compm-1]);
        rotmode = -1;
        REP(mode, 4) {
            int x, y;
            x = compxsig;
            y = compysig;
            rot(&x, &y, mode);
            if(x == basexsig && y == baseysig) {
                rotmode = mode;
                break;
            }
        }
        REP(j, compm) {
            basedx = basex[j] - basex[0];
            basedy = basey[j] - basey[0];
            compdx = compx[compm-1-j] - compx[compm-1];
            compdy = compy[compm-1-j] - compy[compm-1];
            rot(&compdx, &compdy, rotmode);
            if (basedx != compdx || basedy != compdy) {
                match = false;
                break;
            }
        }
        if (match) {
            cout << i+1 << endl;
            continue;
        }
    }

    cout << "+++++" << endl;
}

signed main() {
    int n;
    while(true) {
        cin >> n;
        if(n==0) {
            break;
        } else {
            solve(n);
        }
    }

    return 0;
}

// https://github.com/kurokoji/.cpp-Template/wiki テンプレートについて
// http://www.creativ.xyz/dump-cpp-652 dump()について
// https://gist.github.com/rigibun/7905920 色々
