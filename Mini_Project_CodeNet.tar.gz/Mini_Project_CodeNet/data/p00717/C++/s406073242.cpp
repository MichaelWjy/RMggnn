#include <algorithm>
#include <cassert>
#include <climits>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <deque>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <string>
#include <vector>

#define FOR(i,k,n) for (int (i)=(k); (i)<(n); ++(i))
#define rep(i,n) FOR(i,0,n)
#define pb push_back
#define eb emplace_back
#define all(v) begin(v), end(v)
#define debug(x) cerr<< #x <<": "<<x<<endl
#define debug2(x,y) cerr<< #x <<": "<< x <<", "<< #y <<": "<< y <<endl

using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef pair<int, int> i_i;
typedef pair<i_i, int> p_i;
typedef vector<int> vi;
typedef vector<vector<int> > vvi;
typedef vector<ll> vll;
typedef vector<vector<ll> > vvll;
typedef vector<char> vc;
typedef vector<vector<char> > vvc;
typedef vector<double> vd;
typedef vector<vector<double> > vvd;
template<class T> using vv=vector<vector< T > >;
typedef deque<int> di;
typedef deque<deque<int> > ddi;

// cout vector
template<typename T> ostream& operator<<(ostream& s, const vector<T>& v) {
    int len = v.size();
    for (int i = 0; i < len; ++i) {
        s << v[i]; if (i < len - 1) s << "\t";
    }
    return s;
}

// cout 2-dimentional vector
template<typename T> ostream& operator<<(ostream& s, const vector< vector<T> >& vv) {
    int len = vv.size();
    for (int i = 0; i < len; ++i) {
        s << vv[i] << endl;
    }
    return s;
}

/*
struct pline {
    int m;
    vi x;
    vi y;
    pline() {}
    pline(int m_, vi x_, vi y_) {
        m = m_;
        x = x_;
        y = y_;
    }
};
*/

vi direction(vi x, vi y) {
    assert ((int)x.size() == 2 && (int)y.size() == 2);
    if (y[0] == y[1]) {
        if (x[0] < x[1]) {
            return {0, x[1]-x[0]};
        } else if (x[0] > x[1]) {
            return {2, x[0]-x[1]};
        }
    } else {
        if (y[0] < y[1]) {
            return {1, y[1]-y[0]};
        } else if (y[0] > y[1]) {
            return {3, y[0]-y[1]};
        }
    }
    return {-1, -1};
}

vi v_from_3pts(vi x, vi y) {
    assert ((int)x.size() == 3 && (int)y.size() == 3);
    vi v0 = direction({x[0], x[1]}, {y[0], y[1]});
    vi v1 = direction({x[1], x[2]}, {y[1], y[2]});

    int d = v1[0] - v0[0];
    if (d == 3) {
        d = -1;
    } else if (d == -3) {
        d = 1;
    }

    return {d, v1[1]};
}

vvi convert(vi x, vi y) {
    int m = (int)x.size();
    vvi vecs(m-1);
    int firstd = max(abs(x[1]-x[0]), abs(y[1]-y[0]));
    vecs[0] = {0, firstd};
    FOR (i, 1, m-1) {
        vecs[i] = v_from_3pts({x[i-1], x[i], x[i+1]}, {y[i-1], y[i], y[i+1]});
    }
    return vecs;
}

int main() {
    while (true) {
        int n; cin >> n;
        if ( n == 0 ) { break; }
        //vector<pline> pls(n+1);
        vv<vvi> sets(n+1, vv<vi>(2));
        rep (i, n+1) {
            int m; cin >> m;
            vi x(m);
            vi y(m);
            rep (i, m) {
                cin >> x[i] >> y[i];
            }
            sets[i][0] = convert(x, y);
            reverse(all(x));
            reverse(all(y));
            sets[i][1] = convert(x, y);
            //pls[i] = pline(m, x, y);
        }
        FOR (i, 1, n+1) {
            if ( sets[i][0] == sets[0][0] ||
                 sets[i][0] == sets[0][1] ||
                 sets[i][1] == sets[0][0] ||
                 sets[i][1] == sets[0][1] ) {
                printf("%d\n", i);
            }
        }
        printf("+++++\n");
    }

    return 0;
}