#include<cstdio>
#include<utility>

#define	mp	make_pair

using namespace std;

typedef	pair<int,int>	pii;

pii operator+(pii &p,pii &q){ return mp(p.first+q.first,p.second+q.second); }
pii operator-(pii &p,pii &q){ return mp(p.first-q.first,p.second-q.second); }

void rot(pii *p,int m){
	for(int i=0;i<m;i++)	p[i]=mp(-p[i].second,p[i].first);
}

bool equal(pii *p1,pii *p2,int m){
	for(int i=0;i<4;i++){

		pii shift=p1[0]-p2[0];
		bool ok=true;
		for(int k=0;k<m;k++)	if(p1[k]!=p2[k]+shift){ ok=false; break; }
		if(ok)	return true;

		shift=p1[0]-p2[m-1];
		ok=true;
		for(int k=0;k<m;k++)	if(p1[k]!=p2[m-k-1]+shift){ ok=false; break; }
		if(ok)	return true;

		rot(p2,m);
	}
	return false;
}

int main(){
	for(int n;scanf("%d",&n),n;){
		pii org[10];
		int m;	scanf("%d",&m);
		for(int i=0;i<m;i++){
			int x,y;	scanf("%d%d",&x,&y);
			org[i]=mp(y,x);
		}

		for(int k=1;k<=n;k++){
			pii poly[10];
			int mm;	scanf("%d",&mm);
			for(int i=0;i<mm;i++){
				int x,y;	scanf("%d%d",&x,&y);
				poly[i]=mp(y,x);
			}
			if(m==mm && equal(org,poly,m))	printf("%d\n",k);
		}

		puts("+++++");
	}

	return 0;
}