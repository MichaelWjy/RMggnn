#include <iostream>
#include <sstream>
#include <iomanip>
#include <algorithm>
#include <cmath>
#include <string>
#include <vector>
#include <list>
#include <queue>
#include <stack>
#include <set>
#include <map>
#include <bitset>
#include <numeric>
#include <cfloat>
using namespace std;

vector<int> solve(vector<vector<int> >& x, vector<vector<int> >& y)
{
    int n = x.size();
    x.push_back(x[0]);
    y.push_back(y[0]);
    reverse(x[n].begin(), x[n].end());
    reverse(y[n].begin(), y[n].end());

    for(int i=0; i<n+1; ++i){
        int m = x[i].size();
        for(int j=m-1; j>=0; --j){
            x[i][j] -= x[i][0];
            y[i][j] -= y[i][0];
        }
        while(x[i][1] <= 0){
            for(int j=0; j<m; ++j){
                swap(x[i][j], y[i][j]);
                y[i][j] *= -1;
            }
        }
    }

    vector<int> ret;
    for(int i=1; i<n; ++i){
        if((x[i] == x[0] && y[i] == y[0]) || (x[i] == x[n] && y[i] == y[n]))
            ret.push_back(i);
    }
    return ret;
}

int main()
{
    for(;;){
        int n;
        cin >> n;
        if(n == 0)
            break;
        vector<vector<int> > x(n+1), y(n+1);
        for(int i=0; i<n+1; ++i){
            int m;
            cin >> m;
            x[i].resize(m);
            y[i].resize(m);
            for(int j=0; j<m; ++j)
                cin >> x[i][j] >> y[i][j];
        }
        vector<int> ret = solve(x, y);
        for(unsigned i=0; i<ret.size(); ++i)
            cout << ret[i] << endl;
        cout << "+++++" << endl;
    }
}