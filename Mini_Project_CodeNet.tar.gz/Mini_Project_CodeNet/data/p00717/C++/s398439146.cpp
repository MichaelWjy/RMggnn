#include <cmath>
#include <vector>
#include <iostream>
#include <algorithm>

using namespace std;

int main()
{
	int n, m, x, y;

	while (true)
	{
		cin >> n;

		if (n == 0) { break; }

		vector<vector<pair<long double, long double> > > L(2 * n + 2);

		long double theta, theta2, x4, y4;

		for (int i = 0; i <= n; i++)
		{
			cin >> m;

			for (int j = 0; j < m; j++)
			{
				cin >> x >> y;

				L[2 * i].push_back(make_pair(x, y));
			}

			L[2 * i + 1] = L[2 * i]; reverse(L[2 * i + 1].begin(), L[2 * i + 1].end());
		}

		for (int i = 0; i < 2 * n + 2; i++)
		{
			int zx = -L[i][0].first;
			int zy = -L[i][0].second;

			for (int j = 0; j < m; j++)
			{
				L[i][j].first += zx; L[i][j].second += zy;
			}

			theta = -atan2l(L[i][1].second, L[i][1].first);

			for (int j = 1; j < m; j++)
			{
				theta2 = atan2l(L[i][j].second, L[i][j].first) + theta;

				x4 = cosl(theta2) * sqrtl(L[i][j].first * L[i][j].first + L[i][j].second * L[i][j].second);
				y4 = sinl(theta2) * sqrtl(L[i][j].first * L[i][j].first + L[i][j].second * L[i][j].second);

				L[i][j].first = x4; L[i][j].second = y4;
			}
		}

		for (int i = 1; i <= n; i++)
		{
			bool ok1 = (L[0].size() == L[2 * i].size());
			bool ok2 = (L[0].size() == L[2 * i + 1].size());
			bool ok3 = (L[1].size() == L[2 * i].size());
			bool ok4 = (L[1].size() == L[2 * i + 1].size());

			for (int j = 0; j < min(L[0].size(), L[2 * i].size()); j++)
			{
				if (!(-1e-6 < L[2 * i][j].first - L[0][j].first && L[2 * i][j].first - L[0][j].first < 1e-6 && -1e-6 < L[2 * i][j].second - L[0][j].second && L[2 * i][j].second - L[0][j].second < 1e-6))
				{
					ok1 = false;
				}
			}
			
			for (int j = 0; j < min(L[0].size(), L[2 * i + 1].size()); j++)
			{
				if (!(-1e-6 < L[2 * i + 1][j].first - L[0][j].first && L[2 * i + 1][j].first - L[0][j].first < 1e-6 && -1e-6 < L[2 * i + 1][j].second - L[0][j].second && L[2 * i + 1][j].second - L[0][j].second < 1e-6))
				{
					ok2 = false;
				}
			}
			
			for (int j = 0; j < min(L[1].size(), L[2 * i].size()); j++)
			{
				if (!(-1e-6 < L[2 * i][j].first - L[1][j].first && L[2 * i][j].first - L[1][j].first < 1e-6 && -1e-6 < L[2 * i][j].second - L[1][j].second && L[2 * i][j].second - L[1][j].second < 1e-6))
				{
					ok3 = false;
				}
			}

			for (int j = 0; j < min(L[1].size(), L[2 * i + 1].size()); j++)
			{
				if (!(-1e-6 < L[2 * i + 1][j].first - L[1][j].first && L[2 * i + 1][j].first - L[1][j].first < 1e-6 && -1e-6 < L[2 * i + 1][j].second - L[1][j].second && L[2 * i + 1][j].second - L[1][j].second < 1e-6))
				{
					ok4 = false;
				}
			}

			if (ok1 || ok2 || ok3 || ok4)
			{
				cout << i << endl;
			}
		}

		cout << "+++++" << endl;
	}

	return 0;
}