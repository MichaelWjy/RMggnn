#include<iostream>
#include<set>
using namespace std;

int n,m[51],x[51][10],y[51][10];

bool same(int i1, int i2)
{
  if(m[i1]!=m[i2])return false;
  for(int j=0;j<m[i1];j++)if(x[i1][j]!=x[i2][j] || y[i1][j]!=y[i2][j])return false;
  return true;
}
void add(int i, int ax, int ay)
{
  for(int j=0;j<m[i];j++){
    x[i][j]+=ax;
    y[i][j]+=ay;
  }
}
void rotate(int i)
{
  for(int j=0;j<m[i];j++){
    int tx=x[i][j],ty=y[i][j];
    x[i][j]=ty;
    y[i][j]=-tx;
  }
}
void reverse(int i)
{
  int tx[10],ty[10];
  for(int j=0;j<m[i];j++){
    tx[j]=x[i][j];
    ty[j]=y[i][j];
  }
  for(int j=0;j<m[i];j++){
    x[i][j]=tx[m[i]-j-1];
    y[i][j]=ty[m[i]-j-1];
  }
}

int main()
{
  while(cin>>n,n){
    for(int i=0;i<=n;i++){
      cin>>m[i];
      for(int j=0;j<m[i];j++){
	cin>>x[i][j]>>y[i][j];
      }
    }

    set<int>ans;
    set<int>::iterator it;
    add(0,-x[0][0],-y[0][0]);
    for(int i=1;i<=n;i++){
      add(i,-x[i][0],-y[i][0]);
      for(int k=0;k<4;k++){
	rotate(i);
	if(same(0,i))ans.insert(i);
      }
      reverse(i);
      add(i,-x[i][0],-y[i][0]);
      for(int k=0;k<4;k++){
	rotate(i);
	if(same(0,i))ans.insert(i);
      }
    }

    for(it=ans.begin();it!=ans.end();it++)cout<<*it<<endl;
    puts("+++++");
  }
}