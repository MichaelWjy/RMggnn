#include <bits/stdc++.h>

using namespace std;

#define LOG(...) fprintf(stderr, __VA_ARGS__)
//#define LOG(...)
#define FOR(i, a, b) for(int i=(int)(a); i<(int)(b); ++i)
#define REP(i, n) for(int i=0; i<(int)(n); ++i)
#define ALL(a) (a).begin(), (a).end()
#define RALL(a) (a).rbegin(), (a).rend()
#define EXIST(s, e) ((s).find(e)!=(s).end())
#define SORT(c) sort(ALL(c))
#define RSORT(c) sort(RALL(c))
#define SQ(n) (n) * (n)

typedef long long ll;
typedef unsigned long long ull;
typedef vector<bool> vb;
typedef vector<int> vi;
typedef vector<ll> vll;
typedef vector<vb> vvb;
typedef vector<vi> vvi;
typedef vector<vll> vvll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;

vector<pii> inputline(){
  int m;
  cin >> m;
  vector<pii> line(m);
  REP(i, m){
    cin >> line[i].first >> line[i].second;
  }
  return line;
}

vector<pii> transform(vector<pii> line, pii src){
  REP(i, line.size()){
    line[i].first -= src.first;
    line[i].second -= src.second;
  }
  return line;
}

vector<pii> rotate(vector<pii> line, int n){
  REP(j, n){
    REP(i, line.size()){
      line[i] = {-line[i].second, line[i].first};
    }
  }
  return line;
}

int main() {
  int n;

  while(cin >> n, n){

    vector<pii> src = inputline();
    vector<pii> rsrc = src;
    reverse(ALL(rsrc));
    vector<vector<pii>> answer;
    answer.push_back(transform(src, src[0]));
    answer.push_back(transform(rsrc, rsrc[0]));
    REP(i, 3){
      answer.push_back(rotate(answer[0], i + 1));
      answer.push_back(rotate(answer[1], i + 1));
    }

    // LOG("anserrrrrrrrr\n");
    // for(vector<pii> line:answer) {
    //   for (pii p : line) {
    //     LOG("%d %d, ", p.first, p.second);
    //   }
    //   LOG("\n");
    // }
    // LOG("anserrrrrrrrr\n");

    REP(i, n){
      vector<pii> line = inputline();
      line = transform(line, line[0]);
      // for (pii p : line) {
      //   LOG("%d %d, ", p.first, p.second);
      // }
      // LOG("\n");
      for(vector<pii> l : answer) {
        if (l == line) {
          cout << i + 1 << endl;
          break;
        }
      }
    }
    cout << "+++++" << endl;
  }
}