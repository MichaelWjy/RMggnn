#include <algorithm>
#include <iostream>
#include <vector>

using namespace std;

struct Point {
    int x = 0;
    int y = 0;
    bool operator==(const Point& rhs) const { return x == rhs.x && y == rhs.y; }
};

struct Line {
    Point p1;
    Point p2;
    bool operator==(const Line& rhs) const
    {
        return (p1 == rhs.p1 && p2 == rhs.p2) || (p1 == rhs.p2 && p2 == rhs.p1);
    }
};

class Polygon {
    vector<Point> points_;

public:
    void addPoint(const Point& point) { points_.push_back(point); }

    // return pair of upper left and lower right
    pair<Point, Point> boundingBox() const
    {
        auto xMinMax = minmax_element(
            begin(points_), end(points_),
            [](const Point& lhs, const Point& rhs) { return lhs.x < rhs.x; });
        auto yMinMax = minmax_element(
            begin(points_), end(points_),
            [](const Point& lhs, const Point& rhs) { return lhs.y < rhs.y; });
        return make_pair(Point{xMinMax.first->x, yMinMax.second->y},
                         Point{xMinMax.second->x, yMinMax.first->y});
    }

    void translate(int x, int y)
    {
        for_each(begin(points_), end(points_), [x, y](Point& p) {
            p.x += x;
            p.y += y;
        });
    }

    // rotate 90 degrees around (0, 0) clockwise
    void rotate90Clockwise()
    {
        for_each(begin(points_), end(points_), [](Point& p) {
            auto t = p;
            p.x = t.y;
            p.y = -t.x;
        });
    }

    // return Polygon which upper left is (0, 0)
    Polygon normalized() const
    {
        auto bb = boundingBox();
        auto r = *this;
        r.translate(0 - bb.first.x, 0 - bb.first.y);
        return r;
    }

    Polygon rotated() const
    {
        auto r = normalized();
        r.rotate90Clockwise();
        return r.normalized();
    }

    vector<Line> lines() const
    {
        vector<Line> r;
        for (size_t i = 0; i < points_.size() - 1; ++i) {
            r.push_back({points_[i], points_[i + 1]});
        }
        return r;
    }

    bool operator==(const Polygon& rhs) const
    {
        auto l = lines();
        auto r = rhs.lines();
        return l.size() == r.size() &&
               is_permutation(begin(l), end(l), begin(r), end(r));
    }
};

int main()
{
    while (true) {
        int n;
        cin >> n;
        if (n == 0) {
            break;
        }
        vector<Polygon> v;
        for (int i = 0; i < n + 1; ++i) {
            int m;
            cin >> m;
            Polygon p;
            for (int j = 0; j < m; ++j) {
                int x;
                int y;
                cin >> x >> y;
                p.addPoint({x, y});
            }
            v.push_back(p);
        }
        auto target = v[0].normalized();
        for (size_t i = 1; i < v.size(); ++i) {
            auto n1 = v[i].normalized();
            // 90 degrees
            auto n2 = n1.rotated();
            // 180 degrees
            auto n3 = n2.rotated();
            // 270 degrees
            auto n4 = n3.rotated();
            if (n1 == target || n2 == target || n3 == target || n4 == target) {
                cout << i << endl;
            }
        }
        cout << "+++++" << endl;
    }
}