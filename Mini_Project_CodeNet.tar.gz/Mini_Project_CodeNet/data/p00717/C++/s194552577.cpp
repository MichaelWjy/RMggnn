#include<iostream>
#include<string>
#include<algorithm>

using namespace std;

string encode() {
    int m;
    cin >> m;
    int x, y;
    cin >> x >> y;
    string s = "";
    int dirx = 0;
    int diry = 0;
    for (int i = 1; i < m; ++i) {
        int dx, dy;
        cin >> dx >> dy;
        dx -= x;
        dy -= y;

        int dist = abs(dx + dy);
        int ndirx = (dx > 0) - (dx < 0);
        int ndiry = (dy > 0) - (dy < 0);

        if (dirx == 1 && ndiry == -1) s += 'r';
        else if (dirx == 1 && ndiry == 1) s += 'l';
        else if (dirx == -1 && ndiry == -1) s += 'l';
        else if (dirx == -1 && ndiry == 1) s += 'r';
        else if (diry == 1 && ndirx == -1) s += 'l';
        else if (diry == 1 && ndirx == 1) s += 'r';
        else if (diry == -1 && ndirx == -1) s += 'r';
        else if (diry == -1 && ndirx == 1) s += 'l';


        dirx = ndirx;
        diry = ndiry;
        x += dx;
        y += dy;

        s += to_string(dist);
    }
        //cout << s << endl;
    return s;
}

int main() {
    while (1) {
        int n;
        cin >> n;
        if (n == 0) break;
        string code = encode();
        string rev(code);
        reverse(rev.begin(), rev.end());
        for (int i = 0; i < rev.size(); ++i) {
            if (rev[i] == 'r' || rev[i] == 'l') rev[i] = rev[i] == 'r' ? 'l' : 'r';
        }

        //cout << code << endl;
        //cout << rev << endl << endl;
        for (int i = 1; i <= n; ++i) {
            string ancode = encode();
            if(ancode == code || ancode == rev) cout << i << endl;
        }
        cout << "+++++" << endl;
    }
}
