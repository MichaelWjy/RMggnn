#include<iostream>
#include<vector>
#define MAX 10
using namespace std;

struct Point{
	int x,y;
	Point():x(0),y(0){}
	bool operator==(const Point &p){
		return (x == p.x && y == p.y);
	}
};

inline Point Rotate90(const Point &p){
	Point ret;
	ret.x = -p.y;
	ret.y = p.x;
	return ret;
}


struct Polygon{
	int maxv;
	Point vertex[MAX];
	Polygon(){}
	Polygon(int m):maxv(m){}
	Polygon Rotate90(){
		Polygon ret(maxv);
		for(int i = 0; i < maxv; ++i){
			ret.vertex[i] = ::Rotate90(vertex[i]);
		}
		return ret;
	}
	Polygon Translation(int from_vertex, const Polygon &target, int to_vertex){
		Polygon ret = *this;
		int dx = target.vertex[to_vertex].x - vertex[from_vertex].x;
		int dy = target.vertex[to_vertex].y - vertex[from_vertex].y;

		for(int i = 0; i < maxv; ++i){
			ret.vertex[i].x += dx;
			ret.vertex[i].y += dy;
		}
		return ret;
	}
	bool operator==(const Polygon &p){
		Polygon t = p;

		if( maxv != t.maxv )
			return false;
		
		for(int r = 0; r < 4; ++r){
			for(int i = 0; i < maxv; ++i){
				for(int j = 0; j < maxv; ++j){
					bool bSame = true;
					Polygon s = t.Translation( j, *this, i );
					for(int k = 0; k < maxv; ++k){
						if( !(s.vertex[k] == this->vertex[k]) ){
							bSame = false;
							break;
						}
					}
					if( bSame )
						return true;

					// reverse order
					bSame = true;
					for(int k = 0; k < maxv; ++k){
						if( !(s.vertex[maxv-1-k] == this->vertex[k]) ){
							bSame = false;
							break;
						}
					}
					if( bSame )
						return true;
				}
			}
			t = t.Rotate90();
		}
		return false;
	}
};

int main(){
	while(true){
		int n;
		scanf("%d", &n);
		
		if(n==0)break;

		vector< int > vAnss(n+1,0);
		vector< Polygon > vPols;
		vPols.reserve( n+1 );

		for(int i = 0; i <= n; ++i){
			int m;
			scanf("%d", &m);
			
			Polygon pol(m);
			for(int j = 0; j < m; ++j){
				scanf("%d%d", &pol.vertex[j].x, &pol.vertex[j].y);
			}
			vPols.push_back( pol );
		}

		for(int i = 1; i <= n; ++i){
			if( vPols[0] == vPols[i] ){
				vAnss[i] = 1;
			}
		}

		for(int i = 1; i <= n; ++i){
			if( vAnss[i] ){
				printf("%d\n", i);
			}
		}
		
		printf("+++++\n");
	}
	return 0;
}