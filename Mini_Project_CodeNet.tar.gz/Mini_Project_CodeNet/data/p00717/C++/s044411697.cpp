#include <bits/stdc++.h>
#define rep(i, n) for (int i = 0; i < n; i++)
#define INF 10000000
using namespace std;
typedef pair<int, int> P;
int main()
{
    int n;
    while (cin >> n, n)
    {
        vector<vector<P>> v(n);
        vector<vector<P>> w(8);
        int m;
        cin >> m;
        rep(i, m)
        {
            int x, y;
            cin >> x >> y;
            w[0].push_back(make_pair(x, y));
            w[1].push_back(make_pair(y, -x));
            w[2].push_back(make_pair(-x, -y));
            w[3].push_back(make_pair(-y, x));
        }
        rep(i, 4)
        {
            w[i + 4] = vector<P>(m);
            reverse_copy(begin(w[i]), end(w[i]), begin(w[i + 4]));
        }
        rep(i, 8)
        {
            int m = w[i].size();
            rep(j, m)
            {
                if (j == 0)
                    continue;
                w[i][j].first -= w[i][0].first;
                w[i][j].second -= w[i][0].second;
            }
            w[i][0] = P(0, 0);
        }
        rep(i, n)
        {
            int m;
            cin >> m;
            rep(j, m)
            {
                int x, y;
                cin >> x >> y;
                v[i].push_back(make_pair(x, y));
            }
            rep(j, m)
            {
                if (j == 0)
                    continue;
                v[i][j].first -= v[i][0].first;
                v[i][j].second -= v[i][0].second;
            }
            v[i][0] = P(0, 0);
            bool ok = false;
            rep(j, 8)
            {
                if (v[i] == w[j])
                    ok = true;
            }
            if (ok)
                cout << i + 1 << endl;
        }
        /*
        rep(i, 8)
        {
            rep(j, 8) cout << w[i][j].first << "," << w[i][j].second << "|";
            cout << endl;
        }*/
        cout << "+++++" << endl;
    }
    return 0;
}

