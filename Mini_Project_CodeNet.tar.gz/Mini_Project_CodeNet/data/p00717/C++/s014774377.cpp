#include <cstdio>
#include <iostream>
#include <cmath>
#include <ctype.h>
#include <string> 
#include <sstream>
#include <iostream>
#include <algorithm>
#include <cstdlib>
#include <map>
#include <queue>
#include <utility>
#include <vector>
#include <set>
#include <iomanip>
#include <stack>
  
using namespace std;

#define pi 3.141592653589793

int rotation(int x, int y, int i, int n)
{
	int cos_r[4] = {1, 0, -1, 0};
	int sin_r[4] = {0, 1, 0, -1};
	if(n == 0) return x * cos_r[i] - y * sin_r[i];
	else return x * sin_r[i] + y * cos_r[i];
}

bool issame(int temple_x[], int temple_y[], int comp_x[], int comp_y[], int m)
{
	int dx[2] = {1, -1};
	int dy[2] = {1, -1};
	int cnt = 0;
	int tmpvec_x[10], tmpvec_y[10], compvec_x[10], compvec_y[10];
	for(int i = 0; i < m - 1; i++){
		tmpvec_x[i] = temple_x[i + 1] - temple_x[i];
		tmpvec_y[i] = temple_y[i + 1] - temple_y[i];
		compvec_x[i] = comp_x[i + 1] - comp_x[i];
		compvec_y[i] = comp_y[i + 1] - comp_y[i];
	}
	for(int i = 0; i < 2; i++){
		cnt = 0;
		while(cnt < m - 1){
			if(tmpvec_x[cnt] * dx[i] == compvec_x[cnt] && tmpvec_y[cnt] * dy[i] == compvec_y[cnt]) cnt++;
			else break;
		}
		if(cnt == m - 1) return true;
		cnt = 0;
		while(cnt < m - 1){
			if(tmpvec_x[m - 2 - cnt] * dx[i] == compvec_x[cnt] && tmpvec_y[m - 2 - cnt] * dy[i] == compvec_y[cnt]) cnt++;
			else break;
		}
		if(cnt == m - 1) return true;
	}
	
	return false;
}

int main()
{
	int n;
	while(1){
		cin >> n;
		if(n == 0) break;
		int vertice_x[51][10], vertice_y[51][10];
		int m;
		for(int i = 0; i < n + 1; i++){
			cin >> m;
			for(int j = 0; j < m; j++){
				cin >> vertice_x[i][j] >> vertice_y[i][j];
			}
		}
		int rotatedtmp_x[4][10], rotatedtmp_y[4][10];
		for(int i = 0; i < 4; i++){
			for(int j = 0; j < m; j++){
				rotatedtmp_x[i][j] = rotation(vertice_x[0][j], vertice_y[0][j], i, 0);
				rotatedtmp_y[i][j] = rotation(vertice_x[0][j], vertice_y[0][j], i, 1);
			}
		}
		for(int i = 1; i < n + 1; i++){
			for(int j = 0; j < 4; j++){
				if(issame(rotatedtmp_x[j], rotatedtmp_y[j], vertice_x[i], vertice_y[i], m)){
					cout << i << endl;
					break;
				}
			}
		}
		cout << "+++++" << endl;
	}
	return 0;
}