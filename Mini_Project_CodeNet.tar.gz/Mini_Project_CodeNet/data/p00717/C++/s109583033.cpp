#include "bits/stdc++.h"
#include<unordered_map>
#include<unordered_set>
#pragma warning(disable:4996)
using namespace std;
using ld = long double;
template<class t>
using table = vector<vector<t>>;
const ld eps=1e-9;

//// < "d:\d_download\visual studio 2015\projects\programing_contest_c++\debug\a.txt"
struct ore {
	vector<int>rights;
	vector<int>lens;
};
bool operator ==(const ore&l, const ore&r) {
	return l.rights == r.rights&&l.lens == r.lens;
}
ore getrev(ore a) {
	for (auto &r : a.rights) {
		r = !r;
	}
	reverse(a.rights.begin(), a.rights.end());
	reverse(a.lens.begin(), a.lens.end());
	return a;
}
int main() {
	while (1) {
		int N; cin >> N;
		if (!N) {
			break;
		}
		ore origin;
		{
			int m; cin >> m;
			int px, py; cin >> px >> py;
			int way = -1;
			vector<int>arights;
			vector<int>lens;
			for (int j =1 ; j < m; ++j) {
				int x, y; cin >> x >> y;
				const int dx = x - px;
				const int dy = y - py;
				int newway;
				if (!dx)newway = dy > 0 ? 3 : 1;
				else newway = dx > 0 ? 0 : 2;
				if (j != 1) {
					if (way == (newway + 1) % 4) {
						arights.push_back(1);
					}
					else {
						arights.push_back(0);
					}
				}
				way = newway;
				lens.push_back(abs(dx) + abs(dy));
				px = x; py = y;
			}
			origin.lens = lens;
			origin.rights = arights;
		}
		vector<ore>ores;
		int ans = 0;
		for (int i = 0; i < N; ++i) {
			int m; cin >> m;
			int px, py; cin >> px >> py;
			int way = -1;
			vector<int>arights;
			vector<int>lens;
			for (int j = 1; j < m; ++j) {
				int x, y; cin >> x >> y;
				const int dx = x - px;
				const int dy = y - py;
				int newway;
				if (!dx)newway = dy > 0 ? 3 : 1;
				else newway = dx > 0 ? 0 : 2;
				if (j != 1) {
					if (way == (newway + 1) % 4) {
						arights.push_back(1);
					}
					else {
						arights.push_back(0);
					}
				}
				way = newway;
				lens.push_back(abs(dx) + abs(dy));
				px = x; py = y;
			}
			ore o;
			o.lens = lens;
			o.rights = arights;
			bool same = false;
			ore ao = getrev(o);
			if (o == origin)same = true;
			else if (getrev(o) == origin)same = true;
			if (same)cout << i + 1 << endl;
		}
		cout << "+++++" << endl;
	}
	return 0;
}