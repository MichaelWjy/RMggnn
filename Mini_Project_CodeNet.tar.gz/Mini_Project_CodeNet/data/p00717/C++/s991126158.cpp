#include <bits/stdc++.h>
#define rep(i,n) for(int i=0;i<(int)(n);i++)
#define len(v) (int)(v).size()
#define all(v) (v).begin(),(v).end()
#define pb push_back
#define svec(v) cout << #v << ":";for(auto& fq : v) cout<<fq<<" ";cout << "\n"

using namespace std;

void rot(int& x, int& y)
{
    int xx = x, yy = y;
    x = -yy, y = xx;
}

int main()
{
    while(1){
    int n;
    cin >> n;
    if(n == 0){
        break;
    }
    map<vector<int>,vector<int> > mp;
    vector<vector<int> > vec(n+1);
    rep(i,n+1){
        int m;
        cin >> m;
        int x = 0, y = 0;
        int id = 0;
        rep(j,m){
            int u,v;
            cin >> u >> v;
            if(j){
                if(j == 1){
                    if(u == x){
                        if(v-y>0){
                            id = 3;
                        }else{
                            id = 1;
                        }
                    }else{
                        if(u-x<0){
                            id = 2;
                        }
                    }
                }
                int nx = u-x, ny = v-y;
                rep(k,id){
                    rot(nx,ny);
                }
                vec[i].pb(nx),vec[i].pb(ny);
            }
            x = u, y = v;
        }
        if(i){
            mp[vec[i]].pb(i);
            vector<int> nw(len(vec[i]));
            rep(j,len(vec[i])){
                if(vec[i][j] == 0){
                    nw[len(vec[i])-j-1] = -vec[i][j+1], nw[len(vec[i])-j-2] = 0;
                }else{
                    nw[len(vec[i])-j-1] = 0, nw[len(vec[i])-j-2] = -vec[i][j];
                }
                j++;
            }
            int hoge = 0;
            if(nw[0] == 0){
                if(nw[1] > 0){
                    hoge = 3;
                }else{
                    hoge = 1;
                }
            }else{
                if(nw[0] < 0){
                    hoge = 2;
                }
            }
            rep(j,hoge){
                rep(k,len(nw)){
                    rot(nw[k],nw[k+1]);
                    k++;
                }
            }
            mp[nw].pb(i);
        }
    }
    sort(all(mp[vec[0]]));
    mp[vec[0]].erase(unique(all(mp[vec[0]])),mp[vec[0]].end());
    for(auto& it : mp[vec[0]]){
        cout << it << "\n";
    }
    cout << "+++++\n";
}
}

