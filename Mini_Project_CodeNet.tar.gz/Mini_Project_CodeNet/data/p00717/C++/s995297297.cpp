#include <bits/stdc++.h>
using namespace std;
int M, m, N;
int A[11][2];
int B[11][2];

bool hantei() {
	
	for (int i = m - 1; i >= 0; i--) {
		B[i][0] -= B[0][0];
		B[i][1] -= B[0][1];
	}
	for (int i = 0; i < m ; i++) {
		if (B[i][0] != A[i][0] or B[i][1] != A[i][1]) return false;
	}
	return true;
}

bool reversed() {
	for (int i = 0; i < m / 2; i++) {
		swap(B[i], B[m - i - 1]);
	}
	for (int i = m - 1; i >= 0; i--) {
		B[i][0] -= B[0][0];
		B[i][1] -= B[0][1];
	}
	bool res = hantei();
	for (int i = 0; i < m / 2; i++) {
		swap(B[i], B[m - i - 1]);
	}
	for (int i = m - 1; i >= 0; i--) {
		B[i][0] -= B[0][0];
		B[i][1] -= B[0][1];
	}
	return res;
}

void rotate() {
	for (int i = 0; i < m ; i++) {
		swap(B[i][0], B[i][1]);
		B[i][0] *= -1;
	}
}

int main() {
	while (cin >> N, N) {
		cin >> M;
		for(int i = 0; i < M; i++) {
			cin >> A[i][0] >> A[i][1];
		}
		for(int i = M - 1; i >= 0; i--) {
			A[i][0] -= A[0][0];
			A[i][1] -= A[0][1];
		}
		
		for(int n = 1; n <= N; n++) {
			cin >> m;
			for (int i = 0; i < m; i++) {
				cin >> B[i][0] >> B[i][1];
			}
			if (m != M) continue;
			bool f = false;
			for (int i = 0; i < 4 and (!f); i++) {
				f = (f or hantei());
				f = (f or reversed());
				rotate();
			}
			if (f) {
				cout << n << endl;
			}
		}
		cout << "+++++" << endl;
	}
}
		

