#include <iostream>
using namespace std;
int ax[11],ay[11];
int bx[11],by[11];
struct po{
  int dir,na;
};
po hen[11];
po bhen[11];
int m;
int am;
void ahen() {
  for(int i=0;i<m-1;i++) {
    if(ax[i] == ax[i+1]) {
      if(ay[i+1] - ay[i] > 0) {
	hen[i].dir = 1;
	hen[i].na = ay[i+1] - ay[i];
      }
      else {
	hen[i].dir = 3;
	hen[i].na = -1*(ay[i+1]-ay[i]);
      }
    }
    else if(ay[i] == ay[i+1]) {
      if(ax[i+1]-ax[i] > 0) {
	hen[i].dir = 2;
	hen[i].na = ax[i+1]- ax[i];
      }else {
	hen[i].dir = 0;
	hen[i].na = -1*(ax[i+1]- ax[i]);
      }
    }
    //cout << hen[i].dir << " "<<hen[i].na<<endl;
  }
}

int bbhen() {
  for(int i=0;i<m-1;i++) {
    if(bx[i] == bx[i+1]) {
      if(by[i+1] - by[i] > 0) {
	bhen[i].dir = 1;
	bhen[i].na = by[i+1] - by[i];
      }
      else {
	bhen[i].dir = 3;
	bhen[i].na = -1*(by[i+1]-by[i]);
      }
    }
    else if(by[i] == by[i+1]) {
      if(bx[i+1]-bx[i] > 0) {
	bhen[i].dir = 2;
	bhen[i].na = bx[i+1]- bx[i];
      }else {
	bhen[i].dir = 0;
	bhen[i].na = -1*(bx[i+1]- bx[i]);
      }
    }

    //cout << bhen[i].dir << " "<<bhen[i].na<<endl;
  }

  int t;
  int flg = 0;

 for(int j=0;j<4;j++) {
   t=j;
  if(bhen[0].na == hen[0].na) {
    for(int i=0;i<m-1;i++) 
      if((bhen[i].dir+t)%4 != hen[i].dir%4 || hen[i].na != bhen[i].na){
	flg++;
	break;
      }
  } else flg++;
 
  if(bhen[m-2].na == hen[0].na) {
    
    if(t < 0) t*=-1;
    for(int i=0;i<m-1;i++) 
      if((bhen[m-2-i].dir+t)%4 != hen[i].dir%4 || hen[i].na != bhen[m-2-i].na){
	flg++;
	break;
      }
  } else flg++;

 }

  return flg;
}
  

int main(){

  while(1) {
    int n;
    cin >> n;
    if(n == 0) break;
    
    for(int i=0;i<=n;i++) {
      cin >> m;

      for(int j=0;j<11;j++) bx[j] = by[j] = 0;

      for(int j=0;j<m;j++) {
	if(i == 0) cin  >> ax[j] >> ay[j];
	else cin >> bx[j] >> by[j];
      }
      //cout <<i<<"??????"<<endl;
      if(i == 0) ahen(),am = m;
      else {
	if(am != m) continue;
	if(bbhen() != 8) cout << i <<endl;
      }
    }
    
    
    cout <<"+++++"<<endl;
  }
  
  return 0;
}