#include "bits/stdc++.h"
#define ll long long
using namespace std;

bool check(vector<pair<int, int>>& a1, vector<pair<int, int>>& a2) {
	int Size = a1.size();
	//cout << "check" << endl;
	for (int i = 0; i < Size;i++) {
		//cout << "{" << a1[i].first << ", " << a1[i].second << "}{" << a2[i].first << ", " << a2[i].second << "} " << endl;

		if (a1[i].first != a2[i].first || a1[i].second != a2[i].second)return false;
	}
	return true;
}

int main() {
	cin.tie(0); ios::sync_with_stdio(false);
	int n;

	while (cin >> n, n) {
		int m; cin >> m;
		vector<pair<int, int>> base(m), baseL[2];
		for (int i = 0; i < m; i++) {
			int x, y; cin >> x >> y;
			base[i] = { x,y };
		}
		pair<int, int> baseP[2];
		baseP[0]= base[0], baseP[1] = base[m - 1];

		baseL[0] = baseL[1] = base;
		for (int i = 0; i < 2; i++) {
			for (int j = 0; j < m;j++) {
				baseL[i][j].first -= baseP[i].first;
				baseL[i][j].second -= baseP[i].second;
			}
		}
		reverse(baseL[1].begin(), baseL[1].end());

		//sort(baseL[0].begin(), baseL[0].end());
		//sort(baseL[1].begin(), baseL[1].end());

		
		/*for (int i = 0; i < 2; i++) {
			cout << "base" << i << endl;
			for (int j = 0; j < m;j++) {
				cout << baseL[i][j].first << " " << baseL[i][j].second << endl;
			}
			cout << "-----" << endl;
		}*/
		

		for (int i = 1; i <= n;i++) {
			int M; cin >> M;
			vector<pair<int, int>> L(M);
			for (int j = 0; j < M;j++) {
				int x, y; cin >> x >> y;
				L[j] = { x,y};
			}

			int basex = L[0].first, basey = L[0].second;
			for (int j = 0; j < M;j++) {
				L[j].first -= basex; L[j].second -= basey;
			}

			if (M != m) continue;
			for (int j = 0; j < 4;j++) {
				//sort(L.begin(), L.end());

				/*cout << "L = " << i << endl;
				for (int j = 0; j < m;j++) {
					cout << L[j].first << " " << L[j].second << endl;
				}
				cout << "-----" << endl;*/

				if (check(L, baseL[0]) || check(L, baseL[1])) {
					cout << i << endl;
					break;
				}
				for (int k = 0; k < L.size();k++) {
					L[k] = { -L[k].second,L[k].first };
				}
			}
		}
		cout << "+++++" << endl;
	}
}