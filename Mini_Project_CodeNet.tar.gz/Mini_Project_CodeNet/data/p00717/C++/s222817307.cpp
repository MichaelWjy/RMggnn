#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
typedef pair<int,int> P;
int N,M,x,y;

P sub(P p,P q){
	return P(q.first-p.first,q.second-p.second);
}

bool direction(P p1,P q1,P p2,P q2){
	return sub(p1,q1)==sub(p2,q2);
}

bool same(vector<P> a,vector<P> b){
	if((int)a.size()!=(int)b.size()) return false;
	int n = a.size();
	for(int i=0;i<=4;i++){
		for(int j=0;j<n;j++){
			int x = b[j].first,y = b[j].second;
			b[j] = P(-y,x);
		}
		bool judge = true;
		for(int j=0;j<n-1;j++){
			if(!direction(a[j],a[j+1],b[j],b[j+1])) judge = false;
		}
		if(judge) return true;
		reverse(b.begin(),b.end());
		judge = true;
		for(int j=0;j<n-1;j++){
			if(!direction(a[j],a[j+1],b[j],b[j+1])) judge = false;
		}
		if(judge) return true;
	}
	return false;
}

int main(){
	while(cin >> N && N>0){
		vector<vector<P>> v(N+1);
		for(int i=0;i<=N;i++){
			cin >> M;
			for(int j=0;j<M;j++){
				cin >> x >> y;
				v[i].push_back(P(x,y));			
			}
		}
		for(int i=1;i<=N;i++){
			if(same(v[0],v[i])) cout << i << endl;
		}
		cout << "+++++" << endl;
	}
}
