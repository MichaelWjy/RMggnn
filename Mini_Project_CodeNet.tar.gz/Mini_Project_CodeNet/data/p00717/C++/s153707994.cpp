#include <bits/stdc++.h>
#define fi first
#define se second
using namespace std;
using p = pair<int, int>;

int n, m;
vector<vector<p>> v;
vector<p> mom[2];
vector<int> ans;

void solve();
bool ch(int x, bool y, int z);

int main() {
  while(1) {
    cin >> n;
    if(n == 0) break;
    cin >> m;
    for(int i = 0; i < m; ++i) {
      int x, y;
      cin >> x >> y;
      mom[0].push_back({x, y});
      mom[1].push_back({x, y});
    }
    reverse(mom[1].begin(), mom[1].end());
    for(int i = 0; i < n; ++i) {
      vector<p> dum;
      cin >> m;
      for(int j = 0; j < m; ++j) {
        int x, y;
        cin >> x >> y;
        dum.push_back({x, y});
      }
      v.push_back(dum);
    }
    solve();
    for(int i = 0; i < ans.size(); ++i)
      cout << ans[i] + 1 << endl;
    cout << "+++++" << endl;
    mom[0].erase(mom[0].begin(), mom[0].end());
    v.erase(v.begin(), v.end());
    ans.erase(ans.begin(), ans.end());
  }
  return 0;
}
void solve() {
  m = mom[0].size();
  for(int i = 0; i < n; ++i)
    for(int j = 0; j < 2; ++j)
      if(ch(i, 0, j) || ch(i, 1, j)) {
        ans.push_back(i);
        break;
      }
}

bool ch(int x, bool y, int z) {
  bool nowans = 0;
  if(z == 0) z = -1;
  if(v[x].size() != m) return 0;
  for(int i = 1; i < m; ++i) {
    p nv, nm;
    nv = {(v[x][i].fi - v[x][i - 1].fi) * z,
          (v[x][i].se - v[x][i - 1].se) * z};
    nm = {mom[y][i].fi - mom[y][i - 1].fi,
          mom[y][i].se - mom[y][i - 1].se};
    if(nv != nm) break;
    if(i == m - 1) nowans = 1;
  }

  for(int i = 1; i < m; ++i) {
    p nv, nm;
    nv = {(v[x][i].se - v[x][i - 1].se) * z,
          -(v[x][i].fi - v[x][i - 1].fi) * z};
    nm = {mom[y][i].fi - mom[y][i - 1].fi,
          mom[y][i].se - mom[y][i - 1].se};
    if(nv != nm) break;
    if(i == m - 1) nowans = -1;
  }
  return nowans;
}
