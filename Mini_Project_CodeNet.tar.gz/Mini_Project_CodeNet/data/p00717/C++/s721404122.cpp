#include <iostream>
#include <vector>

using namespace std;

bool check_line(vector<int>& td, vector<int>& data) {
  for (size_t i = 0; i < td.size(); ++i) {
    if (td[i] != data[i]) {
      break;
    }
    else if (i == td.size()-1 && td[i] == data[i]) {
      return true;
    }
  }
  for (size_t i = 0; i < td.size(); ++i) {
    if (i%2 == 0) {
      if (td[i] != data[td.size()-i-1]) {
        break;
      }
      if (i == td.size()-1 && td[i] == data[td.size()-i-1]) {
        return true;
      }
    }
    else {
      if (td[i] != -data[td.size()-i-1]) {
        break;
      }
    }
  }
  return false;
}

int main(void) {
  int n;
  while (cin >> n,n) {
    vector< vector<int> > lsx(n+1),lsy(n+1);
    vector<bool> eq(n+1,true);
    int m,x,y,len;
    for (int i = 0; i < n+1; ++i) {
      cin >> m;
      if (i == 0) {
        len = m;
      }
      else if (len != m) {
        eq[i] = false;
      }
      for (int j = 0; j < m; ++j) {
        cin >> x >> y;
        lsx[i].push_back(x);
        lsy[i].push_back(y);
      }
    }
    
    vector< vector<int> > data(n+1);
    int dirx = 1;
    int diry = 1;
    for (int l = 0; l < n+1; ++l) {
			dirx = 1;
			diry = 1;
      for (int i = 0; i < len-1; ++i) {
        if (lsx[l][i] == lsx[l][i+1]) {
          if (lsy[l][i] > lsy[l][i+1]) {
            if (i > 0) {
              data[l].push_back(dirx);
            }
						diry = -1;
            data[l].push_back(lsy[l][i]-lsy[l][i+1]);
          }
          else {
            if (i > 0) {
              data[l].push_back(-dirx);
            }
						diry = 1;
            data[l].push_back(lsy[l][i+1]-lsy[l][i]);
          }
        }
        else {
          if (lsx[l][i] > lsx[l][i+1]) {
            if (i > 0) {
              data[l].push_back(-diry);
						}
						dirx = -1;
            data[l].push_back(lsx[l][i]-lsx[l][i+1]);
          }
          else {
            if (i > 0) {
              data[l].push_back(diry);
            }
						dirx = 1;
            data[l].push_back(lsx[l][i+1]-lsx[l][i]);
          }
        }
      }
    }
    
    for (int i = 1; i < n + 1; ++i) {
      if (eq[i]) {
        if (check_line(data[0],data[i])) {
          cout << i << endl;
        }
      }
    }
    cout << "+++++" << endl;
  }
  return 0;
}