#include<bits/stdc++.h>
using namespace std;

int getDir(int x1, int y1, int x2, int y2)
{
  if(x1 == x2) {
    if(y1 < y2) return(1);
    else        return(3);
  } else {
    if(x1 < x2) return(0);
    else        return(2);
  }
}

int main()
{
  int N;
  while(cin >> N, N) {
    vector< vector< pair< int, int > > > lines(N + 1);
    vector< vector< pair< int, int > > > relines(N + 1);

    for(int i = 0; i <= N; i++) {
      int M;
      cin >> M;
      vector< int > x(M), y(M);
      for(int j = 0; j < M; j++) cin >> x[j] >> y[j];

      for(int k = 0; k < 2; k++) {

        for(int j = 1; j < M; j++) {
          lines[i].push_back({abs(x[j] - x[j - 1]) + abs(y[j] - y[j - 1]), getDir(x[j - 1], y[j - 1], x[j], y[j])});
        }
        int base = lines[i][0].second;
        for(auto& l : lines[i]) l.second = (l.second - base + 8) % 4;
        reverse(x.begin(), x.end());
        reverse(y.begin(), y.end());
        swap(lines, relines);
      }
    }

    for(int i = 1; i <= N; i++) {
      if(lines[i] == relines[0] || lines[i] == lines[0]) cout << i << endl;
    }
    cout << "+++++" << endl;
  }
}