//#include "bits/stdc++.h"

#include <iostream>
#include <vector>
// #include <map>
// #include <string>
#include <algorithm>
// #include <numeric>
// #include <limits>

using namespace std;

struct Point {
	int x;
	int y;
};

using PolygonalLine = vector<Point>;

vector<PolygonalLine> lines;

void print(PolygonalLine line) {
	cout << "+ " << line.size() << endl;
	for (auto point : line) {
		cout << "  " << point.x << " " << point.y << endl;
	}
}

void rotate(PolygonalLine& line, int a, int b, int c, int d) {
	for (auto& point : line) {
		int x = point.x;
		int y = point.y;
		point.x = a * x + b * y;
		point.y = c * x + d * y;
	}
}

void rotate(PolygonalLine& line, int angle) {
	if (angle == 180) {
		rotate(line, -1, 0, 0, -1);
	} else if (angle == 270) {
		rotate(line, 0, 1, -1, 0);
	} else if (angle == 90) {
		rotate(line, 0, -1, 1, 0);
	}
}

void shift(PolygonalLine& line) {
	int x = line[0].x;
	int y = line[0].y;
	for (auto& point : line) {
		point.x -= x;
		point.y -= y;
	}
}

// align to line[1].x > line[0].x
void align(PolygonalLine& line) {
	if (line[1].x - line[0].x > 0) {
		return;
	} else if (line[1].x - line[0].x < 0) {
		rotate(line, 180);
	} else if (line[1].y - line[0].y > 0) {
		rotate(line, 270);
	} else if (line[1].y - line[0].y < 0) {
		rotate(line, 90);
	}
	shift(line);
}

void inputLine() {
	PolygonalLine line;
	int m;
	cin >> m;
	// std::cout << "debug m " << m << std::endl; // debug
	line.resize(m);
	for (int i = 0; i < m; i++) {
		Point point;
		cin >> point.x >> point.y;
		// std::cout << "debug point " << point.x << " " << point.y << std::endl; // debug
		line[i] = point;
	}
	align(line);
	lines.push_back(line);
}

bool isSame(const Point& p1, const Point& p2) {
	return p1.x == p2.x and p1.y == p2.y;
}

bool isSame(const PolygonalLine& l1, const PolygonalLine& l2) {
	if (l1.size() != l2.size()) {
		return false;
	}
	for (size_t i = 0; i < l1.size(); i++) {
		if (isSame(l1[i], l2[i]) == false) {
			return false;
		}
	}
	return true;
}

void solve(int n) {
	lines.clear();
	for (int i = 0; i < n + 1; i++) {
		inputLine();
	}
	PolygonalLine rev_line = lines[0];
	reverse(rev_line.begin(), rev_line.end());
	align(rev_line);
	for (size_t i = 1; i < lines.size(); i++) {
		// print(lines[i]); // debug
		if (isSame(lines[0], lines[i]) or isSame(rev_line, lines[i])) {
			cout << i << endl;
		}
	}
	cout << "+++++" << endl;
}

int main() {
	int n;
	cin >> n;
	while (n != 0) {
		// std::cout << "debug n " << n << std::endl; // debug
		solve(n);
		cin >> n;
	}
	// std::cout << "\e[38;5;0m\e[48;5;40m --- end ---  \e[m" << std::endl; // debug
	return 0;
}