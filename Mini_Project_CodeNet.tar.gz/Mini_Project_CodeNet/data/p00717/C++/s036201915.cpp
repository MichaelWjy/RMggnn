#include<bits/stdc++.h>
using namespace std;
typedef pair<int,int> P;

int rec(vector<P> a,vector<P> b){
  if(a.size()!=b.size())return 0;
  for(int i=0;i<a.size();i++){
    if(a[i].second-a[0].second!=b[i].second-b[0].second)return 0;
    if(a[i].first-a[0].first!=b[i].first-b[0].first)return 0;
  }
  return 1;
}

int main(){
  int n;
  while(cin>>n,n){
  vector<P> v[55];
  for(int i=0;i<=n;i++){
    int m;
    cin>>m;
    for(int j=0;j<m;j++){
      int x,y;
      cin>>x>>y;
      v[i].push_back(P(x,y));
    }
  }
  vector<P> t[8];
  int s=v[0].size();
  for(int i=0;i<s;i++){
    int x=v[0][i].first;
    int y=v[0][i].second;
    t[0].push_back(P(x,y));
    t[1].push_back(P(-x,-y));
    t[2].push_back(P(y,-x));
    t[3].push_back(P(-y,x));
    x=v[0][s-1-i].first;
    y=v[0][s-1-i].second;
    t[4].push_back(P(x,y));
    t[5].push_back(P(-x,-y));
    t[6].push_back(P(y,-x));
    t[7].push_back(P(-y,x));
  }
  for(int i=1;i<=n;i++){
    int f=0;
    for(int j=0;j<8;j++){
      if(rec(v[i],t[j]))f=1;
    }
    if(f)cout<<i<<endl;
  }
  cout<<"+++++"<<endl;
}
  return 0;
  
}

