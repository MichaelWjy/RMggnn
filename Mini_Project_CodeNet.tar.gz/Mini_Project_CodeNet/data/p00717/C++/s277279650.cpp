#include<cmath>
#include<cassert>
#include<string>
#include<vector>
#include<queue>
#include<stack>
#include<set>
#include<map>
#include<algorithm>
#include <iostream>
#include<utility>
using namespace std;

#define X first
#define Y second

vector<long> find_line;
vector<vector<long> > data;
vector<vector<long> > rev_data;

int n;

int outer_product(pair<int, int> a, pair<int, int> b) {
  return (a.X * b.Y - b.X * a.Y) > 0 ? 1 : -1;
}

long sqr_len(pair<int, int> a) {
  return a.X * a.X + a.Y * a.Y;
}

pair<int, int> mkvec(pair<int, int> a, pair<int, int> b) {
  return pair<int, int>(a.X - b.X, a.Y - b.Y);
}

void init() { 
  n=0;
  find_line.clear();
  data.clear();
  rev_data.clear();
}

vector<long> input_dataset() {
  vector<long> ret;
  int x[16], y[16];
  int m;
  pair<int, int> vec, prev_vec;

  cin >> m;
  for(int i=0;i<m;i++){
    cin >> x[i] >> y[i];
  }

  prev_vec = mkvec(pair<int, int>(x[0], y[0]), pair<int, int>(x[1], y[1]));
  ret.push_back(sqr_len(prev_vec));
  for(int i = 2; i < m; i++) {
    vec = mkvec(pair<int, int>(x[i - 1], y[i - 1]), pair<int, int>(x[i], y[i]));
    ret.push_back(outer_product(prev_vec, vec) * sqr_len(vec));
    prev_vec = vec;
  }
  vector<long > res=ret;
  data.push_back(ret);
  
  ret.clear();
  vec=prev_vec= make_pair(0,0);
  prev_vec = mkvec(pair<int, int>(x[m - 1], y[m - 1]), pair<int, int>(x[m-2], y[m-2]));
  ret.push_back(sqr_len(prev_vec));
  for(int i = m-3; i>-1; i--) {
    vec = mkvec(pair<int, int>(x[i+1], y[i+1]), pair<int, int>(x[i], y[i]));
    ret.push_back(outer_product(prev_vec, vec) * sqr_len(vec));
    prev_vec = vec;
  }
  rev_data.push_back(ret);
  return res;
}


bool input() {
  cin >> n;
  if(n == 0){
    return false;
  }

  find_line = input_dataset();
  for(int i = 1; i <= n; i++) {
    input_dataset();
  }
  
  
 /* 
  for(int i=1;i<find_line.size();i++){
    cout<<find_line[i]<<" ";
  }cout<<endl;
  for(int i=1;i<data.size();i++){
    cout<<"nor:";
    for(int j=0;j<data[i].size();j++){
      cout<<data[i][j]<<" ";
    }cout<<endl;
  }
  for(int i=0;i<data.size();i++){
    cout<<"rev"<<i<<":";
    for(int j=0;j<data[i].size();j++){
      cout<<data[i][j]<<" ";
    }cout<<endl;
  }
*/

  return true;
}

void solve() {
  for(int i = 1; i < data.size(); i++) {
    if(find_line.size() != data[i].size())
      continue;
    int j = 0;
    for(; j < find_line.size(); j++) {
      if(find_line[j] != data[i][j])
        break;
    }
    if(j == find_line.size()) {
      cout << i  << endl;
      continue;
    }
    for(; j < find_line.size(); j++) {
      if(find_line[j] != rev_data[i][j])
        break;
    }
    if(j == find_line.size()) {
      cout << i << endl;
      continue;
    }
  }
}

int main() {
  while(init(), input()) {
    solve();
    cout << "+++++" << endl;
  }
}