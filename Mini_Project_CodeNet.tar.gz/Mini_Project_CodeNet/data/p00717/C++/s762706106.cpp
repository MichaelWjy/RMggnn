#include <iostream>
#include <vector>
#include <utility>
#include <algorithm>

using namespace std;


struct Line {
    int length;
    int direction;

    Line(int _l, int _d) : length(_l), direction(_d) {}

    bool operator==(const Line& l) const {
        return length == l.length && direction == l.direction;
    }

    bool operator!=(const Line& l) const {
        return !(*this == l);
    }
};

struct Point {
    int x;
    int y;
    Point(int _x, int _y) : x(_x), y(_y) {}
};

using PolygonalLine = pair<vector<Line>, vector<Line>>;

PolygonalLine
converter(vector<Point> points) {
    vector<Line> lines, lines_back;
    for(int i = 0; i < points.size() - 1; ++i) {
        int dx = points[i+1].x - points[i].x;
        int dy = points[i+1].y - points[i].y;
        if(dx == 0) {
            if(dy > 0)      lines.emplace_back(dy, 1);
            else if(dy < 0) lines.emplace_back(-dy, 3);
        } else if(dy == 0) {
            if(dx > 0)      lines.emplace_back(dx, 0);
            else if(dx < 0) lines.emplace_back(-dx, 2);
        }
    }
    int rotate;
    rotate = 4 - lines[0].direction;
    for(int i = 0; i < lines.size(); i++) {
        lines[i].direction = (lines[i].direction + rotate) % 4;
    }
    for(int i = points.size() - 1; i > 0; --i) {
        int dx = points[i-1].x - points[i].x;
        int dy = points[i-1].y - points[i].y;
        if(dx == 0) {
            if(dy > 0)      lines_back.emplace_back(dy, 1);
            else if(dy < 0) lines_back.emplace_back(-dy, 3);
        } else if(dy == 0) {
            if(dx > 0)      lines_back.emplace_back(dx, 0);
            else if(dx < 0) lines_back.emplace_back(-dx, 2);
        }
    }
    rotate = 4 - lines_back[0].direction;
    for(int i = 0; i < lines_back.size(); i++) {
        lines_back[i].direction = (lines_back[i].direction + rotate) % 4;
    }
    return make_pair(lines, lines_back);
}

int main() {
    while(true) {
        int n; cin >> n;
        if(n == 0) break;
        vector<PolygonalLine> plines;
        for(int i = 0; i <= n; ++i) {
            int m; cin >> m;
            vector<Point> points;
            for(int j = 0; j < m; ++j) {
                int x, y;
                cin >> x >> y;
                points.emplace_back(x, y);
            }
            plines.emplace_back(converter(points));
        }
        for(int i = 1; i <= n; ++i) {
            if(
                (plines[0].first == plines[i].first && plines[0].second == plines[i].second)
                || (plines[0].second == plines[i].first && plines[0].first == plines[i].second)
            )
            cout << i << endl;
        }
        cout << "+++++" << endl;
    }
}
// [Problem] Polygonal Line Search
// http://judge.u-aizu.ac.jp/onlinejudge/description.jsp?id=1136&lang=jp

