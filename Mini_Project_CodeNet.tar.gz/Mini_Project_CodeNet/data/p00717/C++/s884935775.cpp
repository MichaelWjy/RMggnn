#include<iostream>
#include<vector>
#include<cstdlib>
using namespace std;

struct Point {
  vector<int> data;
  vector<int> longdata;
  vector<int> roll1;
  vector<int> roll2;
  vector<int> roll3;
  vector<int> revdata;
  vector<int> revlongdata;
  vector<int> revroll1;
  vector<int> revroll2;
  vector<int> revroll3;

  void change(){
    for(int i=0;i<data.size();i+=2){
      int s,t;
      s=data[i]-data[0];
      t=data[i+1]-data[1];
      longdata.push_back(s);
      longdata.push_back(t);
    }
  }
  void rev(){
    for(int i=data.size()-2;i>=0;i-=2){
      int s=data[i];
      int t=data[i+1];
      revdata.push_back(s);
      revdata.push_back(t);
    }
  }
  void revchange(){
    for(int i=0;i<revdata.size();i+=2){
      int s,t;
      s=revdata[i]-revdata[0];
      t=revdata[i+1]-revdata[1];
      revlongdata.push_back(s);
      revlongdata.push_back(t);
    }
  }
  void roll(){
    for(int i=0;i<data.size();i+=2){
      int s,t;
      s=longdata[i];
      t=longdata[i+1];
      t*=-1;
      roll1.push_back(t);
      roll1.push_back(s);
    }
    for(int i=0;i<roll1.size();i+=2){
      int s,t;
      s=roll1[i];
      t=roll1[i+1];
      t*=-1;
      roll2.push_back(t);
      roll2.push_back(s);
    }
    for(int i=0;i<roll2.size();i+=2){
      int s,t;
      s=roll2[i];
      t=roll2[i+1];
      t*=-1;
      roll3.push_back(t);
      roll3.push_back(s);
    }
  }
  void revroll(){
    for(int i=0;i<revdata.size();i+=2){
      int s,t;
      s=revlongdata[i];
      t=revlongdata[i+1];
      t*=-1;
      revroll1.push_back(t);
      revroll1.push_back(s);
    }
    for(int i=0;i<revroll1.size();i+=2){
      int s,t;
      s=revroll1[i];
      t=revroll1[i+1];
      t*=-1;
      revroll2.push_back(t);
      revroll2.push_back(s);
    }
    for(int i=0;i<revroll2.size();i+=2){
      int s,t;
      s=revroll2[i];
      t=revroll2[i+1];
      t*=-1;
      revroll3.push_back(t);
      revroll3.push_back(s);
    }
  }
};

typedef vector<Point> vnode;

int main(void){
  int n;
  while(cin>>n,n!=0){
    vnode node;
    vector<int> data;
    int m,x,y;
    for(int i=0;i<n+1;i++){
      cin >> m;
      for(int j=0;j<m;j++){
	cin>>x>>y;
	data.push_back(x);
	data.push_back(y);
      }
      Point p;
      p.data = data;
      node.push_back(p);
      data.clear();
    }
    vnode::iterator p=node.begin();
    vnode::iterator q=node.begin();
    (*p).change();
    (*p).rev();
    (*p).roll();
    (*p).revchange();
    (*p).revroll();
    p++;
    for(int i=1;p!=node.end();p++,i++){
       (*p).change();
       if((*q).longdata==(*p).longdata) cout<<i<<endl;
       else if((*q).roll1==(*p).longdata) cout<<i<<endl;
       else if((*q).roll2==(*p).longdata) cout<<i<<endl;
       else if((*q).roll3==(*p).longdata) cout<<i<<endl;
       else if((*q).revlongdata==(*p).longdata) cout<<i<<endl;
       else if((*q).revroll1==(*p).longdata) cout<<i<<endl;
       else if((*q).revroll2==(*p).longdata) cout<<i<<endl;
       else if((*q).revroll3==(*p).longdata) cout<<i<<endl;
    }
    cout<<"+++++"<<endl;
  }
  cout<<"+++++"<<endl;
}