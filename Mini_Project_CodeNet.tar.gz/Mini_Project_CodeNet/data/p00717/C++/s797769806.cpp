#include <iostream>
#include <vector>
#include <string>
#include <map>
#include <algorithm>
#include <complex>
#include <cmath>

#define REP(i,n) for(int i=0;i<(int)(n);i++)

using namespace std;

typedef pair<int,int> P;

int main() {
  while(1){
    int n;
    cin>>n;
    if(!n)break;
    vector<vector<P>> v(n);
    vector<vector<P>> w(8);
    int m;cin>>m;
    REP(i,m){
      double x,y;
      cin>>x>>y;
      w[0].emplace_back(x,y);
      w[1].emplace_back(y,-x);
      w[2].emplace_back(-x,-y);
      w[3].emplace_back(-y,x);
    }
    REP(i,4){
      w[i+4]=vector<P>(m);
      reverse_copy(begin(w[i]),end(w[i]),begin(w[i+4]));
    }
    REP(i,8){
      int m=w[i].size();
      REP(j,m){
        if(j==0)continue;
        w[i][j].first-=w[i][0].first;
        w[i][j].second-=w[i][0].second;
      }
      w[i][0]=P(0,0);
    }
    REP(i,n){
      int m;
      cin>>m;
      REP(j,m){
        double x,y;
        cin>>x>>y;
        v[i].emplace_back(x,y);
      }
      REP(j,m){
        if(j==0)continue;
        v[i][j].first-=v[i][0].first;
        v[i][j].second-=v[i][0].second;
      }
      v[i][0]=P(0,0);
      bool ok=false;
      REP(j,8){
        if(v[i]==w[j])
          ok=true;
      }
      if(ok)
        cout<<(i+1)<<endl;
    }
    cout<<"+++++"<<endl;
  }
  return 0;
}