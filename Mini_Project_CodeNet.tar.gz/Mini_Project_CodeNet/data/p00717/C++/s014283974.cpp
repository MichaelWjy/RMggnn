#include <iostream>
#include <string>
#include <algorithm>
#include <cmath>
#include <math.h>
#include <stdlib.h>
using namespace std;
int main(){
	int n;
	while(cin>>n){
		if(n==0) break;
		int m,mm;
		cin>>m;
		int x[m],y[m];
		for(int i=0;i<m;i++){
			cin>>x[i]>>y[i];
		}
		for(int i=0;i<n;i++){
			cin>>mm;
			int xx[mm],yy[mm];
			for(int j=0;j<mm;j++){
				cin>>xx[j]>>yy[j];
			}
			if(m!=mm){
				goto end;
			}
			int h1,h2,k1,k2;
			int sa;
			if(x[1]-x[0]>0){
				h1=0;
				k1=x[1]-x[0];
			}
			else if(y[1]-y[0]>0){
				h1=1;
				k1=y[1]-y[0];
			}
			else if(x[1]-x[0]<0){
				h1=2;
				k1=x[0]-x[1];
			}
			else if(y[1]-y[0]<0){
				h1=3;
				k1=y[0]-y[1];
			}
			if(xx[1]-xx[0]>0){
				h2=0;
				k2=xx[1]-xx[0];
			}
			else if(yy[1]-yy[0]>0){
				h2=1;
				k2=yy[1]-yy[0];
			}
			else if(xx[1]-xx[0]<0){
				h2=2;
				k2=xx[0]-xx[1];
			}
			else if(yy[1]-yy[0]<0){
				h2=3;
				k2=yy[0]-yy[1];
			}
			sa=(h2-h1)%4;
			if(k1!=k2){
				goto aida;
			}
			for(int j=1;j<m-1;j++){
				if(x[j+1]-x[j]>0){
					h1=0;
					k1=x[j+1]-x[j];
				}
				else if(y[j+1]-y[j]>0){
					h1=1;
					k1=y[j+1]-y[j];
				}
				else if(x[j+1]-x[j]<0){
					h1=2;
					k1=x[j]-x[j+1];
				}
				else if(y[j+1]-y[j]<0){
					h1=3;
					k1=y[j]-y[j+1];
				}
				if(xx[j+1]-xx[j]>0){
					h2=0;
					k2=xx[j+1]-xx[j];
				}
				else if(yy[j+1]-yy[j]>0){
					h2=1;
					k2=yy[j+1]-yy[j];
				}
				else if(xx[j+1]-xx[j]<0){
					h2=2;
					k2=xx[j]-xx[j+1];
				}
				else if(yy[j+1]-yy[j]<0){
					h2=3;
					k2=yy[j]-yy[j+1];
				}
				if(k2!=k1||(h1+sa)%4!=h2){
					goto aida;
				}
			}
			cout<<i+1<<endl;
			goto end;
			aida:;
			if(x[m-2]-x[m-1]>0){
				h1=0;
				k1=x[m-2]-x[m-1];
			}
			else if(y[m-2]-y[m-1]>0){
				h1=1;
				k1=y[m-2]-y[m-1];
			}
			else if(x[m-2]-x[m-1]<0){
				h1=2;
				k1=x[m-1]-x[m-2];
			}
			else if(y[m-2]-y[m-1]<0){
				h1=3;
				k1=y[m-1]-y[m-2];
			}
			if(xx[1]-xx[0]>0){
				h2=0;
				k2=xx[1]-xx[0];
			}
			else if(yy[1]-yy[0]>0){
				h2=1;
				k2=yy[1]-yy[0];
			}
			else if(xx[1]-xx[0]<0){
				h2=2;
				k2=xx[0]-xx[1];
			}
			else if(yy[1]-yy[0]<0){
				h2=3;
				k2=yy[0]-yy[1];
			}
			sa=(h2-h1)%4;
			if(k1!=k2){
				goto end;
			}
			for(int j=1;j<m-1;j++){
				if(x[m-j-2]-x[m-j-1]>0){
					h1=0;
					k1=x[m-j-2]-x[m-j-1];
				}
				else if(y[m-j-2]-y[m-j-1]>0){
					h1=1;
					k1=y[m-j-2]-y[m-j-1];
				}
				else if(x[m-j-2]-x[m-j-1]<0){
					h1=2;
					k1=x[m-j-1]-x[m-j-2];
				}
				else if(y[m-j-2]-y[m-j-1]<0){
					h1=3;
					k1=y[m-j-1]-y[m-j-2];
				}
				if(xx[j+1]-xx[j]>0){
					h2=0;
					k2=xx[j+1]-xx[j];
				}
				else if(yy[j+1]-yy[j]>0){
					h2=1;
					k2=yy[j+1]-yy[j];
				}
				else if(xx[j+1]-xx[j]<0){
					h2=2;
					k2=xx[j]-xx[j+1];
				}
				else if(yy[j+1]-yy[j]<0){
					h2=3;
					k2=yy[j]-yy[j+1];
				}
				if(k2!=k1||(h1+sa)%4!=h2){
					goto end;
				}
			}
			cout<<i+1<<endl;
			end:;
		}
		cout<<"+++++"<<endl;
	}
    return 0;
}