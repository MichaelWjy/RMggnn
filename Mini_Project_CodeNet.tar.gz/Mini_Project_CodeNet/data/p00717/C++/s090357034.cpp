#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>

#define all(c) (c).begin(),(c).end()

using namespace std;

const double EPS=1e-10;

double add(double a,double b){
	if(abs(a+b)<EPS*(abs(a)+abs(b)))return 0;
	return a+b;
}

struct point{
	double x,y;
	point(){}
	point(double x,double y):x(x),y(y){}
	point operator + (point p){return point(add(x,p.y),add(y,p.y));}
	point operator - (point p){return point(add(x,-p.y),add(y,-p.y));}
	bool operator == (const point &p)const{return abs(x-p.x)<EPS && abs(y-p.y)<EPS;}
};

double dot(point a, point b){return (a.x * b.x + a.y * b.y);}
double cross(point a, point b){return (a.x * b.y - a.y * b.x);}
double norm(point a){return sqrt(a.x*a.x+a.y*a.y);}
double dist(point a,point b){return sqrt(pow(a.x-b.x,2)+pow(a.y-b.y,2));}

int ccw(point a, point b, point c) {
  b =b-a,c=c-a;
  if (cross(b, c) > 0)   return 1;
  if (cross(b, c) < 0)   return -1;

  //return 0;
}

int main(void){
	
	int n,m;
	
	while(cin >> n,n){
		vector<point>p[51];
		for(int i=0;i<n+1;i++){
			cin >> m;
			for(int j=0;j<m;j++){
				point in;
				cin >> in.x >> in.y;
				p[i].push_back(in);
			}
		}
		
		
		for(int i=1;i<=n;i++){
			
			if(p[0].size()!=p[i].size())continue;
			
			for(int j=0;j<p[i].size()-1;j++)
				if(dist(p[0][j],p[0][j+1])!=dist(p[i][j],p[i][j+1]))goto end;
			
			for(int j=1;j<p[i].size()-1;j++)
				if(ccw(p[0][j-1],p[0][j],p[0][j+1])!=ccw(p[i][j-1],p[i][j],p[i][j+1]))goto end;
			
			cout << i << endl;
			continue;
			end:;
			reverse(p[i].begin(),p[i].end());
			
			for(int j=0;j<p[i].size()-1;j++)
				if(dist(p[0][j],p[0][j+1])!=dist(p[i][j],p[i][j+1]))goto loopend;
			
			for(int j=1;j<p[i].size()-1;j++)
			if(ccw(p[0][j-1],p[0][j],p[0][j+1])!=ccw(p[i][p[i].size()-j-2],p[i][p[i].size()-j-1],p[i][p[i].size()-j]))goto loopend;
			
			cout << i << endl;
			loopend:;
		}
		
		
		cout << "+++++" << endl;
	}
	
	
	return 0;
}