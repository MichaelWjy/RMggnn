#include <iostream>
#include <set>

using namespace std;

double max(double a,double b){
	if(a>=b)return a;
	else return b;
}

double min(double a,double b){
	if(a>=b)return b;
	else return a;
}

class polygon_obj{

public:
	int m;
	double x[10];
	double y[10];

	double maxX,minX,maxY,minY;
};

int main(){

	int n;

	polygon_obj poly[51];

	while(cin>>n){
		if(n==0)break;
		set<int> ans;

		for(int i=0;i<=n;i++){
			poly[i].maxX=-50000;
			poly[i].minX=50000;
			poly[i].maxY=-50000;
			poly[i].minY=50000;
		}

		for(int i=0;i<=n;i++){
			int m;
			cin>>poly[i].m;
			for(int j=0;j<poly[i].m;j++){
				cin>>poly[i].x[j]>>poly[i].y[j];
				poly[i].maxX = max(poly[i].maxX,poly[i].x[j]);
				poly[i].minX = min(poly[i].minX,poly[i].x[j]);
				poly[i].maxY = max(poly[i].maxY,poly[i].y[j]);
				poly[i].minY = min(poly[i].minY,poly[i].y[j]);
			}

			//???????????????????????????????????????????????§?¨????????´¢???
			//??????????????§?¨????0,0??????????§????????????????
			double centerX=(poly[i].maxX+poly[i].minX)/2.0;
			double centerY=(poly[i].maxY+poly[i].minY)/2.0;

			for(int j=0;j<poly[i].m;j++){
				poly[i].x[j]-=centerX;
				poly[i].y[j]-=centerY;
			}
		}

		for(int i=0;i<4;i++){
			//90????????¢????????????
			
			for(int j=0;j<poly[i].m;j++){
				double tmpX = poly[0].x[j];
				double tmpY = poly[0].y[j];
				poly[0].x[j] = -tmpY;
				poly[0].y[j] = tmpX;
			//	cout<<poly[0].x[j]<<poly[0].y[j]<<endl;
			}

			//cout<<endl<<endl;



			//??????????????¨????´¢????????????
			for(int j=1;j<=n;j++){
				int ansFlag=0;
				if(poly[0].m!=poly[j].m){
					continue;
				}
				for(int k=0;k<poly[0].m;k++){
					if(poly[0].x[k]!=poly[j].x[k] || 
						poly[0].y[k]!=poly[j].y[k]){
						ansFlag=1;
						break;
					}
				}
				if(ansFlag==0){
					ans.insert(j);
					continue;
				}
				ansFlag=0;
				for(int k=0;k<poly[0].m;k++){
					if(poly[0].x[poly[0].m-k-1]!=poly[j].x[k] || 
						poly[0].y[poly[0].m-k-1]!=poly[j].y[k]){
						ansFlag=1;
						break;
					}
				}
				if(ansFlag==0){
					ans.insert(j);
					continue;
				}
			}

		}

		//cout<<"UNKO"<<endl;
		for(set<int>::iterator it = ans.begin();it!=ans.end();it++){
			cout<<*it<<endl;
		}
		cout<<"+++++"<<endl;


	}
	return 0;

}