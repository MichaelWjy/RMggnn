#include<cstdio>
#include<iostream>
#include<algorithm>
#include<vector>
#include<string>
#include<sstream>
#include<queue>
#include<cstdlib>
#include<cmath>

using namespace std;

#define reps(i,f,n) for(int i=f;i<int(n);i++)
#define rep(i,n) reps(i,0,n)


class Line{
	public:
	int x,y;
	Line(int x,int y):x(x),y(y){}
	bool operator!=(const Line& line)const{
		if(fabs(line.x-x)>0.001)return true;
		if(fabs(line.y-y)>0.001)return true;
		return false;
	}
};

int getarg(Line line){
	int par = 1;
	if(line.x>0)return par*0;
	if(line.x<0)return par*2;
	if(line.y>0)return par*1;
	if(line.y<0)return par*3;
	return 0;
}

void henkan(vector<Line>& lines, int arg){
	rep(i,lines.size()){
		int x = lines[i].x;
		int y = lines[i].y;
		rep(j,arg){
			int bin = x;
			x = y;
			y = -bin;
		}
		
		lines[i] = Line(x,y);
	}
}

int main(){
	while(1){
		int n;
		cin>>n;
		if(n==0)break;
		
		vector<Line> moto;
		
		rep(i,n+1){
			int m;
			cin>>m;
			
			int a,b;
			cin>>a>>b;
			
			vector<Line> lines;
			rep(j,m-1){
				int c,d;
				cin>>c>>d;
				lines.push_back(Line(c-a,d-b));
				a=c; b=d;
			}
			
			vector<Line> lines2;
			for(int i=lines.size()-1;i>=0;i--){
				lines2.push_back(lines[i]);
			}
			int arg2 = getarg(lines2[0]);
			henkan(lines2,arg2);
			
			int arg = getarg(lines[0]);
			henkan(lines, arg);
			
			/*
			printf("arg = %d\n",arg);
			rep(i,lines.size()){
				printf("%d %d\n",lines[i].x, lines[i].y);
			}*/
			
			
			if(i==0){
				moto = lines;
			}else{
				bool same = true;
				bool same2 = true;
				rep(i,lines.size()){
					if(lines[i] != moto[i])same = false;
					if(lines2[i] != moto[i])same2 = false;
				}
				if(same || same2)printf("%d\n",i);
			}
		}
		
		printf("+++++\n");
	}
}