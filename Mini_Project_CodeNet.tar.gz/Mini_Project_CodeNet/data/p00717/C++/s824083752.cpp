#include <bits/stdc++.h>
using namespace std;

int main(){
    while (1){
        int n;
        cin >> n;
        if (n == 0) break;
        int m;
        cin >> m;
        vector<int> ox(m);
        vector<int> oy(m);
        for (int i = 0; i < m; i++){
            cin >> ox[i] >> oy[i];
        }
        vector<int> dx(m, 0);
        vector<int> dy(m, 0);
        vector<int> rev_dx(m, 0);
        vector<int> rev_dy(m, 0);
        for (int i = 1; i < m; i++){
            dx[i] = ox[i] - ox[i-1];
            dy[i] = oy[i] - oy[i-1];
            rev_dx[i] = ox[m - i - 1] - ox[m - i];
            rev_dy[i] = oy[m - i - 1] - oy[m - i];
        }

        for (int i = 0; i < n; i++){
            cin >> m;
            vector<int> ix(m);
            vector<int> iy(m);
            vector<int> sx(m, 0);
            vector<int> sy(m, 0);
            for (int j = 0; j < m; j++){
                cin >> ix[j] >> iy[j];
            }
            for (int j = 1; j < m; j++){
                sx[j] = ix[j] - ix[j-1];
                sy[j] = iy[j] - iy[j-1];
            }
            if ((sx == dx && sy == dy) || (sx == rev_dx && sy == rev_dy)){
                cout << i + 1 << endl;
                continue;
            }
            for (int j = 0; j < m; j++) sx[j] = -sx[j];
            if ((sy == dx && sx == dy) || (sy == rev_dx && sx == rev_dy)){
                cout << i + 1 << endl;
                continue;
            }
            for (int j = 0; j < m; j++) sy[j] = -sy[j];
            if ((sx == dx && sy == dy) || (sx == rev_dx && sy == rev_dy)){
                cout << i + 1 << endl;
                continue;
            }
            for (int j = 0; j < m; j++) sx[j] = -sx[j];
            if ((sy == dx && sx == dy) || (sy == rev_dx && sx == rev_dy)){
                cout << i + 1 << endl;
                continue;
            }
        }
        cout << "+++++" << endl;
    }
}

