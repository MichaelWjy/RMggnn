#include <cstdio>

using namespace std;


void make_data();
int ab(int a);
int hanten(int a);


int n;				
int m0;
int m;
int len0[9];		
int direct0[8];		
int len[9];		
int direct[8];	
int x[10];
int y[10];

int main()
{
	for (;;)
	{
		scanf("%d", &n);

		if (n==0) return 0;
		
		
		
		
		
		scanf("%d", &m0);
		for (int i=0; i<m0; i++)
		{
			scanf("%d %d", &x[i], &y[i]);
		}
		
		for (int i=0; i<m0-1; i++)
		{
			if (ab(x[i+1]-x[i]) > ab(y[i+1]-y[i]))
			{
				len0[i] = ab(x[i+1]-x[i]);
			}
			else
			{
				len0[i] = ab(y[i+1]-y[i]);
			}
		}
		for (int i=0; i<m0-2; i++)
		{
			if (ab(x[i+1]-x[i]) > ab(y[i+1]-y[i]))
			{
				if (x[i+1]-x[i] > 0)
				{
					if (y[i+2]-y[i+1] > 0)
					{
						direct0[i] = -2;
					}
					else
					{
						direct0[i] = -1;
					}
				}
				else
				{
					if (y[i+2]-y[i+1] > 0)
					{
						direct0[i] = -1;
					}
					else
					{
						direct0[i] = -2;
					}
				}
			}
			else
			{
				if (y[i+1]-y[i] > 0)
				{
					if(x[i+2]-x[i+1] > 0)
					{
						direct0[i] = -1;
					}
					else
					{
						direct0[i] = -2;
					}
				}
				else
				{
					if (x[i+2]-x[i+1] > 0)
					{
						direct0[i] = -2;
					}
					else
					{
						direct0[i] = -1;
					}
				}
			}	
		}
		
		
		for (int i=0; i<n; i++)
		{
			make_data();
			
			bool flag1 = true;
			bool flag2 = true;
			for (int i2=0; i2<m-1; i2++)
			{
				if (len0[i2]!=len[i2])
				{
					flag1 = false;
				}
				if (len0[i2]!=len[m-2-i2])
				{
					flag2 = false;
				}
			}
			for (int i2=0; i2<m-2; i2++)
			{
				if (direct0[i2]!=direct[i2])
				{
					flag1 = false;
				}
				if (direct0[i2]!=hanten(direct[m-3-i2]))
				{
					flag2 = false;
				}
			}
			if (flag1 || flag2) printf("%d\n", i+1);
		}

		printf("+++++\n");
	
	}

}



void make_data()
{
	scanf("%d", &m);
	for (int i=0; i<m; i++)
	{
		scanf("%d %d", &x[i], &y[i]);
	}
	for (int i=0; i<m-1; i++)
	{
		if (ab(x[i+1]-x[i]) > ab(y[i+1]-y[i]))
		{
			len[i] = ab(x[i+1]-x[i]);
		}
		else
		{
			len[i] = ab(y[i+1]-y[i]);
		}
	}
	for (int i=0; i<m-2; i++)
	{
		if (ab(x[i+1]-x[i]) > ab(y[i+1]-y[i]))
		{
			if (x[i+1]-x[i] > 0)
			{
				if (y[i+2]-y[i+1] > 0)
				{
					direct[i] = -2;
				}
				else
				{
					direct[i] = -1;
				}
			}
			else
			{
				if (y[i+2]-y[i+1] > 0)
				{
					direct[i] = -1;
				}
				else
				{
					direct[i] = -2;
				}
			}
		}
		else
		{
			if (y[i+1]-y[i] > 0)
			{
				if(x[i+2]-x[i+1] > 0)
				{
					direct[i] = -1;
				}
				else
				{
					direct[i] = -2;
				}
			}
			else
			{
				//次に、↓
				if (x[i+2]-x[i+1] > 0)
				{
					//そして、→
					direct[i] = -2;
				}
				else
				{
					//そして、←
					direct[i] = -1;
				}
			}
		}	
	}

}

int hanten(int a)
{
	if (a==-1) return -2;
	else return -1;
}

int ab(int a)
{
	if (a>0) return a;
	else return -a;
}