#include <iostream>
#include <sstream>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <ctime>
#include <cstring>
#include <climits>
#include <algorithm>
#include <map>
#include <set>
#include <stack>
#include <vector>
#include <queue>
#include <string>
#include <complex>
using namespace std;

#define rep(i,n) for(int i=0; i<n; i++)
#define repa(i,s,e) for(int i=s; i<=e; i++)
#define repd(i,s,e) for(int i=s; i>=e; i--)

typedef long long ll;
typedef unsigned long long ull;
typedef vector<int> vi;
typedef pair<int, int> pii;

typedef complex<int> ci;

int n, m, x, y;
vector<vector<ci> > v;

bool equiv(vector<ci>& a, vector<ci>& b) {
	int np = a.size();
	if(np != b.size()) return false;

	repd(i,np-1,0) {
		a[i] -= a[0];
		b[i] -= b[0];
	}

	ci rot(0, 1);
	rep(i,4) {
		bool ret = true;
		rep(j,np) {
			if(a[j] != b[j]) {
				ret = false;
				break;
			}
		}
		if(ret) return true;

		rep(j,np) b[j] *= rot;
	}

	rep(i,np) {
		b[i] -= b[np-1];
	}
	
	rep(i,4) {
		bool ret = true;
		rep(j,np) {
			if(a[j] != b[np-j-1]) {
				ret = false;
				break;
			}
		}
		if(ret) return true;
		
		rep(j,np) b[j] *= rot;
	}

	return false;
}

void solve() {
	set<int> s;
	repa(i,1,n) {
		if(equiv(v[0], v[i])) {
			cout << i << endl;
		}
	}
	cout << "+++++" << endl;
}

int main() {
	while(cin>>n,n) {
		v = vector<vector<ci> >(n+1);
		rep(i,n+1) {
			cin >> m;
			v[i] = vector<ci>(m);
			rep(j,m) {
				cin >> x >> y;
				v[i][j] = ci(x, y);
			}
		}
		solve();
	}
}